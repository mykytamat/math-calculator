"""Translation of finished responses (lang option; the page has its own table, static/js/i18n.js).

The solvers write English; a response is translated at the very end, so no calculation can depend
on the language. The table (locale_ru.py) maps English templates to Russian, {} standing for a
value that varies. Math between $...$ is left alone, except for words in \\text{...}.

Messages are often assembled from parts ("It converges: " + reason), so a value matched by {} is
translated in turn, and a text that matches no template as a whole is split into sentences.
"""
from __future__ import annotations

import re

# Fields holding text for people, and fields holding LaTeX (only their \text{...} is translated).
_TEXT_KEYS = {"message", "hint", "label", "warning", "caption", "title", "text", "notes", "columns"}
_LATEX_KEYS = {"latex", "copy", "summary_latex", "rows"}
_LETTERS = re.compile(r"[A-Za-z]{2}")
_TEXT_IN_LATEX = re.compile(r"\\text\{([^{}]*)\}")
_MATH = re.compile(r"\$[^$]*\$")
_HOLE = re.compile(r"\{(\d*)\}")
_tables: dict[str, "_Table"] = {}


class _Table:
    def __init__(self, entries: dict[str, str]):
        self.exact: dict[str, str] = {}
        self.patterns: list[tuple[str, re.Pattern, str]] = []
        for key, value in entries.items():
            if "{}" not in key:
                self.exact[key.strip()] = value.strip()
                continue
            parts = key.strip().split("{}")
            rx = "(.*?)".join(re.escape(p) for p in parts)
            self.patterns.append((max(parts, key=len), re.compile(rx, re.DOTALL), value.strip()))
        # The most specific template first: "Unknown name '{}'." before "Unknown {}."
        self.patterns.sort(key=lambda p: -len(p[1].pattern))

    def whole(self, text: str) -> str | None:
        """The translation of text if it matches one entry as a whole."""
        if text in self.exact:
            return self.exact[text]
        for literal, rx, value in self.patterns:
            if literal not in text:
                continue
            m = rx.fullmatch(text)
            if m:
                return _fill(value, [self.translate(g) for g in m.groups()])
        return None

    def sentence(self, text: str) -> str | None:
        found = self.whole(text)
        if found is not None:
            return found
        # "The denominator" and "the denominator" share an entry.
        if text[:1].isupper():
            found = self.whole(text[0].lower() + text[1:])
            return found[0].upper() + found[1:] if found else None
        found = self.whole(text[:1].upper() + text[1:])
        return found[0].lower() + found[1:] if found else None

    def parts(self, text: str, separators: str = ".;") -> str | None:
        """Text that matches no entry as a whole, translated piece by piece."""
        found = self.sentence(text)
        if found is None and text[-1:] in ".;:,":
            found = self.sentence(text[:-1])
            found = found + text[-1] if found else None
        if found is not None or not separators:
            return found
        pieces = _split(text, separators[0])
        if len(pieces) < 2:
            return self.parts(text, separators[1:])
        done = [self.parts(p, separators[1:]) for p in pieces]
        return None if all(d is None for d in done) else " ".join(d or p for d, p in zip(done, pieces))

    def translate(self, text: str) -> str:
        core = text.strip()
        if not _LETTERS.search(_MATH.sub("", core)):
            return text
        found = self.parts(core)
        if found is None:
            return text
        lead = text[:len(text) - len(text.lstrip())]
        tail = text[len(text.rstrip()):]
        return lead + found + tail


def _fill(value: str, groups: list[str]) -> str:
    order = iter(groups)

    def hole(m: re.Match) -> str:
        return groups[int(m.group(1))] if m.group(1) else next(order)
    return _HOLE.sub(hole, value)


def _split(text: str, mark: str) -> list[str]:
    """Split after "<mark> " outside $...$ and brackets, keeping the mark."""
    out, start, in_math, depth = [], 0, False, 0
    for i, c in enumerate(text):
        if c == "$":
            in_math = not in_math
        elif in_math:
            continue
        elif c in "([":
            depth += 1
        elif c in ")]":
            depth -= 1
        elif c == " " and depth == 0 and text[i - 1] == mark:
            out.append(text[start:i])
            start = i + 1
    out.append(text[start:])
    return [p for p in out if p]


def _table(lang: str) -> _Table | None:
    if lang != "ru":
        return None
    if lang not in _tables:
        from .locale_ru import TEXT
        _tables[lang] = _Table(TEXT)
    return _tables[lang]


def translate(text: str, lang: str | None) -> str:
    table = _table(lang or "")
    return table.translate(text) if table else text


def _latex(table: _Table, s: str) -> str:
    return _TEXT_IN_LATEX.sub(lambda m: r"\text{" + table.translate(m.group(1)) + "}", s)


def _walk(table: _Table, node, key: str | None = None):
    if isinstance(node, dict):
        return {k: _walk(table, v, k) for k, v in node.items()}
    if isinstance(node, list):
        return [_walk(table, v, key) for v in node]
    if isinstance(node, str):
        if key in _TEXT_KEYS:
            return table.translate(node)
        if key in _LATEX_KEYS or key == "echo":
            return _latex(table, node)
    return node


def localize(response: dict, lang: str | None) -> dict:
    """The response with its text in `lang` (unchanged for English or an unknown language)."""
    table = _table(lang or "")
    return _walk(table, response) if table else response
