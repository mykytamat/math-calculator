"""Task registry: runs inside the compute worker process."""
from __future__ import annotations

import time

from .modules import calculus, equations, evaluate, graph, matrices, parameters, piecewise, sequences

TASKS = {
    "evaluate": evaluate.run,
    "piecewise": piecewise.run,
    "graph": graph.run,
    "equations": equations.run,
    "calculus": calculus.run,
    "sequences": sequences.run,
    "parameters": parameters.run,
    "matrices": matrices.run,
}


def _debug_sleep(payload: dict) -> dict:
    # Used by tests to exercise timeouts and cancellation (and partial results).
    partial = payload.get("partial") or (payload.get("options") or {}).get("partial")
    if partial:
        from .modules.common import report_partial
        report_partial(partial)
    time.sleep(float(payload.get("seconds", payload.get("input") or 1)))
    return {"ok": True, "results": [], "echo": [], "summary_latex": None}


TASKS["debug_sleep"] = _debug_sleep


def run(name: str, payload: dict) -> dict:
    if name not in TASKS:
        raise KeyError(f"Unknown task '{name}'")
    return TASKS[name](payload)


def warm_up():
    """Import and exercise SymPy once so the first real request is fast."""
    evaluate.run({"input": "sqrt(2) + sin(pi/6)", "mode": "plain"})
