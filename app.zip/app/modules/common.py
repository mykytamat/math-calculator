"""Helpers shared by the problem modules: result items, definitions, errors."""
from __future__ import annotations

import sympy as sp

from ..core.format import exact_and_decimal, tex
from ..i18n import localize
from ..parsing import A, MathError, ParseError, attach_source, parse
from ..parsing.echo import to_latex


def line(latex: str, label: str | None = None, copy: str | None = None) -> dict:
    return {"label": label, "latex": latex, "copy": copy if copy is not None else latex}


def item(node: A.Node | None, kind: str, lines: list[dict], badge: str | None = None,
         notes: list[str] | None = None, **extra) -> dict:
    d = {
        "input_latex": to_latex(node) if node is not None else None,
        "kind": kind,
        "lines": lines,
        "badge": badge,
        "notes": notes or [],
    }
    d.update(extra)
    return d


def error_item(node: A.Node | None, err: Exception, text: str | None = None) -> dict:
    if isinstance(err, ParseError):
        if text is not None:
            attach_source(err, text)
        e = err.to_dict()
    elif isinstance(err, MathError):
        e = err.to_dict()
    else:
        e = {"kind": "internal", "message": f"Internal error: {type(err).__name__}: {err}"}
    d = item(node, "error", [], badge="undefined" if e["kind"] == "math" else "error")
    d["error"] = e
    return d


def response(results: list[dict], echo: list[str] | None = None, **extra) -> dict:
    out = {"ok": True, "results": results, "echo": echo or []}
    out.update(extra)
    out["summary_latex"] = summarize(results)
    return out


def parse_error_response(err: ParseError, text: str) -> dict:
    attach_source(err, text)
    return {"ok": False, "results": [], "echo": [], "error": err.to_dict(), "summary_latex": None}


def summarize(results: list[dict]) -> str | None:
    """Short answer for the history sidebar: the last answer, skipping definitions."""
    for r in reversed(results):
        if r.get("kind") in ("definition", "assignment"):
            continue
        if r.get("lines"):
            return r["lines"][0]["latex"]
        if r.get("error"):
            return r"\text{undefined}" if r["error"].get("kind") == "math" else r"\text{error}"
    for r in results:
        if r.get("lines"):
            return r["lines"][0]["latex"]
    return None


# ------------------------------------------------------ partial results ---
# Inside the worker process this sends a provisional response to the server,
# which shows it if the computation then runs out of time or is stopped.
_partial_sink = None
_language = None


def set_partial_sink(fn) -> None:
    global _partial_sink
    _partial_sink = fn


def set_language(lang: str | None) -> None:
    global _language
    _language = lang


def report_partial(resp: dict) -> None:
    if _partial_sink is not None:
        try:
            _partial_sink(localize(resp, _language))
        except Exception:
            pass


def number_line(value: sp.Expr, places: int, label: str | None = None) -> dict:
    f = exact_and_decimal(value, places)
    return line(f["latex"], label=label)


def math_error(message: str) -> MathError:
    return MathError(message)


__all__ = ["line", "item", "error_item", "response", "parse_error_response", "number_line",
           "math_error", "tex", "parse", "ParseError", "MathError"]
