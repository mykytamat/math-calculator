"""Graph tab: plot several functions of one variable together.

Each line is one of
    f(x) = ...        (cases and recursion allowed; several lines per function)
    y = expression
    expression in one variable, e.g.  sin x / x
Options: x from / to, y from / to (empty = automatic).
"""
from __future__ import annotations

import sympy as sp

from ..core.functions import collect_definitions
from ..graphing.jsprint import to_js
from ..graphing.traces import expression_trace, function_trace, graph_spec, label_for
from ..parsing import A, MathError, ParseError, parse
from ..parsing.echo import program_to_latex
from ..parsing.to_sympy import Converter, RelChain, symbol
from .common import error_item, item, parse_error_response, response

AppliedUndef = sp.core.function.AppliedUndef
DEFAULT_WINDOW = (-10.0, 10.0)


def window_from(options: dict, default=DEFAULT_WINDOW) -> tuple[float, float]:
    """x range from the tab options (or a zoomed view sent by the browser)."""
    xr = options.get("x_range")
    if isinstance(xr, (list, tuple)) and len(xr) == 2:
        try:
            a, b = float(xr[0]), float(xr[1])
            if b > a:
                return a, b
        except (TypeError, ValueError):
            pass
    a, b = default
    if str(options.get("x_min", "")).strip() != "":
        a = _number(options["x_min"], "x range")
    if str(options.get("x_max", "")).strip() != "":
        b = _number(options["x_max"], "x range")
    if not b > a:
        raise MathError("The x range must go from a smaller to a larger number.")
    return a, b


def y_range_from(options: dict):
    lo = str(options.get("y_min", "")).strip()
    hi = str(options.get("y_max", "")).strip()
    if lo and hi:
        a, b = _number(lo, "y range"), _number(hi, "y range")
        if b > a:
            return [a, b]
    return None


def _number(text, what: str) -> float:
    """A range bound typed in an option box: 10, -2.5, 2pi, pi/2."""
    try:
        stmts = parse(str(text), "plain")
        v = Converter().expr(stmts[0]) if len(stmts) == 1 else None
        f = float(v) if v is not None and not v.free_symbols else None
    except (ParseError, MathError, TypeError, ValueError):
        f = None
    if f is None:
        raise MathError(f"The {what} must be numbers, for example -10 and 10 (pi and 2pi work too).")
    return f


def build_traces(stmts, window, depth_limit: int = 1000, only_defined: bool = False, skip=frozenset()):
    """Traces for every graphable line. Returns (traces, errors by statement index, notes).
    A trace using other letters besides x (and y) gets "params": those letters (sliders)."""
    table, defs_at, def_errors = collect_definitions(stmts)
    traces, errors, notes = [], dict(def_errors), []
    done = set()
    names = set(table.functions)
    for i, st in enumerate(stmts):
        if i in errors or i in skip:
            continue
        if i in defs_at:
            fd = defs_at[i]
            if fd.name in done:
                continue
            done.add(fd.name)
            if fd.arity == 2 and not only_defined:
                try:
                    if fd.name in table.recursive_names():
                        raise MathError(f"{fd.name} is recursive; it can't be drawn as a surface.")
                    x, y = symbol("x"), symbol("y")
                    body = _expand_functions(fd.body().subs(dict(zip(fd.params, (x, y))), simultaneous=True), table)
                    traces.append(surface_trace(body, f"{fd.name}(x, y)"))
                except Exception as e:
                    errors[i] = _line_error(e)
                continue
            if fd.arity != 1:
                notes.append(f"{fd.name} has {fd.arity} variables; only functions of one or two variables "
                             "are graphed.")
                continue
            try:
                extra = sp.sympify(fd.body()).free_symbols - set(fd.params)
                if extra and not only_defined:
                    if fd.name in table.recursive_names():
                        raise MathError(f"{fd.name} is recursive, so it can't have a slider parameter.")
                    traces.append(param_trace(fd.body(), fd.params[0], label_for(fd), extra))
                else:
                    traces.append(function_trace(table, fd, window, depth_limit))
            except Exception as e:
                errors[i] = _line_error(e)
            continue
        if only_defined:
            continue
        try:
            if _is_surface_line(st):
                traces.append(_surface_line(st, table, names))
                continue
            if _is_relation(st):
                traces.extend(_relation_traces(st, table, names, window))
                continue
            trace = _expression_line(st, table, names, window, depth_limit)
        except Exception as e:  # one line's problem must not stop the others
            errors[i] = _line_error(e)
            continue
        if trace is not None:
            traces.append(trace)
    return traces, errors, notes, table


def _line_error(e: Exception) -> Exception:
    if isinstance(e, ValueError) and "integer string conversion" in str(e):
        return MathError("A number in this line is too large to draw.")
    return e


def _names_in(node: A.Node) -> set[str]:
    return {n.name for n in A.walk(node) if isinstance(n, A.Name)}


def _is_surface_line(st: A.Node) -> bool:
    """z = f(x, y), or an expression that uses both x and y."""
    if isinstance(st, A.Rel) and st.ops == ["="] and len(st.items) == 2 and isinstance(st.items[0], A.Name) \
            and st.items[0].name == "z":
        return True
    if isinstance(st, (A.Rel, A.Logic, A.System, A.InSet, A.Conditional, A.Cases, A.Matrix, A.Seq)):
        return False
    return {"x", "y"} <= _names_in(st)


def _surface_line(st: A.Node, table, names) -> dict:
    node = st.items[1] if isinstance(st, A.Rel) else st
    conv = Converter(table.log_base, names)
    obj = conv.convert(node)
    if not isinstance(obj, sp.Expr):
        raise MathError("A surface is written z = f(x, y), for example z = x^2 - y^2.")
    from .evaluate import calculus_here
    obj = calculus_here(_expand_functions(obj, table))
    return surface_trace(obj, _plain_label(st))


def surface_trace(expr, label: str) -> dict:
    """A surface z = f(x, y), sampled by the browser (other letters are sliders)."""
    expr = sp.sympify(expr)
    js = to_js(expr)
    if js is None:
        raise MathError("This surface can't be drawn (it uses something the browser can't compute).")
    params = sorted(s.name for s in expr.free_symbols - {symbol("x"), symbol("y")})
    if "z" in params:
        raise MathError("z is the height of the surface (z = f(x, y)), so it can't be used in the formula itself.")
    return {"kind": "surface", "label": label, "js": js, "params": params}


def _is_relation(st: A.Node) -> bool:
    if isinstance(st, A.Logic) or isinstance(st, A.System):
        return True
    if isinstance(st, A.Rel):
        # y = expression is an ordinary curve; anything else is a relation in x and y.
        return not (st.ops == ["="] and isinstance(st.items[0], A.Name) and st.items[0].name == "y"
                    and "y" not in {n.name for n in A.walk(st.items[1]) if isinstance(n, A.Name)})
    return False


def _relation_traces(st: A.Node, table, names, window) -> list[dict]:
    """A curve (x^2 + y^2 = 4) or a shaded region (y > x^2, ... and ...) in the plane."""
    from ..graphing.plane import plane_graph
    from ..solving.systems import Leaf
    conv = Converter(table.log_base, names)
    nodes = st.items if isinstance(st, (A.Logic, A.System)) else [st]
    if isinstance(st, A.Logic) and st.op == "or" and any(isinstance(n, A.Rel) and "=" in n.ops for n in nodes):
        raise MathError("'or' between equations can't be drawn; put each on its own line.")
    leaves = []
    for n in nodes:
        if not isinstance(n, A.Rel):
            raise MathError("Write each part as an equation or inequality, e.g. y > x^2 and y < 4.")
        rc = conv.convert(n)
        exprs = [_expand_functions(e, table) for e in rc.exprs]
        leaves += [Leaf(a, op, b) for op, a, b in zip(rc.ops, exprs, exprs[1:])]
    free = set().union(*[lf.free() for lf in leaves])
    params = sorted(v.name for v in free - {symbol("x"), symbol("y")})
    tree_js = None
    if isinstance(st, A.Logic) and st.op == "or":
        tree_js = to_js(sp.Or(*[lf.relation() for lf in leaves]))
    spec = plane_graph(leaves, symbol("x"), symbol("y"), window, tree_js=tree_js)
    if spec is None:
        raise MathError("This relation can't be drawn.")
    label = _plain_label(st)
    for t in spec["traces"]:
        if t["kind"] == "region":
            t["label"] = label
        if params:
            t["params"] = params  # explicit curves (y = f(x) parts) don't use them, the rest are compiled
    return spec["traces"]


def param_trace(expr, x, label: str, params) -> dict:
    """A curve depending on slider parameters: compiled for the browser, which redraws it live."""
    js = to_js(expr)
    if js is None:
        raise MathError("This function can't be drawn with sliders (it uses something the browser "
                        "can't compute).")
    return {"label": label, "kind": "js", "js": js, "breaks": [], "periodic": [], "dots": [], "refetch": False,
            "params": sorted(p.name for p in params), "var": x.name}


def slider_settings(stmts):
    """Lines that set a slider: a = 2 (start value), a in [0, 5] (range). Returns (settings, line indices)."""
    settings, used = {}, set()
    for i, st in enumerate(stmts):
        name = None
        if isinstance(st, A.Rel) and st.ops == ["="] and isinstance(st.items[0], A.Name):
            name = st.items[0].name
            if name in ("x", "y", "pi", "e", "inf") or "_" in name:
                continue
            try:
                v = Converter().expr(st.items[1])
            except (MathError, ParseError):
                continue
            if v.free_symbols or not v.is_real:
                continue
            settings.setdefault(name, {})["value"] = float(v)
            used.add(i)
        elif isinstance(st, A.InSet) and isinstance(st.item, A.Name) and st.item.name not in ("x", "y") \
                and isinstance(st.set, A.Interval):
            try:
                lo, hi = Converter().expr(st.set.lo), Converter().expr(st.set.hi)
            except (MathError, ParseError):
                continue
            if lo.free_symbols or hi.free_symbols or not float(hi) > float(lo):
                continue
            settings.setdefault(st.item.name, {}).update(min=float(lo), max=float(hi))
            used.add(i)
    return settings, used


def slider_specs(traces, settings) -> list[dict]:
    names = sorted({p for t in traces for p in t.get("params", [])})
    out = []
    for n in names:
        s = settings.get(n, {})
        lo, hi = s.get("min", -5.0), s.get("max", 5.0)
        v = s.get("value", 1.0 if lo <= 1.0 <= hi else (lo + hi) / 2)
        lo, hi = min(lo, v), max(hi, v)
        out.append({"name": n, "min": lo, "max": hi, "step": (hi - lo) / 200, "value": v})
    return out


def _expand_functions(expr, table):
    for _ in range(50):
        calls = expr.atoms(AppliedUndef)
        if not calls:
            return expr
        for c in calls:
            name = c.func.__name__
            if name not in table.functions:
                raise MathError(f"{name} is not defined. Define it first, for example {name}(x) = x^2.")
            if name in table.recursive_names():
                raise MathError(f"{name} is recursive; it can't be used inside a curve or region.")
            fd = table.functions[name]
            expr = expr.xreplace({c: fd.body().subs(dict(zip(fd.params, c.args)), simultaneous=True)})
    return expr


def _expression_line(st: A.Node, table, names, window, depth_limit):
    conv = Converter(table.log_base, names)
    label_node = st
    node = st
    if isinstance(st, A.Rel) and st.ops == ["="] and isinstance(st.items[0], A.Name) and st.items[0].name == "y":
        node = st.items[1]
    obj = conv.convert(node)
    if isinstance(obj, RelChain):
        raise MathError("Write y = … or f(x) = …, or a relation in x and y such as x^2 + y^2 = 4.")
    if not isinstance(obj, sp.Expr):
        raise MathError("Only expressions can be graphed here.")
    free = obj.free_symbols
    label = _plain_label(label_node)
    if len(free) > 1:
        x = symbol("x")
        if x not in free:
            raise MathError("Use x as the variable; the other letters then become sliders.")
        if obj.atoms(AppliedUndef):
            raise MathError("Functions defined on other lines can't be combined with slider parameters yet.")
        from .evaluate import calculus_here
        return param_trace(calculus_here(obj), x, label, free - {x})
    x = next(iter(free)) if free else symbol("x")
    calls = obj.atoms(AppliedUndef)
    if calls:
        recursive = table.recursive_names()
        if any(c.func.__name__ not in table.functions for c in calls):
            missing = next(c.func.__name__ for c in calls if c.func.__name__ not in table.functions)
            raise MathError(f"{missing} is not defined. Define it first, for example {missing}(x) = x^2.")
        if any(c.func.__name__ in recursive for c in calls):
            # Plot it as a helper function so recursion is followed numerically.
            from ..core.functions import Case, FunctionDef
            helper = FunctionDef("_plot", [x], [Case(obj, "always")])
            table.functions["_plot"] = helper
            try:
                tr = function_trace(table, helper, window, depth_limit)
            finally:
                del table.functions["_plot"]
            tr["label"] = label
            return tr
        for _ in range(50):
            calls = obj.atoms(AppliedUndef)
            if not calls:
                break
            for c in calls:
                fd = table.functions[c.func.__name__]
                obj = obj.xreplace({c: fd.body().subs(dict(zip(fd.params, c.args)), simultaneous=True)})
    from .evaluate import calculus_here
    obj = calculus_here(obj)  # y = f'(x)
    return expression_trace(obj, x, label, conv.conditions, window)


def _plain_label(node: A.Node) -> str:
    from ..parsing.echo import to_plain
    s = to_plain(node)
    return s if len(s) <= 60 else s[:57] + "…"


def run(payload: dict) -> dict:
    text = payload.get("input", "")
    mode = payload.get("mode", "plain")
    options = payload.get("options", {})
    try:
        stmts = parse(text, mode)
    except ParseError as e:
        return parse_error_response(e, text)
    try:
        window = window_from(options)
    except MathError as e:
        return {"ok": False, "results": [], "echo": [], "error": e.to_dict(), "summary_latex": None}
    settings, setting_lines = slider_settings(stmts)
    all_traces, errors, notes, _ = build_traces(stmts, window, int(options.get("depth", 1000)), skip=setting_lines)
    traces = [t for t in all_traces if t["kind"] != "surface"]
    surfaces = [t for t in all_traces if t["kind"] == "surface"]
    spec = graph_spec(traces, window, notes, source={"tab": "graph"})
    spec["y_range"] = y_range_from(options)
    params = slider_specs(traces, settings)
    if params:
        spec["params"] = params
    if options.get("graph_only"):
        return {"ok": True, "graph": spec}
    results = [error_item(stmts[i], e, text) for i, e in sorted(errors.items())]
    if surfaces:
        results.insert(0, surface_item(surfaces, options, settings))
    if traces:
        results.insert(0, item(None, "graph", [], graph=spec, notes=notes + _trace_notes(traces) +
                               _slider_note(params)))
    return response(results, echo=program_to_latex(stmts))


def _slider_note(params) -> list[str]:
    if not params:
        return []
    names = ", ".join(p["name"] for p in params)
    return [f"Move the slider{'s' if len(params) > 1 else ''} to change {names}; "
            "a line such as a = 2 sets the start value, and a in [0, 10] the range."]


def surface_item(surfaces, options, settings) -> dict:
    """A separate 3D graph (it can't share axes with the plane graphs)."""
    given_x = str(options.get("x_min", "")).strip() or str(options.get("x_max", "")).strip()
    xw = window_from(options) if given_x else (-5.0, 5.0)
    yw = y_range_from(options) or list(xw)
    spec = {"three_d": True, "x_range": list(xw), "y_range": list(yw), "traces": surfaces, "notes": []}
    params = slider_specs(surfaces, settings)
    if params:
        spec["params"] = params
    notes = ["Change the x, y and z ranges above the graph (or zoom out) to see more. 'True proportions' draws "
             "x, y and z to the same scale; 'cut off spikes' hides the tallest values near poles."] + \
        _slider_note(params)
    return item(None, "graph", [], graph=spec, notes=notes)


def _trace_notes(traces) -> list[str]:
    out = []
    for t in traces:
        if t.get("note"):
            out.append(t["note"])
        elif t.get("approximate"):
            out.append(f"Some break points of {t['label']} were located numerically.")
    return out
