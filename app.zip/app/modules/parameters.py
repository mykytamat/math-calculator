"""Parameters tab: an equation or inequality in x with a parameter (a by default).

    x^2 - 2x + a = 0              how many roots for every a (critical values, the (x, a) plane)
    |x - 1| = a for x in [0, 3]   only the roots in an interval count
    x^2 + a x + 1 > 0             for which a it holds for every x, and for which a for some x
The option "solutions wanted" (2, 0, >= 1, inf) turns the table into an answer: a ∈ ….
"""
from __future__ import annotations

import sympy as sp

from ..core.format import set_latex, tex
from ..graphing import plane
from ..graphing.jsprint import to_js
from ..graphing.traces import expression_trace, graph_spec
from ..parsing import A, MathError, ParseError, parse
from ..parsing.echo import program_to_latex
from ..parsing.to_sympy import Converter, RelChain, Restriction, symbol
from ..solving.parameter import INF, Equation, Inequality
from ..solving.univariate import as_float, pick_between, safe
from .common import error_item, item, line, parse_error_response, response
from .graph import _number


# ------------------------------------------------------------ the question -
def parse_want(text: str):
    """'2', '0', 'none', '>= 1', 'at least 1', 'inf' -> (predicate on counts, words)."""
    t = (text or "").strip().lower().replace(" ", "").replace("≥", ">=").replace("≤", "<=")
    if not t:
        return None
    if t in ("inf", "infinite", "infinitelymany", "∞", "oo"):
        return (lambda n: n == INF), "infinitely many solutions"
    if t in ("none", "no", "nosolutions"):
        t = "0"
    for prefix, op in (("atleast", ">="), ("atmost", "<="), (">=", ">="), ("<=", "<="), (">", ">"),
                       ("<", "<"), ("=", "="), ("exactly", "=")):
        if t.startswith(prefix):
            num, op_ = t[len(prefix):], op
            break
    else:
        num, op_ = t, "="
    if not num.isdigit():
        raise MathError("The option 'solutions wanted' must be a number of solutions such as 2, 0, >= 1 or inf.")
    k = int(num)
    words = {"=": f"exactly {k}", ">=": f"at least {k}", "<=": f"at most {k}", ">": f"more than {k}",
             "<": f"fewer than {k}"}[op_] + (" solution" if k == 1 and op_ == "=" else " solutions")

    def pred(n):
        if n is None:
            return None
        if n == INF:
            return op_ in (">=", ">")
        return {"=": n == k, ">=": n >= k, "<=": n <= k, ">": n > k, "<": n < k}[op_]
    return pred, words


def count_latex(n, per_period=None) -> str:
    if n is None:
        return r"\text{?}"
    if n == INF:
        return r"\infty" + (rf"\ \left({per_period}\text{{ per period}}\right)" if per_period else "")
    return str(n)


def count_words(n, per_period=None) -> str:
    if n is None:
        return "not determined"
    if n == INF:
        return "infinitely many solutions" + (f" ({per_period} per period)" if per_period else "")
    return "no solutions" if n == 0 else ("1 solution" if n == 1 else f"{n} solutions")


def range_latex(lo, hi, p: str, lo_closed: bool = False, hi_closed: bool = False) -> str:
    left = r" \le " if lo_closed else " < "
    right = r" \le " if hi_closed else " < "
    above = r" \ge " if lo_closed else " > "
    if lo == -sp.oo and hi == sp.oo:
        return r"\text{all } " + p
    if lo == -sp.oo:
        return f"{p}{right}{tex(hi)}"
    if hi == sp.oo:
        return f"{p}{above}{tex(lo)}"
    return f"{tex(lo)}{left}{p}{right}{tex(hi)}"


# ------------------------------------------------------------ one line ----
class ParameterSession:
    def __init__(self, options: dict, places: int):
        self.options = options
        self.places = places
        self.want = parse_want(str(options.get("want", "")))
        self.param_name = str(options.get("parameter", "") or "").strip() or None
        self.a_range = _range(options, "a_min", "a_max")
        self.x_range = _range(options, "x_min", "x_max")

    def line(self, st: A.Node) -> dict:
        node, cond = st, None
        if isinstance(st, A.Conditional):
            node, cond = st.value, st.cond
            if cond is None:
                raise MathError("'otherwise' doesn't make sense here.")
        if not isinstance(node, A.Rel) or len(node.ops) != 1:
            raise MathError("Write one equation or inequality in x with a parameter, e.g. x^2 - 2x + a = 0.")
        conv = Converter()
        rc = conv.convert(node)
        if not isinstance(rc, RelChain):
            raise MathError("Write one equation or inequality.")
        lhs, rhs = rc.exprs
        op = rc.ops[0]
        if op == "!=":
            raise MathError("≠ isn't supported here; write an equation or an inequality.")
        x, a = self._variables(lhs, rhs)
        restriction = self._restriction(conv, cond, x)
        conds = [c for c in conv.conditions]
        if op == "=":
            return self.equation(st, lhs, rhs, x, a, conds, restriction)
        return self.inequality(st, lhs, op, rhs, x, a, conds, restriction)

    def _variables(self, lhs, rhs):
        free = sorted((sp.sympify(lhs).free_symbols | sp.sympify(rhs).free_symbols), key=lambda s: s.name)
        x = symbol("x")
        if x not in free:
            raise MathError("Use x as the unknown (and another letter, such as a, as the parameter).")
        others = [s for s in free if s != x]
        if self.param_name:
            others = [s for s in others if s.name == self.param_name] or others
        if not others:
            raise MathError("There is no parameter here. Equations without one are solved in the "
                            "Equations & inequalities tab.")
        if len(others) > 1:
            raise MathError("Only one parameter at a time: this has " + ", ".join(s.name for s in others) +
                            ". Give the others values.")
        return x, others[0]

    def _restriction(self, conv, cond, x):
        if cond is None:
            return None
        obj = conv.convert(cond)
        if isinstance(obj, Restriction):
            if obj.var != x:
                raise MathError("The restriction must be on x, e.g. for x in [0, 2pi].")
            return obj.interval
        c = conv.condition(cond)
        if c.free_symbols != {x}:
            raise MathError("The restriction may only use x, e.g. for x > 0.")
        s = safe(lambda: sp.Intersection(c.as_set(), sp.S.Reals))
        if not isinstance(s, sp.Interval):
            raise MathError("The restriction must be a single interval, e.g. for x in [0, 2pi] or for x > 0.")
        return s

    # ---------------------------------------------------- equations -----
    def equation(self, node, lhs, rhs, x, a, conds, restriction) -> dict:
        eq = Equation(lhs, rhs, x, a, conds, restriction)
        res = eq.solve(self.a_range, self.x_range)
        p = tex(a)
        cases = r" \\ ".join(
            f"{count_latex(r.count, r.per_period)} & " +
            (f"{p} = {tex(r.lo)}" if r.point else range_latex(r.lo, r.hi, p, r.lo_closed, r.hi_closed))
            for r in res.rows)
        lines = [line(r"N\left(" + p + r"\right) = \begin{cases}" + cases + r"\end{cases}",
                      label="Number of solutions")]
        notes = list(res.notes)
        if res.period is not None:
            notes.append(f"The equation is periodic (period ${tex(res.period)}$), so a solution comes back in "
                         "every period. Add 'for x in [0, 2pi]' to count the solutions in an interval.")
        if self.want is not None:
            pred, words = self.want
            lines.append(self.answer_line(res.rows, pred, p, words, notes))
        rows = [[(f"{p} = {tex(r.lo)}" if r.point else range_latex(r.lo, r.hi, p, r.lo_closed, r.hi_closed)),
                 count_latex(r.count, r.per_period) + (r"\ \checkmark" if r.checked else "")] for r in res.rows]
        table = {"caption": "Number of solutions for each a" + (" (✓ = checked by solving directly)"
                                                                if any(r.checked for r in res.rows) else ""),
                 "columns": [a.name, "solutions"], "rows": rows}
        g = self.equation_graph(lhs, rhs, x, a, conds, res, restriction)
        badge = "exact" if res.exact else "numerical estimate"
        return item(node, "solution", lines, badge=badge, notes=notes, table=table, **({"graph": g} if g else {}))

    def answer_line(self, rows, pred, p, words, notes) -> dict:
        s = sp.S.EmptySet
        unknown = False
        for r in rows:
            ok = pred(r.count)
            if ok is None:
                unknown = True
                continue
            if ok:
                s = s | r.as_set()
        if unknown:
            notes.append("At some critical values the number of solutions wasn't determined, so they are "
                         "left out of the answer.")
        latex = (p + r" \in " + set_latex(s)) if s != sp.S.EmptySet else r"\text{no value of } " + p
        return line(latex, label=f"For {words}")

    def equation_graph(self, lhs, rhs, x, a, conds, res, restriction) -> dict | None:
        xs = [as_float(v) for v in res.xs if v.is_finite] if res.xs else []
        crit = [float(sp.N(v)) for v in res.critical if v is not None and v.is_finite]
        window = self.x_range or plane.fit_window(xs, default=(-6.0, 6.0))
        a_window = self.a_range or _a_window(crit)
        traces = []
        if res.method == "symbolic" and res.branches:
            for i, gx in enumerate(res.branches):
                bconds = [c.subs({a: gx}) for c in conds if sp.sympify(c.expr).free_symbols <= {x, a}]
                bconds = [c for c in bconds if sp.sympify(c.expr).free_symbols <= {x}]
                try:
                    t = expression_trace(gx, x, f"a = {plane._short(gx)}", bconds, window)
                except Exception:
                    continue
                traces.append(t)
            if res.all_a:
                traces.append({"kind": "vlines", "label": "solution for every a",
                               "x": [as_float(c) for c in res.all_a], "periodic": []})
        else:
            t = plane.boundary_trace(lhs, rhs, "=", x, a, f"{plane._short(lhs)} = {plane._short(rhs)}", window)
            if t is not None:
                traces.append(t)
        if not traces:
            return None
        if restriction is not None:
            lo = None if restriction.inf == -sp.oo else as_float(restriction.inf)
            hi = None if restriction.sup == sp.oo else as_float(restriction.sup)
            traces.append({"kind": "xbands", "label": "x allowed", "intervals": [[lo, hi]], "period": None})
        for v in crit:
            traces.append(_hline(v, f"a = {_short(v)}"))
        name = a.name
        traces.append({"kind": "js", "label": f"line {name} = const", "js": name, "breaks": [], "periodic": [],
                       "dots": [], "refetch": False})
        js = [to_js(gx) for gx in res.branches] if res.method == "symbolic" else []
        if js and all(js):
            traces.append({"kind": "levelroots", "label": "solutions", "js": js, "param": name,
                           "always": [as_float(c) for c in res.all_a]})
        readout = []
        for r in res.rows:
            text = count_words(r.count, r.per_period)
            if r.point:
                readout.append({"at": float(sp.N(r.lo)), "text": text})
            else:
                readout.append({"lo": None if r.lo == -sp.oo else float(sp.N(r.lo)),
                                "hi": None if r.hi == sp.oo else float(sp.N(r.hi)), "text": text,
                                "lo_closed": r.lo_closed, "hi_closed": r.hi_closed})
        spec = graph_spec(traces, window)
        spec.update(_plane_extras(name, a_window, _start_value(crit, a_window)))
        spec["readout"] = {"param": name, "rows": readout}
        return spec

    # ---------------------------------------------------- inequalities --
    def inequality(self, node, lhs, op, rhs, x, a, conds, restriction) -> dict:
        ineq = Inequality(lhs, op, rhs, x, a, conds, restriction)
        res = ineq.solve(self.a_range, self.x_range)
        p = tex(a)
        where = "every x" if restriction is None else "every x in the interval"
        lines = [line(_set_line(p, res.holds_all), label=f"Holds for {where}"),
                 line(_set_line(p, res.some), label="Has a solution")]
        notes = list(res.notes)
        if self.want is not None:
            notes.append("The option 'solutions wanted' is for equations; for an inequality both questions "
                         "are answered above.")
        g = self.inequality_graph(lhs, op, rhs, x, a, res, restriction)
        badge = "exact" if res.exact else "numerical estimate"
        return item(node, "solution", lines, badge=badge, notes=notes, **({"graph": g} if g else {}))

    def inequality_graph(self, lhs, op, rhs, x, a, res, restriction) -> dict | None:
        from ..solving.systems import Leaf
        crit = [float(sp.N(v)) for v in res.critical if v.is_finite]
        xs = [as_float(v) for v in res.xs if v.is_finite]
        window = self.x_range or plane.fit_window(xs, default=(-6.0, 6.0))
        a_window = self.a_range or _a_window(crit)
        lf = Leaf(lhs, op, rhs)
        traces = []
        js = to_js(lf.relation())
        if js is not None:
            traces.append({"kind": "region", "label": "where it holds", "js": js, "vars": [x.name, a.name]})
        t = plane.boundary_trace(lhs, rhs, op, x, a, plane._short_rel(lf), window)
        if t is not None:
            traces.append(t)
        if not traces:
            return None
        if restriction is not None:
            lo = None if restriction.inf == -sp.oo else as_float(restriction.inf)
            hi = None if restriction.sup == sp.oo else as_float(restriction.sup)
            traces.append({"kind": "xbands", "label": "x allowed", "intervals": [[lo, hi]], "period": None})
        for v in crit:
            traces.append(_hline(v, f"a = {_short(v)}"))
        name = a.name
        traces.append({"kind": "js", "label": f"line {name} = const", "js": name, "breaks": [], "periodic": [],
                       "dots": [], "refetch": False})
        edges = [-sp.oo] + sorted(set(res.critical), key=lambda v: float(sp.N(v))) + [sp.oo]
        readout = []
        for lo, hi in zip(edges, edges[1:]):
            s = pick_between(lo, hi)
            readout.append({"lo": None if lo == -sp.oo else float(sp.N(lo)),
                            "hi": None if hi == sp.oo else float(sp.N(hi)), "text": _ineq_words(res, s)})
            if hi != sp.oo:
                readout.append({"at": float(sp.N(hi)), "text": _ineq_words(res, hi)})
        spec = graph_spec(traces, window)
        spec.update(_plane_extras(name, a_window, _start_value(crit, a_window)))
        spec["readout"] = {"param": name, "rows": readout}
        return spec


def _ineq_words(res, v) -> str:
    if res.holds_all.contains(v) == sp.true:
        return "holds for every x"
    if res.some.contains(v) == sp.true:
        return "holds for some x, not all"
    return "no solutions"


def _set_line(p, s) -> str:
    if s == sp.S.EmptySet:
        return r"\text{for no } " + p
    if s == sp.S.Reals:
        return r"\text{for every } " + p
    return p + r" \in " + set_latex(s)


def _hline(v: float, label: str) -> dict:
    return {"kind": "js", "label": label, "js": repr(v), "breaks": [], "periodic": [], "dots": [],
            "refetch": False, "dash": True, "faint": True}


def _short(v: float) -> str:
    return f"{v:.4g}"


def _a_window(crit: list[float]) -> tuple[float, float]:
    if not crit:
        return (-5.0, 5.0)
    lo, hi = min(crit), max(crit)
    span = max(hi - lo, 4.0)
    return (lo - span * 0.5, hi + span * 0.5)


def _start_value(crit, a_window) -> float:
    """A slider start that sits strictly between critical values (a typical a)."""
    lo, hi = a_window
    if crit:
        c = sorted(crit)
        v = c[0] + (c[1] - c[0]) / 2 if len(c) > 1 else c[0] - max(1.0, (hi - lo) * 0.15)
    else:
        v = (lo + hi) / 2
    return float(f"{v:.3g}")


def _plane_extras(name: str, a_window, value) -> dict:
    lo, hi = a_window
    lo, hi = min(lo, value), max(hi, value)
    return {"vars": ["x", name], "free_aspect": True, "y_range": [lo, hi],
            "params": [{"name": name, "min": float(f"{lo:.3g}"), "max": float(f"{hi:.3g}"),
                        "step": (hi - lo) / 400, "value": value}]}


def _range(options, lo_key, hi_key):
    lo, hi = str(options.get(lo_key, "") or "").strip(), str(options.get(hi_key, "") or "").strip()
    if not lo and not hi:
        return None
    if not (lo and hi):
        raise MathError("Give both ends of a range, or neither.")
    a, b = _number(lo, "range"), _number(hi, "range")
    if not b > a:
        raise MathError("A range must go from a smaller to a larger number.")
    return (a, b)


def run(payload: dict) -> dict:
    text = payload.get("input", "")
    mode = payload.get("mode", "plain")
    options = payload.get("options", {}) or {}
    places = int(options.get("decimals", 4))
    try:
        stmts = parse(text, mode)
    except ParseError as e:
        return parse_error_response(e, text)
    try:
        ps = ParameterSession(options, places)
    except MathError as e:
        return {"ok": False, "results": [], "echo": [], "error": e.to_dict(), "summary_latex": None}
    results = []
    for st in stmts:
        try:
            results.append(ps.line(st))
        except (MathError, ParseError) as e:
            results.append(error_item(st, e, text))
        except Exception as e:  # keep the other lines' answers
            results.append(error_item(st, e))
    return response(results, echo=program_to_latex(stmts))
