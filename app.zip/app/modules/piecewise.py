"""Piecewise & recursive tab.

Definitions (cases may call the function itself), then lines to evaluate:

    f(x) = 0 if 0 < x < 1
    f(x) = 1 + f(log(x, 2)) if x >= 1
    f(16)

Each evaluation shows the answer, the call chain (16 -> 4 -> 2 -> 1 -> 0)
and a table of the steps with the case used at each one. Undefined results
and non-terminating recursion are explained along the chain. Every defined
one-variable function is graphed with its breaks and endpoint dots.
"""
from __future__ import annotations

import sympy as sp

from ..core.domain import explain, first_violation
from ..core.format import exact_and_decimal, tex
from ..core.functions import FunctionDef, collect_definitions
from ..core.recursion import Evaluator, NonTermination, Result, Undefined, call_tex, chain_tex, short_tex
from ..parsing import A, MathError, ParseError, parse
from ..parsing.echo import program_to_latex
from ..parsing.to_sympy import Condition
from .common import error_item, item, line, parse_error_response, response
from .evaluate import Session

MAX_TABLE_ROWS = 60

AppliedUndef = sp.core.function.AppliedUndef


class PiecewiseSession(Session):
    def run(self, node: A.Node) -> dict:
        conv = self.converter()
        try:
            expr = conv.convert(node)
        except ParseError:
            raise
        if isinstance(expr, sp.Expr) and not isinstance(node, A.Rel) and expr.has(AppliedUndef):
            if self.values:
                expr = expr.subs(self.values)
            calls = expr.atoms(AppliedUndef)
            if all(not a.free_symbols for c in calls for a in c.args):
                return self.with_chain(node, expr, conv.conditions)
        return super().run(node)

    def with_chain(self, node: A.Node, expr, conditions: list[Condition]) -> dict:
        # A fresh evaluator per line, so earlier lines' cached results don't cut
        # this line's call chain short (f(16) must show 16 -> 4 -> 2 -> 1 -> 0).
        ev = Evaluator(self.table, self.evaluator.depth_limit)
        try:
            result = ev.evaluate(expr)
        except NonTermination as e:
            d = error_item(node, MathError(e.message))
            d["badge"] = "undefined"
            d["error"]["title"] = "Does not terminate"
            return d
        except Undefined as e:
            return error_item(node, MathError(e.message))
        # The expression around the calls may have its own requirements, e.g. ln(f(3)).
        resolved = []
        for c in conditions:
            e = sp.sympify(c.expr).xreplace({k: ev.memo.get(ev.key_of(k), k) for k in sp.sympify(c.expr).atoms(AppliedUndef)})
            resolved.append(Condition(c.rel, e, c.what, c.latex, c.guard, c.custom))
        v = first_violation(resolved)
        if v is not None:
            raise MathError("Undefined. " + explain(*v))
        value = result.value
        if value.has(sp.nan, sp.zoo):
            raise MathError("Undefined (the expression has no value here).")
        f = exact_and_decimal(value, self.places)
        lines = [line(f["latex"], copy=f["decimal"] if f.get("too_long") else None)]
        if len(result.chain) >= 2:
            lines.append(line(chain_tex(result.chain), label="Call chain"))
        notes = list(result.numeric_decisions)
        if f.get("too_long"):
            notes.append(f["too_long"])
        if result.calls > 1:
            notes.append(f"{result.calls} different calls were evaluated (depth {len(result.chain)}).")
        badge = "numerical estimate" if result.numeric_decisions or f.get("too_long") else "exact"
        return item(node, "value", lines, badge=badge, notes=notes, table=steps_table(result, self.table, self.places))


def steps_table(result: Result, table, places: int) -> dict | None:
    steps = result.steps
    if len(steps) < 2:
        return None
    rows = []
    for s in steps:
        fd: FunctionDef = table.functions[s.name]
        if s.case.kind in ("otherwise", "always"):
            case = r"\text{otherwise}" if fd.piecewise else r"\text{(formula)}"
        else:
            case = tex(s.case.condition(fd.params))
        val = exact_and_decimal(s.value, places)
        val_tex = val["latex"] if len(val["latex"]) <= 60 else short_tex(s.value)
        rows.append([call_tex((s.name, s.args)), case, val_tex])
    omitted = 0
    if len(rows) > MAX_TABLE_ROWS:
        omitted = len(rows) - MAX_TABLE_ROWS
        rows = rows[:MAX_TABLE_ROWS // 2] + [[r"\vdots", "", ""]] + rows[-MAX_TABLE_ROWS // 2:]
    caption = "Steps, in the order they were finished"
    if omitted:
        caption += f" ({omitted} rows not shown)"
    return {"caption": caption, "columns": ["Call", "Case used", "Value"], "rows": rows}


def run(payload: dict) -> dict:
    if payload.get("options", {}).get("graph_only"):
        return graph_only(payload)
    text = payload.get("input", "")
    mode = payload.get("mode", "plain")
    options = payload.get("options", {})
    places = int(options.get("decimals", 4))
    try:
        stmts = parse(text, mode)
    except ParseError as e:
        return parse_error_response(e, text)
    table, defs_at, def_errors = collect_definitions(stmts)
    session = PiecewiseSession(table, places=places, depth_limit=_depth(options))
    results = []
    shown: set[str] = set()
    for i, st in enumerate(stmts):
        if i in def_errors:
            results.append(error_item(st, def_errors[i], text))
            continue
        if i in defs_at:
            fd = defs_at[i]
            if fd.name not in shown:
                shown.add(fd.name)
                card = item(fd.nodes[0], "definition", [line(fd.latex(), label="Defined")],
                            notes=list(table.notes.get(fd.name, [])))
                results.append(card)
            continue
        try:
            results.append(session.run(st))
        except MathError as e:
            results.append(error_item(st, e))
        except ParseError as e:
            results.append(error_item(st, e, text))
        except Exception as e:  # keep the other lines' answers
            results.append(error_item(st, e))
    if not table.functions and not def_errors:
        results.insert(0, item(None, "message", [], notes=[
            "No function is defined yet. Define one by cases, for example "
            "f(x) = 0 if 0 < x < 1 and f(x) = 1 + f(log(x, 2)) if x >= 1, then evaluate f(16)."]))
    graph = _graph(stmts, table, options, session)
    if graph is not None:
        results.append(graph)
    return response(results, echo=program_to_latex(stmts))


def _default_window(stmts, table) -> tuple[float, float]:
    """Show the points that were evaluated, and the start of the cases' region."""
    pts = []
    for st in stmts:
        for n in A.walk(st):
            if isinstance(n, A.Call) and n.name in table.functions and all(isinstance(a, A.Num) for a in n.args):
                try:
                    pts.append(float(sp.Rational(n.args[0].text)))
                except (ValueError, TypeError):
                    pass
    lo, hi = -1.0, 10.0
    for fd in table.functions.values():
        cov = fd.coverage()
        try:
            if cov is not None and cov != sp.S.Reals and float(cov.inf) > -1e6:
                lo = min(lo, float(cov.inf) - 1)
        except (TypeError, ValueError):
            pass
    for p in pts:
        if abs(p) <= 100:  # beyond that the graph would be a blur; the user can set the range
            lo = min(lo, p - 1)
            hi = max(hi, p * 1.15 + 1)
    return lo, hi


def _graph(stmts, table, options, session) -> dict | None:
    from ..graphing.traces import graph_spec
    from .graph import build_traces, window_from, y_range_from
    if not any(fd.arity == 1 for fd in table.functions.values()):
        return None
    try:
        window = window_from(options, _default_window(stmts, table))
        traces, errors, notes, _ = build_traces(stmts, window, session.evaluator.depth_limit, only_defined=True)
        spec = graph_spec(traces, window, notes, source={"tab": "piecewise"})
        spec["y_range"] = y_range_from(options)
    except MathError as e:
        return error_item(None, e)
    if not traces:
        return None
    notes = [t["note"] for t in traces if t.get("note")]
    notes += [f"Some break points of {t['label']} were located numerically." for t in traces
              if t.get("approximate") and not t.get("note")]
    notes += _empty_notes(traces)
    return item(None, "graph", [], graph=spec, notes=notes)


def _empty_notes(traces) -> list[str]:
    """Explain a graph line that is (mostly) missing."""
    out = []
    for t in traces:
        segs = t.get("segments")
        if not segs:
            continue
        ys = [y for s in segs for y in s["y"]]
        finite = sum(1 for y in ys if y is not None)
        if ys and finite < 0.02 * len(ys):
            out.append(f"{t['label']} has no value for most of this range: either no case applies "
                       "or its recursion does not end there.")
    return out


def graph_only(payload: dict) -> dict:
    """Re-sampled graph for a new view (zoom/pan) of the Piecewise tab."""
    text = payload.get("input", "")
    options = payload.get("options", {})
    stmts = parse(text, payload.get("mode", "plain"))
    table, _, _ = collect_definitions(stmts)
    session = PiecewiseSession(table, depth_limit=_depth(options))
    g = _graph(stmts, table, options, session)
    return {"ok": True, "graph": g.get("graph") if g else None}


def _depth(options: dict) -> int:
    try:
        return max(10, min(int(options.get("depth", 1000)), 20000))
    except (TypeError, ValueError):
        return 1000
