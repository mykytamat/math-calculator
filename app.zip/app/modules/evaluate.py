"""Evaluate / Simplify tab.

Each line is one of:
  * a function definition      f(x) = x^2 + 1   (cases allowed, not recursion)
  * an assignment              a = 5
  * an expression              f(3) + sqrt(a)   -> exact ≈ decimal
  * a comparison of numbers    sqrt(2) < 1.5    -> true / false
Expressions that still contain variables are simplified (plus expanded and
factored forms when those differ).
"""
from __future__ import annotations

import sympy as sp

from ..core.decide import compare
from ..core.domain import explain, first_violation, requirements_note, substitute
from ..core.format import decimal_latex, exact_and_decimal, tex
from ..parsing import A, MathError, ParseError, parse
from ..parsing.echo import program_to_latex
from ..core.functions import FunctionDef, FunctionTable, collect_definitions
from ..core.recursion import Evaluator
from ..parsing.to_sympy import (CasesObj, Condition, Converter, Guarded, RelChain, Restriction,
                                SeqObj, SystemObj, is_boolean, symbol)
from .common import error_item, item, line, parse_error_response, response


class Session:
    def __init__(self, table: FunctionTable, places: int = 4, depth_limit: int = 1000):
        self.table = table
        self.places = places
        self.values: dict[sp.Symbol, sp.Expr] = {}
        self.recursive = table.recursive_names()
        self.evaluator = Evaluator(table, depth_limit)

    def converter(self) -> Converter:
        return Converter(self.table.log_base, set(self.table.functions))

    # ------------------------------------------------------------------
    def run(self, node: A.Node) -> dict:
        if isinstance(node, A.Rel) and node.ops == ["="] and isinstance(node.items[0], A.Name) \
                and node.items[0].name not in ("pi", "e", "inf"):
            return self.assign(node)
        conv = self.converter()
        obj = conv.convert(node)
        if isinstance(obj, RelChain):
            return self.relation(node, obj, conv.conditions)
        if isinstance(obj, Guarded):
            raise MathError("A condition ('if ...') only makes sense in a function definition, "
                            "for example f(x) = 0 if x < 0.")
        if isinstance(obj, (Restriction, SystemObj)):
            raise MathError("Equations, inequalities and systems are solved in the Equations & "
                            "inequalities tab.")
        if isinstance(obj, CasesObj):
            raise MathError("Give the cases a name to use them, for example f(x) = {cases}.")
        if isinstance(obj, SeqObj):
            return self.sequence(node, obj, conv.conditions)
        if isinstance(obj, sp.MatrixBase):
            return item(node, "matrix", [line(tex(obj.subs(self.values)))], badge="exact")
        if is_boolean(obj):
            raise MathError("Conditions can't be evaluated on their own here.")
        return self.expression(node, obj, conv.conditions)

    def definition_card(self, fd: FunctionDef) -> dict:
        notes = list(self.table.notes.get(fd.name, []))
        if fd.name in self.recursive:
            notes.append(f"{fd.name} is recursive. The Piecewise & recursive tab shows the call chain "
                         "and a graph.")
        return item(fd.nodes[0], "definition", [line(fd.latex(), label="Defined")], notes=notes)

    def assign(self, node: A.Rel) -> dict:
        name = node.items[0].name
        conv = self.converter()
        value = conv.expr(node.items[1])
        value, conditions = self.apply(value, conv.conditions)
        self.check(conditions)
        value = sp.simplify(value)
        sym = symbol(name)
        self.values[sym] = value
        lines = [line(f"{tex(sym)} = " + exact_and_decimal(value, self.places)["latex"], label="Stored")]
        return item(node, "assignment", lines, badge="exact")

    # ------------------------------------------------------------------
    def apply(self, expr, conditions: list[Condition]):
        """Substitute stored values and user functions. Returns (expr, conditions).

        Non-recursive functions are substituted as formulas (so f(x) can be
        simplified); recursive ones are evaluated at their numeric arguments."""
        conditions = list(conditions)
        if self.values:
            expr = expr.subs(self.values)
            conditions = substitute(conditions, self.values)
        for _ in range(100):
            calls = [f for f in sp.sympify(expr).atoms(sp.core.function.AppliedUndef)]
            if not calls:
                break
            call = calls[0]
            name = call.func.__name__
            if name not in self.table.functions:
                raise MathError(f"{name} is not defined. Define it first, for example {name}(x) = x^2.")
            fd = self.table.functions[name]
            if len(call.args) != fd.arity:
                raise MathError(f"{name} takes {fd.arity} argument(s) but was given {len(call.args)}.")
            if name in self.recursive:
                inner = [c for c in calls if c.func.__name__ in self.recursive
                         and not any(a.has(sp.core.function.AppliedUndef) for a in c.args)]
                target = next((c for c in inner if not any(a.free_symbols for a in c.args)), None)
                if target is None:
                    raise MathError(f"{name} is recursive, so it can only be evaluated at numbers here.")
                result = self.evaluator.evaluate(target)
                expr = expr.xreplace({target: result.value})
                continue
            mapping = dict(zip(fd.params, call.args))
            body = fd.body().subs(mapping, simultaneous=True)
            conditions.extend(substitute(fd.guarded_conditions(), mapping))
            if fd.piecewise and not any(c.kind in ("otherwise", "always") for c in fd.cases):
                conditions.append(_case_condition(fd, call, mapping))
            expr = expr.subs(call, body)
        return expr, conditions

    def check(self, conditions: list[Condition]):
        v = first_violation(conditions)
        if v is not None:
            c, exact = v
            msg = explain(c, exact)
            raise MathError(msg if c.rel == "case" else "Undefined. " + msg)

    def expression(self, node: A.Node, expr, conditions) -> dict:
        expr, conditions = self.apply(expr, conditions)
        expr = calculus_here(expr)
        if not expr.free_symbols:
            self.check(conditions)
            return self.number(node, expr)
        return self.symbolic(node, expr, conditions)

    def number(self, node: A.Node, expr) -> dict:
        value = sp.simplify(expr)
        if value.has(sp.nan, sp.zoo) or value is sp.nan:
            raise MathError("Undefined (the expression has no value here).")
        if value in (sp.oo, -sp.oo):
            return item(node, "value", [line(tex(value))], badge="exact")
        if decimal_latex(value, self.places) is None:
            n = sp.N(value, 20)
            if n.is_number and not n.is_real:
                raise MathError("The result is not a real number (it would be "
                                f"${tex(sp.N(value, 6))}$ in complex numbers).")
            raise MathError("The result could not be evaluated.")
        f = exact_and_decimal(value, self.places)
        if f.get("too_long"):
            return item(node, "value", [line(f["latex"], copy=f["decimal"])], badge="numerical estimate",
                        notes=[f["too_long"]])
        return item(node, "value", [line(f["latex"])], badge="exact")

    def symbolic(self, node: A.Node, expr, conditions) -> dict:
        simplified = sp.simplify(expr)
        lines = [line(tex(simplified), label="Simplified")]
        seen = {sp.srepr(simplified)}
        for label, fn in (("Expanded", sp.expand), ("Factored", sp.factor)):
            try:
                form = fn(simplified)
            except Exception:
                continue
            key = sp.srepr(form)
            if key not in seen:
                seen.add(key)
                lines.append(line(tex(form), label=label))
        notes = []
        note = requirements_note(conditions)
        if note:
            notes.append(note)
        return item(node, "symbolic", lines, badge="exact", notes=notes)

    def relation(self, node: A.Node, rel: RelChain, conditions) -> dict:
        exprs = []
        for e in rel.exprs:
            e2, conditions = self.apply(e, conditions)
            exprs.append(e2)
        if any(e.free_symbols for e in exprs):
            raise MathError("This is an equation or inequality with a variable: solve it in the "
                            "Equations & inequalities tab.")
        self.check(conditions)
        truth, exact = True, True
        for op, a, b in zip(rel.ops, exprs, exprs[1:]):
            t = compare(op, a, b)
            if t.value is None:
                raise MathError("This comparison can't be decided (a side is not a real number).")
            exact = exact and t.exact
            truth = truth and t.value
        latex = r"\text{true}" if truth else r"\text{false}"
        notes = [] if exact else ["Decided numerically: the two sides agree to 45 digits."]
        return item(node, "truth", [line(latex)], badge="exact" if exact else "numerical estimate",
                    notes=notes)

    def sequence(self, node: A.Node, seq: SeqObj, conditions) -> dict:
        values = []
        for it in seq.items:
            if not isinstance(it, sp.Expr):
                raise MathError("Lists can only contain expressions here.")
            e, conds = self.apply(it, conditions)
            if not e.free_symbols:
                self.check(conds)
            values.append(sp.simplify(e))
        open_, close = (r"\left(", r"\right)") if seq.bracket == "(" else (r"\left[", r"\right]")
        exact = open_ + ", ".join(tex(v) for v in values) + close
        lines = [line(exact)]
        if all(not v.free_symbols and decimal_latex(v, self.places) for v in values):
            dec = open_ + ", ".join(decimal_latex(v, self.places)[0] for v in values) + close
            if dec != exact:
                lines.append(line(r"\approx " + dec, copy=dec))
        return item(node, "value", lines, badge="exact")


def calculus_here(expr):
    """f'(2) and d/dx are worked out here; limits and integrals go to the Calculus tab.
    Finite sums and products are worked out; others go to the Sequences & series tab."""
    if expr.has(sp.Limit, sp.Integral):
        raise MathError("Limits and integrals are worked out in the Calculus tab (with checks and a graph).")
    if expr.has(sp.Sum, sp.Product):
        expr = finite_sums(expr)
    if expr.has(sp.Subs, sp.Derivative):
        if expr.has(sp.core.function.AppliedUndef):
            raise MathError("Derivatives of recursive functions aren't supported.")
        expr = expr.doit()
        expr = expr.replace(lambda t: isinstance(t, sp.DiracDelta), lambda t: sp.Integer(0))
    return expr


def finite_sums(expr):
    """Replace each sum and product with whole-number bounds by its value (innermost first)."""
    from ..calculus.series import finite_product, finite_sum
    while True:
        ops = [s for s in expr.atoms(sp.Sum, sp.Product) if not s.function.has(sp.Sum, sp.Product)]
        if not ops:
            return expr
        for s in ops:
            f, (k, a, b) = s.function, s.limits[0]
            if isinstance(s, sp.Product):
                if b == sp.oo:
                    raise MathError("Infinite products aren't supported yet. A product up to a whole number "
                                    "or a letter works.")
                if not (a.is_Integer and b.is_Integer):
                    raise MathError("Products up to a letter are worked out in the Sequences & series tab.")
                r = finite_product(f, k, int(a), int(b))
                if r.value is None:
                    raise MathError(f"${tex(s)}$ is too large to work out exactly here; "
                                    "try the Sequences & series tab.")
            else:
                if not (a.is_Integer and b.is_Integer):
                    raise MathError("Infinite sums and sums up to a letter are worked out in the "
                                    "Sequences & series tab.")
                r = finite_sum(f, k, int(a), int(b))
                if r.value is None:
                    raise MathError(f"${tex(s)}$ has too many terms to add up exactly here; "
                                    "try the Sequences & series tab.")
            expr = expr.xreplace({s: r.value})


def _case_condition(fd: FunctionDef, call, mapping) -> Condition:
    """The argument of a piecewise function must fall into one of its cases."""
    conds = [c.condition(fd.params) for c in fd.ordered()]
    any_case = sp.Or(*conds).subs(mapping, simultaneous=True)
    cases = "; ".join(f"${tex(c)}$" for c in conds)
    return Condition("case", sp.Tuple(*call.args), fd.name, cases, sp.true, any_case)


def run(payload: dict) -> dict:
    text = payload.get("input", "")
    mode = payload.get("mode", "plain")
    places = int(payload.get("options", {}).get("decimals", 4))
    try:
        stmts = parse(text, mode)
    except ParseError as e:
        return parse_error_response(e, text)
    options = payload.get("options", {})
    table, defs_at, def_errors = collect_definitions(stmts)
    session = Session(table, places=places, depth_limit=int(options.get("depth", 1000)))
    results = []
    shown: set[str] = set()
    for i, st in enumerate(stmts):
        if i in def_errors:
            results.append(error_item(st, def_errors[i], text))
            continue
        if i in defs_at:
            fd = defs_at[i]
            if fd.name not in shown:  # all lines of one function are shown merged, once
                shown.add(fd.name)
                results.append(session.definition_card(fd))
            continue
        try:
            results.append(session.run(st))
        except MathError as e:
            results.append(error_item(st, e))
        except ParseError as e:
            results.append(error_item(st, e, text))
        except Exception as e:  # keep the other lines' answers
            results.append(error_item(st, e))
    return response(results, echo=program_to_latex(stmts))
