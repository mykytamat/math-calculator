"""Matrices tab.

Each line is one of
    A = [[1, 2], [3, 4]]          store a matrix (also B = A^T, k = 3)
    A   or   [[1, 2], [3, 4]]     everything about it: determinant, rank, inverse, RREF, eigenvalues …
    det(A), inv(A), A^-1, A^T, rank(A), tr(A), rref(A), eig(A), eigenvectors(A), A*B + 2A, A^3
    solve(A, [1, 2])              the linear system A·x = b
    {x + 2y = 5; 3x - y = 1}      a linear system written out (also one equation per row in the editor)
All entries stay exact (fractions, roots); every result is checked (see core/linalg.py).
"""
from __future__ import annotations

import sympy as sp

from ..core.format import exact_and_decimal, tex
from ..core.linalg import (determinant, eigen, inverse_checked, rank_checked, rref_checked, shape_text,
                           solve_linear)
from ..parsing import A, MathError, ParseError, parse
from ..parsing.echo import program_to_latex, to_latex
from ..parsing.to_sympy import Converter, MatrixQuery, RelChain, SeqObj, SystemObj, symbol
from ..solving.systems import order_symbols
from .common import error_item, item, line, parse_error_response, response


def matrix_tex(m) -> str:
    return tex(m)


def augmented_tex(R, split: int) -> str:
    """A matrix with a vertical bar before column `split`: (A | b)."""
    cols = "c" * split + "|" + "c" * (R.cols - split)
    rows = r" \\ ".join(" & ".join(tex(R[i, j]) for j in range(R.cols)) for i in range(R.rows))
    return r"\left(\begin{array}{" + cols + "}" + rows + r"\end{array}\right)"


def value_tex(v, places) -> str:
    v = sp.sympify(v)
    if v.free_symbols:
        return tex(v)
    return exact_and_decimal(v, places)["latex"]


class MatrixSession:
    def __init__(self, places: int):
        self.places = places
        self.matrices: dict[str, sp.ImmutableMatrix] = {}
        self.scalars: dict[sp.Symbol, sp.Expr] = {}

    def converter(self) -> Converter:
        return Converter(matrices=self.matrices)

    def convert(self, node):
        obj = self.converter().convert(node)
        if isinstance(obj, SeqObj) and all(isinstance(i, sp.Expr) for i in obj.items):
            obj = sp.ImmutableMatrix(obj.items)  # a list [1, 2] is a column vector here
        if self.scalars and isinstance(obj, (sp.Basic, sp.MatrixBase)):
            obj = obj.subs(self.scalars)
        if isinstance(obj, MatrixQuery) and self.scalars:
            obj = MatrixQuery(obj.name, [a.subs(self.scalars) for a in obj.args])
        return obj

    # ---------------------------------------------------- dispatch ------
    def line(self, st: A.Node) -> dict:
        if isinstance(st, A.Rel) and st.ops == ["="] and isinstance(st.items[0], A.Name) \
                and st.items[0].name not in ("pi", "e", "inf") and self._is_definition(st):
            return self.assign(st)
        if isinstance(st, (A.System, A.Rel)):
            return self.system(st)
        if isinstance(st, A.Call) and st.name in ("det", "inv", "rank"):
            return self.checked_call(st)
        obj = self.convert(st)
        if isinstance(obj, MatrixQuery):
            return self.query(st, obj)
        if isinstance(obj, sp.MatrixBase):
            if isinstance(st, (A.Matrix, A.Name)):
                name = st.name if isinstance(st, A.Name) else "A"
                return self.report(st, sp.ImmutableMatrix(obj), name)
            return self.matrix_result(st, obj)
        if isinstance(obj, sp.Expr):
            if obj.free_symbols:
                return item(st, "symbolic", [line(tex(sp.simplify(obj)), label="Result")], badge="exact")
            return item(st, "value", [line(value_tex(sp.simplify(obj), self.places))], badge="exact")
        raise MathError("Write a matrix, an operation on matrices, or a linear system.")

    def _is_definition(self, st: A.Rel) -> bool:
        """A = [[…]] or k = 3, not an equation such as x = 3 - y."""
        rhs = st.items[1]
        names = {n.name for n in A.walk(rhs) if isinstance(n, A.Name)}
        unknown = names - set(self.matrices) - {s.name for s in self.scalars} - {"pi", "e", "inf", "T"}
        return not unknown

    # ---------------------------------------------------- storing -------
    def assign(self, st: A.Rel) -> dict:
        name = st.items[0].name
        obj = self.convert(st.items[1])
        if isinstance(obj, MatrixQuery):
            raise MathError(f"{obj.name}(…) gives several results, so it can't be stored.")
        if isinstance(obj, sp.MatrixBase):
            m = sp.ImmutableMatrix(obj)
            self.matrices[name] = m
            self.scalars.pop(symbol(name), None)
            return item(st, "assignment", [line(f"{_name(name)} = {matrix_tex(m)}",
                                                label=f"Stored ({shape_text(m)})")], badge="exact")
        if isinstance(obj, sp.Expr) and not obj.free_symbols:
            v = sp.simplify(obj)
            self.scalars[symbol(name)] = v
            self.matrices.pop(name, None)
            return item(st, "assignment", [line(f"{_name(name)} = {value_tex(v, self.places)}", label="Stored")],
                        badge="exact")
        raise MathError("Only a matrix or a number can be stored.")

    # ---------------------------------------------------- one matrix ----
    def report(self, node, m, name: str) -> dict:
        nm = _name(name)
        lines = [line(f"{nm} = {matrix_tex(m)}", label=f"Matrix ({shape_text(m)})")]
        notes: list[str] = []
        exact = True
        square = m.rows == m.cols
        table = None
        if square:
            d = determinant(m)
            exact = exact and d.exact
            lines.append(line(f"\\det {nm} = {value_tex(d.value, self.places)}", label="Determinant"))
            notes += ["Determinant: " + _lc(n) for n in d.notes]
            lines.append(line(f"\\operatorname{{tr}} {nm} = {tex(m.trace())}", label="Trace"))
        r = rank_checked(m)
        lines.append(line(f"\\operatorname{{rank}} {nm} = {tex(r.value)}", label="Rank"))
        if square:
            if sp.simplify(d.value) == 0:
                lines.append(line(r"\text{none: the determinant is 0}", label="Inverse"))
            else:
                inv = inverse_checked(m)
                exact = exact and inv.exact
                lines.append(line(f"{nm}^{{-1}} = {self.inverse_tex(inv.value, d.value)}", label="Inverse"))
                notes += ["Inverse: " + _lc(n) for n in inv.notes]
        lines.append(line(f"{nm}^{{T}} = {matrix_tex(m.T)}", label="Transpose"))
        rr = rref_checked(m)
        R, piv = rr.value
        lines.append(line(f"\\operatorname{{rref}} {nm} = {matrix_tex(R)}", label="Reduced row echelon form"))
        notes += ["Reduced form: " + _lc(n) for n in rr.notes]
        if square and m.rows <= 6:
            ev = eigen(m)
            exact = exact and ev.exact
            lines += self.eigen_lines(ev, nm)
            table = self.eigen_table(ev)
            notes += ev.notes
        letters = sorted(s.name for s in m.free_symbols)
        if letters:
            where = f" (for example where the determinant ${tex(d.value)}$ is 0)" if square and d.value.free_symbols \
                else ""
            notes.insert(0, f"The entries contain {', '.join(letters)}: the rank, inverse, reduced form and "
                            f"eigenvectors are for general values of {'it' if len(letters) == 1 else 'them'}; "
                            f"for special values{where} they can be different.")
        badge = "exact" if exact else "numerical estimate"
        out = item(node, "solution", lines, badge=badge, notes=notes)
        if table:
            out["table"] = table
        return out

    def inverse_tex(self, inv, det) -> str:
        """With fractions, show it as (1/det)·(integer matrix) as well."""
        plain = matrix_tex(inv)
        if det.is_Rational and not det.is_Integer or (det.is_Integer and abs(det) > 1):
            scaled = sp.ImmutableMatrix(inv * det)
            if all(e.is_Integer for e in scaled):
                return f"\\frac{{1}}{{{tex(det)}}}{matrix_tex(scaled)} = {plain}"
        return plain

    def eigen_lines(self, ev, nm) -> list[dict]:
        lam = tex(ev.lam)
        out = [line(f"\\det\\left({nm} - {lam} I\\right) = {tex(ev.charpoly)}", label="Characteristic polynomial")]
        parts = []
        for e in ev.items:
            v = f"{lam} = {tex(e.value)}" if e.radical else f"{lam} \\approx {tex(sp.N(e.value, self.places + 2))}"
            parts.append(v + (f"\\ (\\times {e.multiplicity})" if e.multiplicity > 1 else ""))
        out.append(line(r",\quad ".join(parts), label="Eigenvalues"))
        dg = ev.diagonalizable
        if dg is not None:
            out.append(line(r"\text{yes}" if dg else r"\text{no}", label="Diagonalizable (over ℝ)"))
        return out

    def eigen_table(self, ev) -> dict | None:
        rows = []
        for e in ev.items:
            if not e.real:
                continue
            vecs = r",\ ".join(matrix_tex(v) for v in e.vectors) or r"\text{—}"
            value = tex(e.value) if e.radical else r"\approx " + tex(sp.N(e.value, self.places + 2))
            if not e.radical and e.vectors:
                vecs = r"\approx " + vecs
            rows.append([value, str(e.multiplicity), str(len(e.vectors)) if e.radical else "1", vecs])
        if not rows:
            return None
        return {"caption": "Eigenvectors (a basis of each eigenspace)",
                "columns": ["eigenvalue", "algebraic multiplicity", "geometric multiplicity", "eigenvectors"],
                "rows": rows}

    # ---------------------------------------------------- operations ----
    def checked_call(self, st: A.Call) -> dict:
        arg = self.convert(st.args[0])
        if not isinstance(arg, sp.MatrixBase):
            raise MathError(f"{st.name} needs a matrix, e.g. {st.name}([[1, 2], [3, 4]]).")
        head = to_latex(st)
        if st.name == "det":
            d = determinant(arg)
            return item(st, "value", [line(f"{head} = {value_tex(d.value, self.places)}")],
                        badge="exact" if d.exact else "numerical estimate", notes=d.notes)
        if st.name == "rank":
            r = rank_checked(arg)
            return item(st, "value", [line(f"{head} = {tex(r.value)}")], badge="exact", notes=r.notes)
        d = determinant(arg)
        inv = inverse_checked(arg)
        return item(st, "solution", [line(f"{head} = {self.inverse_tex(inv.value, d.value)}", label="Inverse")],
                    badge="exact" if inv.exact else "numerical estimate", notes=inv.notes)

    def matrix_result(self, st, m) -> dict:
        notes = []
        # A^(-k): check that A^k times the result is the identity.
        if isinstance(st, A.BinOp) and st.op == "^" and isinstance(st.right, A.Neg) \
                and isinstance(st.right.operand, A.Num) and st.right.operand.text.isdigit():
            k = int(st.right.operand.text)
            base = self.convert(st.left)
            if isinstance(base, sp.MatrixBase) and base.rows == base.cols \
                    and all(sp.simplify(e) == 0 for e in base ** k * m - sp.eye(base.rows)):
                power = to_latex(st.left) + (f"^{{{k}}}" if k > 1 else "")
                notes.append(f"Checked: multiplying it by ${power}$ gives the identity matrix.")
        return item(st, "matrix", [line(f"{to_latex(st)} = {matrix_tex(m)}", label=f"Result ({shape_text(m)})")],
                    badge="exact", notes=notes)

    def query(self, st, q: MatrixQuery) -> dict:
        m = q.args[0]
        nm = to_latex(st.args[0]) if isinstance(st, A.Call) else "A"
        if q.name == "rref":
            rr = rref_checked(m)
            R, piv = rr.value
            notes = list(rr.notes)
            notes.insert(0, "Pivot columns: " + ", ".join(str(j + 1) for j in piv) + "." if piv else
                         "There are no pivots (the matrix is 0).")
            return item(st, "matrix", [line(f"\\operatorname{{rref}} {nm} = {matrix_tex(R)}",
                                            label="Reduced row echelon form")],
                        badge="exact" if rr.exact else "numerical estimate", notes=notes)
        if q.name in ("eigenvalues", "eigenvectors"):
            ev = eigen(m)
            out = item(st, "solution", self.eigen_lines(ev, nm), badge="exact" if ev.exact else "numerical estimate",
                       notes=ev.notes)
            table = self.eigen_table(ev)
            if table:
                out["table"] = table
            return out
        if q.name == "solve":
            b = q.args[1]
            if not isinstance(b, sp.MatrixBase):
                raise MathError("The right-hand side must be a vector, e.g. solve(A, [1, 2]).")
            names = [sp.Symbol(f"x_{i + 1}") for i in range(m.cols)]
            return self.linear_card(st, m, sp.ImmutableMatrix(b), names)
        raise MathError(f"Unknown operation {q.name}.")

    # ---------------------------------------------------- systems -------
    def system(self, st) -> dict:
        obj = self.convert(st)
        rels = obj.items if isinstance(obj, SystemObj) else [obj]
        eqs = []
        for r in rels:
            if not isinstance(r, RelChain) or r.ops != ["="]:
                raise MathError("Only equations can be solved here (inequalities are in the Equations & "
                                "inequalities tab).")
            if any(isinstance(e, sp.MatrixBase) for e in r.exprs):
                raise MathError("A matrix equation A = B compares matrices; to solve A·x = b use solve(A, b).")
            eqs.append(sp.Eq(r.exprs[0], r.exprs[1]))
        unknowns = order_symbols(set().union(*[e.free_symbols for e in eqs]))
        if not unknowns:
            raise MathError("There are no unknowns in this system.")
        try:
            Am, bm = sp.linear_eq_to_matrix(eqs, unknowns)
        except (ValueError, sp.PolynomialError, NotImplementedError):
            raise MathError("This system is not linear; the Equations & inequalities tab solves it.")
        return self.linear_card(st, sp.ImmutableMatrix(Am), sp.ImmutableMatrix(bm), unknowns)

    def linear_card(self, st, Am, bm, unknowns) -> dict:
        sol = solve_linear(Am, bm)
        aug = sp.ImmutableMatrix(Am.row_join(bm))
        lines = [line(augmented_tex(aug, Am.cols), label="Augmented matrix"),
                 line(augmented_tex(sol.rref, Am.cols), label="Reduced form")]
        names = ", ".join(tex(u) for u in unknowns)
        if sol.kind == "none":
            lines.insert(0, line(r"\text{no solution}", label="Solution"))
            return item(st, "solution", lines, badge="exact", notes=sol.notes)
        vals = ", ".join(tex(v) for v in sol.solution)
        head = f"\\left({names}\\right) = \\left({vals}\\right)" if len(unknowns) > 1 else f"{names} = {vals}"
        lines.insert(0, line(head, label="Solution" if sol.kind == "unique" else "Solutions"))
        notes = list(sol.notes)
        if sol.params:
            ps = ", ".join(f"${tex(p)}$" for p in sol.params)
            notes.insert(0, f"Infinitely many solutions: {ps} can be any real number"
                            f"{'s' if len(sol.params) > 1 else ''} (free unknowns).")
        return item(st, "solution", lines, badge="exact", notes=notes)


def _name(name: str) -> str:
    return tex(sp.Symbol(name))


def _lc(s: str) -> str:
    return s[0].lower() + s[1:] if s else s


def run(payload: dict) -> dict:
    text = payload.get("input", "")
    mode = payload.get("mode", "plain")
    options = payload.get("options", {}) or {}
    places = int(options.get("decimals", 4))
    try:
        stmts = parse(text, mode)
    except ParseError as e:
        return parse_error_response(e, text)
    ms = MatrixSession(places)
    results = []
    for st in stmts:
        try:
            results.append(ms.line(st))
        except (MathError, ParseError) as e:
            results.append(error_item(st, e, text))
        except Exception as e:  # keep the other lines' answers
            results.append(error_item(st, e))
    return response(results, echo=program_to_latex(stmts))
