"""Calculus tab.

Each line is one of
    lim(sin(x)/x, x -> 0)        a limit (one-sided: x -> 0+, at infinity: x -> inf)
    d/dx (x^2 ln x), diff(...)   a derivative; f'(x), f''(2) after defining f
    int(x e^x, x, 0, 1)          an integral (indefinite: int(x^2, x))
    x^3 - 3x  or  f(x) = ...     a function to analyse (domain, extrema, asymptotes, ...)
    x^2 + y^2 = 25               implicit differentiation (add "for x = 3 and y = 4" for the tangent)
Function definitions are analysed when nothing else in the input uses them.
"""
from __future__ import annotations

import sympy as sp

from ..calculus.analysis import analyze, clean_derivative, nicest
from ..calculus.derivatives import at_point, forms
from ..calculus.implicit import implicit
from ..calculus.integrals import definite, indefinite
from ..calculus.limits import compute_limit
from ..core.domain import requirements_note
from ..core.format import decimal_latex, exact_and_decimal, tex
from ..core.functions import collect_definitions
from ..graphing import plane
from ..graphing.jsprint import to_js
from ..graphing.traces import expression_trace, graph_spec
from ..parsing import A, MathError, ParseError, parse
from ..parsing.echo import program_to_latex, to_latex
from ..parsing.to_sympy import RelChain, symbol
from ..solving.periodic import pieces
from ..solving.systems import order_symbols
from ..solving.univariate import safe
from .common import error_item, item, line, parse_error_response, report_partial, response
from .evaluate import Session, finite_sums
from .graph import _number

AppliedUndef = sp.core.function.AppliedUndef
OPERATORS = (sp.Limit, sp.Derivative, sp.Integral, sp.Subs)


def _is_assignment(st) -> bool:
    if not (isinstance(st, A.Rel) and st.ops == ["="] and isinstance(st.items[0], A.Name)):
        return False
    if st.items[0].name in ("pi", "e", "inf", "x", "y"):
        return False
    return not any(isinstance(n, A.Name) and n.name not in ("pi", "e", "inf") for n in A.walk(st.items[1]))


def value_latex(v, places: int) -> str:
    v = sp.sympify(v)
    if v == sp.oo:
        return r"\infty"
    if v == -sp.oo:
        return r"-\infty"
    if v.has(sp.Float):
        d = decimal_latex(v, places)
        return r"\approx " + (d[0] if d else tex(v))
    return exact_and_decimal(v, places)["latex"]


def _eq(lhs: str, v, places) -> str:
    val = value_latex(v, places)
    return f"{lhs} {val}" if val.startswith(r"\approx") else f"{lhs} = {val}"


class CalculusSession:
    def __init__(self, session: Session, options: dict, places: int):
        self.s = session
        self.places = places
        self.options = options
        xr = self._range("x_min", "x_max")
        self.x_window = xr
        self.y_window = self._range("y_min", "y_max")
        self.done: list[dict] = []
        self.echo: list[str] = []

    def _range(self, a, b):
        lo, hi = str(self.options.get(a, "")).strip(), str(self.options.get(b, "")).strip()
        if lo and hi:
            lo_f, hi_f = _number(lo, "graph range"), _number(hi, "graph range")
            if hi_f > lo_f:
                return lo_f, hi_f
            raise MathError("The graph range must go from a smaller to a larger number.")
        return None

    def partial(self, it: dict):
        report_partial(response(self.done + [it], echo=self.echo))

    # ------------------------------------------------------------ dispatch --
    def line(self, st: A.Node) -> dict:
        if isinstance(st, A.Conditional) and not isinstance(st.value, A.Rel):
            raise MathError("A condition ('if ...') only makes sense in a function definition, for example "
                            "f(x) = 0 if x < 0, or after an equation in x and y: x^2 + y^2 = 25 for x = 3.")
        if isinstance(st, A.Conditional) or (isinstance(st, A.Rel) and st.ops == ["="]):
            return self.implicit_line(st)
        if isinstance(st, (A.Rel, A.Logic, A.System, A.InSet)):
            raise MathError("Equations and inequalities are solved in the Equations & inequalities tab. "
                            "Here, an equation in x and y such as x^2 + y^2 = 25 gives dy/dx.")
        conv = self.s.converter()
        obj = conv.convert(st)
        if not isinstance(obj, sp.Expr):
            raise MathError("Write a limit, a derivative, an integral, or a function to analyse.")
        expr, conds = self.s.apply(obj, conv.conditions)
        if expr.has(sp.Sum, sp.Product):
            expr = finite_sums(expr)
        if expr.has(*OPERATORS):
            return self.operators(st, expr, conds)
        free = sorted(expr.free_symbols, key=lambda v: v.name)
        if not free:
            return item(st, "value", [line(value_latex(sp.simplify(expr), self.places))], badge="exact",
                        notes=["There is no variable here, so this is just its value."])
        if len(free) > 1:
            raise MathError("A function to analyse must have one variable (here: " +
                            ", ".join(v.name for v in free) + ").")
        return self.analysis(st, expr, free[0], conds, "f")

    # ------------------------------------------------------------ operators --
    def operators(self, st, expr, conds) -> dict:
        if isinstance(expr, sp.Limit):
            return self.limit(st, expr)
        if isinstance(expr, sp.Derivative):
            return self.derivative(st, expr, conds)
        if isinstance(expr, sp.Subs) and isinstance(expr.expr, sp.Derivative):
            return self.prime(st, expr, conds)
        if isinstance(expr, sp.Integral):
            return self.integral(st, expr, conds)
        # A combination such as 2 lim(...) + int(...): evaluate each operator, innermost first.
        value = self.evaluate_operators(expr, conds)
        value = safe(sp.simplify, value) or value
        if value.free_symbols:
            return item(st, "symbolic", [line(tex(value), label="Result")], badge="exact")
        return item(st, "value", [line(value_latex(value, self.places))], badge="exact")

    def evaluate_operators(self, expr, conds):
        for _ in range(20):
            ops = [o for o in expr.atoms(*OPERATORS) if not o.args[0].has(*OPERATORS)]
            if not ops:
                return expr
            for o in ops:
                if isinstance(o, sp.Limit):
                    e, x, a, d = o.args
                    r = compute_limit(e, x, a, str(d))
                    if not r.exists:
                        raise MathError(f"${tex(o)}$ does not exist.")
                    v = r.value
                elif isinstance(o, sp.Integral) and len(o.limits[0]) == 3:
                    x, a, b = o.limits[0]
                    r = definite(o.function, x, a, b, conds)
                    if not r.converges:
                        raise MathError(f"${tex(o)}$ diverges.")
                    v = r.value
                else:
                    v = o.doit()
                expr = expr.xreplace({o: clean_derivative(v)})
        return expr

    def limit(self, st, L: sp.Limit) -> dict:
        e, x, a, d = L.args
        d = str(d)
        direction = d if a not in (sp.oo, -sp.oo) else "+-"
        try:
            r = compute_limit(e, x, a, direction)
        except ValueError as err:
            raise MathError(str(err))
        sup = "" if direction == "+-" or a in (sp.oo, -sp.oo) else ("^{+}" if d == "+" else "^{-}")
        if r.side_only:
            sup = "^{+}" if r.side_only == "+" else "^{-}"
        head = f"\\lim_{{{tex(x)} \\to {tex(a)}{sup}}} {tex(e)}" if sp.count_ops(e) < 40 else "L"
        lines, notes = [], list(r.notes)
        badge = "exact" if r.exact else "numerical estimate"
        if r.exists:
            lines.append(line(_eq(head, r.value, self.places), label="Limit"))
        else:
            lines.append(line(r"\text{the limit does not exist}", label="Limit"))
            badge = "undefined" if r.exact else badge
            if r.oscillates:
                lo, hi = r.oscillates
                notes.append(f"The values keep oscillating between ${tex(lo)}$ and ${tex(hi)}$.")
            if r.left is not None or r.right is not None:
                fe = tex(e) if sp.count_ops(e) < 40 else "f"
                lines.append(line(_eq(f"\\lim_{{{tex(x)} \\to {tex(a)}^{{-}}}} {fe}", r.left, self.places),
                                  label="From the left"))
                lines.append(line(_eq(f"\\lim_{{{tex(x)} \\to {tex(a)}^{{+}}}} {fe}", r.right, self.places),
                                  label="From the right"))
                notes.append("The one-sided limits differ, so the (two-sided) limit does not exist.")
            elif not r.oscillates:
                notes.append("The function becomes infinite with different signs on the two sides.")
        g = self.limit_graph(e, x, a, r)
        return item(st, "solution", lines, badge=badge, notes=notes, **({"graph": g} if g else {}))

    def limit_graph(self, e, x, a, r):
        if e.free_symbols != {x}:
            return None
        if a == sp.oo:
            window = (-2.0, 30.0)
        elif a == -sp.oo:
            window = (-30.0, 2.0)
        else:
            af = float(sp.N(a))
            span = max(4.0, abs(af) * 0.5)
            window = (af - span, af + span)
        window = self.x_window or window
        traces = [expression_trace(e, x, "y = " + plane._short(e), [], window)]
        if r.exists and r.value not in (sp.oo, -sp.oo, None) and not r.value.has(sp.Float) or \
                (r.exists and isinstance(r.value, sp.Float)):
            L = float(sp.N(r.value))
            if a in (sp.oo, -sp.oo):
                traces.append({"kind": "js", "label": f"y = {plane.plain_label(r.value)}", "js": repr(L),
                               "breaks": [], "periodic": [], "dots": [], "refetch": False, "dash": True})
            else:
                traces.append({"kind": "points", "label": "limit", "x": [float(sp.N(a))], "y": [L],
                               "text": [f"limit {plane.plain_label(r.value)}"], "periodic": [], "open": True})
        return graph_spec(traces, window)

    def derivative(self, st, D: sp.Derivative, conds) -> dict:
        e = D.expr
        (x, n), = D.variable_count
        result = clean_derivative(sp.diff(e, (x, n)))
        fs = forms(result)
        op = (f"\\frac{{d}}{{d{tex(x)}}}" if n == 1 else f"\\frac{{d^{{{n}}}}}{{d{tex(x)}^{{{n}}}}}")
        lhs = op + (f"\\left({tex(e)}\\right)" if sp.count_ops(e) > 0 else tex(e))
        lines = [line(f"{lhs} = {tex(fs[0])}", label="Derivative")]
        for f2 in fs[1:]:
            lines.append(line(tex(f2), label="Simplified"))
        notes = []
        note = requirements_note(conds)
        if note:
            notes.append(note + " The derivative can only exist there.")
        g = None
        if e.free_symbols == {x} and result.free_symbols <= {x}:
            window = self.x_window or (-10.0, 10.0)
            traces = [expression_trace(e, x, "f", [c for c in conds if sp.sympify(c.expr).free_symbols <= {x}],
                                       window)]
            dname = "f" + "'" * n
            try:
                traces.append(expression_trace(result, x, dname, [], window))
            except Exception:
                pass
            g = graph_spec(traces, window)
        return item(st, "symbolic", lines, badge="exact", notes=notes, **({"graph": g} if g else {}))

    def prime(self, st, S: sp.Subs, conds) -> dict:
        D = S.expr
        body = D.expr
        (t, n), = D.variable_count
        point = S.point[0]
        lhs = to_latex(st) if isinstance(st, A.Call) else f"f^{{({n})}}\\left({tex(point)}\\right)"
        if point.free_symbols:
            result = nicest(clean_derivative(sp.diff(body, (t, n)).subs(t, point)))
            return item(st, "symbolic", [line(f"{lhs} = {tex(result)}", label="Derivative")], badge="exact")
        xs = symbol("x")  # messages talk about x, not the internal variable
        r = at_point(body.subs(t, xs), xs, point, n, [c.subs({t: xs}) for c in conds])
        if r.value is None:
            raise MathError(r.reason or "The derivative does not exist there.")
        lines = [line(_eq(lhs, r.value, self.places), label="Derivative")]
        notes = list(r.notes)
        g = None
        if n == 1 and body.free_symbols == {t}:
            x = symbol("x")
            fx = body.subs(t, x)
            a = float(sp.N(point))
            window = self.x_window or (a - 5, a + 5)
            fa = sp.simplify(fx.subs(x, point))
            tangent = sp.expand(fa + r.value * (x - point))
            lines.append(line(f"y = {tex(tangent)}", label="Tangent line"))
            traces = [expression_trace(fx, x, "f", [], window),
                      expression_trace(tangent, x, "tangent", [], window),
                      {"kind": "points", "label": "point", "x": [a], "y": [float(sp.N(fa))],
                       "text": [f"({plane.plain_label(point)}, {plane.plain_label(fa)})"], "periodic": []}]
            traces[1]["dash"] = True
            g = graph_spec(traces, window)
        return item(st, "value", lines, badge="exact" if r.exact else "numerical estimate", notes=notes,
                    **({"graph": g} if g else {}))

    def integral(self, st, I: sp.Integral, conds) -> dict:
        f = I.function
        lim = I.limits[0]
        x = lim[0]
        xs = tex(x)
        conds_x = [c for c in conds if sp.sympify(c.expr).free_symbols <= {x}]
        if len(lim) == 1:
            r = indefinite(f, x)
            if r.value is None:
                raise MathError("No antiderivative in terms of elementary functions was found for "
                                f"${tex(f)}$. A definite integral (with bounds) can still be computed.")
            lines = [line(f"\\int {tex(f)}\\,d{xs} = {tex(r.value)} + C", label="Antiderivative")]
            notes = list(r.notes)
            if r.checked:
                notes.append("Checked: differentiating the answer gives the integrand back.")
            if r.special:
                notes.append("The answer uses the special function " + ", ".join(r.special) +
                             " (there is no formula with elementary functions).")
            if r.value.has(sp.Abs) and r.value.has(sp.log):
                notes.append("The constant C may be different on each interval where the function is defined.")
            g = None
            if f.free_symbols == {x}:
                window = self.x_window or (-10.0, 10.0)
                traces = [expression_trace(f, x, "f (integrand)", conds_x, window)]
                try:
                    traces.append(expression_trace(r.value, x, "F (C = 0)", [], window))
                except Exception:
                    pass
                g = graph_spec(traces, window)
            return item(st, "symbolic", lines, badge="exact" if r.exact else "numerical estimate", notes=notes,
                        **({"graph": g} if g else {}))
        _, a, b = lim
        try:
            r = definite(f, x, a, b, conds_x)
        except ValueError as err:
            raise MathError(str(err))
        head = f"\\int_{{{tex(a)}}}^{{{tex(b)}}} {tex(f)}\\,d{xs}"
        notes = list(r.notes)
        if r.converges:
            lines = [line(_eq(head, r.value, self.places), label="Integral")]
            if r.improper:
                notes.insert(0, "Improper integral (" + "; ".join(r.improper) + "): it converges.")
            if r.checked:
                notes.append("Checked by numerical integration.")
            badge = "exact" if r.exact else "numerical estimate"
        else:
            to = "" if r.value is None else (r" to $\infty$" if r.value == sp.oo else r" to $-\infty$")
            lines = [line(r"\text{diverges}", label="Integral", copy=head + r"\text{ diverges}")]
            notes.insert(0, "Improper integral (" + "; ".join(r.improper) + f"): it diverges{to}.")
            badge = "undefined"
        if r.special:
            notes.append("The answer uses the special function " + ", ".join(r.special) + ".")
        g = None
        if f.free_symbols == {x}:
            af = None if a == -sp.oo else float(sp.N(a))
            bf = None if b == sp.oo else float(sp.N(b))
            lo = af if af is not None else (bf - 10 if bf is not None else -10)
            hi = bf if bf is not None else (lo + 10)
            pad = max(1.0, (hi - lo) * 0.25)
            window = self.x_window or (lo - pad, hi + pad)
            js = to_js(f)
            traces = [expression_trace(f, x, "f", conds_x, window)]
            if js:
                traces.append({"kind": "area", "label": "area", "js": js, "from": af, "to": bf})
            g = graph_spec(traces, window)
        return item(st, "value", lines, badge=badge, notes=notes, **({"graph": g} if g else {}))

    # ------------------------------------------------------------ analysis --
    def analysis(self, node, f, x, conds, name: str) -> dict:
        conds = [c for c in conds if sp.sympify(c.expr).free_symbols <= {x}]
        head = to_latex(node)

        def progress(an):
            it = item(node, "analysis", [line(v, label=lab) for lab, v in an.lines], badge="numerical estimate",
                      notes=["Still working: the rest of the analysis was not finished."])
            self.partial(it)
        an = analyze(f, x, conds, name, self.places, progress=progress)
        lines = [line(v, label=lab) for lab, v in an.lines]
        g = self.analysis_graph(f, x, conds, an, name)
        it = item(node, "analysis", lines, badge="exact" if an.exact else "numerical estimate", notes=an.notes,
                  **({"graph": g} if g else {}))
        it["input_latex"] = head
        return it

    def analysis_graph(self, f, x, conds, an, name):
        xs_of_interest = [m["x"] for m in an.marks] + list(an.vertical)
        if an.families:
            P = max(float(sp.N(fam.period)) for fam, _, _ in an.families)
            window = (-2 * P, 2 * P) if P <= 7 else (-P, P)
        else:
            window = plane.fit_window(xs_of_interest)
        window = self.x_window or window
        try:
            traces = [expression_trace(f, x, f"{name}(x)", conds, window)]
        except Exception:
            return None
        groups: dict = {}
        for m in an.marks:
            groups.setdefault(m["label"], []).append(m)
        for label, ms in groups.items():
            traces.append({"kind": "points", "label": label, "x": [float(sp.N(m["x"])) for m in ms],
                           "y": [float(sp.N(m["y"])) for m in ms],
                           "text": [f"{label} ({plane.plain_label(m['x'])}, {plane.plain_label(m['y'])})"
                                    for m in ms], "periodic": []})
        for fam, label, val in an.families:
            starts = [[float(sp.N(v)), float(sp.N(fam.period))] for kind, v in pieces(fam.base) if kind == "pt"]
            traces.append({"kind": "points", "label": {"max": "local max", "min": "local min"}.get(label, label),
                           "x": [], "y": None, "y_js": to_js(f), "text": [], "periodic": starts})
        vx = [float(sp.N(v)) for v in an.vertical]
        vper = [[float(sp.N(s)), float(sp.N(p))] for s, p in an.vertical_families]
        if vx or vper:
            traces.append({"kind": "vlines", "label": "vertical asymptote", "x": vx, "periodic": vper})
        for kk, bb in an.slanted:
            js = to_js(kk * x + bb)
            if js:
                traces.append({"kind": "js", "label": "asymptote y = " + plane._short(kk * x + bb), "js": js,
                               "breaks": [], "periodic": [], "dots": [], "refetch": False, "dash": True,
                               "faint": True})
        spec = graph_spec(traces, window)
        if self.y_window:
            spec["y_range"] = list(self.y_window)
        return spec

    # ------------------------------------------------------------ implicit --
    def implicit_line(self, st) -> dict:
        cond = None
        node = st
        if isinstance(st, A.Conditional):
            node, cond = st.value, st.cond
            if cond is None:
                raise MathError("'otherwise' only makes sense in a function definition by cases.")
        conv = self.s.converter()
        rc = conv.convert(node)
        if not isinstance(rc, RelChain) or rc.ops != ["="]:
            raise MathError("Write one equation, e.g. x^2 + y^2 = 25.")
        lhs, rhs = rc.exprs
        lhs, _ = self.s.apply(lhs, [])
        rhs, _ = self.s.apply(rhs, [])
        free = order_symbols(sp.sympify(lhs - rhs).free_symbols | sp.sympify(lhs).free_symbols
                             | sp.sympify(rhs).free_symbols)
        if len(free) != 2:
            raise MathError("That's an equation in one variable: solve it in the Equations & inequalities tab. "
                            "Here, an equation in two variables (x and y) gives dy/dx." if len(free) < 2 else
                            "Implicit differentiation works with two variables (x and y).")
        x, y = free
        points = []
        if cond is not None:
            c = conv.condition(cond)
            given = {}
            for rel in (c.args if isinstance(c, sp.And) else [c]):
                if isinstance(rel, sp.Equality) and isinstance(rel.lhs, sp.Symbol) and not rel.rhs.free_symbols:
                    given[rel.lhs] = rel.rhs
            if x not in given:
                raise MathError(f"Give the point as 'for {x.name} = 3 and {y.name} = 4' (or just 'for {x.name} = 3').")
            if y in given:
                points = [(given[x], given[y])]
            else:
                ys = sp.solve(sp.sympify(lhs - rhs).subs(x, given[x]), y)
                points = [(given[x], v) for v in ys if v.is_real]
                if not points:
                    raise MathError(f"No point of the curve has ${tex(x)} = {tex(given[x])}$.")
        try:
            base = implicit(lhs, rhs, x, y)
        except ValueError as err:
            raise MathError(str(err))
        dy = f"\\frac{{d{tex(y)}}}{{d{tex(x)}}}"
        lines = [line(f"{dy} = {tex(base.dydx)}", label="Derivative"),
                 line(f"\\frac{{d^{{2}}{tex(y)}}}{{d{tex(x)}^{{2}}}} = {tex(base.d2ydx2)}", label="Second derivative")]
        notes = [f"Found by differentiating both sides with respect to ${tex(x)}$, treating ${tex(y)}$ as a "
                 f"function of ${tex(x)}$."]
        tangents = []
        for x0, y0 in points:
            try:
                r = implicit(lhs, rhs, x, y, (x0, y0))
            except ValueError as err:
                raise MathError(str(err))
            at = f"\\left({tex(x0)}, {tex(y0)}\\right)"
            if r.slope is None:
                lines.append(line(f"{tex(x)} = {tex(x0)}", label=f"Tangent at ({plane.plain_label(x0)}, "
                                                                  f"{plane.plain_label(y0)})"))
                notes += r.notes
                continue
            lines.append(line(f"\\left.{dy}\\right|_{{{at}}} = {value_latex(r.slope, self.places)}",
                              label="Slope"))
            lines.append(line(f"{tex(y)} = {tex(r.tangent)}", label="Tangent line"))
            tangents.append((x0, y0, r.tangent))
        from ..solving.systems import Leaf
        g = plane.plane_graph([Leaf(lhs, "=", rhs)], x, y, self.x_window or (-10.0, 10.0), self.y_window,
                              points=[{x: x0, y: y0} for x0, y0 in points] or None, label_points="point")
        if g is not None:
            for x0, y0, tline in tangents:
                js = to_js(tline)
                if js:
                    g["traces"].append({"kind": "js", "label": "tangent", "js": js, "breaks": [], "periodic": [],
                                        "dots": [], "refetch": False, "dash": True})
        return item(st, "solution", lines, badge="exact", notes=notes, **({"graph": g} if g else {}))


def run(payload: dict) -> dict:
    text = payload.get("input", "")
    mode = payload.get("mode", "plain")
    options = payload.get("options", {}) or {}
    places = int(options.get("decimals", 4))
    try:
        stmts = parse(text, mode)
    except ParseError as e:
        return parse_error_response(e, text)
    table, defs_at, def_errors = collect_definitions(stmts)
    session = Session(table, places=places, depth_limit=int(options.get("depth", 1000)))
    try:
        cs = CalculusSession(session, options, places)
    except MathError as e:
        return {"ok": False, "results": [], "echo": [], "error": e.to_dict(), "summary_latex": None}
    cs.echo = program_to_latex(stmts)
    others = [i for i, st in enumerate(stmts) if i not in defs_at and i not in def_errors and not _is_assignment(st)]
    shown: set[str] = set()
    results = cs.done
    for i, st in enumerate(stmts):
        try:
            if i in def_errors:
                results.append(error_item(st, def_errors[i], text))
                continue
            if i in defs_at:
                fd = defs_at[i]
                if fd.name in shown:
                    continue
                shown.add(fd.name)
                results.append(session.definition_card(fd))
                if not others and fd.arity == 1 and fd.name not in session.recursive:
                    body = fd.body()
                    x = fd.params[0]
                    results.append(cs.analysis(fd.nodes[0], body, x, list(fd.guarded_conditions()), fd.name))
                continue
            if _is_assignment(st):
                results.append(session.assign(st))
                continue
            results.append(cs.line(st))
        except (MathError, ParseError) as e:
            results.append(error_item(st, e, text))
        except Exception as e:
            results.append(error_item(st, e))
    return response(results, echo=cs.echo)
