"""Sequences & series tab.

Each line is one of
    a_n = 2a_(n-1) + 1   with   a_0 = 0      a recurrence and its initial values
                                             (also a_(n+1) = ..., or f(n) = ... with f(0) = ...)
    a_n = 1/n   or just   1/n                an explicit formula (from n = 1 unless set)
    a_10                                     one term of a defined sequence
    sum(1/n^2, n, 1, inf)                    a series, a finite sum, or a sum up to a letter
In this tab a_n, a_(n-1), a_0 are read as terms of the sequence a: the
subscripts are rewritten into calls a(n), a(n-1), a(0) before converting.
"""
from __future__ import annotations

import sympy as sp

from ..calculus.sequences import (Sequence, check_rule, closed_form, float_terms, index_symbol, iterate,
                                  numeric_limit, progression, sequence_limit)
from ..calculus.series import closed_product, closed_sum, finite_product, finite_sum, infinite_series
from ..core.domain import explain, first_violation
from ..core.format import decimal_latex, exact_and_decimal, tex
from ..graphing.traces import graph_spec
from ..parsing import A, MathError, ParseError, parse
from ..parsing.echo import program_to_latex, to_latex
from ..parsing.names import FUNCTIONS
from ..parsing.to_sympy import Converter
from .common import error_item, item, line, parse_error_response, report_partial, response

AppliedUndef = sp.core.function.AppliedUndef
MAX_TERMS = 200
MAX_INDEX = 5000


# ------------------------------------------------------------ rewriting ---
def sequence_names(stmts) -> set[str]:
    """Names defined as sequences: the left side of a_n = …, a_(n+1) = …, a_0 = …, f(n) = …"""
    out = set()
    for st in stmts:
        if not (isinstance(st, A.Rel) and st.ops == ["="] and len(st.items) == 2):
            continue
        lhs = st.items[0]
        if isinstance(lhs, A.Name) and "_" in lhs.name:
            base = lhs.name.partition("_")[0]
            if base not in ("pi", "e", "inf"):
                out.add(base)
        elif isinstance(lhs, A.Subscript):
            out.add(lhs.base)
        elif isinstance(lhs, A.Call) and lhs.name not in FUNCTIONS and lhs.primes == 0 and len(lhs.args) == 1:
            out.add(lhs.name)
    return out


def rewrite(node: A.Node, names: set[str]) -> A.Node:
    """a_n -> a(n), a_0 -> a(0), a_(n-1) -> a(n-1) for the sequence names."""
    def fn(nd):
        if isinstance(nd, A.Name) and "_" in nd.name:
            base, _, sub = nd.name.partition("_")
            if base in names and sub:
                idx = A.Num(sub, span=nd.span) if sub.isdigit() else A.Name(sub, span=nd.span)
                return A.Call(base, [idx], span=nd.span)
        if isinstance(nd, A.Subscript) and nd.base in names:
            return A.Call(nd.base, [nd.index], span=nd.span)
        return None
    return A.transform(node, fn)


def subscript_latex(latex: str, names: set[str]) -> str:
    r"""a\left(n-1\right) -> a_{n-1} for the sequence names (in condition texts)."""
    out, i = [], 0
    while i < len(latex):
        hit, brace = None, False
        for nm in names:
            for b in (False, True):  # SymPy prints a(k) as a{\left(k \right)}
                head = nm + ("{" if b else "") + r"\left("
                if latex.startswith(head, i) and (i == 0 or not latex[i - 1].isalpha()):
                    hit, brace = nm, b
        if hit is None:
            out.append(latex[i])
            i += 1
            continue
        j = i + len(hit) + len(r"\left(") + brace
        depth, k = 1, j
        while k < len(latex) and depth:
            if latex.startswith(r"\left(", k):
                depth += 1
                k += len(r"\left(")
            elif latex.startswith(r"\right)", k):
                depth -= 1
                if depth == 0:
                    break
                k += len(r"\right)")
            else:
                k += 1
        if depth:
            out.append(latex[i:])
            break
        out.append(f"{hit}_{{{latex[j:k].strip()}}}")
        i = k + len(r"\right)")
        if brace and latex.startswith("}", i):
            i += 1
    return "".join(out)


def _name_tex(name: str) -> str:
    return name if len(name) == 1 else r"\operatorname{" + name + "}"


# ------------------------------------------------------------ definitions -
class Definitions:
    def __init__(self):
        self.seqs: dict[str, Sequence] = {}
        self.nodes: dict[str, list[A.Node]] = {}
        self.lines: dict[int, str] = {}
        self.errors: dict[int, Exception] = {}


def collect(rewritten, originals, names, start_option: int) -> Definitions:
    d = Definitions()
    raw: dict[str, dict] = {}
    for i, st in enumerate(rewritten):
        if not (isinstance(st, A.Rel) and st.ops == ["="] and len(st.items) == 2
                and isinstance(st.items[0], A.Call) and st.items[0].name in names):
            continue
        lhs, rhs_node = st.items
        name = lhs.name
        entry = raw.setdefault(name, {"rule": None, "rule_line": None, "initial": {}, "lines": []})
        try:
            if len(lhs.args) != 1:
                raise MathError(f"A sequence has a single index: write {name}_n = ….")
            idx = Converter().expr(lhs.args[0])
            conv = Converter(int_vars={s.name for s in idx.free_symbols})
            rhs = conv.expr(rhs_node)
            if rhs.has(sp.Sum, sp.Product):
                raise MathError("Sums and products inside a sequence's definition aren't supported; write the sum "
                                "or product on its own line.")
            conds = conv.conditions
            for c in conds:
                c.latex = subscript_latex(c.latex, names)
            if idx.is_number:
                _initial_value(entry, name, idx, rhs, conds)
            else:
                if entry["rule"] is not None:
                    raise MathError(f"{name} is defined by two formulas. Keep one, and give initial values "
                                    f"such as {name}_0 = … on their own.")
                entry["rule"] = _rule(name, idx, rhs, conds)
                entry["rule_line"] = i
            entry["lines"].append(i)
            d.lines[i] = name
        except (MathError, ParseError) as e:
            d.errors[i] = e
    for name, entry in raw.items():
        first = min(entry["lines"]) if entry["lines"] else None
        if first is None:
            continue
        try:
            if entry["rule"] is None:
                raise MathError(f"Only initial values of {name} are given. Add the rule, e.g. "
                                f"{name}_n = 2{name}_(n-1) + 1.")
            n, rule, conds = entry["rule"]
            try:
                check_rule(name, n, rule)
            except MathError as e:
                d.errors[entry["rule_line"]] = e
                for i in entry["lines"]:
                    d.lines.pop(i, None)
                continue
            seq = Sequence(name, n, rule, conds, dict(entry["initial"]))
            if seq.explicit:
                seq.start = min([start_option] + list(seq.initial))
            else:
                seq.start = min(seq.initial) if seq.initial else 0
            d.seqs[name] = seq
            d.nodes[name] = [originals[i] for i in sorted(entry["lines"])]
        except MathError as e:
            d.errors[first] = e
            for i in entry["lines"]:
                d.lines.pop(i, None)
    return d


def _initial_value(entry, name, idx, rhs, conds):
    if not idx.is_Integer:
        raise MathError(f"The index of an initial value must be a whole number, e.g. {name}_0 = 1.")
    if rhs.free_symbols or rhs.has(AppliedUndef):
        raise MathError(f"An initial value must be a number: ${_name_tex(name)}_{{{tex(idx)}}} = …$ "
                        "with a number on the right.")
    v = first_violation(conds)
    if v is not None:
        raise MathError("Undefined. " + explain(*v))
    if rhs.has(sp.nan, sp.zoo, sp.oo, -sp.oo) or rhs.is_real is False:
        raise MathError(f"${_name_tex(name)}_{{{tex(idx)}}}$ must be a real number.")
    k = int(idx)
    if k in entry["initial"]:
        raise MathError(f"${_name_tex(name)}_{{{k}}}$ is given twice.")
    entry["initial"][k] = rhs


def _rule(name, idx, rhs, conds):
    free = idx.free_symbols
    shift = sp.simplify(idx - next(iter(free))) if len(free) == 1 else None
    if shift is None or not shift.is_Integer:
        raise MathError(f"The index on the left must be like n or n + 1 (here it is ${tex(idx)}$). "
                        "Recursions such as f(2n) = … belong in the Piecewise & recursive tab.")
    n = next(iter(free))
    rule = rhs.subs(n, n - shift) if shift else rhs
    conds = [c.subs({n: n - shift}) for c in conds] if shift else conds
    extra = rule.free_symbols - {n}
    if extra:
        names = ", ".join(sorted(s.name for s in extra))
        raise MathError(f"The formula uses {names} besides the index {n.name}. Use numbers instead "
                        f"(or {n.name} as the index).")
    return n, rule, conds


# ------------------------------------------------------------ session -----
class SequencesSession:
    def __init__(self, defs: Definitions, options: dict, places: int):
        self.defs = defs
        self.places = places
        self.terms = _int_option(options, "terms", 10, 1, MAX_TERMS)
        self.start = _int_option(options, "start", 1, -1000, 10**6)
        self.done: list[dict] = []
        self.echo: list[str] = []
        self._cf_cache: dict[str, object] = {}
        self._cf_notes: dict[str, list[str]] = {}

    def partial(self, it: dict):
        report_partial(response(self.done + [it], echo=self.echo))

    # ---------------------------------------------------- dispatch ------
    def line(self, st: A.Node, orig: A.Node) -> dict:
        if isinstance(st, (A.Rel, A.Logic, A.System, A.InSet, A.Conditional)):
            raise MathError("Equations and inequalities are solved in the Equations & inequalities tab. "
                            "Here, define a sequence (a_n = …) or write a sum, e.g. sum(1/n^2, n, 1, inf).")
        conv = Converter()
        obj = conv.convert(st)
        if not isinstance(obj, sp.Expr):
            raise MathError("Write a sequence (a_n = … or a formula in n) or a sum.")
        if len(obj.free_symbols) == 1 and not obj.has(sp.Sum, sp.Product):
            # A formula in one letter is a sequence: that letter is a whole-number index.
            conv = Converter(int_vars={s.name for s in obj.free_symbols})
            obj = conv.convert(st)
        if obj.has(sp.Product):
            return self.product_line(orig, obj, conv)
        if obj.has(sp.Sum):
            return self.sum_line(orig, obj, conv)
        if obj.has(AppliedUndef):
            return self.term_line(orig, obj)
        free = sorted(obj.free_symbols, key=lambda s: s.name)
        if not free:
            v = sp.simplify(obj)
            return item(orig, "value", [line(exact_and_decimal(v, self.places)["latex"])], badge="exact",
                        notes=["There is no index here, so this is just its value."])
        if len(free) > 1:
            raise MathError("A formula for a sequence must use one letter as the index (here: " +
                            ", ".join(s.name for s in free) + ").")
        seq = Sequence("a", free[0], obj, conv.conditions, {}, self.start)
        return self.sequence_card(seq, [orig], implicit=True)

    # ---------------------------------------------------- sequences -----
    def closed(self, seq: Sequence, terms):
        if seq.name not in self._cf_cache:
            why: list[str] = []
            self._cf_cache[seq.name] = None if seq.explicit else closed_form(seq, terms, why)
            self._cf_notes[seq.name] = why
        return self._cf_cache[seq.name]

    def formula(self, seq: Sequence):
        """(expression in the integer index N, N) valid for every n ≥ start, or None."""
        N = index_symbol(seq)
        if seq.explicit:
            if seq.initial:
                return None
            return sp.sympify(seq.rule).xreplace({seq.n: N}), N
        it = iterate(seq, 16)
        cf = self.closed(seq, it.terms)
        if cf is None or cf.general or cf.valid_from > seq.start:
            return None
        return cf.expr, cf.N

    def sequence_card(self, seq: Sequence, nodes, implicit=False) -> dict:
        nm = _name_tex(seq.name)
        n = seq.n
        lines, notes = [], []
        badge = "exact"
        it = iterate(seq, max(self.terms, 16))
        shown = it.terms[:self.terms]
        lhs = f"{nm}_{{{tex(n)}}}"
        formula = None
        cf = None
        if implicit:
            notes.append(f"Read as the sequence ${lhs} = {tex(seq.rule)}$ for ${tex(n)} \\ge {seq.start}$ "
                         "(change the first index in the options).")
        if seq.explicit:
            if not seq.initial:
                formula = sp.sympify(seq.rule).xreplace({n: index_symbol(seq)})
        else:
            cf = self.closed(seq, it.terms)
            if cf is not None and cf.general:
                lines.append(line(f"{lhs} = {tex(cf.expr)}", label="General solution"))
                missing = ", ".join(f"${nm}_{{{k}}}$" for k in seq.missing_initial())
                notes.append(f"No value is given for {missing}, so the solution has constants "
                             f"($C_0, C_1, …$). Give {missing} to fix them.")
                notes.append("Checked by substitution: it satisfies the recurrence for any constants.")
            elif cf is not None:
                lines.append(line(f"{lhs} = {tex(cf.expr)}", label="Closed form"))
                notes.append(cf.proof)
                if cf.valid_from > seq.start:
                    notes.append(f"The formula holds for ${tex(n)} \\ge {cf.valid_from}$ (the given initial "
                                 "values before that don't follow it).")
                else:
                    formula = cf.expr
            else:
                notes.extend(self._cf_notes.get(seq.name) or
                             ["No closed form was found; the terms are computed from the recurrence."])
        # Terms
        if shown:
            lines.append(line(self.terms_latex(seq, shown, len(it.terms) > len(shown) or not it.stopped),
                              label=f"First {len(shown)} terms" if len(shown) > 1 else "First term"))
        if it.stopped and (len(it.terms) < self.terms or seq.missing_initial()):
            if "undefined" in it.stopped:
                badge = "undefined"
            if not (cf is not None and cf.general):
                notes.append(it.stopped)
        # Arithmetic / geometric
        if formula is not None:
            N = cf.N if cf is not None else index_symbol(seq)
            kind = progression(formula, N)
            if kind is not None:
                lines.append(line(_kind_latex(kind), label="Type"))
        # Partial sums (skipped when they could only come out unreadable)
        irrational_powers = formula is not None and any(
            p.base.is_number and p.base.is_irrational and p.exp.free_symbols for p in formula.atoms(sp.Pow))
        if formula is not None and not irrational_powers:
            N = cf.N if cf is not None else index_symbol(seq)
            k = sp.Symbol("k", integer=True)
            renamed = (sp.harmonic, sp.polygamma, sp.zeta, sp.lerchphi, sp.hyper, sp.gamma, sp.loggamma)
            S = closed_sum(formula.xreplace({N: k}), k, seq.start, n,
                           keep=lambda s: len(tex(s)) < 240 and not s.has(*renamed))
            if S is not None and S.value is not None and len(tex(S.value)) < 120:
                sum_tex = f"\\sum_{{k={seq.start}}}^{{{tex(n)}}} {nm}_{{k}}"
                lines.append(line(f"S_{{{tex(n)}}} = {sum_tex} = {tex(S.value)}", label="Partial sums"))
                notes.extend("Partial sums: " + s[0].lower() + s[1:] for s in S.notes)
        # Limit
        limit_value = None
        if not (cf is not None and cf.general) and not (it.stopped and len(it.terms) < self.terms):
            lim_tex = f"\\lim_{{{tex(n)} \\to \\infty}} {lhs}"
            if formula is not None:
                N = cf.N if cf is not None else index_symbol(seq)
                L = sequence_limit(formula, N)
                lim_line, extra, exact = self.limit_lines(lim_tex, L.value, L.exists, L.exact,
                                                          L.subsequences, L.oscillates)
                notes.extend(L.notes + extra)
            else:
                nl = numeric_limit(seq)
                lim_line, extra, exact = self.limit_lines(lim_tex, nl.value, nl.exists, False, None, None)
                notes.extend(nl.notes + extra)
                L = nl
            if lim_line is not None:
                lines.append(lim_line)
                if not exact and badge == "exact":
                    badge = "numerical estimate"
                if L.exists and L.value is not None and L.value not in (sp.oo, -sp.oo):
                    limit_value = L.value
        g = self.sequence_graph(seq, limit_value)
        out = item(nodes[0], "solution", lines, badge=badge, notes=notes, **({"graph": g} if g else {}))
        if len(nodes) > 1:
            out["input_latex"] = r",\quad ".join(to_latex(nd) for nd in nodes)
        out["table"] = self.terms_table(seq, shown)
        return out

    def terms_latex(self, seq, terms, more: bool) -> str:
        vals = []
        exact = all(t.exact is not None for t in terms) and sum(len(tex(t.exact)) for t in terms) < 300
        for t in terms:
            if exact:
                vals.append(tex(t.exact))
            else:
                d = decimal_latex(sp.Float(str(t.value), 20), self.places)
                vals.append(d[0] if d else tex(sp.Float(str(t.value), 6)))
        body = ",\\ ".join(vals) + (",\\ \\ldots" if more else "")
        return body if exact else r"\approx " + body

    def terms_table(self, seq, terms):
        if len(terms) < 2:
            return None
        rows = []
        for t in terms:
            if t.exact is not None and len(tex(t.exact)) <= 40:
                v = exact_and_decimal(t.exact, self.places)["latex"]
            else:
                d = decimal_latex(sp.Float(str(t.value), 20), self.places)
                v = r"\approx " + (d[0] if d else "?")
            rows.append([str(t.k), v])
        return {"caption": f"Terms for {seq.n.name} = {terms[0].k} to {terms[-1].k}",
                "columns": [seq.n.name, f"{seq.name}_{seq.n.name}"], "rows": rows}

    def limit_lines(self, lim_tex, value, exists, exact, subsequences, oscillates):
        notes = []
        if exists is None:
            return None, ["The limit could not be determined."], False
        if exists is False:
            if value in (sp.oo, -sp.oo):
                return line(f"{lim_tex} = {tex(value)}", label="Limit"), \
                    [f"The sequence diverges to ${tex(value)}$."], exact
            if subsequences:
                p = subsequences[0][0]
                vals = ", ".join(f"${tex(v)}$" for _, _, v in subsequences)
                which = "the even and the odd terms" if p == 2 else \
                    f"the terms with $n = {p}m, {p}m+1, …, {p}m+{p - 1}$"
                notes.append(f"It does not exist: {which} tend to {vals}.")
            elif oscillates:
                notes.append("It does not exist: the terms keep oscillating.")
            return line(r"\text{does not exist}", label="Limit", copy=lim_tex + r"\text{ does not exist}"), \
                notes, exact
        if value in (sp.oo, -sp.oo):
            return line(f"{lim_tex} = {tex(value)}", label="Limit"), \
                [f"The sequence diverges to ${tex(value)}$."], exact
        if isinstance(value, sp.Float) or not exact:
            d = decimal_latex(value, self.places)
            v = exact_and_decimal(value, self.places)["latex"] if not isinstance(value, sp.Float) else \
                (d[0] if d else tex(value))
            sep = "=" if not isinstance(value, sp.Float) else r"\approx"
            return line(f"{lim_tex} {sep} {v}", label="Limit"), notes, False
        return line(f"{lim_tex} = {exact_and_decimal(value, self.places)['latex']}", label="Limit"), notes, True

    def sequence_graph(self, seq: Sequence, limit_value) -> dict | None:
        pts = float_terms(seq, min(max(self.terms, 30), MAX_TERMS))
        if len(pts) < 2:
            return None
        nm = seq.name
        traces = [{"kind": "points", "label": f"{nm}_{seq.n.name}", "x": [float(k) for k, _ in pts],
                   "y": [v for _, v in pts], "text": [f"{nm}_{k} ≈ {v:.6g}" for k, v in pts], "periodic": []}]
        if limit_value is not None:
            L = float(sp.N(limit_value))
            traces.append({"kind": "js", "label": f"limit {_short(limit_value)}", "js": repr(L), "breaks": [],
                           "periodic": [], "dots": [], "refetch": False, "dash": True})
        lo, hi = pts[0][0], pts[-1][0]
        return graph_spec(traces, (lo - 1, hi + 1))

    # ---------------------------------------------------- terms ---------
    def term_line(self, node, obj) -> dict:
        reps, notes, exact = {}, [], True
        for c in obj.atoms(AppliedUndef):
            name = c.func.__name__
            seq = self.defs.seqs.get(name)
            if seq is None:
                raise MathError(f"{name} is not defined. Define it first, e.g. {name}_n = ….")
            if len(c.args) != 1 or c.args[0].free_symbols:
                raise MathError(f"Ask for one term with a number as the index, e.g. {name}_10.")
            k = c.args[0]
            if not k.is_Integer or k < seq.start:
                raise MathError(f"The index must be a whole number ≥ {seq.start} (the first index of {name}).")
            v, ex = self.term_value(seq, int(k))
            reps[c] = v
            exact = exact and ex
        value = obj.xreplace(reps)
        if exact:
            value = sp.simplify(value) if sp.count_ops(value) < 200 else value
            f = exact_and_decimal(value, self.places)
            if f.get("too_long"):
                notes.append(f["too_long"])
            return item(node, "value", [line(f["latex"], copy=f["decimal"] if f.get("too_long") else None)],
                        badge="numerical estimate" if f.get("too_long") else "exact", notes=notes)
        d = decimal_latex(value, self.places)
        notes.append("The exact value got too large to keep, so this was computed with 30-digit decimals.")
        return item(node, "value", [line(r"\approx " + (d[0] if d else tex(value)))], badge="numerical estimate",
                    notes=notes)

    def term_value(self, seq: Sequence, k: int):
        if seq.explicit and k not in seq.initial:
            v = first_violation([c.subs({seq.n: k}) for c in seq.conditions])
            if v is not None:
                raise MathError(f"${_name_tex(seq.name)}_{{{k}}}$ is undefined: " + explain(*v))
            value = sp.sympify(seq.rule).subs(seq.n, k)
            if value.has(sp.nan, sp.zoo) or value.is_real is False:
                raise MathError(f"${_name_tex(seq.name)}_{{{k}}}$ is undefined (not a real number).")
            return value, True
        if k - seq.start >= MAX_INDEX:
            f = self.formula(seq)
            if f is not None:
                expr, N = f
                return expr.subs(N, k), True
            raise MathError(f"That term is too far out to compute by stepping through the recurrence "
                            f"(more than {MAX_INDEX} steps), and no closed form was found.")
        it = iterate(seq, k - seq.start + 1)
        if not it.terms or it.terms[-1].k != k:
            raise MathError(it.stopped or "That term could not be computed.")
        t = it.terms[-1]
        if t.exact is not None:
            return t.exact, True
        return sp.Float(str(t.value), 25), False

    # ---------------------------------------------------- sums ----------
    def sum_line(self, node, obj, conv) -> dict:
        if not isinstance(obj, sp.Sum):
            return self.sum_combination(node, obj, conv)
        f, (k, lo, hi) = obj.function, obj.limits[0]
        conds = conv.sum_conditions.get(obj, [])
        if not lo.is_Integer:
            raise MathError("Start the sum at a whole number, e.g. sum(1/k^2, k, 1, inf).")
        head = subscript_latex(tex(obj), set(self.defs.seqs))
        f, direct = self.substitute_sequences(f, k, lo, hi)
        if direct is not None:
            v = exact_and_decimal(direct, self.places)
            return item(node, "value", [line(f"{head} = {v['latex']}", label="Sum")], badge="exact",
                        notes=["Added up from the computed terms."])
        if hi == sp.oo:
            return self.series_card(node, f, k, int(lo), conds, head)
        if hi.is_Integer:
            r = finite_sum(f, k, int(lo), int(hi), conds)
            return self.finite_card(node, r, head)
        if isinstance(hi, sp.Symbol):
            r = closed_sum(f, k, lo, hi)
            if r is None:
                raise MathError(f"No formula was found for ${head}$. With a number as the upper bound it can be "
                                "added up.")
            lines = [line(f"{head} = {tex(r.value)}", label="Sum")]
            notes = list(r.notes) + [f"For ${tex(hi)} \\ge {tex(lo)}$ (a whole number)."]
            return item(node, "symbolic", lines, badge="exact", notes=notes)
        raise MathError("The upper bound must be a whole number, a letter, or ∞.")

    def substitute_sequences(self, f, k, lo, hi):
        """Terms a_k of defined sequences inside a sum are replaced by their formula.
        Returns (new summand, None), or (None, value) when a finite sum had to be
        added up from the computed terms (no formula)."""
        calls = f.atoms(AppliedUndef)
        if not calls:
            return f, None
        reps = {}
        for c in calls:
            seq = self.defs.seqs.get(c.func.__name__)
            if seq is None:
                raise MathError(f"{c.func.__name__} is not defined here.")
            fm = self.formula(seq)
            if fm is None:
                if lo.is_Integer and hi.is_Integer and hi - lo < MAX_INDEX:
                    return None, self.sum_of_terms(f, k, int(lo), int(hi))
                raise MathError(f"${_name_tex(seq.name)}$ has no closed form, so it can only be summed "
                                "with numbers as bounds.")
            expr, N = fm
            for j in ([lo] if lo.is_Integer else []):
                if c.args[0].subs(k, j) < seq.start:
                    raise MathError(f"The sum uses terms before the first one, "
                                    f"${_name_tex(seq.name)}_{{{seq.start}}}$.")
            reps[c] = expr.subs(N, c.args[0])
        return f.xreplace(reps), None

    def sum_of_terms(self, f, k, lo, hi):
        values: dict[str, dict[int, sp.Expr]] = {}
        total = sp.Integer(0)
        for j in range(lo, hi + 1):
            t = f.subs(k, j)
            reps = {}
            for c in t.atoms(AppliedUndef):
                seq = self.defs.seqs[c.func.__name__]
                idx = c.args[0]
                if not idx.is_Integer or idx < seq.start:
                    raise MathError(f"${tex(c)}$ is not a term of {seq.name} (its first index is {seq.start}).")
                vals = values.setdefault(seq.name, {})
                if int(idx) not in vals:
                    it = iterate(seq, int(idx) - seq.start + 1 + (hi - j))
                    vals.update({tm.k: tm.exact for tm in it.terms})
                    if int(idx) not in vals:
                        raise MathError(it.stopped or f"${tex(c)}$ could not be computed.")
                if vals[int(idx)] is None:
                    raise MathError("The terms got too large to add up exactly.")
                reps[c] = vals[int(idx)]
            total += t.xreplace(reps)
        return total

    def sum_combination(self, node, obj, conv) -> dict:
        reps = {}
        for s in obj.atoms(sp.Sum):
            f, (k, lo, hi) = s.function, s.limits[0]
            f, direct = self.substitute_sequences(f, k, lo, hi)
            conds = conv.sum_conditions.get(s, [])
            if direct is not None:
                reps[s] = direct
            elif not lo.is_Integer:
                raise MathError("Start each sum at a whole number.")
            elif hi == sp.oo:
                r = infinite_series(f, k, int(lo), conds)
                if not r.converges or r.value is None:
                    raise MathError(f"${tex(s)}$ has no exact value here; write it on its own line to see why.")
                reps[s] = r.value
            elif hi.is_Integer and lo.is_Integer:
                r = finite_sum(f, k, int(lo), int(hi), conds)
                if r.value is None:
                    raise MathError(f"${tex(s)}$ has no exact value.")
                reps[s] = r.value
            else:
                raise MathError("Write a sum up to a letter on its own line.")
        value = obj.xreplace(reps)
        if value.free_symbols:
            return item(node, "symbolic", [line(tex(sp.simplify(value)), label="Result")], badge="exact")
        return item(node, "value", [line(exact_and_decimal(sp.simplify(value), self.places)["latex"])],
                    badge="exact")

    # ---------------------------------------------------- products ------
    def product_line(self, node, obj, conv) -> dict:
        """∏ with whole-number bounds (multiplied out) or up to a letter (a formula proved by
        induction), alone or inside an expression. Infinite products are not worked out yet."""
        if obj.has(sp.Sum):
            raise MathError("Write sums and products on separate lines.")
        reps, notes = {}, []
        for p in obj.atoms(sp.Product):
            if p.function.has(sp.Product):
                raise MathError("Products of products aren't supported.")
            f, (k, lo, hi) = p.function, p.limits[0]
            if f.has(AppliedUndef):
                raise MathError("Products of a defined sequence's terms aren't supported; write the formula instead.")
            if not lo.is_Integer:
                raise MathError("Start the product at a whole number, e.g. prod(1 + 1/k, k, 1, n).")
            if hi == sp.oo:
                raise MathError("Infinite products aren't supported yet. A product up to a whole number or a letter "
                                "works.")
            head = tex(p)
            if hi.is_Integer:
                r = finite_product(f, k, int(lo), int(hi), conv.sum_conditions.get(p, []))
                if p == obj:
                    return self.finite_card(node, r, head, label="Product")
                if r.value is None:
                    raise MathError(f"${head}$ is too large to work out exactly; write it on its own line.")
            elif hi.free_symbols:  # up to n, or n - 1, 2n, ...
                N = sp.Dummy("N", integer=True)
                r = closed_product(f, k, lo, N)
                if r is None:
                    raise MathError(f"No formula was found for ${head}$. With a number as the upper bound it can be "
                                    "multiplied out.")
                r.value = r.value.subs(N, hi)
                if p == obj:
                    notes = list(r.notes) + [f"For ${tex(hi)} \\ge {tex(lo)}$ (a whole number)."]
                    return item(node, "symbolic", [line(f"{head} = {tex(r.value)}", label="Product")],
                                badge="exact", notes=notes)
            else:
                raise MathError("The upper bound of a product must be a whole number or a letter.")
            reps[p] = r.value
            how = r.notes[0] if r.notes else ""
            notes.append(f"${head} = {tex(r.value)}$. {how}" if not hi.is_Integer else f"${head}$: {how}")
        value = sp.simplify(obj.xreplace(reps))
        if value.free_symbols:
            return item(node, "symbolic", [line(tex(value), label="Result")], badge="exact", notes=notes)
        return item(node, "value", [line(exact_and_decimal(value, self.places)["latex"])], badge="exact",
                    notes=notes)

    def finite_card(self, node, r, head, label="Sum") -> dict:
        notes = list(r.notes)
        if r.value is not None:
            v = r.value
            if v.free_symbols:
                return item(node, "symbolic", [line(f"{head} = {tex(v)}", label=label)], badge="exact", notes=notes)
            f = exact_and_decimal(v, self.places)
            if f.get("too_long"):
                notes.append(f["too_long"])
            lines = [line(f"{head} = {f['latex']}" if not f.get("too_long") else f"{head} {f['latex']}",
                          label=label, copy=f["decimal"] if f.get("too_long") else None)]
            g = self.partial_graph(r.partial, float(sp.N(v)) if not f.get("too_long") else None)
            return item(node, "value", lines, badge="exact", notes=notes, **({"graph": g} if g else {}))
        d = decimal_latex(r.estimate, self.places)
        return item(node, "value", [line(f"{head} \\approx {d[0] if d else tex(r.estimate)}", label=label)],
                    badge="numerical estimate", notes=notes)

    def series_card(self, node, f, k, lo, conds, head) -> dict:
        def progress(res):
            if res.converges is None:
                return
            word = r"\text{converges}" if res.converges else r"\text{diverges}"
            self.partial(item(node, "solution", [line(word, label="Convergence")], badge="numerical estimate",
                              notes=["Still working: the rest was not finished."]))
        r = infinite_series(f, k, lo, conds, progress=progress)
        lines, notes = [], []
        badge = "exact" if r.exact else "numerical estimate"
        if r.condition is not None:
            lines.append(line(f"{head} = {tex(r.value)}", label="Sum"))
            lines.append(line(tex(r.condition), label="When"))
            notes += r.notes
            return item(node, "solution", lines, badge=badge, notes=notes)
        if r.converges is False:
            to = "" if r.to is None else (r" to $\infty$" if r.to == sp.oo else r" to $-\infty$")
            word = r"\text{diverges}" + ("" if r.to is None else (r"\text{ to }" + tex(r.to)))
            lines.append(line(word, label="Convergence", copy=head + r"\ " + word))
            notes.append(f"It diverges{to}: {r.reason}.")
            badge = "exact" if r.exact else "numerical estimate"
        elif r.converges:
            how = {True: r"\text{converges absolutely}", False: r"\text{converges conditionally}",
                   None: r"\text{converges}"}[r.absolute]
            lines.append(line(how, label="Convergence"))
            notes.append(f"It converges: {r.reason}.")
            if r.absolute is False:
                notes.append("The series of absolute values diverges, so the convergence is conditional.")
            elif r.absolute is None:
                notes.append("Whether it also converges absolutely was not decided.")
            if r.value is not None:
                lines.insert(0, line(f"{head} = {exact_and_decimal(r.value, self.places)['latex']}", label="Sum"))
            elif r.estimate is not None:
                lines.insert(0, line(f"{head} \\approx {tex(r.estimate)}", label="Sum", copy=str(r.estimate)))
        else:
            lines.append(line(r"\text{not decided}", label="Convergence"))
            badge = "numerical estimate"
        notes += r.notes
        target = None
        if r.converges:
            target = r.value if r.value is not None else r.estimate
        g = self.partial_graph(r.partial, float(sp.N(target)) if target is not None else None)
        return item(node, "solution", lines, badge=badge, notes=notes, **({"graph": g} if g else {}))

    def partial_graph(self, partial, target) -> dict | None:
        if len(partial) < 2:
            return None
        traces = [{"kind": "points", "label": "partial sums S_N", "x": [float(N) for N, _ in partial],
                   "y": [s for _, s in partial], "text": [f"S_{N} ≈ {s:.6g}" for N, s in partial], "periodic": []}]
        if target is not None:
            traces.append({"kind": "js", "label": "sum", "js": repr(target), "breaks": [], "periodic": [],
                           "dots": [], "refetch": False, "dash": True})
        return graph_spec(traces, (partial[0][0] - 1, partial[-1][0] + 1))


def _kind_latex(kind) -> str:
    what, v = kind
    if what == "arithmetic":
        return r"\text{arithmetic, } d = " + tex(v)
    if what == "geometric":
        return r"\text{geometric, } q = " + tex(v)
    return r"\text{constant}"


def _short(v) -> str:
    d = decimal_latex(v, 4)
    return d[0] if d else str(v)


def _int_option(options, key, default, lo, hi) -> int:
    raw = str(options.get(key, "") or "").strip()
    if not raw:
        return default
    try:
        v = int(raw)
    except ValueError:
        raise MathError(f"The option '{key}' must be a whole number.")
    return max(lo, min(hi, v))


def run(payload: dict) -> dict:
    text = payload.get("input", "")
    mode = payload.get("mode", "plain")
    options = payload.get("options", {}) or {}
    places = int(options.get("decimals", 4))
    try:
        stmts = parse(text, mode)
    except ParseError as e:
        return parse_error_response(e, text)
    names = sequence_names(stmts)
    rewritten = [rewrite(st, names) for st in stmts]
    try:
        start = _int_option(options, "start", 1, -1000, 10**6)
        defs = collect(rewritten, stmts, names, start)
        ss = SequencesSession(defs, options, places)
    except MathError as e:
        return {"ok": False, "results": [], "echo": [], "error": e.to_dict(), "summary_latex": None}
    ss.echo = program_to_latex(stmts)
    results = ss.done
    shown: set[str] = set()
    for i, st in enumerate(rewritten):
        orig = stmts[i]
        try:
            if i in defs.errors:
                results.append(error_item(orig, defs.errors[i], text))
                continue
            if i in defs.lines:
                name = defs.lines[i]
                if name in shown or name not in defs.seqs:
                    continue
                shown.add(name)
                results.append(ss.sequence_card(defs.seqs[name], defs.nodes[name]))
                continue
            results.append(ss.line(st, orig))
        except (MathError, ParseError) as e:
            results.append(error_item(orig, e, text))
        except Exception as e:  # keep the other lines' answers
            results.append(error_item(orig, e))
    return response(results, echo=ss.echo)
