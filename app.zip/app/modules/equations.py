"""Equations & inequalities tab.

Each line is one problem:
    log(x-1, 2) + log(x+1, 2) = 3          an equation
    sin x = 1/2 for x in [0, 2pi]          ... with the solutions in an interval
    (x - 1)/(x + 2) >= 0                   an inequality
    {x + y = 3; x - y = 1}                 a system (also: ... and ..., or the System button)
    y >= x^2 - 2 and y < x + 1             a region in the plane
Earlier lines can define functions (f(x) = x^2 - 1) and values (a = 2). Once
f is defined, a later line `f(x) = 3` is an equation to solve. When several
equation lines share unknowns (any line has two or more), they are solved
together as one system.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import sympy as sp

from ..core.decide import compare
from ..core.domain import requirements_note
from ..core.format import decimal_latex, exact_and_decimal, set_latex, tex
from ..core.functions import collect_definitions, definition_head
from ..graphing import plane
from ..graphing.jsprint import to_js
from ..parsing import A, MathError, ParseError, parse
from ..parsing.echo import program_to_latex, to_plain
from ..parsing.to_sympy import Converter, RelChain, Restriction, restriction_condition, symbol
from ..solving.periodic import NotRepresentable, PeriodicSet, k_symbol
from ..solving.systems import Leaf, Tree, order_symbols, solve_one_variable_tree, solve_system
from ..solving.univariate import DEFAULT_SEARCH, OneVariable, Result, bool_set, split_set
from .common import error_item, item, line, parse_error_response, report_partial, response
from .evaluate import Session
from .graph import _number

UNKNOWN_NAMES = {"x", "y", "z"}
MAX_VALUE_LINES = 8


@dataclass
class Problem:
    node: A.Node
    tree: Tree
    conditions: list
    restriction: sp.Basic | None = None       # a condition on the unknown (for x in [a, b], x > 0)
    notes: list[str] = field(default_factory=list)


# ------------------------------------------------------------ input pass ---
def equation_lines(stmts) -> set[int]:
    """Indexes of `f(...) = ...` lines that are equations, not definitions:
    the function is already completely defined by earlier lines."""
    complete: set[str] = set()
    out = set()
    for i, st in enumerate(stmts):
        d = definition_head(st)
        if d is None:
            continue
        if d.name in complete and not d.guarded:
            out.add(i)
            continue
        if not d.guarded and d.params is not None:
            complete.add(d.name)
        elif d.guarded and d.cond is None:
            complete.add(d.name)  # "otherwise" closes a definition by cases
    return out


class EquationsSession:
    def __init__(self, session: Session, options: dict):
        self.s = session
        self.places = session.places
        self.options = options
        self.solve_for = [symbol(n.strip()) for n in str(options.get("solve_for", "")).replace(";", ",").split(",")
                          if n.strip()]
        self.x_window = self._window("x_min", "x_max")
        self.y_window = self._window("y_min", "y_max")

    def _window(self, a, b):
        lo, hi = str(self.options.get(a, "")).strip(), str(self.options.get(b, "")).strip()
        if lo and hi:
            lo_f, hi_f = _number(lo, "graph range"), _number(hi, "graph range")
            if hi_f > lo_f:
                return lo_f, hi_f
            raise MathError("The graph range must go from a smaller to a larger number.")
        return None

    # ---- AST -> relations ----
    def tree(self, node: A.Node, conv: Converter, conds: list) -> Tree:
        if isinstance(node, A.Logic):
            return Tree(node.op, [self.tree(it, conv, conds) for it in node.items])
        if isinstance(node, A.System):
            return Tree("and", [self.tree(it, conv, conds) for it in node.items])
        if isinstance(node, A.Rel):
            rc = conv.convert(node)
            if not isinstance(rc, RelChain):
                raise MathError("Expected an equation or inequality.")
            exprs = []
            for e in rc.exprs:
                if not isinstance(e, sp.Expr):
                    raise MathError("A cases block can only stand in a function definition such as "
                                    "f(x) = {cases}.")
                e2, extra = self.s.apply(e, [])
                conds.extend(extra)
                exprs.append(e2)
            leaves = [Tree("leaf", leaf=Leaf(a, op, b)) for op, a, b in zip(rc.ops, exprs, exprs[1:])]
            return leaves[0] if len(leaves) == 1 else Tree("and", leaves)
        if isinstance(node, A.InSet):
            r = conv.convert(node)
            rel = restriction_condition(r)
            return Tree("and", [Tree("leaf", leaf=Leaf(a.lhs, _op(a), a.rhs)) for a in rel.args])
        if isinstance(node, A.Conditional):
            raise MathError("A condition can't be used here.")
        raise MathError("This line is not an equation or inequality. Use the Evaluate tab to compute a "
                        "value, or write an equation such as x^2 = 4.")

    def problem(self, node: A.Node) -> Problem:
        conv = self.s.converter()
        conds: list = []
        restriction = None
        value = node
        if isinstance(node, A.Conditional):
            if node.cond is None:
                raise MathError("'otherwise' only makes sense in a function definition by cases.")
            value = node.value
            cond_obj = conv.convert(node.cond)
            if isinstance(cond_obj, Restriction):
                restriction = restriction_condition(cond_obj)
            elif isinstance(cond_obj, RelChain):
                restriction = cond_obj.as_sympy()
            else:
                restriction = conv.condition(node.cond)
        t = self.tree(value, conv, conds)
        conds = conv.conditions + conds
        if restriction is not None and self.s.values:
            restriction = restriction.subs(self.s.values)
        return Problem(node, t, conds, restriction)

    # ---- solving ----
    def unknowns(self, p: Problem):
        free = p.tree.free()
        if not free:
            # x/x = 1 simplifies to 1 = 1, but x still matters: it can't be 0.
            for c in p.conditions:
                free |= sp.sympify(c.expr).free_symbols
            free = {v for v in free if isinstance(v, sp.Symbol)}
        if p.restriction is not None:
            free |= sp.sympify(p.restriction).free_symbols
        vars_ = order_symbols(free)
        if self.solve_for:
            chosen = [v for v in self.solve_for if v in free]
            if not chosen:
                names = ", ".join(v.name for v in self.solve_for)
                raise MathError(f"The option 'solve for' names {names}, which doesn't appear here.")
            return vars_, chosen
        if len(vars_) <= 1:
            return vars_, vars_
        leaves = p.tree.leaves()
        n_eq = sum(1 for lf in leaves if lf.op == "=")
        if set(v.name for v in vars_) == {"x", "y"} and (n_eq < 2):
            return vars_, vars_  # a curve or a region in the plane
        if n_eq == 0:
            return vars_, vars_[:2] if len(vars_) == 2 else vars_
        if n_eq < len(vars_) and all(_linear(lf.expr, vars_) for lf in leaves):
            return vars_, vars_  # a linear system with free unknowns: answer with parameters
        return vars_, vars_[:n_eq] if n_eq < len(vars_) else vars_

    def solve(self, p: Problem, numeric_only: bool = False) -> dict:
        vars_, unknowns = self.unknowns(p)
        if not vars_:
            return self.truth(p)
        params = [v for v in vars_ if v not in unknowns]
        if len(unknowns) == 1:
            x = unknowns[0]
            if params:
                return self.with_parameters(p, x, params)
            return self.one_variable(p, x, numeric_only)
        if not p.tree.is_conjunction():
            if len(unknowns) == 2 and not params and all(lf.op != "=" for lf in p.tree.leaves()):
                return self.region(p, unknowns, p.tree.leaves(), _tree_relation(p.tree))
            raise MathError("'or' between equations works only with one unknown; between inequalities "
                            "in x and y it gives a region.")
        if params:
            p.notes.append(_parameter_note(params))
        return self.several(p, unknowns, numeric_only)

    def truth(self, p: Problem) -> dict:
        value, exact = _decide(p.tree)
        if value is None:
            raise MathError("This can't be decided (a side is not a real number).")
        latex = r"\text{true}" if value else r"\text{false}"
        notes = [] if exact else ["Decided numerically: the two sides agree to 45 digits."]
        return item(p.node, "truth", [line(latex)], badge="exact" if exact else "numerical estimate", notes=notes)

    # ---- one unknown ----
    def one_variable(self, p: Problem, x, numeric_only: bool) -> dict:
        restriction = None
        if p.restriction is not None:
            r = bool_set(p.restriction, x, sp.S.Reals)
            if r is None:
                raise MathError("The condition after 'for' must be about the unknown, e.g. x in [0, 2pi] "
                                "or x > 0.")
            restriction = r
        search = self.x_window or DEFAULT_SEARCH
        if p.tree.op == "leaf":
            lf = p.tree.leaf
            res = OneVariable(lf.lhs, lf.op, lf.rhs, x, p.conditions, restriction, search).solve(numeric_only)
            op = lf.op
        else:
            res = solve_one_variable_tree(p.tree, x, p.conditions, restriction, search, numeric_only)
            op = "system"
        k = k_symbol({s.name for s in p.tree.free()})
        if op == "=":
            lines = self.equation_lines(res, x, k)
        else:
            lines = self.set_lines(res, x, k)
        notes = list(p.notes) + self.notes_for(res, x, k, op, p.conditions)
        extra = {}
        if op != "=":
            nl = plane.number_line(res, x)
            if nl is not None:
                extra["numberline"] = nl
        if p.tree.op == "leaf":
            window = self.x_window or self.window_for(res)
            try:
                g = plane.one_variable_graph(p.tree.leaf.lhs, p.tree.leaf.rhs, x, p.conditions, res, window, op,
                                             _typed_sides(p.node))
            except Exception:
                g = None
            if g is not None:
                extra["graph"] = g
        badge = "exact" if res.exact and not numeric_only else "numerical estimate"
        return item(p.node, "solution", lines, badge=badge, notes=notes, **extra)

    def value_latex(self, v) -> str:
        v = sp.sympify(v)
        if v.has(sp.Float) or v.has(sp.CRootOf):
            d = decimal_latex(sp.N(v, 30), self.places)
            return r"\approx " + (d[0] if d else tex(sp.N(v, self.places + 1)))
        return exact_and_decimal(v, self.places)["latex"]

    def equals(self, xs: str, v) -> str:
        val = self.value_latex(v)
        return f"{xs} {val}" if val.startswith(r"\approx") else f"{xs} = {val}"

    def display_set(self, s):
        """The set with long decimals rounded and CRootOf shown as decimals."""
        def fix(e):
            if isinstance(e, sp.Float):
                return sp.Float(e, self.places + 1)
            if isinstance(e, sp.CRootOf):
                return sp.Float(sp.N(e, 30), self.places + 1)
            return e
        try:
            return s.replace(lambda e: isinstance(e, (sp.Float, sp.CRootOf)), fix)
        except Exception:
            return s

    def equation_lines(self, res: Result, x, k) -> list[dict]:
        xs = tex(x)
        out = []
        general = res.general if res.general is not None else (
            res.solution if isinstance(res.solution, PeriodicSet) else None)
        if general is not None:
            out.append(line(general.latex_equation(xs, k), label="General solution"))
            if res.general is None:
                return out
        sol = res.solution
        label_in = f"Solutions in {_interval_plain(res.restriction)}" if res.restriction is not None else None
        if not isinstance(sol, sp.Set):
            return out
        if sol == sp.S.EmptySet:
            text = r"\text{no real solutions}" if res.restriction is None else r"\text{no solutions in this interval}"
            out.append(line(text, label=label_in or "Solutions", copy=r"\varnothing"))
            return out
        pts, ivs, ok = split_set(sol)
        if ok and ivs == sp.S.EmptySet and len(pts) <= MAX_VALUE_LINES:
            pts = sorted(pts, key=lambda v: float(sp.N(v)))
            for i, v in enumerate(pts):
                label = (label_in or ("Solution" if len(pts) == 1 else "Solutions")) if i == 0 else None
                out.append(line(self.equals(xs, v), label=label))
            if len(pts) > 1:
                out.append(line(f"{xs} \\in " + set_latex(self.display_set(sol)), label="Solution set"))
            return out
        out.append(line(f"{xs} \\in " + set_latex(self.display_set(sol)), label=label_in or "Solution set"))
        return out

    def set_lines(self, res: Result, x, k) -> list[dict]:
        xs = tex(x)
        out = []
        general = res.general if res.general is not None else (
            res.solution if isinstance(res.solution, PeriodicSet) else None)
        if general is not None:
            if general.points_only:
                out.append(line(general.latex_equation(xs, k), label="Solution set"))
            else:
                out.append(line(general.latex_inequality(xs, k), label="Solution"))
                out.append(line(general.latex_set(xs, k), label="Interval form"))
            if res.general is None:
                return out
        sol = res.solution
        label = f"In {_interval_plain(res.restriction)}" if res.restriction is not None else "Solution set"
        if not isinstance(sol, sp.Set):
            return out
        if sol == sp.S.EmptySet:
            out.append(line(r"\text{no solutions}", label=label, copy=r"\varnothing"))
            return out
        shown = self.display_set(sol)
        out.append(line(f"{xs} \\in " + set_latex(shown), label=label))
        if sol not in (sp.S.Reals,) and res.restriction is None:
            rt = relational_latex(shown, xs)
            if rt and len(rt) < 400:
                out.append(line(rt, label="As inequalities"))
        return out

    def notes_for(self, res: Result, x, k, op, conditions) -> list[str]:
        xs = tex(x)
        notes = []
        for rj in res.rejected:
            if isinstance(rj.value, PeriodicSet):
                what = rj.value.latex_equation(xs, k)
            else:
                what = f"{xs} = {tex(rj.value)}"
            notes.append(f"Rejected ${what}$ (extraneous): {rj.reason}")
        if isinstance(res.domain, sp.Set) and res.domain not in (sp.S.Reals,) and res.domain != sp.S.EmptySet \
                and not res.periodic and res.general is None:
            notes.append(f"Domain: ${xs} \\in {set_latex(res.domain)}$.")
        elif res.periodic or res.general is not None:
            note = requirements_note(conditions)
            if note:
                notes.append(note)
        if op == "=" and res.exact and isinstance(res.solution, (sp.FiniteSet, PeriodicSet)) \
                and not (isinstance(res.solution, PeriodicSet) and res.solution.is_empty):
            notes.append("Each solution was checked by substituting it back into the equation.")
        if not res.exact:
            notes.append("Values shown only with ≈ were found numerically: they are numerical estimates.")
        if res.searched is not None and op == "=":
            lo, hi = res.searched
            notes.append(f"No exact method found every solution, so ${lo:g} \\le {xs} \\le {hi:g}$ was searched "
                         "numerically; there may be more solutions outside this range "
                         "(change it with the x range options).")
        if res.complex_roots:
            vals = ", ".join(tex(sp.nsimplify(r) if r.is_Float else r) for r in res.complex_roots)
            notes.append(f"In complex numbers the solutions would be ${vals}$.")
        notes += [n for n in res.notes if n not in notes]
        return notes

    def window_for(self, res: Result):
        if res.restriction is not None:
            r = res.restriction
            if r.inf != -sp.oo and r.sup != sp.oo:
                a, b = float(sp.N(r.inf)), float(sp.N(r.sup))
                pad = (b - a) * 0.08 or 1
                return a - pad, b + pad
        sol = res.general or res.solution
        if isinstance(sol, PeriodicSet):
            P = float(sp.N(sol.period))
            return (-2 * P, 2 * P) if P <= 7 else (-P, P)
        values = []
        if isinstance(sol, sp.Set):
            try:
                pts, ivs, ok = split_set(sol)
                values = list(pts)
                for kind, iv in ([] if ivs == sp.S.EmptySet else _pieces(ivs)):
                    values += [e for e in (iv.start, iv.end) if e.is_finite]
            except Exception:
                values = []
        return plane.fit_window(values)

    # ---- parameters ----
    def with_parameters(self, p: Problem, x, params) -> dict:
        if p.tree.op != "leaf" or p.tree.leaf.op != "=":
            raise MathError(f"This has the parameter(s) {', '.join(v.name for v in params)}. Inequalities and "
                            "systems with parameters belong to the Parameters tab (milestone 6).")
        g = p.tree.leaf.expr
        sols = sp.solve(g, x)
        xs = tex(x)
        if not sols:
            lines = [line(r"\text{no solution found in terms of the parameters}")]
        else:
            lines = [line(f"{xs} = {tex(sp.simplify(s))}", label="Solutions" if i == 0 else None)
                     for i, s in enumerate(sols)]
        notes = [_parameter_note(params)]
        return item(p.node, "solution", lines, badge="exact", notes=notes)

    # ---- several unknowns ----
    def several(self, p: Problem, unknowns, numeric_only: bool) -> dict:
        leaves = p.tree.leaves()
        if p.restriction is not None:
            r = sp.sympify(p.restriction)
            for a in (r.args if isinstance(r, sp.And) else [r]):
                leaves.append(Leaf(a.lhs, _op(a), a.rhs))
        eqs = [lf for lf in leaves if lf.op == "="]
        two_d = len(unknowns) == 2
        box = self.x_window or (-10.0, 10.0)
        if not eqs:
            if not two_d:
                raise MathError("Systems of inequalities can be solved for two unknowns (a region in the "
                                "plane), not more.")
            return self.region(p, unknowns, leaves, None, numeric_only)
        if two_d and len(eqs) == 1 and set(v.name for v in unknowns) == {"x", "y"} and len(leaves) == 1:
            return self.curve(p, leaves[0], unknowns)
        return self.points(p, leaves, unknowns, numeric_only, box)

    def region(self, p: Problem, unknowns, leaves, relation=None, numeric_only: bool = False) -> dict:
        """Inequalities in two unknowns: the answer is a region of the plane."""
        names = [tex(v) for v in unknowns]
        xv, yv = unknowns
        if relation is None:
            res = solve_system(leaves, unknowns, p.conditions, numeric_only)
            corners = res.corners
            rel = ", \\; ".join(tex(lf.relation()) for lf in leaves)
        else:
            corners = []
            rel = tex(relation)
        lines = [line(f"\\left\\{{ \\left({names[0]}, {names[1]}\\right) \\;\\middle|\\; {rel} \\right\\}}",
                      label="Solution set")]
        if corners:
            pts = ", ".join(self.point_latex(c, unknowns) for c in corners)
            lines.append(line(pts, label="Corner points"))
        notes = list(p.notes) + ["The solution set is the shaded region in the graph. A solid boundary "
                                 "is included, a dashed one is not."]
        g = plane.plane_graph(leaves, xv, yv,
                              self.x_window or plane.fit_points([c[xv] for c in corners]) or (-10.0, 10.0),
                              self.y_window or plane.fit_points([c[yv] for c in corners]),
                              points=corners, label_points="corners",
                              tree_js=to_js(relation) if relation is not None else None)
        return item(p.node, "solution", lines, badge="exact", notes=notes, **({"graph": g} if g else {}))

    def points(self, p: Problem, leaves, unknowns, numeric_only: bool, box) -> dict:
        names = [tex(v) for v in unknowns]
        two_d = len(unknowns) == 2
        res = solve_system(leaves, unknowns, p.conditions, numeric_only, box)
        lines = []
        tuple_head = r"\left(" + ", ".join(names) + r"\right)"
        if res.kind == "parametric":
            vals, params = res.parametric
            body = r"\left(" + ", ".join(tex(v) for v in vals) + r"\right)"
            ps = ", ".join(tex(t) for t in params)
            lines.append(line(f"{tuple_head} = {body},\\quad {ps} \\in \\mathbb{{R}}",
                              label="Infinitely many solutions"))
        elif not res.solutions:
            lines.append(line(r"\text{no real solutions}", label="Solutions", copy=r"\varnothing"))
        else:
            for i, s in enumerate(res.solutions):
                body = r"\left(" + ", ".join(self.coord_latex(s[v]) for v in unknowns) + r"\right)"
                lines.append(line(f"{tuple_head} = {body}",
                                  label=("Solution" if len(res.solutions) == 1 else "Solutions") if i == 0 else None))
        notes = list(p.notes)
        for c, why in res.rejected:
            notes.append(f"Rejected ${tuple_head} = {self.point_latex(c, unknowns)}$ (extraneous): {why}")
        if res.solutions and res.exact:
            notes.append("Each solution was checked by substituting it back into every equation.")
        if not res.exact:
            notes.append("Values shown only with ≈ were found numerically: they are numerical estimates.")
        notes += res.notes
        extra = {}
        if two_d:
            xv, yv = unknowns
            pts = res.solutions
            g = plane.plane_graph(leaves, xv, yv,
                                  self.x_window or plane.fit_points([s[xv] for s in pts], 6.0) or (-10.0, 10.0),
                                  self.y_window or plane.fit_points([s[yv] for s in pts], 6.0),
                                  points=pts)
            if g is not None:
                extra["graph"] = g
        badge = "exact" if res.exact and res.complete and not numeric_only else "numerical estimate"
        return item(p.node, "solution", lines, badge=badge, notes=notes, **extra)

    def coord_latex(self, v) -> str:
        v = sp.sympify(v)
        if v.has(sp.Float) or v.has(sp.CRootOf):
            d = decimal_latex(sp.N(v, 30), self.places)
            return r"\approx " + (d[0] if d else tex(v))
        return tex(v)

    def point_latex(self, s: dict, unknowns) -> str:
        return r"\left(" + ", ".join(self.coord_latex(s[v]) for v in unknowns) + r"\right)"

    def curve(self, p: Problem, leaf: Leaf, unknowns) -> dict:
        xv, yv = unknowns
        rel = leaf.relation()
        lines = [line(tex(rel) if not isinstance(rel, sp.logic.boolalg.BooleanAtom) else
                      f"{tex(leaf.lhs)} = {tex(leaf.rhs)}", label="Curve")]
        sols = None
        try:
            sols = sp.solve(leaf.expr, yv)
        except Exception:
            sols = None
        if sols:
            for i, s in enumerate(sols[:4]):
                lines.append(line(f"{tex(yv)} = {tex(s)}", label="Solved for y" if i == 0 else None))
        badge = "exact"
        if _has_real_points(leaf.expr, xv, yv, self.x_window or (-10.0, 10.0), self.y_window or (-10.0, 10.0)):
            notes = list(p.notes) + ["Every point of the curve in the graph is a solution (infinitely many)."]
        else:
            badge = "numerical estimate"
            lines.append(line(r"\text{no real points in the shown range}", label="Solutions",
                              copy=r"\varnothing"))
            notes = list(p.notes) + ["The two sides are never equal for real x and y in the range searched "
                                     "(a grid check, not a proof)."]
        g = plane.plane_graph([leaf], xv, yv, self.x_window or (-10.0, 10.0), self.y_window)
        return item(p.node, "solution", lines, badge=badge, notes=notes, **({"graph": g} if g else {}))


# ------------------------------------------------------------- helpers ------
def _has_real_points(expr, xv, yv, xr, yr) -> bool:
    """Does expr change sign (or vanish) somewhere on a grid over the range?"""
    import numpy as np
    try:
        f = sp.lambdify((xv, yv), expr, modules="numpy")
        X, Y = np.meshgrid(np.linspace(*xr, 241), np.linspace(*yr, 241))
        with np.errstate(all="ignore"):
            Z = np.asarray(f(X, Y), dtype=complex) * np.ones_like(X)
        Z = np.where(np.abs(Z.imag) < 1e-12, Z.real, np.nan)
    except Exception:
        return True
    Z = Z[np.isfinite(Z)]
    return Z.size == 0 or (Z.min() <= 0 <= Z.max())


def _linear(expr, vars_) -> bool:
    try:
        return sp.Poly(expr, *vars_).total_degree() <= 1
    except (sp.PolynomialError, sp.GeneratorsNeeded):
        return False


def _typed_sides(node):
    """The two sides as the user typed them (for the graph legend)."""
    if isinstance(node, A.Conditional):
        node = node.value
    if isinstance(node, A.Rel) and len(node.items) == 2:
        return to_plain(node.items[0]), to_plain(node.items[1])
    return None


def _op(rel) -> str:
    return {sp.StrictLessThan: "<", sp.LessThan: "<=", sp.StrictGreaterThan: ">", sp.GreaterThan: ">=",
            sp.Equality: "=", sp.Unequality: "!="}[type(rel)]


def _pieces(s):
    from ..solving.periodic import pieces
    return pieces(s)


def _interval_plain(s) -> str:
    try:
        if isinstance(s, sp.Interval):
            lo = "−∞" if s.start == -sp.oo else plane.plain_label(s.start)
            hi = "∞" if s.end == sp.oo else plane.plain_label(s.end)
            return ("(" if s.left_open else "[") + f"{lo}, {hi}" + (")" if s.right_open else "]")
    except Exception:
        pass
    return "the interval"


def relational_latex(s, xs: str) -> str | None:
    """(-oo, -2) U [1, oo)  ->  x < -2 or x >= 1   (pieces from left to right)."""
    try:
        parts = sorted(_pieces(s), key=lambda kv: float(sp.N(kv[1] if kv[0] == "pt" else kv[1].inf)))
    except Exception:
        return None
    out = []
    for kind, v in parts:
        if kind == "pt":
            out.append(f"{xs} = {tex(v)}")
            continue
        if v.start == -sp.oo and v.end == sp.oo:
            return None
        if v.end == sp.oo:  # x > a reads better than a < x
            out.append(f"{xs} {'>' if v.left_open else chr(92) + 'ge'} {tex(v.start)}")
            continue
        lo = "" if v.start == -sp.oo else tex(v.start) + (r" < " if v.left_open else r" \le ")
        hi = (r" < " if v.right_open else r" \le ") + tex(v.end)
        out.append(f"{lo}{xs}{hi}")
    return r"\text{ or }".join(out) if out else None


def _parameter_note(params) -> str:
    names = ", ".join(v.name for v in params)
    return (f"{names} {'is' if len(params) == 1 else 'are'} treated as "
            f"{'a parameter' if len(params) == 1 else 'parameters'}. How the solutions depend on it "
            "(when they are real, how many there are) is the job of the Parameters tab (milestone 6). "
            "To solve for another letter, fill in 'solve for'.")


def _tree_relation(tree: Tree):
    if tree.op == "leaf":
        return tree.leaf.relation()
    parts = [_tree_relation(t) for t in tree.items]
    return sp.And(*parts, evaluate=False) if tree.op == "and" else sp.Or(*parts, evaluate=False)


def _decide(tree: Tree):
    if tree.op == "leaf":
        lf = tree.leaf
        t = compare(lf.op, lf.lhs, lf.rhs)
        return t.value, t.exact
    vals = [_decide(t) for t in tree.items]
    exact = all(e for _, e in vals)
    if any(v is None for v, _ in vals):
        return None, exact
    if tree.op == "and":
        return all(v for v, _ in vals), exact
    return any(v for v, _ in vals), exact


def _is_assignment(st: A.Node) -> bool:
    if not (isinstance(st, A.Rel) and st.ops == ["="] and isinstance(st.items[0], A.Name)):
        return False
    name = st.items[0].name
    if name in ("pi", "e", "inf") or name in UNKNOWN_NAMES:
        return False
    return not any(isinstance(n, A.Name) and n.name not in ("pi", "e", "inf")
                   for n in A.walk(st.items[1]))


def _relation_like(st: A.Node) -> bool:
    node = st.value if isinstance(st, A.Conditional) else st
    return isinstance(node, (A.Rel, A.Logic, A.System, A.InSet))


# ----------------------------------------------------------------- run ------
def run(payload: dict) -> dict:
    text = payload.get("input", "")
    mode = payload.get("mode", "plain")
    options = payload.get("options", {}) or {}
    places = int(options.get("decimals", 4))
    try:
        stmts = parse(text, mode)
    except ParseError as e:
        return parse_error_response(e, text)
    skip = equation_lines(stmts)
    table, defs_at, def_errors = collect_definitions(stmts, skip=skip)
    session = Session(table, places=places, depth_limit=int(options.get("depth", 1000)))
    try:
        es = EquationsSession(session, options)
    except MathError as e:
        return {"ok": False, "results": [], "echo": [], "error": e.to_dict(), "summary_latex": None}

    entries: list = []   # ("item", dict) | ("problem", Problem)
    shown: set[str] = set()
    for i, st in enumerate(stmts):
        if i in def_errors:
            entries.append(("item", error_item(st, def_errors[i], text)))
            continue
        if i in defs_at:
            fd = defs_at[i]
            if fd.name not in shown:
                shown.add(fd.name)
                entries.append(("item", session.definition_card(fd)))
            continue
        try:
            if _is_assignment(st):
                entries.append(("item", session.assign(st)))
                continue
            if isinstance(st, A.InSet) and entries and entries[-1][0] == "problem" \
                    and entries[-1][1].restriction is None:
                # `x in [0, 2pi]` after a problem (same line after a comma, or the next line).
                prob = entries[-1][1]
                conv = session.converter()
                prob.restriction = restriction_condition(conv.convert(st))
                prob.node = A.Conditional(prob.node, st)
                continue
            if not _relation_like(st):
                raise MathError("This line is not an equation or inequality. Use the Evaluate tab to "
                                "compute a value, or write an equation such as x^2 = 4.")
            entries.append(("problem", es.problem(st)))
        except (MathError, ParseError) as e:
            entries.append(("item", error_item(st, e, text)))
        except Exception as e:
            entries.append(("item", error_item(st, e)))

    # Several equation lines that share unknowns form one system.
    probs = [p for kind, p in entries if kind == "problem"]
    if len(probs) >= 2 and all(p.restriction is None for p in probs) \
            and any(len(p.tree.free()) >= 2 for p in probs):
        merged = Problem(A.System([p.node for p in probs]), Tree("and", [p.tree for p in probs]),
                         [c for p in probs for c in p.conditions])
        merged.notes.append("These lines were solved together as one system, because they share unknowns. "
                            "To solve them one at a time, calculate them separately.")
        first = next(i for i, (kind, _) in enumerate(entries) if kind == "problem")
        entries = [e for e in entries if e[0] != "problem"]
        entries.insert(first, ("problem", merged))

    results: list[dict] = []
    for idx, (kind, obj) in enumerate(entries):
        if kind == "item":
            results.append(obj)
            continue
        # A fast numerical answer first: shown if the exact solver runs out of time.
        try:
            provisional = es.solve(obj, numeric_only=True)
            provisional["notes"] = ["Provisional: the exact solver was still working."] + provisional["notes"]
            pending = [o for k, o in entries[idx + 1:] if k == "item"]
            report_partial(response(results + [provisional] + pending, echo=program_to_latex(stmts)))
        except Exception:
            pass
        try:
            results.append(es.solve(obj))
        except NotRepresentable as e:
            results.append(error_item(obj.node, MathError(f"This can't be solved here ({e}).")))
        except (MathError, ParseError) as e:
            results.append(error_item(obj.node, e, text))
        except Exception as e:
            results.append(error_item(obj.node, e))
    if not results:
        results.append(item(None, "message", [], notes=["Type an equation or inequality, e.g. x^2 - 5x + 6 = 0."]))
    return response(results, echo=program_to_latex(stmts))


__all__ = ["run", "to_plain"]
