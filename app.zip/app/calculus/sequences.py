"""Sequences: recurrences and explicit formulas.

A sequence is a(n) = rule for n from some start index, where the rule may use
earlier terms a(n-1), ..., a(n-order), plus initial values a(k) = v. Terms are
computed by forward iteration (exact while the values stay small, with mpmath
decimals alongside). A closed form comes from SymPy's rsolve, or for nonlinear
rules from a pattern guessed from the first terms; either way it is only shown
once it is checked against the recurrence and the computed terms (substituting
it into the recurrence and the initial values is a proof by induction).
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

import mpmath
import sympy as sp

from ..core.domain import explain, first_violation
from ..core.format import huge_number_digits, tex
from ..parsing import MathError
from ..parsing.to_sympy import Condition
from ..solving.univariate import safe
from .limits import compute_limit

AppliedUndef = sp.core.function.AppliedUndef

EXACT_OPS = 80          # stop keeping exact values once they get this big
DPS = 30                # working precision of the decimals


@dataclass
class Sequence:
    name: str
    n: sp.Symbol                          # the index as typed
    rule: sp.Expr | None                  # a(n) = rule; uses a(n - j) for j = 1..order
    conditions: list[Condition] = field(default_factory=list)  # domain conditions of the rule
    initial: dict[int, sp.Expr] = field(default_factory=dict)
    start: int = 0

    @property
    def order(self) -> int:
        return recurrence_order(self.name, self.n, self.rule)

    @property
    def explicit(self) -> bool:
        return self.order == 0

    def call(self, arg) -> sp.Expr:
        return sp.Function(self.name, real=True)(arg)

    def needed_initial(self) -> list[int]:
        """Indices that must be given for the recurrence to start."""
        return list(range(self.start, self.start + self.order))

    def missing_initial(self) -> list[int]:
        return [k for k in self.needed_initial() if k not in self.initial]


def recurrence_order(name: str, n: sp.Symbol, rule) -> int:
    if rule is None:
        return 0
    order = 0
    for c in sp.sympify(rule).atoms(AppliedUndef):
        if c.func.__name__ == name:
            order = max(order, int(n - c.args[0]))
    return order


def check_rule(name: str, n: sp.Symbol, rule: sp.Expr) -> None:
    """The rule may only use a(n - j) with j a whole number ≥ 1."""
    sub = name if len(name) == 1 else r"\operatorname{" + name + "}"
    for c in rule.atoms(AppliedUndef):
        if c.func.__name__ != name:
            raise MathError(f"${tex(c)}$ isn't defined here. Define it first, e.g. "
                            f"{c.func.__name__}_n = …")
        if len(c.args) != 1:
            raise MathError(f"{name} must have a single index.")
        j = sp.simplify(n - c.args[0])
        if not (j.is_Integer):
            raise MathError(f"${sub}_{{{tex(c.args[0])}}}$ is not an earlier term ${sub}_{{{tex(n)}-1}}, "
                            f"{sub}_{{{tex(n)}-2}}, …$. Recursions like that are handled in the Piecewise & "
                            "recursive tab.")
        if j <= 0:
            raise MathError(f"The right side uses ${sub}_{{{tex(c.args[0])}}}$; it may only use earlier "
                            f"terms such as ${sub}_{{{tex(n)}-1}}$.")
        if j > 20:
            raise MathError("Recurrences of order more than 20 aren't supported.")


# ------------------------------------------------------------- terms ------
@dataclass
class Term:
    k: int
    exact: sp.Expr | None      # None once the exact value got too big to keep
    value: mpmath.mpf          # decimal (DPS digits)


class Undefined(MathError):
    pass


@dataclass
class Iteration:
    terms: list[Term]
    stopped: str | None = None    # why the iteration stopped early (undefined term, missing values)


def _placeholders(seq: Sequence):
    """The rule with a(n - j) replaced by symbols p_j, and the list of (j, p_j)."""
    ps = {}
    rule = sp.sympify(seq.rule)
    for c in rule.atoms(AppliedUndef):
        j = int(seq.n - c.args[0])
        ps[c] = sp.Dummy(f"p{j}", real=True)
    return ps


def iterate(seq: Sequence, count: int, exact_count: int | None = None) -> Iteration:
    """The terms a(start), ..., a(start + count - 1). Exact values are kept for
    the first `exact_count` terms at most (all, by default) while they stay small."""
    exact_count = count if exact_count is None else exact_count
    ps = _placeholders(seq)
    rule = sp.sympify(seq.rule).xreplace(ps) if seq.rule is not None else None
    conds = [Condition(c.rel, sp.sympify(c.expr).xreplace(ps), c.what, c.latex,
                       sp.sympify(c.guard).xreplace(ps), c.custom) for c in seq.conditions]
    by_j = {int(seq.n - c.args[0]): p for c, p in ps.items()}
    order = max(by_j) if by_j else 0
    args = [seq.n] + [by_j.get(j, sp.Dummy()) for j in range(1, order + 1)]
    fnum = None
    if rule is not None:
        try:
            fnum = sp.lambdify(args, rule, modules="mpmath")
        except Exception:
            fnum = None
    exact_vals: dict[int, sp.Expr | None] = {}
    float_vals: dict[int, mpmath.mpf] = {}
    out: list[Term] = []
    keep_exact = True
    with mpmath.workdps(DPS):
        for k in range(seq.start, seq.start + count):
            if len(out) >= exact_count:
                keep_exact = False
            if k in seq.initial:
                ex = sp.sympify(seq.initial[k])
                fv = _to_mpf(ex)
            else:
                if rule is None:
                    return Iteration(out, f"${_term_tex(seq, k)}$ is not given and there is no rule for it.")
                missing = [k - j for j in range(1, order + 1) if (k - j) not in float_vals]
                if missing:
                    need = ", ".join(f"${_term_tex(seq, i)}$" for i in seq.missing_initial())
                    return Iteration(out, f"The recurrence needs {need} to start.")
                ex = None
                if keep_exact and all(exact_vals.get(k - j) is not None for j in range(1, order + 1)):
                    m = {seq.n: sp.Integer(k)}
                    m.update({by_j[j]: exact_vals[k - j] for j in by_j})
                    v = first_violation([c.subs(m) for c in conds])
                    if v is not None:
                        return Iteration(out, f"${_term_tex(seq, k)}$ is undefined: " + _lower(explain(*v)))
                    ex = rule.xreplace(m)
                    if ex.has(sp.nan, sp.zoo, sp.oo, -sp.oo) or ex.is_real is False:
                        return Iteration(out, f"${_term_tex(seq, k)}$ is undefined (it is not a real number).")
                    fv = _to_mpf(ex)
                else:
                    try:
                        fv = fnum(k, *[float_vals[k - j] for j in range(1, order + 1)]) if fnum else None
                    except (ZeroDivisionError, ValueError, OverflowError, TypeError):
                        fv = None
                    if fv is None or isinstance(fv, mpmath.mpc) or not mpmath.isfinite(fv):
                        return Iteration(out, f"${_term_tex(seq, k)}$ is undefined, or too large to compute.")
            if fv is None:
                return Iteration(out, f"${_term_tex(seq, k)}$ is not a real number.")
            if ex is not None and (sp.count_ops(ex) > EXACT_OPS or huge_number_digits(ex) > 0):
                ex = None
                keep_exact = False
            exact_vals[k] = ex
            float_vals[k] = fv
            out.append(Term(k, ex, fv))
    return Iteration(out)


def _to_mpf(v) -> mpmath.mpf | None:
    try:
        f = sp.N(v, DPS)
        if not f.is_real:
            return None
        return mpmath.mpf(str(f)) if f.is_Float or f.is_Integer or f.is_Rational else None
    except (TypeError, ValueError):
        return None


def _lower(s: str) -> str:
    return s[0].lower() + s[1:] if s else s


def _term_tex(seq: Sequence, k) -> str:
    base = seq.name if len(seq.name) == 1 else r"\operatorname{" + seq.name + "}"
    return f"{base}_{{{tex(k)}}}"


# -------------------------------------------------------- closed form -----
@dataclass
class ClosedForm:
    expr: sp.Expr                  # in terms of the integer symbol N
    N: sp.Symbol
    valid_from: int
    proof: str                     # how it was checked (for a note)
    general: bool = False          # contains constants C0, C1, ...
    guessed: bool = False


def index_symbol(seq: Sequence) -> sp.Symbol:
    if seq.start >= 0:
        return sp.Symbol(seq.n.name, integer=True, nonnegative=True)
    return sp.Symbol(seq.n.name, integer=True)


def cubic_or_worse(rule, a, N) -> bool:
    """A linear recurrence with constant coefficients whose characteristic polynomial has an
    irreducible factor of degree ≥ 3: its closed form needs cubic (Cardano) roots, which are
    unreadable and extremely slow to check, so it isn't attempted."""
    calls = sorted((c for c in rule.atoms(AppliedUndef) if c.func == a), key=str)
    if not calls:
        return False
    try:
        P = sp.Poly(rule, *calls)
    except sp.PolynomialError:
        return False
    if P.total_degree() != 1 or any(not P.coeff_monomial(c).is_number for c in calls):
        return False
    lam = sp.Dummy("lam")
    k = max(int(N - c.args[0]) for c in calls)
    char = lam ** k - sum(P.coeff_monomial(c) * lam ** (k - int(N - c.args[0])) for c in calls)
    return any(f.degree() >= 3 for f, _ in sp.factor_list(sp.Poly(char, lam))[1])


def closed_form(seq: Sequence, terms: list[Term], notes: list | None = None) -> ClosedForm | None:
    """A verified closed form of a recurrence (None if none was found)."""
    N = index_symbol(seq)
    a = sp.Function(seq.name, real=True)
    rule = sp.sympify(seq.rule).xreplace({seq.n: N})
    order = seq.order
    if cubic_or_worse(rule, a, N):
        if notes is not None:
            notes.append("No closed form is shown: it would need the roots of a cubic (or higher) "
                         "equation, which have no readable formula.")
        return None
    exact = {t.k: t.exact for t in terms}
    missing = seq.missing_initial()
    if missing:
        init = {a(k): sp.sympify(v) for k, v in seq.initial.items() if k in seq.needed_initial()}
        sol = _rsolve(a(N) - rule, a(N), init)
        if sol is None or not _satisfies(sol, rule, a, N):
            return None
        return ClosedForm(sol, N, seq.start, "it satisfies the recurrence", general=True)
    # Solve from the last `order` given values: the rule applies after them.
    last = max(seq.initial) if seq.initial else seq.start + order - 1
    base = max(seq.start, last - order + 1)
    init_idx = list(range(base, base + order))
    if any(exact.get(k) is None for k in init_idx):
        return None
    init = {a(k): exact[k] for k in init_idx}
    sol = _rsolve(a(N) - rule, a(N), init)
    guessed = False
    if sol is None or sol.free_symbols - {N}:
        sol = _guess(seq, rule, a, N, terms, base)
        guessed = sol is not None
        if sol is None:
            return None
    step = _satisfies(sol, rule, a, N)
    if step is None:
        return None
    checked = [t for t in terms if t.k >= base][:10]
    if not checked or not all(_equal(sol.subs(N, t.k), t.exact, t.value) for t in checked):
        return None
    if guessed and step != "proof":
        return None
    valid_from = base
    for t in sorted((t for t in terms if t.k < base), key=lambda t: -t.k):
        if _equal(sol.subs(N, t.k), t.exact, t.value):
            valid_from = t.k
        else:
            break
    if step == "proof":
        proof = ("Checked by substitution: it satisfies the recurrence and the initial values, "
                 "which proves it by induction")
    else:
        proof = ("Checked: it matches the initial values, and it satisfies the recurrence "
                 "numerically to 40 digits at 30 values of n (not proven symbolically)")
    proof += f"; it also matches the first {len(checked)} computed terms."
    if guessed:
        proof = "Found by spotting a pattern in the first terms. " + proof
    return ClosedForm(sol, N, valid_from, proof, guessed=guessed)


def _rsolve(eq, f, init):
    try:
        sol = safe(sp.rsolve, eq, f, init) if init else safe(sp.rsolve, eq, f)
    except Exception:
        return None
    if sol is None or isinstance(sol, (list, dict)) or sp.count_ops(sol) > 150:
        return None  # nothing, or too long to read (and to check)
    return clean(sp.sympify(sol))


def clean(e: sp.Expr) -> sp.Expr:
    """A readable real form of a closed form (rsolve may use complex powers)."""
    if e.has(sp.I):
        r = safe(lambda: sp.simplify(sp.expand_complex(e.rewrite(sp.exp))))
        if r is not None and not r.has(sp.I):
            e = r
    cands = [e]
    for fn in (sp.simplify, sp.factor):
        r = safe(fn, e)
        if r is not None and not r.has(sp.I):
            cands.append(r)

    def score(c):
        # 2^(-n) style factors read badly: prefer (1/2 + √5/2)^n over 2^(-n)(1 + √5)^n.
        neg = sum(1 for p in c.atoms(sp.Pow) if p.exp.free_symbols and p.exp.could_extract_minus_sign())
        return (sp.count_ops(c) + 4 * neg, len(str(c)))
    return min(cands, key=score)


def _satisfies(sol, rule, a, N) -> str | None:
    """Does a(N) = sol satisfy a(N) = rule? "proof" (symbolically), "numeric", or None."""
    order = recurrence_order(a.__name__, N, rule)
    m = {a(N - j): sol.subs(N, N - j) for j in range(1, order + 1)}
    resid = sol - rule.xreplace(m)
    if is_zero(resid, N):
        return "proof"
    # Numerically, at many n (high precision).
    with mpmath.workdps(50):
        bad = 0
        for k in range(order + 2, order + 32):
            try:
                v = sp.N(resid.subs(N, k), 45)
            except Exception:
                return None
            if not v.is_number or abs(v) > sp.Float(10) ** -38 * max(1, abs(sp.N(sol.subs(N, k), 45))):
                bad += 1
        return "numeric" if bad == 0 else None


def is_zero(expr, N) -> bool:
    """Symbolic zero test that also handles sums of powers c·r^N."""
    z = safe(sp.simplify, expr)
    if z is not None and z == 0:
        return True
    e = sp.expand(sp.expand_power_exp(sp.expand(expr)))
    pows = {p for p in e.atoms(sp.Pow) if p.exp == N and p.base.is_number}
    if pows:
        ds = {p: sp.Dummy() for p in pows}
        poly = e.xreplace(ds)
        coeffs = sp.collect(sp.expand(poly), list(ds.values()), evaluate=False)
        ok = True
        for c in coeffs.values():
            c = sp.radsimp(sp.simplify(c))
            if c != 0:
                ok = False
                break
        if ok:
            return True
    return False


def _equal(v, exact, approx) -> bool:
    if exact is not None:
        d = safe(sp.simplify, sp.sympify(v) - exact)
        if d is not None and d == 0:
            return True
        d = sp.radsimp(sp.nsimplify(sp.sympify(v) - exact)) if d is None else d
        if d == 0:
            return True
    try:
        fv = sp.N(v, DPS)
        return fv.is_real and abs(float(fv) - float(approx)) <= 1e-20 * max(1.0, abs(float(approx)))
    except (TypeError, ValueError):
        return False


def _guess(seq, rule, a, N, terms, base):
    """For a nonlinear rule: guess a formula from the first terms; it is only
    kept if it is proven by substitution (checked by the caller)."""
    vals = [t.exact for t in terms if t.k >= base]
    if len(vals) < 8 or not all(v is not None and v.is_Rational for v in vals):
        return None
    from sympy.concrete.guess import guess
    try:
        cands = guess(vals[:14])
    except Exception:
        cands = []
    i0 = sp.Symbol("i0")
    out = []
    for g in cands or []:
        g = sp.sympify(g)
        syms = g.free_symbols
        if syms and syms != {i0}:
            continue
        out.append(sp.simplify(g.subs(i0, N - base + 1)))
    # Or: a linear recurrence with constant coefficients that the terms satisfy, solved.
    from sympy.concrete.guess import find_simple_recurrence
    b = sp.Function("b")
    nn = sp.Symbol("n", integer=True, nonnegative=True)
    try:
        rec = find_simple_recurrence(vals[:14], A=b, N=nn)
    except Exception:
        rec = 0
    if rec != 0:
        shifts = [int(c.args[0] - nn) for c in sp.sympify(rec).atoms(AppliedUndef)]
        k = max(shifts) if shifts else 0
        if 0 < k < len(vals):
            sol = _rsolve(rec, b(nn), {b(i): vals[i] for i in range(k)})
            if sol is not None and not sol.free_symbols - {nn}:
                out.append(sol.subs(nn, N - base))
    for c in out:
        if _satisfies(c, rule, a, N) == "proof":
            return clean(c)
    return None


# -------------------------------------------------------------- limit -----
@dataclass
class SeqLimit:
    value: object = None          # exact value, ±oo, or a Float estimate
    exists: bool | None = None    # None: unknown
    exact: bool = True
    notes: list[str] = field(default_factory=list)
    subsequences: list | None = None   # [(p, r, value)] when they disagree
    oscillates: tuple | None = None


def _periodic(expr, N) -> bool:
    for p in expr.atoms(sp.Pow):
        if p.exp.has(N) and p.base.is_number and not p.base.is_positive:
            return True
    trig = (sp.sin, sp.cos, sp.tan, sp.cot, sp.sec, sp.csc)
    return any(f.has(N) for f in expr.atoms(*trig)) or any(f.has(N) for f in expr.atoms(sp.floor, sp.ceiling))


def _even_powers(expr, m):
    """b^(k m + c) with b < 0 and k even  ->  (b^k)^m · b^c, whose base is positive."""
    def fix(p):
        b, e = p.base, p.exp
        if not (b.is_number and b.is_negative):
            return None
        poly = sp.Poly(e, m) if e.is_polynomial(m) else None
        if poly is None or poly.degree() != 1:
            return None
        k, c = poly.all_coeffs()
        if not (k.is_Integer and k % 2 == 0):
            return None
        return sp.Pow(sp.expand(b ** k), m) * sp.Pow(b, c)
    reps = {}
    for p in expr.atoms(sp.Pow):
        if p.exp.has(m):
            f = fix(p)
            if f is not None:
                reps[p] = f
    return expr.xreplace(reps) if reps else expr


def sequence_limit(expr, N) -> SeqLimit:
    """lim a(N) as N → ∞ over the whole numbers."""
    expr = sp.sympify(expr)
    if N not in expr.free_symbols:
        return SeqLimit(expr, True)
    x = sp.Symbol(N.name, positive=True)
    fallback = None
    if not _periodic(expr, N):
        try:
            r = compute_limit(expr.xreplace({N: x}), x, sp.oo, "-")
        except (ValueError, TypeError):
            r = None
        if r is not None and r.exists and r.exact:
            return SeqLimit(r.value, True, notes=[n for n in r.notes])
        fallback = r
    m = sp.Symbol("m", integer=True, nonnegative=True)
    mx = sp.Symbol("m", positive=True)
    for p in (2, 3, 4, 6, 8, 12):
        vals = []
        for r in range(p):
            sub = _even_powers(expr.subs(N, p * m + r), m)
            if _periodic(sub, m):
                s2 = safe(sp.simplify, sub)
                if s2 is None or _periodic(s2, m):
                    break
                sub = s2
            try:
                rl = compute_limit(sub.xreplace({m: mx}), mx, sp.oo, "-")
            except (ValueError, TypeError):
                break
            if not (rl.exists and rl.exact):
                break
            vals.append(rl.value)
        else:
            if all(sp.simplify(v - vals[0]) == 0 if vals[0] not in (sp.oo, -sp.oo) else v == vals[0]
                   for v in vals):
                which = ("the even and the odd terms both tend to it" if p == 2 else
                         f"the subsequences n = {p}m, {p}m + 1, …, {p}m + {p - 1} all tend to it")
                return SeqLimit(vals[0], True, notes=[f"Found by splitting the terms: {which}."])
            return SeqLimit(None, False, subsequences=[(p, r, v) for r, v in enumerate(vals)])
    if fallback is not None and fallback.exists is False and fallback.oscillates is None:
        return SeqLimit(None, False, exact=fallback.exact)
    if fallback is not None and fallback.exists:
        return SeqLimit(fallback.value, True, exact=False, notes=list(fallback.notes))
    # Numerical look at far-out terms.
    return _numeric_tail(expr, N)


def _numeric_tail(expr, N) -> SeqLimit:
    try:
        f = sp.lambdify(N, expr, modules="mpmath")
        with mpmath.workdps(30):
            far = [f(mpmath.mpf(k)) for k in list(range(10**6, 10**6 + 60)) + list(range(10**8, 10**8 + 60))]
    except Exception:
        return SeqLimit(None, None, exact=False)
    if any(isinstance(v, mpmath.mpc) for v in far):
        return SeqLimit(None, None, exact=False)
    fl = [float(v) for v in far]
    a, b = fl[:60], fl[60:]
    spread = max(b) - min(b)
    if spread > 1e-3 * max(1.0, max(abs(v) for v in b)):
        return SeqLimit(None, False, exact=False, oscillates=(min(b), max(b)),
                        notes=["Far-out terms keep jumping between about "
                               f"{min(b):.4g} and {max(b):.4g} (checked numerically)."])
    if abs(b[-1] - a[-1]) > 1e-6 * max(1.0, abs(b[-1])):
        return SeqLimit(None, None, exact=False)  # still drifting between n = 10⁶ and 10⁸
    return SeqLimit(sp.Float(b[-1], 12), True, exact=False,
                    notes=["Estimated from the terms near n = 10⁸ (numerical; not proven)."])


@dataclass
class NumericLimit:
    value: object = None       # exact fixed point or Float, ±oo
    exists: bool | None = None
    notes: list[str] = field(default_factory=list)


def numeric_limit(seq: Sequence, count: int = 3000) -> NumericLimit:
    """Without a closed form: iterate with decimals and look at what the terms do."""
    it = iterate(seq, count, exact_count=0)
    mp = [t.value for t in it.terms]   # mpmath numbers: no overflow even for huge terms
    if len(mp) < 50:
        return NumericLimit(None, None, ["The terms could not be computed far enough to judge the limit."])
    big = [abs(v) for v in mp[-5:]]
    if all(b > 1e40 for b in big) and big[-1] > big[-2] > big[-3]:
        if all(v > 0 for v in mp[-5:]):
            return NumericLimit(sp.oo, False, ["The terms keep growing: the sequence appears to diverge to ∞ "
                                               "(numerical, not proven)."])
        if all(v < 0 for v in mp[-5:]):
            return NumericLimit(-sp.oo, False, ["The terms keep decreasing: the sequence appears to diverge "
                                                "to −∞ (numerical, not proven)."])
        return NumericLimit(None, False, ["The terms grow without bound while changing sign, so there is no "
                                          "limit (numerical, not proven)."])
    if any(abs(v) > 1e300 for v in mp[-50:]):
        return NumericLimit(None, None, ["The terms get too large to judge the limit numerically."])
    vals = [float(v) for v in mp]
    tail = vals[-50:]
    last = vals[-1]
    if abs(vals[-1] - vals[-2]) > 1e-9 * max(1.0, abs(last)) or abs(vals[-1] - vals[len(vals) // 2]) > 1e-6 * max(1.0, abs(last)):
        lo, hi = min(tail), max(tail)
        return NumericLimit(None, None, [f"The terms don't settle down in the first {len(vals)} terms "
                                         f"(they move between about {lo:.6g} and {hi:.6g})."])
    est = mpmath.mpf(it.terms[-1].value)
    # An autonomous rule g: a fixed point L = g(L, ..., L) is the candidate.
    ps = _placeholders(seq)
    L = sp.Symbol("L", real=True)
    g = sp.sympify(seq.rule).xreplace({c: L for c in ps})
    if seq.n not in g.free_symbols:
        roots = safe(sp.solve, sp.Eq(L, g), L) or []
        for r in roots:
            if not r.is_real:
                continue
            if abs(float(sp.N(r)) - float(est)) <= 1e-6 * max(1.0, abs(float(est))) and \
                    safe(sp.simplify, g.subs(L, r) - r) == 0:
                return NumericLimit(r, True, [
                    f"The terms approach ${tex(r)}$ numerically, and $L = {tex(r)}$ solves "
                    f"$L = {tex(g)}$ exactly. That the terms converge was seen numerically, not proven."])
    return NumericLimit(sp.Float(float(est), 12), True, ["Estimated by computing the terms (numerical, not proven)."])


# ------------------------------------------------------------ shape -------
def progression(cf_expr, N) -> tuple[str, sp.Expr] | None:
    """("arithmetic", d), ("geometric", q) or ("constant", c) from a formula in N."""
    d = safe(sp.simplify, cf_expr.subs(N, N + 1) - cf_expr)
    if d is not None and not d.has(N):
        if d == 0:
            return ("constant", sp.simplify(cf_expr))
        return ("arithmetic", d)
    if safe(sp.simplify, cf_expr) == 0:
        return None
    q = safe(sp.simplify, cf_expr.subs(N, N + 1) / cf_expr)
    if q is not None and not q.has(N) and q != 0 and q.is_real is not False:
        return ("geometric", q)
    return None


def float_terms(seq: Sequence, count: int) -> list[tuple[int, float]]:
    out = []
    for t in iterate(seq, count, exact_count=0).terms:
        f = float(t.value)
        if math.isfinite(f) and abs(f) < 1e300:
            out.append((t.k, f))
    return out
