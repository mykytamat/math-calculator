"""Calculus: limits, derivatives, integrals, function analysis (Calculus tab)."""
