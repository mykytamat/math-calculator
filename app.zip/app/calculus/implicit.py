"""Implicit differentiation: dy/dx (and d²y/dx²) for a curve F(x, y) = 0,
with the slope and tangent line at a point of the curve."""
from __future__ import annotations

from dataclasses import dataclass, field

import sympy as sp

from ..core.decide import compare
from ..core.format import tex
from ..solving.univariate import safe
from .analysis import nicest


@dataclass
class ImplicitResult:
    dydx: object = None
    d2ydx2: object = None
    slope: object = None           # at the point
    tangent: object = None         # y as an expression of x, or ("vertical", x0)
    notes: list = field(default_factory=list)


def implicit(lhs, rhs, x, y, point=None) -> ImplicitResult:
    res = ImplicitResult()
    F = sp.sympify(lhs - rhs)
    Fx, Fy = sp.diff(F, x), sp.diff(F, y)
    if Fy == 0:
        raise ValueError(f"${tex(y)}$ does not appear in the equation, so $dy/dx$ is not defined by it.")
    d1 = nicest(-Fx / Fy)
    res.dydx = d1
    d2 = sp.diff(d1, x) + sp.diff(d1, y) * d1
    d2 = nicest(d2)
    # Use the equation itself to simplify, e.g. -(x² + y²)/y³ = -25/y³ on x² + y² = 25.
    for a, b in ((lhs, rhs), (rhs, lhs)):
        a = sp.sympify(a)
        if a.free_symbols and sp.count_ops(a) > 0:
            alt = safe(lambda a=a, b=b: nicest(d2.subs(a, b)))
            if alt is not None and len(tex(alt)) < len(tex(d2)):
                d2 = alt
    res.d2ydx2 = d2
    if point is not None:
        x0, y0 = point
        on = compare("=", sp.sympify(lhs).subs({x: x0, y: y0}), sp.sympify(rhs).subs({x: x0, y: y0}))
        if not on.value:
            raise ValueError(f"The point $\\left({tex(x0)}, {tex(y0)}\\right)$ is not on the curve.")
        fy0 = sp.simplify(Fy.subs({x: x0, y: y0}))
        if fy0 == 0:
            res.tangent = ("vertical", x0)
            res.notes.append(f"At this point $\\partial F/\\partial {tex(y)} = 0$: the tangent is vertical, "
                             f"${tex(x)} = {tex(x0)}$.")
            return res
        m = sp.simplify(d1.subs({x: x0, y: y0}))
        res.slope = m
        res.tangent = sp.expand(y0 + m * (x - x0))
    return res
