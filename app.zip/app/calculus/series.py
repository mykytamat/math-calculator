"""Sums and series.

Finite sums are added up exactly term by term (or, for very many terms, from a
closed form proved by induction). A sum with a letter as its upper bound gets
a closed form that is checked the same way. Infinite series go through the
cheapest tests first, reporting what is known as it goes (there is no
per-step timeout on Windows):
  1. the divergence test (terms not tending to 0);
  2. SymPy's doit (an exact value or ∞);
  3. the exponent test: p = lim(−ln|aₖ| / ln k);
  4. SymPy's is_convergent (can be slow).
mpmath's nsum never decides convergence (it returns finite numbers for
divergent series), so it is only used to check a value, or to estimate one
once convergence is proven, showing only the digits two methods agree on.
"""
from __future__ import annotations

import math
import time
from dataclasses import dataclass, field

import mpmath
import sympy as sp

from ..core.domain import explain, first_violation
from ..core.format import tex
from ..parsing import MathError
from ..solving import numeric
from ..solving.univariate import safe
from .limits import compute_limit
from .sequences import is_zero, sequence_limit

MAX_DIRECT = 2000      # finite sums with at most this many terms are added term by term
MAX_FLOAT = 200000     # beyond this, not even decimals are added one by one


@dataclass
class SumResult:
    value: object = None            # exact value (finite sum, closed form, or series sum)
    estimate: object = None         # sp.Float showing only trusted digits
    converges: bool | None = None   # for series; None = undecided
    absolute: bool | None = None
    to: object = None               # divergence to sp.oo / -sp.oo
    reason: str | None = None       # why it converges / diverges
    condition: object = None        # the value holds when this holds (parameters)
    exact: bool = True
    notes: list[str] = field(default_factory=list)
    partial: list[tuple[int, float]] = field(default_factory=list)  # (N, S_N) for the graph


def int_symbol(k: sp.Symbol, lower) -> sp.Symbol:
    lower = sp.sympify(lower)
    if lower.is_number and lower >= 1:
        return sp.Symbol(k.name, integer=True, positive=True)
    if lower.is_number and lower >= 0:
        return sp.Symbol(k.name, integer=True, nonnegative=True)
    return sp.Symbol(k.name, integer=True)


def term_tex(k, j) -> str:
    return f"{tex(k)} = {j}"


# ------------------------------------------------------------ checks ------
def check_terms(f, k, indices, conditions) -> None:
    """Raise MathError at the first index where the summand is undefined."""
    conds = [c for c in conditions if sp.sympify(c.expr).free_symbols <= {k}]
    for j in indices:
        v = first_violation([c.subs({k: j}) for c in conds])
        if v is not None:
            raise MathError(f"Undefined: the term for ${term_tex(k, j)}$ has no value. " + explain(*v))
        t = f.subs(k, j)
        if t.has(sp.nan, sp.zoo) or (t.is_number and t.is_real is False):
            raise MathError(f"Undefined: the term for ${term_tex(k, j)}$ has no value (it is not a real number).")


def bad_indices(conditions, k, lower, upper) -> list[int]:
    """Whole numbers in [lower, upper] where a condition could fail: the integer
    points next to the real roots of each condition's expression (it can only
    change sign there), and the ends."""
    pts = {int(lower)}
    if upper != sp.oo:
        pts.add(int(upper))
    for c in conditions:
        e = sp.sympify(c.expr)
        if e.free_symbols != {k}:
            continue
        roots = safe(sp.solve, e, k) or []
        for r in roots:
            try:
                rf = float(sp.N(r))
            except (TypeError, ValueError):
                continue
            if not math.isfinite(rf):
                continue
            for j in (math.floor(rf) - 1, math.floor(rf), math.ceil(rf), math.ceil(rf) + 1):
                if j >= lower and (upper == sp.oo or j <= upper):
                    pts.add(j)
    return sorted(pts)


# ------------------------------------------------------------ finite ------
def finite_sum(f, k, a: int, b: int, conditions=()) -> SumResult:
    res = SumResult()
    a, b = int(a), int(b)
    if b < a:
        res.value = sp.Integer(0)
        res.notes.append("The upper bound is below the lower one, so the sum is empty: it equals 0.")
        return res
    count = b - a + 1
    if count <= MAX_DIRECT:
        check_terms(f, k, range(a, b + 1), conditions)
        total = sp.Integer(0)
        for j in range(a, b + 1):
            total += f.subs(k, j)
        if not total.free_symbols and sp.count_ops(total) > 40:
            s = safe(sp.nsimplify, total) if total.is_Rational else None
            total = s if s is not None else (safe(sp.simplify, total) or total)
        elif total.free_symbols:
            total = safe(sp.expand, total) or total
        res.value = total
        res.notes.append(f"Added term by term ({count} terms).")
        res.partial = _partials(f, k, a, min(b, a + 199))
        return res
    check_terms(f, k, bad_indices(conditions, k, a, b), conditions)
    n = sp.Dummy("n", integer=True)
    closed = closed_sum(f, k, a, n)
    special = (sp.harmonic, sp.polygamma, sp.zeta, sp.gamma, sp.loggamma, sp.lerchphi, sp.hyper)
    if closed is not None and closed.exact and closed.value.has(*special):
        # e.g. the harmonic number H_(10^7): exactly a fraction with millions of digits.
        try:
            g = sp.lambdify(n, closed.value, modules="mpmath")
            with mpmath.workdps(30):
                v = g(mpmath.mpf(b))
            if not isinstance(v, mpmath.mpc) and mpmath.isfinite(v):
                res.estimate = sp.Float(mpmath.nstr(v, 15), 15)
                res.exact = False
                N = sp.Symbol("N")
                res.notes.append(f"From the formula ${tex(closed.value.subs(n, N))}$ for the sum up to $N$, "
                                 f"evaluated at $N = {b}$ with 30-digit decimals (the exact value is a fraction "
                                 "far too long to show).")
                return res
        except Exception:
            pass
    if closed is not None and closed.exact and not closed.value.has(*special):
        res.value = safe(sp.simplify, closed.value.subs(n, b)) or closed.value.subs(n, b)
        res.notes.append(f"From the formula ${tex(closed.value.subs(n, sp.Symbol('N')))}$ for the sum up to $N$ "
                         f"({closed.notes[0][0].lower() + closed.notes[0][1:] if closed.notes else ''})")
        res.partial = _partials(f, k, a, a + 199)
        return res
    if count > MAX_FLOAT or f.free_symbols - {k}:
        raise MathError(f"This sum has {count} terms and no formula for it was found, so it can't be added up here.")
    fl = _float_fn(f, k)
    with mpmath.workdps(30):
        total = mpmath.fsum(fl(j) for j in range(a, b + 1))
    res.estimate = sp.Float(str(total), 15)
    res.exact = False
    res.notes.append(f"No exact formula was found; the {count} terms were added as decimals.")
    return res


def _float_fn(f, k):
    g = sp.lambdify(k, f, modules="mpmath")

    def at(j):
        v = g(mpmath.mpf(int(j)))
        return mpmath.mpf(v) if not isinstance(v, mpmath.mpc) else v
    return at


def _partials(f, k, a, b) -> list[tuple[int, float]]:
    out = []
    if f.free_symbols - {k}:
        return out
    try:
        fl = _float_fn(f, k)
        s = mpmath.mpf(0)
        with mpmath.workdps(30):
            for j in range(a, b + 1):
                v = fl(j)
                if isinstance(v, mpmath.mpc):
                    return out
                s += v
                fs = float(s)
                if not math.isfinite(fs) or abs(fs) > 1e300:
                    break
                out.append((j, fs))
    except Exception:
        return out
    return out


# ------------------------------------------------------------ closed ------
def closed_sum(f, k, a, n, keep=None) -> SumResult | None:
    """Σ_{k=a}^{n} f as a formula in n, checked by induction:
    S(a) = f(a) and S(n) − S(n−1) = f(n). keep(S) can reject a formula
    before the (slower) checks."""
    kk = int_symbol(k, a)
    fk = f.xreplace({k: kk})
    nn = sp.Symbol("n_", integer=True)
    S = safe(sp.summation, fk, (kk, a, nn))
    if S is None or S.has(sp.Sum) or (keep is not None and not keep(S)):
        return None
    S = _nicest(S)
    res = SumResult(value=S.xreplace({nn: n}))
    params = sorted(f.free_symbols - {k}, key=str)
    step = S - S.subs(nn, nn - 1) - fk.subs(kk, nn)
    first = S.subs(nn, a) - fk.subs(kk, a)
    if not S.has(sp.Piecewise) and is_zero(step, nn) and is_zero(first, nn):
        res.notes.append("Proved by induction: the formula gives the first term, and adding the next term "
                         "gives the formula for n + 1.")
    else:
        # Compare with direct sums for small n (at sample parameter values).
        sample = {p: sp.Rational(3 + 2 * i, 7) for i, p in enumerate(params)}
        ok = True
        total = sp.Integer(0)
        for j in range(int(a), int(a) + 8):
            total += fk.subs(kk, j)
            d = safe(sp.simplify, (S.subs(nn, j) - total).subs(sample))
            if d != 0:
                ok = False
                break
        if not ok:
            return None
        where = (" at " + ", ".join(f"${tex(p)} = {tex(v)}$" for p, v in sample.items())) if sample else ""
        res.notes.append(f"Checked against the sums added term by term for the first 8 values of n{where}; "
                         "the general identity was not proven symbolically.")
    return res


# ------------------------------------------------------------ products ----
MAX_PRODUCT_DIGITS = 10**5  # a product larger than 10^this is shown as a decimal estimate


def finite_product(f, k, a: int, b: int, conditions=()) -> SumResult:
    """∏_{k=a}^{b} f: multiplied factor by factor (each one checked to be defined), or for
    very many factors from a formula proved by induction (closed_product)."""
    res = SumResult()
    a, b = int(a), int(b)
    if b < a:
        res.value = sp.Integer(1)
        res.notes.append("The upper bound is below the lower one, so the product is empty: it equals 1.")
        return res
    count = b - a + 1
    if count <= MAX_DIRECT:
        check_terms(f, k, range(a, b + 1), conditions)
        total = sp.Integer(1)
        for j in range(a, b + 1):
            total *= f.subs(k, j)
            if total == 0:
                res.value = total
                res.notes.append(f"The factor for ${term_tex(k, j)}$ is 0, so the product is 0.")
                return res
        if total.free_symbols:
            total = safe(sp.factor, total) or total
        elif sp.count_ops(total) > 40:
            total = safe(sp.simplify, total) or total
        res.value = total
        res.notes.append(f"Multiplied factor by factor ({count} factors).")
        return res
    check_terms(f, k, bad_indices(conditions, k, a, b), conditions)
    n = sp.Dummy("n", integer=True)
    closed = closed_product(f, k, a, n)
    if closed is None or f.free_symbols - {k}:
        raise MathError(f"This product has {count} factors and no formula for it was found, so it can't be "
                        f"multiplied out here (up to {MAX_DIRECT} factors are multiplied directly).")
    how = closed.notes[0][0].lower() + closed.notes[0][1:] if closed.notes else ""
    formula = tex(closed.value.subs(n, sp.Symbol("N")))
    with sp.evaluate(False):
        at_b = closed.value.subs(n, b)
    size = safe(lambda: sp.N(sp.log(sp.Abs(at_b), 10), 15))
    if size is not None and size.is_finite and size > MAX_PRODUCT_DIGITS:
        v = safe(lambda: sp.N(at_b, 15))
        if v is None or not v.is_finite:
            raise MathError(f"This product has {count} factors; its value is too large to work out here.")
        res.estimate = v
        res.exact = False
        res.notes.append(f"From the formula ${formula}$ for the product up to $N$ ({how}), evaluated at "
                         f"$N = {b}$ with decimals: the exact value has about {int(size) + 1} digits.")
        return res
    res.value = safe(sp.simplify, closed.value.subs(n, b)) or closed.value.subs(n, b)
    res.notes.append(f"From the formula ${formula}$ for the product up to $N$ ({how})")
    return res


def closed_product(f, k, a, n) -> SumResult | None:
    """∏_{k=a}^{n} f as a formula in n, checked by induction: P(a) = f(a) and
    P(n) = P(n−1)·f(n). SymPy's product is not trusted alone."""
    kk = int_symbol(k, a)
    fk = f.xreplace({k: kk})
    nn = sp.Symbol("n_", integer=True)
    P = safe(sp.product, fk, (kk, a, nn))
    if P is None or P.has(sp.Product):
        return None
    P = _nicest(P)
    res = SumResult(value=P.xreplace({nn: n}))
    params = sorted(f.free_symbols - {k}, key=str)
    step = P - P.subs(nn, nn - 1) * fk.subs(kk, nn)
    first = P.subs(nn, a) - fk.subs(kk, a)
    step_zero = is_zero(step, nn) or is_zero(safe(sp.combsimp, step) or step, nn)
    if not P.has(sp.Piecewise) and step_zero and is_zero(first, nn):
        res.notes.append("Proved by induction: the formula gives the first factor, and multiplying by the next "
                         "factor gives the formula for n + 1.")
    else:
        # Compare with the products multiplied out for small n (at sample parameter values).
        sample = {p: sp.Rational(3 + 2 * i, 7) for i, p in enumerate(params)}
        total = sp.Integer(1)
        for j in range(int(a), int(a) + 8):
            total *= fk.subs(kk, j)
            d = safe(sp.simplify, (P.subs(nn, j) - total).subs(sample))
            if d != 0:
                return None
        where = (" at " + ", ".join(f"${tex(p)} = {tex(v)}$" for p, v in sample.items())) if sample else ""
        res.notes.append(f"Checked against the products multiplied out for the first 8 values of n{where}; "
                         "the general identity was not proven symbolically.")
    return res


def _nicest(e):
    cands = [e]
    for fn in (sp.factor, sp.simplify):
        r = safe(fn, e)
        if r is not None:
            cands.append(r)
    return min(cands, key=lambda c: (sp.count_ops(c), len(str(c))))


# ------------------------------------------------------------ series ------
def infinite_series(f, k, a, conditions=(), progress=None) -> SumResult:
    """Σ_{k=a}^{∞} f. progress(res) is called with what is known so far."""
    a = int(a)
    kk = int_symbol(k, a)
    fk = f.xreplace({k: kk})
    conds = [c.subs({k: kk}) for c in conditions]
    params = sorted(fk.free_symbols - {kk}, key=str)
    if params:
        return _with_parameters(fk, kk, a, params)
    check_terms(fk, kk, bad_indices(conds, kk, a, sp.oo) + list(range(a, a + 30)), conds)
    res = SumResult(converges=None)
    res.partial = _partials(fk, kk, a, a + 59)

    def report():
        if progress is not None:
            progress(res)

    sign = _sign(fk, kk, a)
    # 1. exponent test: |a_k| is about 1/k^p. It also settles the divergence test when p ≠ 0.
    p = _exponent(fk, kk, sign)
    terms_to_zero = p is not None and p > 0
    if p is not None:
        if p > 1:
            res.converges, res.absolute = True, True
            res.reason = (f"its terms shrink faster than any power of ${tex(kk)}$" if p == sp.oo else
                          f"its terms are about $1/{tex(kk)}^{{p}}$ in size with $p = {tex(p)} > 1$")
        elif p < 0:
            res.converges = False
            res.reason = "its terms grow without bound, so they don't tend to 0"
            res.to = None if sign is None else (sp.oo if sign > 0 else -sp.oo)
            return res
        elif p < 1 and sign is not None:
            res.converges = False
            res.to = sp.oo if sign > 0 else -sp.oo
            res.reason = (f"its terms all have the same sign and are about $1/{tex(kk)}^{{p}}$ in size with "
                          f"$p = {tex(p)} < 1$, which is too large (like the harmonic series)")
            return res
    report()

    # 2. divergence test, when the size of the terms didn't settle it
    if p is None or p <= 0:
        L = sequence_limit(fk, kk)
        if L.exists is False:
            res.converges = False
            if L.subsequences:
                vals = ", ".join(f"${tex(v)}$" for _, _, v in L.subsequences)
                q = L.subsequences[0][0]
                which = "the even and the odd terms" if q == 2 else f"the terms with $k = {q}m, …, {q}m + {q - 1}$"
                res.reason = f"its terms don't tend to 0 ({which} tend to {vals})"
            elif L.oscillates:
                res.reason = "its terms don't tend to 0 (they keep oscillating)"
            else:
                res.reason = "its terms don't tend to 0 (they have no limit)"
            res.exact = L.exact
            return res
        if L.exists and L.value is not None and L.value != 0 and L.exact:
            res.converges = False
            if L.value in (sp.oo, -sp.oo):
                res.reason = f"its terms tend to ${tex(L.value)}$"
                res.to = L.value
            else:
                res.reason = f"its terms tend to ${tex(L.value)} \\ne 0$"
                res.to = sp.oo if L.value > 0 else -sp.oo
            return res
        terms_to_zero = bool(L.exists and L.value == 0 and L.exact)
        report()

    # 3. SymPy's closed form
    v = safe(lambda: sp.Sum(fk, (kk, a, sp.oo)).doit())
    exact_value = None
    if v is not None and not v.has(sp.Sum):
        v = sp.sympify(v)
        if v in (sp.oo, -sp.oo) and res.converges is None:
            res.converges, res.to = False, v
            res.reason = f"its partial sums grow to ${tex(v)}$"
            return res
        if v.is_number and v.is_real and not v.has(sp.nan, sp.zoo):
            exact_value = _nicest(v)
    if res.converges is None and exact_value is not None:
        res.converges = True
        res.reason = "SymPy found its sum"
    report()

    # 4. SymPy's convergence tests (the slowest step)
    if res.converges is None:
        c = safe(lambda: sp.Sum(fk, (kk, a, sp.oo)).is_convergent())
        if c is sp.true or c is True:
            res.converges = True
            res.reason = "SymPy's convergence tests show it converges"
        elif c is sp.false or c is False:
            res.converges = False
            res.reason = "SymPy's convergence tests show it diverges"
            if sign is not None:
                res.to = sp.oo if sign > 0 else -sp.oo
            return res

    if res.converges and res.absolute is None:
        if sign is not None:
            res.absolute = True
        else:
            res.absolute = _absolutely(fk, kk, a)

    # The value.
    if res.converges:
        est = estimate(fk, kk, a, sign, p)
        if exact_value is not None:
            res.value = exact_value
            if est is not None and _consistent(exact_value, est):
                res.notes.append(f"Checked numerically: {est.how}.")
            elif est is not None and est.digits >= 3:
                res.exact = False
                res.notes.append(f"Warning: a numerical check gives about {mpmath.nstr(est.value, 10)} "
                                 f"({est.how}); the exact value may be wrong.")
            else:
                res.notes.append("The exact value could not be checked numerically.")
        elif est is not None and est.digits >= 3:
            res.estimate = _round(est.value, est.digits)
            res.exact = False
            res.notes.append(f"No exact value was found. Numerically: {est.how}.")
            named = numeric.recognize(sp.Float(str(est.value), 15)) if est.digits >= 12 else []
            if named:
                res.notes.append(f"It looks like ${tex(named[0])}$, but that isn't proven.")
        else:
            res.exact = False
            res.notes.append("It converges, but its value could not be estimated reliably.")
        return res
    # Undecided: only partial sums, which say nothing certain about the limit.
    res.exact = False
    if not terms_to_zero:
        res.notes.append("It isn't even known whether its terms tend to 0.")
    try:
        sums = partial_sum_table(fk, kk, a)
        res.notes.append("Partial sums (numerical): " + ", ".join(
            f"$S_{{{N}}} \\approx {s:.8g}$" for N, s in sums) + ". These don't show whether it converges.")
    except Exception:
        pass
    return res


def _with_parameters(fk, kk, a, params) -> SumResult:
    res = SumResult(converges=None, exact=True)
    v = safe(lambda: sp.Sum(fk, (kk, a, sp.oo)).doit())
    names = ", ".join(f"${tex(p)}$" for p in params)
    if v is None or (v.has(sp.Sum) and not isinstance(v, sp.Piecewise)):
        raise MathError(f"No formula was found for this series with the parameter {names}. "
                        "Give the parameter a value to test convergence.")
    if isinstance(v, sp.Piecewise):
        for val, cond in v.args:
            if not val.has(sp.Sum) and cond is not sp.true:
                res.value, res.condition = _nicest(val), cond
                res.converges = True
                res.notes.append(f"For other values of {names} the convergence was not decided here.")
                break
        else:
            raise MathError(f"No formula was found for this series with the parameter {names}.")
    else:
        if v in (sp.oo, -sp.oo):
            res.converges, res.to = False, v
            return res
        res.value = _nicest(v)
        res.converges = True
        res.notes.append(f"This holds for the values of {names} where the series converges.")
    # Check at a sample parameter value inside the condition.
    for trial in (sp.Rational(1, 3), sp.Rational(-1, 2), sp.Rational(2, 7)):
        sample = {p: trial for p in params}
        if res.condition is not None and sp.sympify(res.condition).subs(sample) is not sp.true:
            continue
        fs = fk.subs(sample)
        est = estimate(fs, kk, a, _sign(fs, kk, a))
        if est is not None and est.digits >= 4:
            if _consistent(res.value.subs(sample), est):
                res.notes.append(f"Checked numerically at {', '.join(f'${tex(p)} = {tex(trial)}$' for p in params)}.")
            else:
                res.exact = False
                res.notes.append("Warning: a numerical check at a sample value disagrees; the formula may be wrong.")
        break
    return res


def _sign(fk, kk, a) -> int | None:
    """+1 / −1 when every term has that sign (proved by SymPy's assumptions or
    seen on the first 200 terms and far out), None when the sign changes."""
    if fk.is_positive:
        return 1
    if fk.is_negative:
        return -1
    try:
        fl = _float_fn(fk, kk)
        with mpmath.workdps(20):
            vals = [fl(j) for j in list(range(a, a + 200)) + list(range(10**6, 10**6 + 4))]
    except Exception:
        return None
    if any(isinstance(v, mpmath.mpc) for v in vals):
        return None
    if all(v >= 0 for v in vals) and any(v > 0 for v in vals):
        return 1
    if all(v <= 0 for v in vals) and any(v < 0 for v in vals):
        return -1
    return None


def _abs(fk, sign):
    if sign is not None:
        return fk if sign > 0 else -fk
    absf = safe(sp.Abs, fk)
    if absf is not None and not absf.has(sp.Abs):
        return absf
    absf = safe(sp.simplify, sp.Abs(fk))
    return absf if absf is not None and not absf.has(sp.Abs) else None


def _exponent(fk, kk, sign):
    """p = lim −ln|a_k| / ln k (exact only), or None."""
    absf = _abs(fk, sign)
    if absf is None:
        return None
    x = sp.Symbol(kk.name, positive=True)
    expr = -sp.log(absf.xreplace({kk: x})) / sp.log(x)
    expr = safe(sp.expand_log, expr, force=True) or expr
    try:
        r = compute_limit(expr, x, sp.oo, "-")
    except (ValueError, TypeError):
        return None
    if not (r.exists and r.exact) or r.value is None:
        return None
    return r.value


def _absolutely(fk, kk, a) -> bool | None:
    absf = safe(sp.Abs, fk)
    if absf is None or absf.has(sp.Abs):
        return None
    v = safe(lambda: sp.Sum(absf, (kk, a, sp.oo)).doit())
    if v in (sp.oo,):
        return False
    if v is not None and not v.has(sp.Sum) and v.is_number and v.is_finite:
        return True
    c = safe(lambda: sp.Sum(absf, (kk, a, sp.oo)).is_convergent())
    if c is True or c is sp.true:
        return True
    if c is False or c is sp.false:
        return False
    return None


@dataclass
class Estimate:
    value: object          # mpf
    digits: int            # significant digits that can be trusted
    how: str               # for a note
    lo: object = None      # a bracket lo <= S <= hi, when one was found
    hi: object = None


def estimate(fk, kk, a, sign, p=None) -> Estimate | None:
    """A numerical value of a convergent series. Extrapolating methods can all
    agree on a wrong value, so a guaranteed bracket is used where the terms allow:
      * same-sign terms, decreasing and convex: the integral test with trapezoid /
        midpoint bounds, S_N + ∫_N^∞ f − f(N)/2  ≤  S  ≤  S_N + ∫_{N+1/2}^∞ f;
      * alternating terms of decreasing size: S lies between S_N and S_{N+1}.
    Otherwise only the digits on which all of mpmath's methods agree are kept."""
    try:
        if sign is not None:
            e = _ratio_bracket(fk, kk, a, sign) if p == sp.oo else _integral_bracket(fk, kk, a, sign)
            if e is not None:
                return e
        else:
            e = _alternating_bracket(fk, kk, a)
            if e is not None:
                return e
    except Exception:
        pass
    return _methods(fk, kk, a)


def _digits(lo, hi) -> int:
    mid = (lo + hi) / 2
    width = abs(hi - lo)
    if width == 0:
        return 15
    if mid == 0:
        return 0
    return int(max(0, min(15, math.floor(-math.log10(float(width / abs(mid)))))))


def _integral_bracket(fk, kk, a, sign, N: int = 1000) -> Estimate | None:
    x = sp.Symbol("x", positive=True)
    g = sp.lambdify(x, (sign * fk).xreplace({kk: x}), modules="mpmath")
    N = max(N, a + 10)
    with mpmath.workdps(30):
        samples = [N + i for i in range(40)] + [2 * N, 5 * N, 10 * N, 100 * N, 10**5 * N]
        for s in samples:
            f0, f1, f2 = g(mpmath.mpf(s)), g(mpmath.mpf(s + 1)), g(mpmath.mpf(s + 2))
            if any(isinstance(v, mpmath.mpc) for v in (f0, f1, f2)):
                return None
            if not (f1 < f0 and f2 - 2 * f1 + f0 >= 0 and f0 > 0):
                return None  # not decreasing and convex there
        S = mpmath.fsum(g(mpmath.mpf(j)) for j in range(a, N + 1))
        tail_lo = _tail_integral(g, mpmath.mpf(N))
        tail_hi = _tail_integral(g, mpmath.mpf(N) + mpmath.mpf(1) / 2)
        if tail_lo is None or tail_hi is None:
            return None
        lo = S + tail_lo - g(mpmath.mpf(N)) / 2
        hi = S + tail_hi
    if not (mpmath.isfinite(lo) and mpmath.isfinite(hi)) or hi < lo:
        return None
    lo, hi = (lo, hi) if sign > 0 else (-hi, -lo)
    return Estimate((lo + hi) / 2, _digits(lo, hi),
                    f"the integral test gives the bounds {mpmath.nstr(lo, 12)} ≤ S ≤ {mpmath.nstr(hi, 12)}; "
                    "the terms were checked to be decreasing and convex numerically", lo, hi)


def _ratio_bracket(fk, kk, a, sign) -> Estimate | None:
    """Terms shrinking faster than any power: once the ratios a_{k+1}/a_k stop
    growing and stay below r < 1, the tail after a_N is at most a_{N+1}/(1 − r)."""
    g = sp.lambdify(kk, sign * fk, modules="mpmath")
    with mpmath.workdps(30):
        N = a + 40
        while N <= 20000:
            vals = [g(mpmath.mpf(j)) for j in range(N, N + 42)]
            if any(isinstance(v, mpmath.mpc) or not v > 0 for v in vals):
                return None
            ratios = [v / u for u, v in zip(vals, vals[1:])]
            r = ratios[0]
            if all(q2 <= q1 * (1 + mpmath.mpf("1e-25")) for q1, q2 in zip(ratios, ratios[1:])) and r < 1:
                S = mpmath.fsum(g(mpmath.mpf(j)) for j in range(a, N + 1))
                tail = vals[1] / (1 - r)
                if tail <= mpmath.mpf("1e-16") * abs(S) or N * 4 > 20000:
                    lo, hi = S, S + tail
                    lo, hi = (lo, hi) if sign > 0 else (-hi, -lo)
                    return Estimate((lo + hi) / 2, _digits(lo, hi),
                                    f"after ${tex(kk)} = {N}$ the ratio of consecutive terms stays below "
                                    f"{mpmath.nstr(r, 6)}, which bounds the rest: "
                                    f"{mpmath.nstr(lo, 12)} ≤ S ≤ {mpmath.nstr(hi, 12)}", lo, hi)
            N *= 4
    return None


def _tail_integral(g, X):
    """∫_X^∞ g(x) dx, computed as ∫_{ln X}^∞ g(e^t) e^t dt (slow tails such as
    1/(x ln²x) become 1/t², which quadrature handles). Two different
    subdivisions must agree, else None."""
    h = lambda t: g(mpmath.exp(t)) * mpmath.exp(t)  # noqa: E731
    t0 = mpmath.log(X)
    # Quadrature goes far out: it must stay cheap there. The points step up gently because one
    # evaluation can be very slow (with (1/3)^x, 0.01 s at t0 + 1000 but 2 s at t0 + 10^4 on a PC,
    # 25 times longer in the WebAssembly version), and it is only timed once it is done.
    for t in (t0 + 50, t0 + 300, t0 + 1000, t0 + 3000, t0 + 10**4, t0 + 10**8):
        started = time.perf_counter()
        try:
            h(mpmath.mpf(t))
        except Exception:
            return None
        if time.perf_counter() - started > 0.02:
            return None
    try:
        one = mpmath.quad(h, [t0, mpmath.inf])
        two = mpmath.quad(h, [t0, t0 + 1, t0 + 4, t0 + 16, t0 + 64, mpmath.inf])
    except Exception:
        return None
    if isinstance(one, mpmath.mpc) or isinstance(two, mpmath.mpc) or not mpmath.isfinite(one):
        return None
    if abs(one - two) > mpmath.mpf("1e-20") * max(1, abs(one)):
        return None
    return two


def _alternating_bracket(fk, kk, a, N: int = 20000) -> Estimate | None:
    g = sp.lambdify(kk, fk, modules="mpmath")
    with mpmath.workdps(30):
        vals = [g(mpmath.mpf(j)) for j in list(range(a + 5, a + 100)) + list(range(N - 50, N + 3))]
        if any(isinstance(v, mpmath.mpc) for v in vals):
            return None
        pairs =list(zip(vals[:94], vals[1:95])) + list(zip(vals[95:], vals[96:]))
        if not all(u * v < 0 and abs(v) < abs(u) for u, v in pairs):
            return None
        S = mpmath.fsum(g(mpmath.mpf(j)) for j in range(a, N + 1))
        S1 = S + g(mpmath.mpf(N + 1))
    lo, hi = min(S, S1), max(S, S1)
    return Estimate((lo + hi) / 2, _digits(lo, hi),
                    f"the terms alternate in sign and shrink, so the sum lies between the partial sums "
                    f"$S_{{{N}}}$ and $S_{{{N + 1}}}$: {mpmath.nstr(lo, 12)} ≤ S ≤ {mpmath.nstr(hi, 12)}", lo, hi)


def _methods(fk, kk, a) -> Estimate | None:
    g = sp.lambdify(kk, fk, modules="mpmath")
    results = []
    with mpmath.workdps(30):
        int_fn = lambda j: g(mpmath.mpf(int(j)))  # noqa: E731
        for name, method, fn in (("Richardson/Shanks", "r+s", int_fn), ("Euler–Maclaurin", "e", g),
                                 ("Levin", "levin", int_fn)):
            try:
                v = mpmath.nsum(fn, [a, mpmath.inf], method=method)
            except Exception:
                continue
            if not isinstance(v, mpmath.mpc) and mpmath.isfinite(v):
                results.append((name, v))
    if len(results) < 2:
        return None
    vs = [v for _, v in results]
    lo, hi = min(vs), max(vs)
    names = ", ".join(n for n, _ in results)
    return Estimate((lo + hi) / 2, _digits(lo, hi),
                    f"only the digits on which all of mpmath's methods ({names}) agree are shown; this is "
                    "not a guaranteed bound")


def _consistent(exact_value, est: Estimate) -> bool:
    """Does the exact value fit the numerical estimate (inside its bracket, or
    matching the digits it trusts)?"""
    with mpmath.workdps(30):
        v = mpmath.mpf(str(sp.N(exact_value, 30)))
        if est.lo is not None:
            slack = abs(est.hi - est.lo) * mpmath.mpf("1e-6") + mpmath.mpf("1e-25") * max(1, abs(v))
            return est.lo - slack <= v <= est.hi + slack
        if est.digits < 6:
            return False
        return abs(v - est.value) <= mpmath.mpf(10) ** (1 - est.digits) * max(1, abs(v))


def _round(v, digits: int):
    return sp.Float(mpmath.nstr(v, max(1, digits)), max(1, digits))


def partial_sum_table(f, k, a, points=(100, 1000, 10000)) -> list[tuple[int, float]]:
    fl = _float_fn(f, k)
    out = []
    with mpmath.workdps(25):
        s, j = mpmath.mpf(0), a
        for N in points:
            while j <= N:
                s += fl(j)
                j += 1
            out.append((N, float(s)))
    return out
