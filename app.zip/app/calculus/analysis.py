"""Function analysis: domain, intercepts, critical points, extrema, monotonicity,
inflection points, concavity, asymptotes (and parity).

Equations and sign charts are solved with the one-variable solver of the
Equations tab (exact where possible, numerical estimates labelled), so periodic
functions get answers with + 2πk.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

import mpmath
import sympy as sp

from ..core.format import exact_and_decimal, set_latex, tex
from ..graphing.breaks import _denominators, _solve, expression_breaks
from ..solving import numeric
from ..solving.periodic import NotRepresentable, PeriodicSet, cmp, k_symbol, pieces
from ..solving.univariate import OneVariable, Result, is_real_number, safe, split_set
from .limits import compute_limit

MAX_LISTED = 8


@dataclass
class Analysis:
    lines: list = field(default_factory=list)       # (label, latex)
    notes: list = field(default_factory=list)
    exact: bool = True
    marks: list = field(default_factory=list)       # {"x", "y", "label"}
    families: list = field(default_factory=list)    # (PeriodicSet, label) of marked points
    vertical: list = field(default_factory=list)    # x values of vertical asymptotes
    vertical_families: list = field(default_factory=list)  # (start, period)
    slanted: list = field(default_factory=list)     # (k, b): y = kx + b (k = 0: horizontal)
    d1: object = None
    d2: object = None


def _num(v, places=4) -> str:
    """exact ≈ decimal for a value shown inside a sentence."""
    v = sp.sympify(v)
    if v.has(sp.Float) or v.has(sp.CRootOf):
        return r"\approx " + exact_and_decimal(sp.Float(sp.N(v, 15), places + 1), places)["latex"]
    return exact_and_decimal(v, places)["latex"]


def _value_at(f, x, c):
    v = safe(lambda: sp.simplify(f.subs(x, c)))
    if v is None or not is_real_number(v):
        n = safe(sp.N, f.subs(x, c), 30)
        return n if n is not None and is_real_number(n) else None
    return v


def _set_text(sol, xs: str, k, empty: str = r"\text{none}") -> str:
    if isinstance(sol, PeriodicSet):
        if sol.is_empty:
            return empty
        return sol.latex_set(xs, k) if not sol.points_only else sol.latex_equation(xs, k)
    if sol == sp.S.EmptySet:
        return empty
    shown = sol.replace(lambda e: isinstance(e, (sp.Float, sp.CRootOf)),
                        lambda e: sp.Float(sp.N(e, 15), 5)) if isinstance(sol, sp.Basic) else sol
    return f"{xs} \\in " + set_latex(shown)


def _points_of(sol, window=(-100, 100)):
    """Finite points of a solution set (periodic ones listed in a window)."""
    if isinstance(sol, PeriodicSet):
        try:
            return [p for k, p in pieces(sol.enumerate_in(sp.Interval(*window))) if k == "pt"]
        except NotRepresentable:
            return []
    if not isinstance(sol, sp.Set):
        return []
    pts, _, ok = split_set(sol)
    return pts if ok else []


def _sign(g, x, t) -> int | None:
    v = numeric.precise(g, x)(t)
    if v is None:
        return None
    if abs(v) < mpmath.mpf(10) ** -25:
        return 0
    return 1 if v > 0 else -1


def _side_signs(g, x, c, gap: float):
    cf = float(sp.N(c, 30))
    d = min(1e-3 * max(1.0, abs(cf)), gap / 4)
    return _sign(g, x, mpmath.mpf(cf) - d), _sign(g, x, mpmath.mpf(cf) + d)


def _gaps(points):
    fs = sorted(float(sp.N(p)) for p in points)
    out = {}
    for i, v in enumerate(fs):
        left = v - fs[i - 1] if i > 0 else 1.0
        right = fs[i + 1] - v if i + 1 < len(fs) else 1.0
        out[v] = max(min(left, right, 1.0), 1e-9)
    return out


def _undefined_points(g, f, x, conditions, window):
    """Points in f's domain where g (a derivative of f) is undefined: |x| at 0, x^(2/3) at 0."""
    cands = set()
    for den in _denominators(g):
        s = _solve(den, x)
        if s is not None and isinstance(s, sp.FiniteSet):
            cands |= set(s)
    for sg in g.atoms(sp.sign):
        s = _solve(sg.args[0], x)
        if s is not None and isinstance(s, sp.FiniteSet):
            cands |= set(s)
    out = []
    for p in cands:
        if not is_real_number(p) or not (window[0] <= float(sp.N(p)) <= window[1]):
            continue
        prob = OneVariable(f, "=", f, x, conditions)
        ok, _ = prob.defined_at(p)
        if not ok:
            continue
        gv = safe(lambda p=p: g.subs(x, p))
        if gv is None or gv.has(sp.nan, sp.zoo, sp.oo, -sp.oo) or not is_real_number(gv) or g.has(sp.sign):
            out.append(p)
    return out


def analyze(f, x, conditions, name: str = "f", places: int = 4, progress=None) -> Analysis:
    an = Analysis()
    f = sp.sympify(f)
    xs = tex(x)
    used = {s.name for s in f.free_symbols}
    k = k_symbol(used)

    def step(label, latex):
        an.lines.append((label, latex))
        if progress:
            progress(an)

    base = OneVariable(f, "=", sp.Integer(0), x, conditions)
    periodic = base.period is not None

    # --- domain ---
    dom = safe(base.domain)
    if isinstance(dom, PeriodicSet):
        if dom.is_everything:
            step("Domain", f"{xs} \\in \\mathbb{{R}}")
        else:
            gaps = dom.complement_within(PeriodicSet(dom.period, sp.Interval.Ropen(0, dom.period)))
            if gaps.points_only:
                step("Domain", gaps.latex_equation(xs, k).replace(f"{xs} =", f"{xs} \\ne", 1)
                     .replace(r"\;\text{or}\;", r",\;").replace(f"{xs} \\ne", f"{xs} \\ne", 1))
            else:
                step("Domain", dom.latex_set(xs, k))
    elif isinstance(dom, sp.Set):
        step("Domain", f"{xs} \\in " + set_latex(dom))
    else:
        an.notes.append("The domain could not be worked out exactly.")
    unbounded_right = dom is None or isinstance(dom, PeriodicSet) or (isinstance(dom, sp.Set) and dom.sup == sp.oo)
    unbounded_left = dom is None or isinstance(dom, PeriodicSet) or (isinstance(dom, sp.Set) and dom.inf == -sp.oo)

    # --- parity and period ---
    parity = None
    symmetric = isinstance(dom, sp.Set) and safe(lambda: sp.simplify(
        sp.Complement(dom, sp.imageset(sp.Lambda(x, -x), dom)))) == sp.S.EmptySet
    if symmetric or isinstance(dom, PeriodicSet) or dom is None:
        fm = f.subs(x, -x)
        if safe(lambda: sp.simplify(fm - f)) == 0:
            parity = "even (the graph is symmetric about the y-axis)"
        elif safe(lambda: sp.simplify(fm + f)) == 0:
            parity = "odd (the graph is symmetric about the origin)"
    text = parity or "neither even nor odd"
    if periodic:
        P = safe(sp.periodicity, f, x) or base.period
        text += f"; periodic with period ${tex(P)}$"
    step("Symmetry", r"\text{" + text.split("$")[0] + "}" + (tex(P) if periodic else ""))

    # --- intercepts ---
    ok0, _ = base.defined_at(sp.Integer(0))
    if ok0:
        y0 = _value_at(f, x, sp.Integer(0))
        if y0 is not None:
            step("y-intercept", f"{name}\\left(0\\right) = {_num(y0, places)}")
            an.marks.append({"x": sp.Integer(0), "y": y0, "label": "y-intercept"})
    else:
        step("y-intercept", r"\text{none (0 is not in the domain)}")
    zeros = base.solve()
    an.exact &= zeros.exact
    step("Zeros", _set_text(zeros.solution, xs, k, r"\text{none}"))
    for p in _points_of(zeros.solution, (-50, 50))[:40]:
        an.marks.append({"x": p, "y": sp.Integer(0), "label": "zero"})
    if zeros.searched:
        an.notes.append(f"The zeros were found numerically in ${zeros.searched[0]:g} \\le {xs} \\le "
                        f"{zeros.searched[1]:g}$.")

    # --- first derivative ---
    d1 = nicest(clean_derivative(sp.diff(f, x)))
    an.d1 = d1
    step(f"{name}′(x)", f"{name}'\\left({xs}\\right) = {tex(d1)}")
    inc, dec, crit_res = OneVariable(d1, "=", sp.Integer(0), x, conditions).signs()
    an.exact &= crit_res.exact and inc.exact and dec.exact
    window = (-100, 100)
    stationary = _points_of(crit_res.solution, (-30, 30) if periodic else window)
    corners = _undefined_points(d1, f, x, conditions, window)
    crit = sorted(set(stationary) | set(corners), key=lambda p: float(sp.N(p)))
    if isinstance(crit_res.solution, PeriodicSet) and not crit_res.solution.is_empty:
        crit_text = crit_res.solution.latex_equation(xs, k)
    elif crit:
        crit_text = f"{xs} \\in " + set_latex(sp.FiniteSet(*[sp.Float(sp.N(c, 15), places + 1)
                                                          if c.has(sp.Float) else c for c in crit]))
    else:
        crit_text = r"\text{none}"
    step("Critical points", crit_text)
    if corners:
        an.notes.append("Critical points where the derivative does not exist: " +
                        ", ".join(f"${xs} = {tex(c)}$" for c in corners) + ".")

    step("Increasing on", _set_text(inc.solution, xs, k, r"\text{nowhere}"))
    step("Decreasing on", _set_text(dec.solution, xs, k, r"\text{nowhere}"))

    # --- extrema ---
    maxima, minima = [], []
    gaps = _gaps(crit)
    for c in crit:
        exact_kind = None
        if c not in corners and not c.has(sp.Float):
            d2c = _value_at(clean_derivative(sp.diff(d1, x)), x, c)
            if d2c is not None and d2c.is_number and d2c != 0:
                exact_kind = "max" if d2c < 0 else "min"
        if exact_kind is None:
            left, right = _side_signs(d1, x, c, gaps.get(float(sp.N(c)), 1.0))
            if left is None or right is None:
                continue
            if left > 0 and right < 0:
                exact_kind = "max"
            elif left < 0 and right > 0:
                exact_kind = "min"
        if exact_kind is None:
            continue
        val = _value_at(f, x, c)
        if val is None:
            continue
        (maxima if exact_kind == "max" else minima).append((c, val))
    crit_periodic = isinstance(crit_res.solution, PeriodicSet) and not crit_res.solution.is_empty
    if crit_periodic and not periodic:
        # f' is periodic but f is not (x - 2 sin x): the extrema repeat with a value depending on k.
        for label, kind in (("Local maximum", "max"), ("Local minimum", "min")):
            fams = _shifted_families(f, x, crit_res.solution, d1, kind, k)
            if not fams:
                step(label, r"\text{none}")
            for fam, val in fams:
                step(label, f"{fam.latex_equation(xs, k)},\\quad {name} = {tex(val)}")
                an.families.append((fam, kind, val))
    for label, items, mark in (("Local maximum", maxima, "max"), ("Local minimum", minima, "min")):
        if crit_periodic and not periodic:
            continue
        if periodic and isinstance(crit_res.solution, PeriodicSet):
            fams = _periodic_extrema(items, base.period)
            for fam, val in fams:
                step(label, f"{fam.latex_equation(xs, k)},\\quad {name} = {_num(val, places)}")
                an.families.append((fam, mark, val))
            if not fams:
                step(label, r"\text{none}")
            continue
        if not items:
            step(label, r"\text{none}")
        for c, val in items[:MAX_LISTED]:
            step(label, f"{name}\\left({tex(c) if not c.has(sp.Float) else _num(c, places)}\\right) = "
                        f"{_num(val, places)}")
            an.marks.append({"x": c, "y": val, "label": f"local {mark}"})
        if len(items) > MAX_LISTED:
            an.notes.append(f"Only the first {MAX_LISTED} local {mark}ima are listed.")

    # --- second derivative ---
    d2 = nicest(clean_derivative(sp.diff(d1, x)))
    an.d2 = d2
    step(f"{name}″(x)", f"{name}''\\left({xs}\\right) = {tex(d2)}")
    up, down, z2 = OneVariable(d2, "=", sp.Integer(0), x, conditions).signs()
    an.exact &= up.exact and down.exact and z2.exact
    step("Concave up on", _set_text(up.solution, xs, k, r"\text{nowhere}"))
    step("Concave down on", _set_text(down.solution, xs, k, r"\text{nowhere}"))
    cands = _points_of(z2.solution, (-30, 30) if periodic else window) + \
        _undefined_points(d2, f, x, conditions, window)
    cands = sorted(set(cands), key=lambda p: float(sp.N(p)))
    infl = []
    g2 = _gaps(cands)
    for c in cands:
        left, right = _side_signs(d2, x, c, g2.get(float(sp.N(c)), 1.0))
        if left is None or right is None or left == 0 or right == 0 or left == right:
            continue
        val = _value_at(f, x, c)
        if val is not None:
            infl.append((c, val))
    if not periodic and isinstance(z2.solution, PeriodicSet) and not z2.solution.is_empty:
        fams = _shifted_families(f, x, z2.solution, d2, "inflection", k)
        for fam, val in fams:
            step("Inflection points", f"{fam.latex_equation(xs, k)},\\quad {name} = {tex(val)}")
            an.families.append((fam, "inflection", val))
        if not fams:
            step("Inflection points", r"\text{none}")
    elif periodic and isinstance(z2.solution, PeriodicSet) and infl:
        fams = _periodic_extrema(infl, base.period)
        for fam, val in fams:
            step("Inflection points", f"{fam.latex_equation(xs, k)},\\quad {name} = {_num(val, places)}")
            an.families.append((fam, "inflection", val))
    elif infl:
        step("Inflection points", ", ".join(
            f"\\left({tex(c) if not c.has(sp.Float) else _num(c, places)}, {_num(v, places)}\\right)"
            for c, v in infl[:MAX_LISTED]))
        for c, v in infl:
            an.marks.append({"x": c, "y": v, "label": "inflection"})
    else:
        step("Inflection points", r"\text{none}")

    # --- asymptotes ---
    _asymptotes(an, f, x, conditions, dom, periodic, unbounded_left, unbounded_right, step, xs)
    if not an.exact:
        an.notes.append("Values shown with ≈ were found numerically: they are numerical estimates.")
    return an


def clean_derivative(e):
    """d/dx sign(x) = 2δ(x): away from the single point it is 0."""
    return sp.sympify(e).replace(lambda t: isinstance(t, (sp.DiracDelta,)), lambda t: sp.Integer(0))


def nicest(e):
    """The shortest of simplify / cancel / factor (by the length of the LaTeX)."""
    cands = [e]
    for fn in (sp.simplify, sp.cancel, sp.factor):
        c = safe(fn, e)
        if c is not None:
            cands.append(c)
    return min(cands, key=lambda c: (sp.count_ops(c), len(tex(c)), cands.index(c)))


def _shifted_families(f, x, zeros: PeriodicSet, g, kind: str, k):
    """Extrema ("max"/"min", g = f') or inflection points (g = f'') of a non-periodic f at a periodic
    set r + Pk of zeros of g. The value f(r + Pk) depends on k, so each residue is its own family."""
    out = []
    P = zeros.period
    reps = []
    for kd, r in pieces(zeros.base):
        if kd == "pt":
            reps.append(r - P if cmp(r, P / 2) > 0 else r)   # the representative the family is shown with
    reps.sort(key=lambda v: float(sp.N(v)))
    for r in reps:
        gap = min([abs(float(sp.N(r - o))) for o in reps if o != r] + [float(sp.N(P))])
        left, right = _side_signs(g, x, r, gap)
        if left is None or right is None or left == 0 or right == 0:
            continue
        this = ("inflection" if left != right else None) if kind == "inflection" else \
            "max" if (left > 0 and right < 0) else "min" if (left < 0 and right > 0) else None
        if this != kind:
            continue
        val = safe(lambda r=r: sp.expand(sp.simplify(f.subs(x, r + P * k))))
        if val is None:
            continue
        out.append((PeriodicSet.from_residues([r], P), val))
    if kind == "inflection" and len(out) > 1:
        # f'' changes sign at every zero (x - 2 sin x: πk): one family with the step of the zeros.
        fam = PeriodicSet.from_residues([r for r in reps], P)
        if len(out) == len(reps) and fam.period != P:
            r0 = fam.families()[0][0][0]
            val = safe(lambda: sp.expand(sp.simplify(f.subs(x, r0 + fam.period * k))))
            if val is not None:
                return [(fam, val)]
    return out


def _periodic_extrema(items, period):
    """Group (residue, value) pairs into families with the same value."""
    groups: dict = {}
    for c, val in items:
        key = sp.nsimplify(val) if val.has(sp.Float) else val
        groups.setdefault(key, []).append(c)
    out = []
    for val, cs in groups.items():
        fam = PeriodicSet.from_residues(cs, period)
        out.append((fam, val))
    return out


def _asymptotes(an: Analysis, f, x, conditions, dom, periodic, left_open, right_open, step, xs):
    lo, hi = -100.0, 100.0
    br = expression_breaks(f, x, conditions, sp.Interval(lo, hi))
    cands = set(p for p in br.points if is_real_number(p))
    if isinstance(dom, sp.Set):
        try:
            for kind, v in pieces(dom):
                if kind == "iv":
                    cands |= {e for e in (v.start, v.end) if e.is_finite}
        except NotRepresentable:
            pass
    vert = []
    for p in sorted(cands, key=lambda p: float(sp.N(p))):
        if _infinite_beside(f, x, p):
            vert.append(p)
    fams = [(start, per) for start, per in br.periodic if _infinite_beside(f, x, start)]
    if fams:
        merged = None
        for start, per in fams:
            ps = PeriodicSet.from_residues([start], per)
            merged = ps if merged is None else merged.union(ps)
        step("Vertical asymptotes", merged.latex_equation(xs, k_symbol({s.name for s in f.free_symbols})))
        for kind, v in pieces(merged.base):
            an.vertical_families.append((v, merged.period))
    elif vert:
        step("Vertical asymptotes", ", ".join(f"{xs} = {tex(p)}" for p in vert))
        an.vertical = vert
    else:
        step("Vertical asymptotes", r"\text{none}")
    if periodic:
        return
    found = []
    for side, open_ in ((sp.oo, right_open), (-sp.oo, left_open)):
        if not open_:
            continue
        line = _slant(f, x, side)
        if line is not None:
            found.append((line, side))
    if not found:
        step("Horizontal / oblique asymptotes", r"\text{none}")
        return
    merged = {}
    for (kk, bb), side in found:
        merged.setdefault((kk, bb), []).append(side)
    for (kk, bb), sides in merged.items():
        where = r"x \to \pm\infty" if len(sides) == 2 else (r"x \to +\infty" if sides[0] == sp.oo else r"x \to -\infty")
        label = "Horizontal asymptote" if kk == 0 else "Oblique asymptote"
        yline = tex(bb) if kk == 0 else tex(kk * sp.Symbol(xs) + bb)
        step(label, f"y = {yline} \\quad \\left(\\text{{as }} {where}\\right)")
        an.slanted.append((kk, bb))


def _infinite_beside(f, x, p) -> bool:
    for s in ("-", "+"):
        try:
            r = compute_limit(f, x, p, s)
        except ValueError:
            continue
        if r.exists and r.value in (sp.oo, -sp.oo):
            return True
    return False


def _slant(f, x, side):
    try:
        L = compute_limit(f, x, side, "-" if side == sp.oo else "+")
    except ValueError:
        return None
    if not L.exists or L.value is None:
        return None
    if L.value not in (sp.oo, -sp.oo):
        return (sp.Integer(0), L.value) if L.exact else None
    try:
        K = compute_limit(f / x, x, side, "-" if side == sp.oo else "+")
    except ValueError:
        return None
    if not K.exists or K.value in (None, sp.oo, -sp.oo, 0) or not K.exact:
        return None
    try:
        B = compute_limit(f - K.value * x, x, side, "-" if side == sp.oo else "+")
    except ValueError:
        return None
    if not B.exists or B.value in (None, sp.oo, -sp.oo) or not B.exact:
        return None
    return (K.value, B.value)


def is_finite_number(v) -> bool:
    try:
        return math.isfinite(float(sp.N(v)))
    except (TypeError, ValueError):
        return False


__all__ = ["analyze", "Analysis", "Result"]
