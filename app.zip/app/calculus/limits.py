"""Limits, with one-sided limits, limits at ±∞, and "does not exist".

SymPy computes limits in the complex numbers, so lim_{x→0} √x comes out as 0
even though √x is undefined left of 0. Before asking SymPy, each side of the
point is checked numerically: a side where the function is not real is left
out (and said so). Two-sided limits are computed as both one-sided limits.
A numerical check confirms the exact answer; if SymPy can't find the limit, a
numerical estimate is given and labelled as such.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

import mpmath
import sympy as sp

from ..core.format import tex
from ..solving import numeric
from ..solving.univariate import safe

AccumBounds = sp.AccumBounds


@dataclass
class LimitResult:
    value: object = None            # exact value, sp.oo / -sp.oo, or None when it doesn't exist
    exists: bool = True
    left: object = None             # one-sided values when they differ
    right: object = None
    oscillates: tuple | None = None  # (lo, hi) for AccumBounds
    exact: bool = True
    notes: list[str] = field(default_factory=list)
    side_only: str | None = None    # "+" / "-" when only one side is in the domain


def _clean(v):
    """SymPy's answer as a real value, ±∞, an oscillation, or None (unknown)."""
    if v is None or isinstance(v, sp.Limit) or (isinstance(v, sp.Basic) and v.has(sp.Limit)):
        return None
    v = sp.sympify(v)
    if v is sp.zoo:
        return sp.zoo
    if v is sp.nan:
        return None
    if isinstance(v, AccumBounds):
        return v
    if v in (sp.oo, -sp.oo):
        return v
    if v.is_number:
        if v.is_real is False:
            return None
        return v
    return None


def _defined_near(f_precise, a: float, side: int) -> bool:
    """Is the function real at points just beside a on one side?"""
    ok = 0
    for k in (3, 5, 7):
        h = 10.0 ** (-k) * max(1.0, abs(a))
        if f_precise(mpmath.mpf(a) + side * mpmath.mpf(h)) is not None:
            ok += 1
    return ok >= 2


def _approach(f_precise, point, side: int):
    """Values of f approaching the point (or ±∞), as floats; None where undefined."""
    vals = []
    for k in range(2, 11):
        if point == sp.oo:
            t = mpmath.mpf(10) ** k
        elif point == -sp.oo:
            t = -mpmath.mpf(10) ** k
        else:
            a = mpmath.mpf(sp.N(point, 40))
            t = a + side * mpmath.mpf(10) ** (-k) * max(1, abs(a))
        v = f_precise(t)
        vals.append(None if v is None else float(v) if abs(v) < 1e300 else math.copysign(1e300, float(v)))
    return vals


def _numeric_limit(vals):
    """A limit guessed from approaching values: (value or ±inf, converged?)."""
    v = [x for x in vals if x is not None]
    if len(v) < 4:
        return None, False
    tail = v[-4:]
    if all(abs(t) >= 1e300 for t in tail[-2:]) and tail[-1] * tail[-2] > 0:  # clamped: beyond 1e300
        return math.copysign(math.inf, tail[-1]), True
    if all(abs(t) > 1e6 for t in tail[-2:]) and abs(tail[-1]) > abs(tail[-2]) > abs(tail[-3]):
        if all(t > 0 for t in tail):
            return math.inf, True
        if all(t < 0 for t in tail):
            return -math.inf, True
        return None, False
    d1, d2 = abs(tail[-1] - tail[-2]), abs(tail[-2] - tail[-3])
    scale = max(1.0, abs(tail[-1]))
    if d1 <= 1e-6 * scale and d1 <= d2 + 1e-15:
        return tail[-1], True
    return None, False


def _agrees(exact_value, vals) -> bool | None:
    """Do the numerical values approach the exact value? None if inconclusive."""
    guess, converged = _numeric_limit(vals)
    if not converged:
        return None
    if exact_value in (sp.oo, -sp.oo):
        return guess == (math.inf if exact_value == sp.oo else -math.inf)
    if math.isinf(guess):
        return False
    ev = float(sp.N(exact_value, 20))
    return abs(ev - guess) <= 1e-4 * max(1.0, abs(ev))


def one_sided(expr, x, point, side: str):
    """SymPy's one-sided limit, cleaned (None if it failed)."""
    return _clean(safe(sp.limit, expr, x, point, side))


def compute_limit(expr, x, point, direction: str) -> LimitResult:
    """direction: "+", "-" or "+-" (two-sided). point may be ±∞."""
    expr = sp.sympify(expr)
    res = LimitResult()
    fp = numeric.precise(expr, x)
    if x not in expr.free_symbols:
        res.value = expr
        return res
    infinite = point in (sp.oo, -sp.oo)
    sides = ["+", "-"] if (direction == "+-" and not infinite) else [direction]
    if not infinite:
        a = float(sp.N(point, 20))
        defined = {s: _defined_near(fp, a, 1 if s == "+" else -1) for s in ("+", "-")}
        if direction == "+-":
            usable = [s for s in sides if defined[s]]
            if not usable:
                raise ValueError(f"The function is not defined (as a real number) near ${tex(point)}$, "
                                 "so the limit doesn't exist.")
            if len(usable) == 1:
                res.side_only = usable[0]
                where = "right" if usable[0] == "+" else "left"
                res.notes.append(f"The function is only defined to the {where} of ${tex(x)} = {tex(point)}$, "
                                 f"so this is the one-sided limit from the {where}.")
                sides = usable
        elif not defined[direction]:
            where = "right" if direction == "+" else "left"
            raise ValueError(f"The function is not defined (as a real number) just to the {where} of "
                             f"${tex(point)}$, so this one-sided limit doesn't exist.")
    found = {}
    for s in sides:
        found[s] = one_sided(expr, x, point, "-" if point == sp.oo else "+" if point == -sp.oo else s)
    vals = {s: _approach(fp, point, 1 if s == "+" else -1) for s in sides}

    # Oscillation (sin(1/x) at 0): AccumBounds.
    for s, v in found.items():
        if isinstance(v, AccumBounds):
            res.exists = False
            res.oscillates = (v.min, v.max)
            return res
    if any(v is None for v in found.values()):
        return _numeric_fallback(res, vals, sides)
    if any(v is sp.zoo for v in found.values()):
        res.exists = False
        return res
    values = [found[s] for s in sides]
    if len(values) == 2 and sp.simplify(values[0] - values[1]) != 0 \
            and not (values[0] == values[1]):
        res.exists = False
        res.right, res.left = found["+"], found["-"]
        return res
    res.value = values[0]
    for s in sides:
        ok = _agrees(res.value, vals[s])
        if ok is False:
            res.exact = False
            g, _ = _numeric_limit(vals[s])
            res.notes.append(f"Warning: a numerical check gives about {g:.6g}; the exact result may be wrong.")
    return res


def _numeric_fallback(res: LimitResult, vals: dict, sides) -> LimitResult:
    res.exact = False
    guesses = {}
    for s in sides:
        g, ok = _numeric_limit(vals[s])
        if not ok:
            raise ValueError("The limit could not be found, exactly or numerically.")
        guesses[s] = g
    gs = list(guesses.values())
    if len(gs) == 2 and not (gs[0] == gs[1] or (not math.isinf(gs[0]) and not math.isinf(gs[1])
                                                 and abs(gs[0] - gs[1]) <= 1e-5 * max(1, abs(gs[0])))):
        res.exists = False
        res.right = _as_value(guesses["+"])
        res.left = _as_value(guesses["-"])
        return res
    res.value = _as_value(gs[0])
    if res.value not in (sp.oo, -sp.oo):
        named = numeric.recognize(sp.Float(gs[0], 15)) if abs(gs[0]) < 1e12 else []
        if named and abs(float(sp.N(named[0])) - gs[0]) < 1e-6 * max(1, abs(gs[0])):
            res.notes.append(f"Found numerically; it looks like ${tex(named[0])}$, but that isn't proven.")
            return res
    res.notes.append("Found numerically (no exact method worked).")
    return res


def _as_value(g: float):
    if math.isinf(g):
        return sp.oo if g > 0 else -sp.oo
    return sp.Float(g, 15)
