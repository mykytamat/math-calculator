"""Integrals: indefinite (checked by differentiating), definite and improper.

* Indefinite: SymPy's antiderivative, with ln(u) written as ln|u| where the
  integrand is also defined for u < 0 (∫ 1/x dx = ln|x| + C), checked by
  differentiating the answer.
* Definite: the interval is split at points inside it where the integrand is
  unbounded, so ∫_{-1}^{1} 1/x² dx is reported as divergent rather than as a
  number. Every finite answer is compared with a numerical integration.
"""
from __future__ import annotations

import math
import random
from dataclasses import dataclass, field

import mpmath
import sympy as sp

from ..core.format import tex
from ..graphing.breaks import expression_breaks
from ..solving import numeric
from ..solving.univariate import domain_set, is_real_number, safe
from .limits import compute_limit

SPECIAL = {sp.erf: "erf", sp.erfi: "erfi", sp.erfc: "erfc", sp.Si: "Si", sp.Ci: "Ci", sp.Ei: "Ei",
           sp.li: "li", sp.gamma: "Γ", sp.uppergamma: "Γ", sp.lowergamma: "γ", sp.fresnels: "S",
           sp.fresnelc: "C", sp.LambertW: "W", sp.polylog: "Li", sp.Shi: "Shi", sp.Chi: "Chi",
           sp.expint: "E", sp.hyper: "hypergeometric", sp.meijerg: "Meijer G"}


@dataclass
class IntegralResult:
    value: object = None                   # antiderivative (indefinite) or number / ±∞ (definite)
    converges: bool = True
    exact: bool = True
    checked: bool = False
    improper: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    special: list[str] = field(default_factory=list)
    split: list = field(default_factory=list)   # points where the interval was split


# ------------------------------------------------------------ indefinite ----
def _sample_points(f, x, n=8):
    fs = numeric.scalar(f, x)
    rnd = random.Random(7)
    pts = []
    for _ in range(400):
        t = rnd.uniform(-9, 9)
        y = fs(t)
        if not math.isnan(y):
            pts.append(t)
        if len(pts) >= n:
            break
    return pts


def _same_function(a, b, x, where) -> bool:
    d = safe(lambda: sp.simplify(a - b))
    if d == 0:
        return True
    fa, fb = numeric.scalar(a, x), numeric.scalar(b, x)
    good = 0
    for t in where:
        va, vb = fa(t), fb(t)
        if math.isnan(va) or math.isnan(vb):
            continue
        if abs(va - vb) > 1e-7 * max(1.0, abs(va)):
            return False
        good += 1
    return good >= 3


def _abs_logs(F, f, x):
    """ln(u) -> ln|u| where the integrand is also defined for u < 0."""
    logs = [L for L in F.atoms(sp.log) if not L.args[0].is_positive and x in L.args[0].free_symbols]
    if not logs:
        return F
    pts = _sample_points(f, x, 40)
    changed = F
    for L in logs:
        u = numeric.scalar(L.args[0], x)
        if any((not math.isnan(u(t))) and u(t) < 0 for t in pts):
            changed = changed.xreplace({L: sp.log(sp.Abs(L.args[0]))})
    return changed


def indefinite(f, x) -> IntegralResult:
    res = IntegralResult()
    F = safe(sp.integrate, f, x)
    if F is None or F.has(sp.Integral):
        res.value = None
        res.notes.append("No antiderivative in terms of elementary functions was found.")
        return res
    F = safe(sp.simplify, F) if sp.count_ops(F) > 40 else F
    F2 = _abs_logs(F, f, x)
    pts = _sample_points(f, x)
    if F2 is not F and _same_function(sp.diff(F2, x), f, x, pts):
        F = F2
    res.value = F
    res.checked = _same_function(sp.diff(F, x), f, x, pts)
    if not res.checked:
        res.exact = False
        res.notes.append("Warning: differentiating the answer did not give the integrand back at every "
                         "test point; check it.")
    for fn, name in SPECIAL.items():
        if F.has(fn):
            res.special.append(name)
    return res


# -------------------------------------------------------------- definite ----
def _unbounded_at(f, x, p) -> bool:
    for side in ("-", "+"):
        try:
            r = compute_limit(f, x, p, side)
        except ValueError:
            continue
        if not r.exists or r.value in (sp.oo, -sp.oo):
            return True
    return False


def _quad(f, x, pts):
    fm = numeric.precise(f, x)

    def g(t):
        v = fm(t)
        return v if v is not None else mpmath.mpf(0)
    pts = [mpmath.inf if p == sp.oo else -mpmath.inf if p == -sp.oo else mpmath.mpf(sp.N(p, 30)) for p in pts]
    with mpmath.workdps(25):
        try:
            v, err = mpmath.quad(g, pts, error=True, maxdegree=8)
        except Exception:
            return None, None
    return float(v), float(err)


def definite(f, x, a, b, conditions) -> IntegralResult:
    res = IntegralResult()
    sign = 1
    if a in (sp.oo,) or b in (-sp.oo,) or (a.is_number and b.is_number and a not in (-sp.oo, sp.oo)
                                           and b not in (-sp.oo, sp.oo) and bool(a > b)):
        a, b, sign = b, a, -1
        res.notes.append("The bounds are in reverse order, so the result is minus the integral from the "
                         "smaller to the larger bound.")
    if a == b:
        res.value = sp.Integer(0)
        return res
    lo = -50.0 if a == -sp.oo else float(sp.N(a))
    hi = 50.0 if b == sp.oo else float(sp.N(b))
    # The integrand must be defined on the whole interval (except at single points).
    D = domain_set(conditions, x, sp.Interval(a, b))
    if D is not None:
        missing = sp.Complement(sp.Interval(a, b), D)
        if missing != sp.S.EmptySet and not isinstance(missing, sp.FiniteSet):
            raise ValueError(f"The integrand is not defined for ${tex(x)} \\in {_set(missing)}$, which is part of "
                             "the interval, so this integral doesn't exist (in the real numbers).")
    # Points where the integrand is unbounded split the interval.
    br = expression_breaks(f, x, conditions, sp.Interval(lo, hi))
    cands = set(br.points)
    for start, per in br.periodic:
        k0 = math.floor((lo - float(start)) / float(per)) - 1
        k1 = math.ceil((hi - float(start)) / float(per)) + 1
        if k1 - k0 < 200:
            cands |= {start + k * per for k in range(k0, k1 + 1)}
    inner = sorted([p for p in cands if is_real_number(p) and float(sp.N(p)) > float(sp.N(a)) + 0
                    and float(sp.N(p)) < float(sp.N(b))], key=lambda p: float(sp.N(p)))
    inner = [p for p in inner if _unbounded_at(f, x, p)]
    for end, name in ((a, "lower"), (b, "upper")):
        if end in (sp.oo, -sp.oo):
            res.improper.append(f"the {name} bound is infinite")
        elif _unbounded_at(f, x, end):
            res.improper.append(f"the integrand is unbounded at ${tex(x)} = {tex(end)}$")
    for p in inner:
        res.improper.append(f"the integrand is unbounded at ${tex(x)} = {tex(p)}$, inside the interval")
    res.split = inner
    edges = [a] + inner + [b]
    pieces = []
    for u, v in zip(edges, edges[1:]):
        val = safe(sp.integrate, f, (x, u, v))
        if val is not None and not val.has(sp.Integral):
            val = safe(sp.simplify, val) if sp.count_ops(val) > 30 else val
        pieces.append(val)
    total = sp.Integer(0)
    numeric_only = False
    for (u, v), val in zip(zip(edges, edges[1:]), pieces):
        if val is None or val.has(sp.Integral) or val.has(sp.nan):
            q, err = _quad(f, x, [u, v])
            if q is None or (err is not None and err > 1e-6 * max(1, abs(q))) or not math.isfinite(q):
                raise ValueError("This integral could not be computed exactly, and the numerical integration "
                                 "did not settle (it may diverge).")
            val = sp.Float(q, 15)
            numeric_only = True
        if val is sp.zoo or val in (sp.oo, -sp.oo):
            res.converges = False
            # The direction (+∞ / −∞) is only stated when the interval wasn't split.
            res.value = val if (val in (sp.oo, -sp.oo) and not inner) else None
            if res.value is not None:
                res.value = sign * res.value
            if inner:
                res.notes.append("A Cauchy principal value may exist, but the integral itself diverges.")
            return res
        total += val
    total = sign * total
    res.value = safe(sp.nsimplify, total) if total.has(sp.Float) and numeric_only is False else total
    if numeric_only:
        res.exact = False
        named = numeric.recognize(sp.Float(float(total), 15)) if abs(float(total)) < 1e12 else []
        res.notes.append("Computed numerically (no exact antiderivative was found)" +
                         (f"; it looks like ${tex(named[0])}$, but that isn't proven." if named else "."))
        return res
    # Numerical check of the exact value (split at kinks of |u| too, for accuracy).
    kinks = []
    for ab in f.atoms(sp.Abs):
        for r in (safe(sp.solve, ab.args[0], x) or []):
            if is_real_number(r) and float(sp.N(a)) < float(sp.N(r)) < float(sp.N(b)):
                kinks.append(r)
    q, err = _quad(f, x, sorted(set(edges) | set(kinks), key=lambda p: float(sp.N(p))))
    if q is not None and math.isfinite(q) and err is not None and err < 1e-6 * max(1, abs(q)):
        ev = float(sp.N(sign * sum(pieces), 20))
        if abs(ev - sign * q) <= 1e-7 * max(1.0, abs(ev)):
            res.checked = True
        else:
            res.exact = False
            res.notes.append(f"Warning: numerical integration gives ≈ {sign * q:.10g}; the exact result may "
                             "be wrong.")
    for fn, name in SPECIAL.items():
        if sp.sympify(res.value).has(fn):
            res.special.append(name)
    return res


def _set(s) -> str:
    from ..core.format import set_latex
    return set_latex(s)
