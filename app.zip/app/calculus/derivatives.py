"""Derivatives, and f'(a) with a check that f is differentiable at a.

SymPy differentiates |x| to sign(x), which is 0 at x = 0, so a naive f'(0)
would be 0. At a point, the derivative is therefore taken as the limit of
f'(x) from both sides (and f must be continuous there); different one-sided
values mean f is not differentiable there.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import sympy as sp

from ..core.domain import explain, first_violation, substitute
from ..core.format import tex
from ..solving.univariate import safe
from .limits import compute_limit


@dataclass
class PointDerivative:
    value: object = None           # exact value, or None if not differentiable
    left: object = None
    right: object = None
    reason: str | None = None
    exact: bool = True
    notes: list[str] = field(default_factory=list)


def forms(expr) -> list:
    """The derivative as SymPy gives it, then its simplest form if that differs."""
    out = [expr]
    cands = [c for c in (safe(fn, expr) for fn in (sp.simplify, sp.cancel, sp.factor)) if c is not None]
    if cands:
        best = min(cands, key=lambda c: (sp.count_ops(c), len(tex(c))))
        if sp.srepr(best) != sp.srepr(expr) and sp.count_ops(best) <= sp.count_ops(expr) + 2:
            out.append(best)
    return out


def derivative(expr, x, order: int = 1):
    return sp.diff(expr, (x, order))


def at_point(f, x, a, order: int, conditions) -> PointDerivative:
    """f^(order)(a), with differentiability checked."""
    res = PointDerivative()
    v = first_violation(substitute(conditions, {x: a}))
    if v is not None:
        res.reason = f"${tex(a)}$ is not in the domain of the function: " + explain(*v)
        return res
    fa = safe(lambda: sp.simplify(f.subs(x, a)))
    if fa is None or fa.has(sp.nan, sp.zoo, sp.oo, -sp.oo) or fa.is_real is False:
        res.reason = f"The function is not defined at ${tex(x)} = {tex(a)}$."
        return res
    g = f
    for n in range(1, order + 1):
        prev = g
        # d/dx sign(x) = 2δ(x) (from |x|, real cube roots): 0 away from the single point.
        g = sp.diff(prev, x).replace(lambda t: isinstance(t, sp.DiracDelta), lambda t: sp.Integer(0))
        # Each lower derivative must be continuous at a for the next one to exist.
        val_prev = fa if n == 1 else safe(lambda p=prev: sp.simplify(p.subs(x, a)))
        sides = {}
        for s in ("-", "+"):
            try:
                r = compute_limit(prev, x, a, s)
                sides[s] = r.value if r.exists else None
            except ValueError:
                sides[s] = "undefined"
        for s, lv in sides.items():
            if lv == "undefined":
                continue
            if lv is None or val_prev is None or lv in (sp.oo, -sp.oo) or \
                    safe(lambda lv=lv: sp.simplify(lv - val_prev)) != 0:
                what = "f" if n == 1 else "f" + "'" * (n - 1)
                res.reason = (f"${what}$ is not continuous at ${tex(x)} = {tex(a)}$, so it has no derivative "
                              "there.")
                return res
    D = g
    left = right = None
    ok_sides = []
    for s in ("-", "+"):
        try:
            r = compute_limit(D, x, a, s)
        except ValueError:
            continue
        ok_sides.append(s)
        if s == "-":
            left = r.value if r.exists else "dne"
        else:
            right = r.value if r.exists else "dne"
    if not ok_sides:
        res.reason = f"The derivative is not defined near ${tex(x)} = {tex(a)}$."
        return res
    vals = [v for v in (left, right) if v is not None]
    if any(v == "dne" for v in vals):
        res.reason = "The difference quotient has no limit there (the derivative does not exist)."
        return res
    if any(v in (sp.oo, -sp.oo) for v in vals):
        res.reason = (f"The tangent at ${tex(x)} = {tex(a)}$ is vertical (the derivative is infinite), so the "
                      "function is not differentiable there.")
        return res
    if len(vals) == 2 and safe(lambda: sp.simplify(vals[0] - vals[1])) != 0:
        res.left, res.right = left, right
        res.reason = (f"The function is not differentiable at ${tex(x)} = {tex(a)}$: the derivative from the left "
                      f"is ${tex(left)}$ and from the right ${tex(right)}$ (a corner).")
        return res
    res.value = safe(sp.simplify, vals[0]) or vals[0]
    if len(ok_sides) == 1:
        side = "right" if ok_sides[0] == "+" else "left"
        res.notes.append(f"This is the one-sided derivative from the {side} (the function is only defined on "
                         "that side).")
    return res
