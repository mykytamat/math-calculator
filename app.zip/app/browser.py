"""Entry points for the offline browser version (Pyodide in a Web Worker, see static/js/engine-worker.js).

The page talks to these instead of the server. Results go back as the same JSON the server
sends. Partial results go through the `mathcalc_js` module that the worker registers.
"""
from __future__ import annotations

import json
import traceback
import warnings

from . import tasks
from .modules import common
from .parsing import convert_input

# mpmath 1.4 warns about functions SymPy still calls; nothing for the user.
warnings.filterwarnings("ignore", category=DeprecationWarning)


def _dumps(obj) -> str:
    # As the server's JSONResponse does.
    return json.dumps(obj, ensure_ascii=False, allow_nan=False, separators=(",", ":"))


def _send_partial(resp: dict) -> None:
    import mathcalc_js
    mathcalc_js.partial(_dumps(resp))


def warm_up() -> None:
    tasks.warm_up()


def run(name: str, payload_json: str) -> str:
    """A tab's computation. An unexpected exception comes back as {"internal_error": ...}."""
    common.set_partial_sink(_send_partial)
    try:
        return _dumps(tasks.run(name, json.loads(payload_json)))
    except Exception as e:
        return _dumps({"internal_error": f"{type(e).__name__}: {e}", "traceback": traceback.format_exc()})


def convert(text: str, src: str) -> str:
    return _dumps(convert_input(text, src))
