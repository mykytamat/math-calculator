"""Names understood by both front ends: functions, constants, keywords."""
from __future__ import annotations

# canonical name -> (min args, max args). Aliases map onto these below.
FUNCTIONS: dict[str, tuple[int, int]] = {
    "sin": (1, 1), "cos": (1, 1), "tan": (1, 1), "cot": (1, 1),
    "sec": (1, 1), "csc": (1, 1),
    "asin": (1, 1), "acos": (1, 1), "atan": (1, 1), "acot": (1, 1),
    "sinh": (1, 1), "cosh": (1, 1), "tanh": (1, 1), "coth": (1, 1),
    "asinh": (1, 1), "acosh": (1, 1), "atanh": (1, 1),
    "exp": (1, 1), "ln": (1, 1), "lg": (1, 1), "log": (1, 2),
    "sqrt": (1, 1), "cbrt": (1, 1), "root": (2, 2),
    "abs": (1, 1), "sign": (1, 1), "floor": (1, 1), "ceil": (1, 1),
    "gcd": (2, 99), "lcm": (2, 99), "min": (1, 99), "max": (1, 99),
    "binom": (2, 2), "factorial": (1, 1),
    # Calculus operators (parsed specially, see Parser.parse_calculus_call).
    "lim": (2, 3), "int": (1, 4), "diff": (1, 3), "sum": (3, 4), "prod": (3, 4),
    # Linear algebra (the Matrices tab).
    "det": (1, 1), "inv": (1, 1), "rank": (1, 1), "trace": (1, 1), "transpose": (1, 1),
    "rref": (1, 1), "eigenvalues": (1, 1), "eigenvectors": (1, 1), "solve": (2, 2),
}

MATRIX_FUNCTIONS = {"det", "inv", "rank", "trace", "transpose", "rref", "eigenvalues", "eigenvectors", "solve"}

CALCULUS_OPERATORS = {"lim", "int", "diff", "sum", "prod"}

ALIASES: dict[str, str] = {
    "tg": "tan", "ctg": "cot", "cotg": "cot", "cosec": "csc",
    "arcsin": "asin", "arccos": "acos", "arctan": "atan", "arctg": "atan",
    "arccot": "acot", "arcctg": "acot",
    "arsinh": "asinh", "arcosh": "acosh", "artanh": "atanh",
    "arcsinh": "asinh", "arccosh": "acosh", "arctanh": "atanh",
    "sgn": "sign", "ceiling": "ceil", "nCr": "binom", "binomial": "binom",
    "limit": "lim", "integrate": "int", "integral": "int", "derivative": "diff",
    "tr": "trace", "inverse": "inv", "eig": "eigenvalues", "eigenvals": "eigenvalues",
    "eigenvects": "eigenvectors",
}

# Functions where `f^{-1}` means the inverse function rather than 1/f.
INVERSE_TRIG = {
    "sin": "asin", "cos": "acos", "tan": "atan", "cot": "acot",
    "sinh": "asinh", "cosh": "acosh", "tanh": "atanh",
}

CONSTANTS: dict[str, str] = {
    "pi": "pi", "e": "e", "inf": "inf", "infinity": "inf", "oo": "inf",
}

GREEK = [
    "alpha", "beta", "gamma", "delta", "epsilon", "varepsilon", "zeta", "eta",
    "theta", "vartheta", "iota", "kappa", "lambda", "mu", "nu", "xi", "rho",
    "sigma", "tau", "upsilon", "phi", "varphi", "chi", "psi", "omega",
]

KEYWORDS = {"if", "otherwise", "else", "and", "or", "in"}

# Single letters that act as function names when followed by "(" even if the
# input never defines them (so that f(2) reports "f is not defined" instead of
# silently meaning f*2).
DEFAULT_FUNCTION_LETTERS = {"f", "g", "h"}


def canonical_function(name: str) -> str | None:
    if name in FUNCTIONS:
        return name
    if name in ALIASES:
        return ALIASES[name]
    return None


# Programming-style inverse names are only recognised as a whole word
# ("asin(x)"), so that "asinx" still reads as a*sin(x).
_WHOLE_WORD_ONLY_FUNCTIONS = {"asin", "acos", "atan", "acot", "asinh", "acosh", "atanh",
                              "lim", "int", "diff", "sum", "prod", "limit", "integrate", "integral", "derivative",
                              "det", "inv", "rank", "trace", "transpose", "rref", "eigenvalues",
                              "eigenvectors", "solve", "tr", "inverse", "eig", "eigenvals", "eigenvects"}


def _whole_words(user_functions) -> set[str]:
    return (set(FUNCTIONS) | set(ALIASES) | set(CONSTANTS) | set(GREEK) | KEYWORDS
            | {"log2", "log10", "for", "when"} | set(user_functions))


def _inner_words(user_functions) -> list[str]:
    words = ((set(FUNCTIONS) | set(ALIASES)) - _WHOLE_WORD_ONLY_FUNCTIONS) | {"pi", "log2", "log10"}
    words |= set(user_functions)
    words = {w for w in words if len(w) > 1}
    return sorted(words, key=len, reverse=True)


def split_letters(run: str, user_functions: set[str] | frozenset[str] = frozenset()) -> list[str]:
    """Split a run of letters into known words and single letters.

    "xsinx" -> ["x", "sin", "x"], "ab" -> ["a", "b"], "pix" -> ["pi", "x"].
    A run that is exactly a known word (keyword, Greek letter, function...) is
    kept whole. Otherwise, at each position the longest function name or "pi"
    wins, else a single letter is taken.
    """
    if run in _whole_words(user_functions):
        return [run]
    words = _inner_words(user_functions)
    out: list[str] = []
    i = 0
    while i < len(run):
        for w in words:
            if run.startswith(w, i):
                out.append(w)
                i += len(w)
                break
        else:
            out.append(run[i])
            i += 1
    return out
