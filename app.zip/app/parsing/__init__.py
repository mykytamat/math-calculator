"""Input parsing: two front ends (plain text, LaTeX) producing one AST."""
from __future__ import annotations

from . import ast as A
from .errors import MathError, ParseError


def parse(text: str, mode: str) -> list[A.Node]:
    """Parse user input. `mode` is "latex" (visual editor) or "plain"."""
    if not text or not text.strip():
        raise ParseError("The input is empty.")
    try:
        if mode == "latex":
            from .latex import parse as parse_latex
            stmts = parse_latex(text)
        else:
            from .plaintext import parse as parse_plain
            stmts = parse_plain(text)
    except RecursionError:
        raise ParseError("The input is nested too deeply to read.") from None
    if not stmts:
        raise ParseError("The input is empty.")
    return stmts


def attach_source(err: ParseError, text: str) -> ParseError:
    if err.source is None:
        err.source = text
    return err


def convert_input(text: str, src: str) -> dict:
    """Convert input between the visual editor (LaTeX, src="latex") and plain text."""
    from .echo import program_to_latex, program_to_plain
    try:
        stmts = parse(text, "latex" if src == "latex" else "plain")
    except ParseError as e:
        e.source = e.source or text
        return {"ok": False, "error": e.to_dict()}
    if src == "latex":
        return {"ok": True, "plain": program_to_plain(stmts)}
    return {"ok": True, "latex": program_to_latex(stmts)}


__all__ = ["A", "MathError", "ParseError", "parse", "attach_source", "convert_input"]
