"""Convert the AST into SymPy objects.

While converting, every operation that restricts the domain (log arguments,
even roots, denominators, tan, arcsin, ...) is recorded as a `Condition`, so
callers can explain *why* a result is undefined and compute natural domains.

All variables are real symbols. Decimals typed by the user become exact
rationals (0.1 -> 1/10).
"""
from __future__ import annotations

from dataclasses import dataclass, field

import sympy as sp

from . import ast as A
from .echo import to_latex
from .errors import MathError, ParseError
from .names import MATRIX_FUNCTIONS

_SYMBOLS: dict[str, sp.Symbol] = {}


def symbol(name: str) -> sp.Symbol:
    if name not in _SYMBOLS:
        _SYMBOLS[name] = sp.Symbol(name, real=True)
    return _SYMBOLS[name]


@dataclass
class Condition:
    """`expr` must satisfy `rel` ('>0', '>=0', '!=0', 'in[-1,1]', 'nonneg_int', ...)."""
    rel: str
    expr: sp.Expr
    what: str            # e.g. "the argument of log₂"
    latex: str           # the sub-expression as typed, in LaTeX
    guard: sp.Basic = sp.true  # only applies where this holds (piecewise branches)
    custom: sp.Basic | None = None  # rel == "case": the argument must satisfy this

    def subs(self, mapping) -> "Condition":
        return Condition(self.rel, sp.sympify(self.expr).subs(mapping), self.what, self.latex,
                         sp.sympify(self.guard).subs(mapping),
                         None if self.custom is None else sp.sympify(self.custom).subs(mapping))

    def as_relational(self) -> sp.Basic:
        e = self.expr
        if self.rel == "case":
            return self.custom
        if self.rel == ">0":
            return e > 0
        if self.rel == ">=0":
            return e >= 0
        if self.rel == "!=0":
            return sp.Ne(e, 0)
        if self.rel == "!=1":
            return sp.Ne(e, 1)
        if self.rel == "in[-1,1]":
            return sp.And(e >= -1, e <= 1)
        if self.rel == ">=1":
            return e >= 1
        if self.rel == "in(-1,1)":
            return sp.And(e > -1, e < 1)
        if self.rel == "nonneg_int":
            return sp.And(e >= 0, sp.Eq(e, sp.floor(e)))
        raise ValueError(self.rel)

    def requirement_text(self) -> str:
        return {
            ">0": "must be positive", ">=0": "must not be negative", "!=0": "must not be zero",
            "!=1": "must not be 1", "in[-1,1]": "must be between −1 and 1",
            ">=1": "must be at least 1", "in(-1,1)": "must be strictly between −1 and 1",
            "nonneg_int": "must be a whole number ≥ 0", "case": "must fall into one of the cases",
        }[self.rel]


@dataclass
class RelChain:
    """A comparison as written: exprs[0] ops[0] exprs[1] ..."""
    ops: list[str]
    exprs: list[sp.Expr]

    def as_sympy(self) -> sp.Basic:
        parts = []
        for op, a, b in zip(self.ops, self.exprs, self.exprs[1:]):
            parts.append(make_rel(op, a, b))
        return sp.And(*parts) if len(parts) > 1 else parts[0]


def make_rel(op: str, a, b) -> sp.Basic:
    return {"=": sp.Eq, "!=": sp.Ne, "<": sp.Lt, "<=": sp.Le, ">": sp.Gt, ">=": sp.Ge}[op](a, b)


@dataclass
class Guarded:
    value: object
    cond: sp.Basic | None  # None = otherwise


@dataclass
class Restriction:
    """x in [a, b]"""
    var: sp.Symbol
    interval: sp.Interval


@dataclass
class SystemObj:
    items: list


@dataclass
class CasesObj:
    branches: list[tuple[object, sp.Basic | None]]  # None = otherwise
    # Domain conditions recorded while converting each branch's value.
    branch_conditions: list[list[Condition]] = field(default_factory=list)

    def as_piecewise(self) -> sp.Piecewise:
        args = []
        for value, cond in self.branches:
            args.append((value, sp.true if cond is None else cond))
        return sp.Piecewise(*args)


@dataclass
class SeqObj:
    items: list
    bracket: str = "["


@dataclass
class MatrixQuery:
    """rref(A), eigenvalues(A), eigenvectors(A), solve(A, b): not a value, answered by the Matrices tab."""
    name: str
    args: list


def _shape(m) -> str:
    return f"{m.rows}×{m.cols}"


def inverse(m):
    """The exact inverse, or MathError when the matrix is singular / not square."""
    if m.rows != m.cols:
        raise MathError(f"Only square matrices have an inverse; this one is {_shape(m)}.")
    d = sp.simplify(m.det())
    if d == 0:
        raise MathError("The determinant is 0, so the matrix has no inverse (it is singular).")
    return sp.ImmutableMatrix(m.inv())


class Converter:
    def __init__(self, log_base: int = 10, user_functions: set[str] | None = None,
                 int_vars: set[str] | None = None, matrices: dict | None = None):
        self.log_base = log_base
        self.user_functions = set(user_functions or ())
        self.matrices = dict(matrices or {})   # names that stand for a stored matrix (Matrices tab)
        self.int_vars = set(int_vars or ())  # whole-number indices: (-1)^n needs no positive base
        self.conditions: list[Condition] = []
        self.sum_conditions: dict[sp.Sum | sp.Product, list[Condition]] = {}  # each term's requirements
        self._guard = sp.true

    # ---- helpers ----
    def require(self, rel: str, expr, what: str, node: A.Node):
        expr = sp.sympify(expr)
        cond = Condition(rel, expr, what, to_latex(node), self._guard)
        # Skip conditions that are trivially true (e.g. log of 2).
        try:
            truth = cond.as_relational()
            if truth is sp.true:
                return
        except TypeError:
            pass
        self.conditions.append(cond)

    def fail(self, message: str, node: A.Node):
        raise ParseError(message, span=node.span if node.span != (0, 0) else None)

    # ---- main dispatch ----
    def convert(self, node: A.Node):
        method = getattr(self, "c_" + type(node).__name__, None)
        if method is None:
            self.fail(f"Can't use {type(node).__name__} here.", node)
        return method(node)

    def expr(self, node: A.Node) -> sp.Expr:
        """Convert and insist on an ordinary expression (not a relation, list, ...)."""
        out = self.convert(node)
        if isinstance(out, MatrixQuery):
            raise MathError(f"{out.name}(…) gives a list of results, so it can only stand on its own line "
                            "(in the Matrices tab).")
        if isinstance(out, (RelChain, Guarded, Restriction, SystemObj, CasesObj, SeqObj)) \
                or is_boolean(out):
            kind = {RelChain: "a comparison", Guarded: "a condition", Restriction: "an interval",
                    SystemObj: "a system", CasesObj: "a cases block", SeqObj: "a list"}.get(type(out), "a condition")
            self.fail(f"Expected an expression here, but found {kind}.", node)
        return out

    def condition(self, node: A.Node) -> sp.Basic:
        out = self.convert(node)
        if isinstance(out, RelChain):
            return out.as_sympy()
        if isinstance(out, Restriction):
            return restriction_condition(out)
        if is_boolean(out):
            return out
        self.fail("Expected a condition such as 0 < x < 1.", node)

    # ---- nodes ----
    def c_Num(self, node: A.Num):
        t = node.text
        if "." in t or "e" in t:
            return sp.Rational(t)
        return sp.Integer(t)

    def c_Name(self, node: A.Name):
        n = node.name
        if n == "pi":
            return sp.pi
        if n == "e":
            return sp.E
        if n == "inf":
            return sp.oo
        if n in self.matrices:
            return self.matrices[n]
        return symbol(n)

    def c_Neg(self, node: A.Neg):
        return -self.expr(node.operand)

    def c_BinOp(self, node: A.BinOp):
        a = self.expr(node.left)
        if node.op == "^" and isinstance(a, sp.MatrixBase) and isinstance(node.right, A.Name) \
                and node.right.name == "T" and "T" not in self.matrices:
            return a.T  # A^T: the transpose
        b = self.expr(node.right)
        op = node.op
        if isinstance(a, sp.MatrixBase) or isinstance(b, sp.MatrixBase):
            return self._matrix_op(op, a, b, node)
        if op == "+":
            return a + b
        if op == "-":
            return a - b
        if op == "*":
            return a * b
        if op == "/":
            self.require("!=0", b, "the denominator", node.right)
            return a / b
        if op == "^":
            self._power_conditions(a, b, node)
            _check_power_size(a, b)
            return sp.Pow(a, b)
        self.fail(f"Unknown operator {op}", node)

    def _matrix_op(self, op, a, b, node: A.BinOp):
        M = sp.MatrixBase
        if op in ("+", "-"):
            if not (isinstance(a, M) and isinstance(b, M)):
                raise MathError("A matrix and a number can't be added or subtracted.")
            if a.shape != b.shape:
                raise MathError(f"Only matrices of the same size can be added: these are {_shape(a)} "
                                f"and {_shape(b)}.")
            return sp.ImmutableMatrix(a + b if op == "+" else a - b)
        if op == "*":
            if isinstance(a, M) and isinstance(b, M) and a.cols != b.rows:
                raise MathError(f"A {_shape(a)} matrix can't be multiplied by a {_shape(b)} matrix: the first "
                                "needs as many columns as the second has rows.")
            return sp.ImmutableMatrix(a * b)
        if op == "/":
            if isinstance(b, M):
                raise MathError("Dividing by a matrix isn't defined; multiply by its inverse, A^(-1).")
            self.require("!=0", b, "the denominator", node.right)
            return sp.ImmutableMatrix(a / b)
        # ^
        if isinstance(b, M) or not isinstance(a, M):
            raise MathError("A number can't be raised to a matrix power. The power of a matrix is A^n "
                            "with a whole number n (A^T is the transpose).")
        if a.rows != a.cols:
            raise MathError(f"Only square matrices have powers; this one is {_shape(a)}.")
        if not b.is_Integer:
            raise MathError("A matrix can only be raised to a whole-number power (A^T is its transpose).")
        if b < 0:
            return sp.ImmutableMatrix(inverse(a) ** int(-b))
        return sp.ImmutableMatrix(a ** int(b))

    def _matrix_call(self, node: A.Call):
        name = node.name
        args = []
        for a in node.args:
            obj = self.convert(a)
            if isinstance(obj, SeqObj) and all(isinstance(i, sp.Expr) for i in obj.items):
                obj = sp.ImmutableMatrix(obj.items)  # a list [1, 2] stands for the column vector
            elif not isinstance(obj, sp.MatrixBase):
                obj = self.expr(a)
            args.append(obj)
        m = args[0]
        if not isinstance(m, sp.MatrixBase):
            raise MathError(f"{name} needs a matrix, e.g. {name}([[1, 2], [3, 4]]).")
        square = name in ("det", "trace", "inv", "eigenvalues", "eigenvectors")
        if square and m.rows != m.cols:
            raise MathError(f"{name} needs a square matrix; this one is {_shape(m)}.")
        if name == "det":
            return sp.simplify(m.det())
        if name == "trace":
            return m.trace()
        if name == "transpose":
            return sp.ImmutableMatrix(m.T)
        if name == "rank":
            return sp.Integer(m.rank())
        if name == "inv":
            return inverse(m)
        return MatrixQuery(name, args)

    def _power_conditions(self, base, exp, node: A.BinOp):
        if base.is_number and base.is_positive:
            return
        if base == sp.E:
            return
        if exp.is_integer or self._integer_valued(exp):
            if exp.is_negative:
                self.require("!=0", base, "the base of a negative power", node.left)
            return
        if exp.is_number:
            # Non-integer exponent: defined for base >= 0 (base > 0 if exponent < 0).
            what = "the base of a fractional power"
            if exp.is_Rational and exp.q % 2 == 1:
                what += r" (for a real odd root of a negative number, write $\sqrt[" + str(exp.q) + r"]{\ }$ or root(x, " + str(exp.q) + "))"
            self.require(">0" if exp.is_negative else ">=0", base, what, node.left)
            return
        # Variable exponent: the base must be positive.
        if not base.is_number or not base.is_positive:
            self.require(">0", base, "the base of a power with a variable exponent", node.left)

    def _integer_valued(self, e) -> bool:
        free = sp.sympify(e).free_symbols
        if not free or not {s.name for s in free} <= self.int_vars:
            return False
        return bool(e.xreplace({s: sp.Dummy(s.name, integer=True) for s in free}).is_integer)

    def c_Call(self, node: A.Call):
        name = node.name
        if name in MATRIX_FUNCTIONS:
            return self._matrix_call(node)
        if name not in _BUILTIN:
            args = [self.expr(a) for a in node.args]
            if node.primes:
                # f'(a): the derivative of f, evaluated at a (f is substituted later).
                if len(args) != 1:
                    self.fail("f'(...) works for functions of one variable.", node)
                t = sp.Dummy("t", real=True)
                return sp.Subs(sp.Derivative(sp.Function(name, real=True)(t), (t, node.primes)), t, args[0])
            return sp.Function(name, real=True)(*args)
        if node.primes:
            self.fail(f"Write the derivative of {name} as d/dx {name}(x).", node)
        args = [self.expr(a) for a in node.args]
        x = args[0]
        arg_node = node.args[0]
        if name in ("ln",):
            self.require(">0", x, "the argument of $\\ln$", arg_node)
            return sp.log(x)
        if name == "lg":
            self.require(">0", x, "the argument of $\\lg$", arg_node)
            return sp.log(x, 10)
        if name == "log":
            base = args[1] if len(args) > 1 else sp.Integer(self.log_base)
            base_txt = to_latex(node.args[1]) if len(args) > 1 else str(self.log_base)
            self.require(">0", x, f"the argument of $\\log_{{{base_txt}}}$", arg_node)
            if len(args) > 1:
                self.require(">0", base, "the base of the logarithm", node.args[1])
                self.require("!=1", base, "the base of the logarithm", node.args[1])
            return sp.log(x, base)
        if name == "sqrt":
            self.require(">=0", x, "the expression under the square root", arg_node)
            return sp.sqrt(x)
        if name == "cbrt":
            return sp.real_root(x, 3)
        if name == "root":
            return self._root(x, args[1], arg_node, node.args[1])
        if name == "abs":
            return sp.Abs(x)
        if name in ("tan", "sec"):
            self.require("!=0", sp.cos(x), f"the cosine of the argument of $\\{name}$", arg_node)
        if name in ("cot", "csc"):
            self.require("!=0", sp.sin(x), f"the sine of the argument of $\\{name}$", arg_node)
        if name in ("asin", "acos"):
            self.require("in[-1,1]", x, f"the argument of $\\arc{name[1:]}$", arg_node)
        if name == "acosh":
            self.require(">=1", x, "the argument of arcosh", arg_node)
        if name == "atanh":
            self.require("in(-1,1)", x, "the argument of artanh", arg_node)
        if name == "coth":
            self.require("!=0", x, "the argument of coth", arg_node)
        if name == "factorial":
            self.require("nonneg_int", x, "the argument of the factorial", arg_node)
            _check_factorial_size(x)
            return sp.factorial(x)
        if name == "binom":
            return sp.binomial(x, args[1])
        if name in ("gcd", "lcm"):
            fn = sp.gcd if name == "gcd" else sp.lcm
            out = args[0]
            for a in args[1:]:
                out = fn(out, a)
            return out
        if name == "min":
            return sp.Min(*args)
        if name == "max":
            return sp.Max(*args)
        return _BUILTIN[name](x)

    def _root(self, x, n, x_node: A.Node, n_node: A.Node):
        if not (n.is_Integer and n >= 2):
            self.fail("The root index must be a whole number 2 or more.", n_node)
        if n % 2 == 0:
            self.require(">=0", x, "the expression under an even root", x_node)
            return sp.root(x, n)
        return sp.real_root(x, n)

    def c_Abs(self, node: A.Abs):
        return sp.Abs(self.expr(node.arg))

    def c_Root(self, node: A.Root):
        x = self.expr(node.arg)
        if node.index is None:
            self.require(">=0", x, "the expression under the square root", node.arg)
            return sp.sqrt(x)
        n = self.expr(node.index)
        return self._root(x, n, node.arg, node.index)

    def c_Factorial(self, node: A.Factorial):
        x = self.expr(node.arg)
        self.require("nonneg_int", x, "the argument of the factorial", node.arg)
        _check_factorial_size(x)
        return sp.factorial(x)

    def c_Degrees(self, node: A.Degrees):
        return self.expr(node.arg) * sp.pi / 180

    def c_Subscript(self, node: A.Subscript):
        return sp.Function(node.base, real=True)(self.expr(node.index))

    def c_Rel(self, node: A.Rel):
        items = []
        for it in node.items:
            # A cases block or matrix may stand on the right of a definition: f(x) = {cases}
            if isinstance(it, (A.Cases, A.Matrix)):
                items.append(self.convert(it))
            else:
                items.append(self.expr(it))
        return RelChain(list(node.ops), items)

    def c_Logic(self, node: A.Logic):
        parts = [self.condition(it) for it in node.items]
        return sp.And(*parts) if node.op == "and" else sp.Or(*parts)

    def c_Interval(self, node: A.Interval):
        lo, hi = self.expr(node.lo), self.expr(node.hi)
        return sp.Interval(lo, hi, not node.left_closed, not node.right_closed)

    def c_InSet(self, node: A.InSet):
        item = self.expr(node.item)
        s = self.convert(node.set)
        if not isinstance(item, sp.Symbol):
            self.fail("Only a single variable can be restricted to an interval (x in [a, b]).", node.item)
        return Restriction(item, s)

    def c_Cases(self, node: A.Cases):
        branches, per_branch = [], []
        outer = self._guard
        for value, cond in node.branches:
            c = None if cond is None else self.condition(cond)
            self._guard = outer if c is None else sp.And(outer, c)
            before = len(self.conditions)
            branches.append((self.convert(value), c))
            per_branch.append(self.conditions[before:])
        self._guard = outer
        return CasesObj(branches, per_branch)

    def c_System(self, node: A.System):
        return SystemObj([self.convert(it) for it in node.items])

    def c_Matrix(self, node: A.Matrix):
        m = sp.ImmutableMatrix([[self.expr(c) for c in row] for row in node.rows])
        if node.det:
            if m.rows != m.cols:
                self.fail("A determinant needs a square matrix.", node)
            return m.det()
        return m

    def c_Seq(self, node: A.Seq):
        return SeqObj([self.convert(it) for it in node.items], node.bracket)

    # ---- calculus (kept unevaluated; the Calculus tab evaluates them with checks) ----
    def _calc_var(self, name: str | None, expr, node: A.Node, what: str) -> sp.Symbol:
        if name is not None:
            return symbol(name)
        free = sorted(sp.sympify(expr).free_symbols - {s for s in sp.sympify(expr).free_symbols
                                                        if not isinstance(s, sp.Symbol)}, key=str)
        free = [v for v in free if not isinstance(v, sp.Dummy)]
        if len(free) == 1:
            return free[0]
        if not free:
            return symbol("x")
        names = ", ".join(v.name for v in free)
        self.fail(f"Say which variable to use for the {what}: the expression has {names}.", node)

    def c_Limit(self, node: A.Limit):
        expr = self.expr(node.expr)
        point = self.expr(node.point)
        if point.free_symbols:
            self.fail("The point of a limit must be a number (or ∞).", node.point)
        d = {"+": "+", "-": "-", None: "+-"}[node.direction]
        if point in (sp.oo, -sp.oo):
            d = "-" if point == sp.oo else "+"
        return sp.Limit(expr, symbol(node.var), point, d)

    def c_Derivative(self, node: A.Derivative):
        expr = self.expr(node.expr)
        var = self._calc_var(node.var, expr, node, "derivative")
        return sp.Derivative(expr, (var, node.order))

    def c_Integral(self, node: A.Integral):
        expr = self.expr(node.expr)
        var = self._calc_var(node.var, expr, node, "integral")
        if node.lower is None:
            return sp.Integral(expr, var)
        a, b = self.expr(node.lower), self.expr(node.upper)
        if a.free_symbols or b.free_symbols:
            self.fail("The bounds of an integral must be numbers (∞ is allowed).", node)
        return sp.Integral(expr, (var, a, b))

    def c_Sum(self, node: A.Sum):
        return self._big_operator(node, sp.Sum, "sum", "summation variable")

    def c_Product(self, node: A.Product):
        return self._big_operator(node, sp.Product, "product", "product's variable")

    def _big_operator(self, node, cls, kind: str, var_name: str):
        """Σ or ∏ over whole numbers var = lower … upper."""
        var = symbol(node.var)
        lo, hi = self.expr(node.lower), self.expr(node.upper)
        for b, which in ((lo, "lower"), (hi, "upper")):
            if var in b.free_symbols:
                self.fail(f"The {var_name} {node.var} can't appear in its own bounds.", node)
            if b.is_number and b not in (sp.oo, -sp.oo) and not b.is_integer:
                self.fail(f"The {which} bound of a {kind} must be a whole number (∞ is allowed at the top).", node)
        if lo in (sp.oo, -sp.oo) or hi == -sp.oo:
            self.fail(f"A {kind} must start at a whole number; only the upper bound can be ∞.", node)
        # The summand's own requirements (1/n needs n ≠ 0) concern the bound
        # variable, so they are kept apart instead of joining this line's conditions.
        before = len(self.conditions)
        outer_ints = set(self.int_vars)
        self.int_vars.add(node.var)
        try:
            expr = self.expr(node.expr)
        finally:
            self.int_vars = outer_ints
        inner = self.conditions[before:]
        del self.conditions[before:]
        s = cls(expr, (var, lo, hi))
        self.sum_conditions[s] = inner
        return s

    def c_Conditional(self, node: A.Conditional):
        cond = None if node.cond is None else self.condition(node.cond)
        outer = self._guard
        if cond is not None:
            self._guard = sp.And(outer, cond)
        value = self.convert(node.value)
        self._guard = outer
        return Guarded(value, cond)


MAX_DIGITS = 10**6   # exact numbers bigger than this are refused (SymPy would compute them forever)
MAX_FACTORIAL = 100000


def _check_power_size(a, b):
    """p/q raised to a whole number is computed at once by SymPy: refuse it when the
    result would have more than a million digits (10^10^10 has ten billion)."""
    if not (isinstance(a, sp.Rational) and isinstance(b, sp.Integer)) or a in (0, 1, -1):
        return
    import math
    size = max(math.log10(abs(int(a.p))), math.log10(abs(int(a.q))) if a.q != 1 else 0.0)
    digits = abs(int(b)) * size
    if digits > MAX_DIGITS:
        raise MathError(f"This number is too large to work with exactly: ${sp.latex(sp.Pow(a, b, evaluate=False))}$ "
                        f"would have about {_digits_text(digits)} digits.")


def _check_factorial_size(x):
    if isinstance(x, sp.Integer) and x > MAX_FACTORIAL:
        digits = (sp.loggamma(x + 1) / sp.log(10)).evalf(15)
        raise MathError(f"${sp.latex(x)}!$ is too large to work with exactly: it has about "
                        f"{_digits_text(float(digits))} digits (the limit is {MAX_FACTORIAL}!).")


def _digits_text(d: float) -> str:
    if d < 1e9:
        return f"{int(round(d)):,}"
    import math
    e = int(math.floor(math.log10(d)))
    return f"{d / 10 ** e:.1f} × 10^{e}"


def is_boolean(obj) -> bool:
    """True for SymPy conditions (x < 1, And(...), true). Symbols are excluded:
    SymPy's Symbol is also a Boolean subclass."""
    return isinstance(obj, sp.logic.boolalg.Boolean) and not isinstance(obj, sp.Expr)


def restriction_condition(r: Restriction) -> sp.Basic:
    iv = r.interval
    lo = (r.var > iv.start) if iv.left_open else (r.var >= iv.start)
    hi = (r.var < iv.end) if iv.right_open else (r.var <= iv.end)
    return sp.And(lo, hi)


_BUILTIN = {
    "sin": sp.sin, "cos": sp.cos, "tan": sp.tan, "cot": sp.cot, "sec": sp.sec, "csc": sp.csc,
    "asin": sp.asin, "acos": sp.acos, "atan": sp.atan, "acot": sp.acot,
    "sinh": sp.sinh, "cosh": sp.cosh, "tanh": sp.tanh, "coth": sp.coth,
    "asinh": sp.asinh, "acosh": sp.acosh, "atanh": sp.atanh,
    "exp": sp.exp, "sign": sp.sign, "floor": sp.floor, "ceil": sp.ceiling,
    "ln": None, "lg": None, "log": None, "sqrt": None, "cbrt": None, "root": None, "abs": None,
    "factorial": None, "binom": None, "gcd": None, "lcm": None, "min": None, "max": None,
}
