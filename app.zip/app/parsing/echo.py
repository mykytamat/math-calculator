"""Print an AST back as LaTeX ("Interpreted as: ...") or as plain text.

The LaTeX echo makes the reading explicit: every function argument gets
parentheses, a bare log is shown as log₁₀, mixed numbers show their "+",
and implicit products of non-numbers get a visible dot. That way a misread
(say, sin 2x+1 read as sin(2x)+1) is visible before the user trusts the answer.
"""
from __future__ import annotations

from . import ast as A
from .names import FUNCTIONS

# Binding strength used to decide where parentheses are needed.
PREC = {"or": 1, "and": 2, "rel": 3, "+": 10, "-": 10, "*": 20, "/": 20, "neg": 25, "^": 30, "post": 40, "atom": 50}

FUNC_LATEX = {
    "sin": r"\sin", "cos": r"\cos", "tan": r"\tan", "cot": r"\cot", "sec": r"\sec", "csc": r"\csc",
    "asin": r"\arcsin", "acos": r"\arccos", "atan": r"\arctan", "acot": r"\operatorname{arccot}",
    "sinh": r"\sinh", "cosh": r"\cosh", "tanh": r"\tanh", "coth": r"\coth",
    "asinh": r"\operatorname{arsinh}", "acosh": r"\operatorname{arcosh}", "atanh": r"\operatorname{artanh}",
    "exp": r"\exp", "ln": r"\ln", "abs": None, "sign": r"\operatorname{sgn}", "floor": None, "ceil": None,
    "gcd": r"\gcd", "lcm": r"\operatorname{lcm}", "min": r"\min", "max": r"\max",
    "factorial": None, "binom": None, "sqrt": None, "cbrt": None, "root": None,
    "det": r"\det", "trace": r"\operatorname{tr}",
}

REL_LATEX = {"=": "=", "!=": r"\ne", "<": "<", "<=": r"\le", ">": ">", ">=": r"\ge"}

GREEK_LATEX = {
    "alpha", "beta", "gamma", "delta", "epsilon", "varepsilon", "zeta", "eta", "theta", "vartheta",
    "iota", "kappa", "lambda", "mu", "nu", "xi", "rho", "sigma", "tau", "upsilon", "phi", "varphi",
    "chi", "psi", "omega", "Gamma", "Delta", "Theta", "Lambda", "Xi", "Pi", "Sigma", "Upsilon",
    "Phi", "Psi", "Omega",
}


def prec(node: A.Node) -> int:
    if isinstance(node, A.Logic):
        return PREC[node.op]
    if isinstance(node, (A.Rel, A.InSet)):
        return PREC["rel"]
    if isinstance(node, A.BinOp):
        return PREC[node.op]
    if isinstance(node, A.Neg):
        return PREC["neg"]
    if isinstance(node, (A.Factorial, A.Degrees)):
        return PREC["post"]
    if isinstance(node, A.Num) and node.text.startswith("-"):
        return PREC["neg"]
    if isinstance(node, (A.Limit, A.Derivative, A.Integral, A.Sum, A.Product)):
        return PREC["*"]  # lim, d/dx, ∫, Σ and ∏ take everything multiplied after them
    return PREC["atom"]


# ---------------------------------------------------------------- LaTeX ----
def name_latex(name: str) -> str:
    if name == "pi":
        return r"\pi"
    if name == "inf":
        return r"\infty"
    if name == "e":
        return "e"
    base, _, sub = name.partition("_")
    b = "\\" + base if base in GREEK_LATEX else base
    if len(base) > 1 and base not in GREEK_LATEX:
        b = r"\operatorname{" + base + "}"
    return f"{b}_{{{sub}}}" if sub else b


def to_latex(node: A.Node) -> str:
    return _L(node)


def _paren(s: str) -> str:
    return r"\left(" + s + r"\right)"


def _wrap(node: A.Node, min_prec: int) -> str:
    s = _L(node)
    return _paren(s) if prec(node) < min_prec else s


def _L(node: A.Node) -> str:
    if isinstance(node, A.Num):
        return node.text
    if isinstance(node, A.Name):
        return name_latex(node.name)
    if isinstance(node, A.Neg):
        return "-" + _wrap(node.operand, PREC["neg"] + 1 if isinstance(node.operand, A.Neg) else PREC["*"])
    if isinstance(node, A.BinOp):
        op = node.op
        if op in ("+", "-"):
            # A Σ at the end of the left side would take in the terms after it.
            left = _paren(_L(node.left)) if _ends_with_sum(node.left) else _wrap(node.left, PREC["+"])
            if op == "+":
                return left + "+" + _wrap(node.right, PREC["+"] if not isinstance(node.right, A.Neg) else PREC["atom"])
            return left + "-" + _wrap(node.right, PREC["-"] + 1)
        if op == "/":
            return r"\frac{" + _L(node.left) + "}{" + _L(node.right) + "}"
        if op == "*":
            left = _wrap(node.left, PREC["*"])
            right = _wrap(node.right, PREC["*"] + 1)
            if isinstance(node.right, A.Neg):
                right = _paren(_L(node.right))
            if node.implicit and _juxtapose_ok(node.left, node.right):
                sep = " " if right[:1].isalpha() and left[-1:].isalpha() else ""
                return left + sep + right
            return left + r"\cdot " + right
        if op == "^":
            base = _L(node.left)
            if prec(node.left) <= PREC["^"] or isinstance(node.left, A.Call) or (
                    isinstance(node.left, A.Num) and "." in node.left.text):
                base = _paren(base)
            return base + "^{" + _L(node.right) + "}"
    if isinstance(node, A.Call):
        return _call_latex(node)
    if isinstance(node, A.Abs):
        return r"\left|" + _L(node.arg) + r"\right|"
    if isinstance(node, A.Root):
        if node.index is None:
            return r"\sqrt{" + _L(node.arg) + "}"
        return r"\sqrt[" + _L(node.index) + "]{" + _L(node.arg) + "}"
    if isinstance(node, A.Factorial):
        return _wrap(node.arg, PREC["atom"]) + "!"
    if isinstance(node, A.Degrees):
        return _wrap(node.arg, PREC["atom"]) + r"^{\circ}"
    if isinstance(node, A.Subscript):
        return name_latex(node.base) + "_{" + _L(node.index) + "}"
    if isinstance(node, A.Rel):
        out = _L(node.items[0])
        for op, item in zip(node.ops, node.items[1:]):
            out += " " + REL_LATEX[op] + " " + _L(item)
        return out
    if isinstance(node, A.Logic):
        word = r"\text{ and }" if node.op == "and" else r"\text{ or }"
        return word.join(_wrap(it, PREC[node.op] + 1) for it in node.items)
    if isinstance(node, A.Interval):
        lb = r"\left[" if node.left_closed else r"\left("
        rb = r"\right]" if node.right_closed else r"\right)"
        return lb + _L(node.lo) + ", " + _L(node.hi) + rb
    if isinstance(node, A.InSet):
        return _L(node.item) + r" \in " + _L(node.set)
    if isinstance(node, A.Cases):
        rows = []
        for value, cond in node.branches:
            c = r"\text{otherwise}" if cond is None else r"\text{if } " + _L(cond)
            rows.append(_L(value) + " & " + c)
        return r"\begin{cases}" + r"\\ ".join(rows) + r"\end{cases}"
    if isinstance(node, A.System):
        return r"\begin{cases}" + r"\\ ".join(_L(it) for it in node.items) + r"\end{cases}"
    if isinstance(node, A.Matrix):
        env = "vmatrix" if node.det else "pmatrix"
        body = r"\\ ".join(" & ".join(_L(c) for c in row) for row in node.rows)
        return rf"\begin{{{env}}}" + body + rf"\end{{{env}}}"
    if isinstance(node, A.Seq):
        inner = ", ".join(_L(it) for it in node.items)
        return (r"\left(" + inner + r"\right)") if node.bracket == "(" else (r"\left[" + inner + r"\right]")
    if isinstance(node, A.Conditional):
        if node.cond is None:
            return _L(node.value) + r",\quad\text{otherwise}"
        return _L(node.value) + r",\quad\text{if } " + _L(node.cond)
    if isinstance(node, A.Limit):
        point = _L(node.point)
        if node.direction:
            point += "^{" + node.direction + "}"
        return r"\lim_{" + name_latex(node.var) + r"\to " + point + "}" + _wrap(node.expr, PREC["*"])
    if isinstance(node, A.Derivative):
        v = name_latex(node.var or _guess_var(node.expr))
        n = node.order
        op = r"\frac{d}{d" + v + "}" if n == 1 else r"\frac{d^{" + str(n) + "}}{d" + v + "^{" + str(n) + "}}"
        inner = _L(node.expr)
        return op + (inner if prec(node.expr) >= PREC["atom"] else _paren(inner))
    if isinstance(node, A.Integral):
        v = name_latex(node.var or _guess_var(node.expr))
        bounds = ""
        if node.lower is not None:
            bounds = "_{" + _L(node.lower) + "}^{" + _L(node.upper) + "}"
        return r"\int" + bounds + " " + _wrap(node.expr, PREC["+"]) + r"\,d" + v
    if isinstance(node, (A.Sum, A.Product)):
        sign = r"\sum" if isinstance(node, A.Sum) else r"\prod"
        return (sign + "_{" + name_latex(node.var) + "=" + _L(node.lower) + "}^{" + _L(node.upper) + "}"
                + _wrap(node.expr, PREC["*"]))
    return r"\text{?}"


def _ends_with_sum(node: A.Node) -> bool:
    """Does the LaTeX of node end with an open Σ or ∏ (one whose terms run on to the right)?"""
    if isinstance(node, (A.Sum, A.Product)):
        return True
    if isinstance(node, A.Neg):
        return _ends_with_sum(node.operand)
    if isinstance(node, A.BinOp) and node.op in ("+", "-"):
        return _ends_with_sum(node.right)
    return False


def _guess_var(node: A.Node) -> str:
    """The variable of diff(x^3) / int(t^2) written without one: the only letter used."""
    names = {n.name for n in A.walk(node) if isinstance(n, A.Name) and n.name not in ("pi", "e", "inf")}
    return next(iter(names)) if len(names) == 1 else "x"


def _juxtapose_ok(left: A.Node, right: A.Node) -> bool:
    """2x, 3\\sin(x), x\\left(x+1\\right) read naturally without a dot."""
    if isinstance(right, A.Num) or (isinstance(right, A.BinOp) and right.op == "^" and isinstance(right.left, A.Num)):
        return False
    if isinstance(left, A.Num):
        return True
    if isinstance(left, A.BinOp) and left.op == "/":
        return not isinstance(right, A.BinOp) or right.op != "/"
    if isinstance(left, (A.Name, A.Abs, A.Root)) or (isinstance(left, A.BinOp) and left.op == "^"):
        return isinstance(right, (A.Name, A.Call, A.Abs, A.Root)) or (
            isinstance(right, A.BinOp) and right.op == "^" and isinstance(right.left, A.Name))
    return False


def _call_latex(node: A.Call) -> str:
    name, args = node.name, node.args
    inner = ", ".join(_L(a) for a in args)
    if name == "log":
        base = _L(args[1]) if len(args) > 1 else "10"
        return r"\log_{" + base + "}" + _paren(_L(args[0]))
    if name == "lg":
        return r"\log_{10}" + _paren(inner)
    if name in ("sqrt",):
        return r"\sqrt{" + inner + "}"
    if name == "cbrt":
        return r"\sqrt[3]{" + inner + "}"
    if name == "root":
        return r"\sqrt[" + _L(args[1]) + "]{" + _L(args[0]) + "}"
    if name == "abs":
        return r"\left|" + inner + r"\right|"
    if name == "floor":
        return r"\left\lfloor " + inner + r"\right\rfloor"
    if name == "ceil":
        return r"\left\lceil " + inner + r"\right\rceil"
    if name == "factorial":
        return _paren(inner) + "!"
    if name == "binom":
        return r"\binom{" + _L(args[0]) + "}{" + _L(args[1]) + "}"
    if name in FUNC_LATEX and FUNC_LATEX[name]:
        return FUNC_LATEX[name] + _paren(inner)
    # user-defined function
    primes = "'" * node.primes
    return name_latex(name) + primes + _paren(inner)


# ------------------------------------------------------------ plain text ----
REL_PLAIN = {"=": "=", "!=": "!=", "<": "<", "<=": "<=", ">": ">", ">=": ">="}


def to_plain(node: A.Node) -> str:
    return _P(node)


def _pwrap(node: A.Node, min_prec: int) -> str:
    s = _P(node)
    if isinstance(node, (A.Sum, A.Product)):  # sum(...) and prod(...) are function calls in plain text
        return s
    return "(" + s + ")" if prec(node) < min_prec else s


def _P(node: A.Node) -> str:
    if isinstance(node, A.Num):
        return node.text
    if isinstance(node, A.Name):
        if node.name == "inf":
            return "inf"
        base, _, sub = node.name.partition("_")
        if sub and not sub.isdigit() and len(sub) > 1:
            return f"{base}_({sub})"
        return node.name
    if isinstance(node, A.Neg):
        return "-" + _pwrap(node.operand, PREC["*"])
    if isinstance(node, A.BinOp):
        op = node.op
        if op == "+":
            r = _pwrap(node.right, PREC["+"])
            if isinstance(node.right, A.Neg):
                r = "(" + _P(node.right) + ")"
            return _pwrap(node.left, PREC["+"]) + " + " + r
        if op == "-":
            return _pwrap(node.left, PREC["-"]) + " - " + _pwrap(node.right, PREC["-"] + 1)
        if op == "/":
            return _pwrap(node.left, PREC["/"]) + "/" + _pwrap(node.right, PREC["/"] + 1)
        if op == "*":
            left = _pwrap(node.left, PREC["*"])
            right = _pwrap(node.right, PREC["*"] + 1)
            if isinstance(node.right, A.Neg):
                right = "(" + _P(node.right) + ")"
            if node.implicit and isinstance(node.left, A.Num) and not isinstance(node.right, A.Num) \
                    and not right[:1].isdigit():
                return left + right
            return left + "*" + right
        if op == "^":
            base = _pwrap(node.left, PREC["^"] + 1)
            if isinstance(node.left, A.Call) or (isinstance(node.left, A.Num) and "." in node.left.text):
                base = "(" + _P(node.left) + ")"
            exp = _pwrap(node.right, PREC["^"])
            if isinstance(node.right, A.Neg) or isinstance(node.right, A.BinOp):
                exp = "(" + _P(node.right) + ")"
            return base + "^" + exp
    if isinstance(node, A.Call):
        name = node.name
        if name == "log":
            if len(node.args) > 1:
                return f"log({_P(node.args[0])}, {_P(node.args[1])})"
            return f"log({_P(node.args[0])})"
        primes = "'" * node.primes
        return name + primes + "(" + ", ".join(_P(a) for a in node.args) + ")"
    if isinstance(node, A.Abs):
        return "|" + _P(node.arg) + "|"
    if isinstance(node, A.Root):
        if node.index is None:
            return "sqrt(" + _P(node.arg) + ")"
        return "root(" + _P(node.arg) + ", " + _P(node.index) + ")"
    if isinstance(node, A.Factorial):
        return _pwrap(node.arg, PREC["atom"]) + "!"
    if isinstance(node, A.Degrees):
        return _pwrap(node.arg, PREC["atom"]) + "°"
    if isinstance(node, A.Subscript):
        return node.base + "_(" + _P(node.index) + ")"
    if isinstance(node, A.Rel):
        out = _P(node.items[0])
        for op, item in zip(node.ops, node.items[1:]):
            out += f" {REL_PLAIN[op]} " + _P(item)
        return out
    if isinstance(node, A.Logic):
        return f" {node.op} ".join(_pwrap(it, PREC[node.op] + 1) for it in node.items)
    if isinstance(node, A.Interval):
        return ("[" if node.left_closed else "(") + _P(node.lo) + ", " + _P(node.hi) + ("]" if node.right_closed else ")")
    if isinstance(node, A.InSet):
        return _P(node.item) + " in " + _P(node.set)
    if isinstance(node, A.Cases):
        lines = []
        for value, cond in node.branches:
            lines.append(_P(value) + (" otherwise" if cond is None else " if " + _P(cond)))
        return "{ " + "; ".join(lines) + " }"
    if isinstance(node, A.System):
        return "{" + "; ".join(_P(it) for it in node.items) + "}"
    if isinstance(node, A.Matrix):
        return "[" + ", ".join("[" + ", ".join(_P(c) for c in row) + "]" for row in node.rows) + "]"
    if isinstance(node, A.Seq):
        inner = ", ".join(_P(it) for it in node.items)
        return "(" + inner + ")" if node.bracket == "(" else "[" + inner + "]"
    if isinstance(node, A.Conditional):
        if node.cond is None:
            return _P(node.value) + " otherwise"
        return _P(node.value) + " if " + _P(node.cond)
    if isinstance(node, A.Limit):
        return f"lim({_P(node.expr)}, {node.var} -> {_P(node.point)}{node.direction or ''})"
    if isinstance(node, A.Derivative):
        args = [_P(node.expr)] + ([node.var] if node.var else [])
        if node.order != 1:
            args.append(str(node.order) if node.var else f"x, {node.order}")
        return "diff(" + ", ".join(args) + ")"
    if isinstance(node, A.Integral):
        args = [_P(node.expr)] + ([node.var] if node.var else [])
        if node.lower is not None:
            args += [_P(node.lower), _P(node.upper)]
        return "int(" + ", ".join(args) + ")"
    if isinstance(node, (A.Sum, A.Product)):
        name = "sum" if isinstance(node, A.Sum) else "prod"
        return f"{name}({_P(node.expr)}, {node.var}, {_P(node.lower)}, {_P(node.upper)})"
    return "?"


def program_to_plain(stmts: list[A.Node]) -> str:
    """Plain text for a whole input. A definition with cases becomes one line per case."""
    lines = []
    for st in stmts:
        if (isinstance(st, A.Rel) and st.ops == ["="] and isinstance(st.items[1], A.Cases)):
            head = _P(st.items[0])
            for value, cond in st.items[1].branches:
                lines.append(f"{head} = {_P(value)}" + (" otherwise" if cond is None else f" if {_P(cond)}"))
        elif isinstance(st, A.Cases):
            for value, cond in st.branches:
                lines.append(_P(value) + (" otherwise" if cond is None else f" if {_P(cond)}"))
        else:
            lines.append(_P(st))
    return "\n".join(lines)


def program_to_latex(stmts: list[A.Node]) -> list[str]:
    """One LaTeX string per visual-editor line. Consecutive `f(x) = ... if ...`
    lines for the same function are merged into one cases block."""
    out: list[str] = []
    i = 0
    while i < len(stmts):
        st = stmts[i]
        head = _definition_head(st)
        if head is not None and isinstance(st, A.Conditional):
            branches = []
            j = i
            while j < len(stmts) and isinstance(stmts[j], A.Conditional) and _definition_head(stmts[j]) == head:
                c = stmts[j]
                branches.append((c.value.items[1], c.cond))
                j += 1
            cases = A.Cases(branches)
            out.append(_L(stmts[i].value.items[0]) + "=" + _L(cases))
            i = j
            continue
        out.append(_L(st))
        i += 1
    return out


def _definition_head(st: A.Node) -> str | None:
    rel = st.value if isinstance(st, A.Conditional) else st
    if isinstance(rel, A.Rel) and rel.ops == ["="] and isinstance(rel.items[0], A.Call) \
            and rel.items[0].name not in FUNCTIONS:  # sin x = 1/2 for x in [...] is not a definition
        return to_plain(rel.items[0])
    return None
