"""Plain-text front end: tokenizer for the documented plain-text syntax."""
from __future__ import annotations

import re

from . import ast as A
from .errors import ParseError
from .names import CONSTANTS, GREEK, KEYWORDS, canonical_function, split_letters
from .parser import Parser, Token

EXTRA_KEYWORDS = {"for", "when"}
# 12, 2.5, .5, and scientific notation 1e-3 / 2.5e6 (but "2e" alone is 2 times e).
_NUMBER = re.compile(r"[0-9]*\.?[0-9]*(?:e[+-]?[0-9]+)?")
DIGITS = "0123456789"

# Unicode characters people paste from documents, mapped to plain syntax.
_SIMPLE_CHARS = {
    "−": ("op", "-"), "–": ("op", "-"), "·": ("op", "*"), "⋅": ("op", "*"),
    "×": ("op", "*"), "÷": ("op", "/"), "≤": ("rel", "<="), "≥": ("rel", ">="),
    "≠": ("rel", "!="), "π": ("const", "pi"), "∞": ("const", "inf"), "∈": ("kw", "in"),
    "°": ("op", "°"), "%": ("op", "%"), "'": ("op", "'"), "’": ("op", "'"), "→": ("to", "->"),
}

# Symbols people paste that have a plain-text spelling (or aren't supported).
_SYMBOL_HINTS = {
    "∫": ("an integral", "Write int(f, x) or int(f, x, a, b), or use the ∫ button in the visual editor."),
    "∑": ("a sum", "Write sum(f, n, 1, inf), or use the Σ button in the visual editor."),
    "Σ": ("a sum", "Write sum(f, n, 1, inf), or use the Σ button in the visual editor."),
    "∏": ("a product", "Write prod(f, k, 1, n), or use the ∏ button in the visual editor."),
    "∂": ("a partial derivative", "Partial derivatives aren't supported; d/dx works for one variable."),
}

# f(x) = ..., area(r) = ..., a(n) = ... : names defined as functions in the input.
_DEF_RE = re.compile(
    r"(?<![A-Za-z0-9_])([A-Za-z][A-Za-z0-9]*)\s*\(\s*[A-Za-z]\w*\s*(?:,\s*[A-Za-z]\w*\s*)*\)\s*:?=(?!=)")


def find_user_functions(text: str) -> set[str]:
    names = set()
    for m in _DEF_RE.finditer(text):
        name = m.group(1)
        if name in CONSTANTS:
            raise ParseError(f"'{name}' can't be a function name: it means the constant "
                             f"{'e ≈ 2.718' if name == 'e' else name}.", span=m.span(1), source=text,
                             hint="Pick another letter, for example f, g or h.")
        if canonical_function(name) is None:
            names.add(name)
    return names


def tokenize(text: str, user_functions: set[str]) -> list[Token]:
    toks: list[Token] = []
    i, n = 0, len(text)

    def add(kind, value, start, end, base=None):
        toks.append(Token(kind, value, start, end, base))

    while i < n:
        c = text[i]
        if c in " \t\r":
            i += 1
            continue
        if c == "\n" or c == ";":
            add("sep", c, i, i + 1)
            i += 1
            continue
        if c in DIGITS or (c == "." and i + 1 < n and text[i + 1] in DIGITS):
            m = _NUMBER.match(text, i)
            j = m.end()
            add("num", text[i:j].rstrip(".") or "0", i, j)
            i = j
            continue
        if c.isascii() and c.isalpha():
            j = i
            while j < n and text[j].isascii() and text[j].isalpha():
                j += 1
            run = text[i:j]
            pos = i
            words = split_letters(run, user_functions)
            for w in words:
                _word_token(add, w, pos, pos + len(w), user_functions, text)
                pos += len(w)
            if words[-1] == "log" and j < n and text[j] in DIGITS:
                # log2(8), log10 x: digits written right after "log" are the base.
                k = j
                while k < n and text[k] in DIGITS:
                    k += 1
                toks[-1].base = text[j:k]
                toks[-1].end = k
                i = k
                continue
            if j < n and text[j] in DIGITS and len(words[-1]) == 1 and toks[-1].kind == "name":
                k = j
                while k < n and text[k] in DIGITS:
                    k += 1
                v = words[-1]
                raise ParseError(
                    f"'{v}{text[j:k]}' is ambiguous.", span=(j - 1, k), source=text,
                    hint=f"Write {v}^{text[j:k]} for a power, {v}_{text[j:k]} for a subscript, "
                         f"or {v}*{text[j:k]} to multiply.")
            i = j
            continue
        two = text[i:i + 2]
        if two == "->":
            add("to", "->", i, i + 2); i += 2; continue
        if two == "**":
            add("op", "^", i, i + 2); i += 2; continue
        if two in ("<=", ">=", "!=", "=<", "=>"):
            if two in ("=<", "=>"):
                raise ParseError(f"Did you mean '{two[::-1]}'?", span=(i, i + 2), source=text)
            add("rel", two, i, i + 2); i += 2; continue
        if two == "==":
            add("rel", "=", i, i + 2); i += 2; continue
        if two == ":=":
            add("rel", "=", i, i + 2); i += 2; continue
        if two == "<>":
            add("rel", "!=", i, i + 2); i += 2; continue
        if c in "+-*/^!":
            add("op", c, i, i + 1); i += 1; continue
        if c in "<>=":
            add("rel", c, i, i + 1); i += 1; continue
        if c in "()[],|_":
            add(c, c, i, i + 1); i += 1; continue
        if c == "{":
            add("lbrace_p", "{", i, i + 1); i += 1; continue
        if c == "}":
            add("rbrace_p", "}", i, i + 1); i += 1; continue
        if c in "²³":
            add("op", "^", i, i + 1)
            add("num", "2" if c == "²" else "3", i, i + 1)
            i += 1
            continue
        if c == "√":
            add("sqrt_sym", "2", i, i + 1); i += 1; continue
        if c == "∛":
            add("sqrt_sym", "3", i, i + 1); i += 1; continue
        if c == "∜":
            add("sqrt_sym", "4", i, i + 1); i += 1; continue
        if c in _SIMPLE_CHARS:
            kind, value = _SIMPLE_CHARS[c]
            add(kind, value, i, i + 1)
            i += 1
            continue
        if c in _SYMBOL_HINTS:
            what, hint = _SYMBOL_HINTS[c]
            raise ParseError(f"The symbol '{c}' ({what}) can't be typed in plain text.", span=(i, i + 1),
                             source=text, hint=hint)
        if c.isalpha():
            raise ParseError(f"Unknown letter '{c}'. Variables must be Latin letters a-z.",
                             span=(i, i + 1), source=text,
                             hint="Write Greek letters by name, e.g. alpha, theta, pi.")
        raise ParseError(f"Unexpected character '{c}'.", span=(i, i + 1), source=text)
    add("end", "", n, n)
    return toks


def _word_token(add, w: str, start: int, end: int, user_functions: set[str], text: str):
    if w in KEYWORDS or w in EXTRA_KEYWORDS:
        add("kw", w, start, end)
    elif w in user_functions:
        add("name", w, start, end)
    elif w in CONSTANTS:
        add("const", CONSTANTS[w], start, end)
    elif w in ("log2", "log10"):
        add("func", "log", start, end, base=w[3:])
    elif canonical_function(w) is not None:
        add("func", canonical_function(w), start, end)
    elif w in GREEK:
        add("name", w, start, end)
    elif len(w) == 1:
        add("name", w, start, end)
    else:  # pragma: no cover - split_letters only yields known words or single letters
        raise ParseError(f"Unknown name '{w}'.", span=(start, end), source=text)


class PlainParser(Parser):
    """Braces: {expr} works like brackets; {a; b} (or one relation per line,
    or separated by commas) is a system."""

    def starts_implicit(self) -> bool:
        return super().starts_implicit() or self.at("lbrace_p")

    def parse_special(self, tok):
        if tok.kind != "lbrace_p":
            return None
        opener = self.next()
        saved, self.abs_depth = self.abs_depth, 0
        items = []
        while True:
            while self.at("sep") or self.at(","):
                self.next()
            if self.at("rbrace_p"):
                break
            if self.at("end"):
                raise self.error("Expected '}' but the input ended.",
                                 hint=f"The brace opened at position {opener.start + 1} is never closed.")
            items.append(self.parse_logic())
            if not (self.at("sep") or self.at(",") or self.at("rbrace_p")):
                raise self.error(f"Expected ';', a new line or '}}' but found {self.describe(self.peek())}.")
        self.next()
        self.abs_depth = saved
        if not items:
            raise self.error("Empty braces.", opener)
        if len(items) == 1:
            return items[0]
        if all(isinstance(it, (A.Rel, A.Logic, A.InSet)) for it in items):
            return self.node(A.System, items, start=opener.start)
        return self.node(A.Seq, items, "(", start=opener.start)


def parse(text: str) -> list:
    """Parse plain-text input into a list of statements (AST nodes)."""
    user_functions = find_user_functions(text)
    tokens = tokenize(text, user_functions)
    return PlainParser(tokens, text, user_functions).parse_program()
