"""Parse errors that point at the offending part of the input."""
from __future__ import annotations


class ParseError(Exception):
    """Raised when input cannot be read.

    `span` is a (start, end) character range in the source text, `read_so_far`
    is the part that was understood before the problem (shown to the user so
    they can see what was misread), and `hint` suggests a fix.
    """

    def __init__(self, message: str, span: tuple[int, int] | None = None,
                 hint: str | None = None, source: str | None = None):
        super().__init__(message)
        self.message = message
        self.span = span
        self.hint = hint
        self.source = source

    def to_dict(self) -> dict:
        d = {"kind": "parse", "message": self.message}
        if self.hint:
            d["hint"] = self.hint
        if self.span is not None and self.source is not None:
            start, end = self.span
            end = max(end, start + 1)
            d["span"] = [start, end]
            d["source"] = self.source
            d["before"] = self.source[:start]
            d["at"] = self.source[start:end]
            d["after"] = self.source[end:]
        return d


class MathError(Exception):
    """A well-formed input that has no answer (undefined, not real, ...)."""

    def __init__(self, message: str, latex: str | None = None):
        super().__init__(message)
        self.message = message
        self.latex = latex

    def to_dict(self) -> dict:
        d = {"kind": "math", "message": self.message}
        if self.latex:
            d["latex"] = self.latex
        return d
