"""LaTeX front end for the visual editor (MathLive output).

The tokenizer maps LaTeX commands onto the same token kinds as the plain-text
tokenizer; the parser subclass adds the LaTeX-only constructs: brace groups,
single-character script/fraction arguments (\\frac12, x^2), \\sqrt[n]{},
environments (cases, matrices, aligned systems) and MathLive quirks such as
the empty base slot it inserts after \\log.
"""
from __future__ import annotations

import re

from . import ast as A
from .errors import ParseError
from .names import CONSTANTS, GREEK, KEYWORDS, canonical_function, split_letters
from .parser import CONDITION_WORDS, OTHERWISE_WORDS, Parser, Token

UPPER_GREEK = ["Gamma", "Delta", "Theta", "Lambda", "Xi", "Pi", "Sigma", "Upsilon", "Phi", "Psi", "Omega"]

FUNCTION_COMMANDS = {
    "sin", "cos", "tan", "cot", "sec", "csc", "arcsin", "arccos", "arctan", "arccot",
    "sinh", "cosh", "tanh", "coth", "exp", "ln", "lg", "log", "max", "min", "gcd", "lcm",
    "tg", "ctg", "arctg", "arcctg", "sgn", "sh", "ch", "th", "cth", "det",
}

# Russian-style names MathLive produces as \operatorname{sh} etc.
LATEX_ONLY_ALIASES = {"sh": "sinh", "ch": "cosh", "th": "tanh", "cth": "coth"}

REL_COMMANDS = {
    "lt": "<", "gt": ">", "le": "<=", "leq": "<=", "leqslant": "<=", "leqq": "<=",
    "ge": ">=", "geq": ">=", "geqslant": ">=", "geqq": ">=", "ne": "!=", "neq": "!=",
    "coloneq": "=", "coloneqq": "=", "eqqcolon": "=",
}

OP_COMMANDS = {"cdot": "*", "times": "*", "ast": "*", "div": "/", "prime": "'"}

SKIP_COMMANDS = {
    "quad", "qquad", "enspace", "thinspace", "medspace", "thickspace", "negthinspace",
    "negmedspace", "negthickspace", "displaystyle", "textstyle", "scriptstyle",
    "scriptscriptstyle", "limits", "nolimits", "space", "nobreakspace", "relax",
}

SIZE_COMMANDS = {"left", "right", "bigl", "bigr", "Bigl", "Bigr", "biggl", "biggr", "Biggl",
                 "Biggr", "big", "Big", "bigg", "Bigg", "middle"}

# Commands whose argument is a word in upright type: \operatorname{tg}, \text{if}.
WORD_COMMANDS = {"operatorname", "mathrm", "text", "textrm", "mbox", "textit", "textnormal",
                 "mathit", "mathbf", "textbf", "boldsymbol", "mathsf", "mathtt", "textup", "mathup",
                 "operatorname*"}
TEXT_COMMANDS = {"text", "textrm", "mbox", "textit", "textnormal", "textbf", "textup"}

LATER = {
    "iint": "Double integrals", "oint": "Contour integrals",
    "partial": "Partial derivatives",
}

UNSUPPORTED = {
    "pm": "± isn't supported. Enter the two cases separately.",
    "mp": "∓ isn't supported. Enter the two cases separately.",
    "imaginaryI": "Complex numbers aren't supported: this calculator works with real numbers.",
    "approx": "≈ can't be used in input.", "equiv": "≡ can't be used in input.",
    "cdots": "'…' can't be used in input.", "ldots": "'…' can't be used in input.",
    "dots": "'…' can't be used in input.", "emptyset": "∅ can't be used in input.",
    "varnothing": "∅ can't be used in input.", "not": "Negated symbols aren't supported.",
    "notin": "∉ isn't supported.", "Vert": "Norms ‖x‖ aren't supported.",
    "langle": "Angle brackets aren't supported.", "rangle": "Angle brackets aren't supported.",
}

ALIGN_ENVS = {"aligned", "align", "align*", "gathered", "gather", "gather*", "split", "eqnarray",
              "alignat", "alignedat"}
CASES_ENVS = {"cases", "dcases", "rcases", "cases*"}
MATRIX_ENVS = {"matrix", "pmatrix", "bmatrix", "Bmatrix", "vmatrix", "smallmatrix", "array",
               "subarray"}

_LETTER = re.compile(r"[A-Za-z]")


class LatexLexer:
    def __init__(self, src: str, user_functions: set[str]):
        self.src = src
        self.i = 0
        self.toks: list[Token] = []
        self.user_functions = user_functions
        # Pending run of adjacent letters: list of (char, start, end, upright)
        self.run: list[tuple[str, int, int, bool]] = []

    # --- helpers ---
    def add(self, kind, value, start, end, base=None):
        self.flush_run()
        self.toks.append(Token(kind, value, start, end, base))

    def err(self, message, start, end, hint=None):
        return ParseError(message, span=(start, end), hint=hint, source=self.src)

    def read_group_raw(self) -> tuple[str, int, int]:
        """Read a {...} group starting at self.i (after optional spaces). Returns
        (content, content_start, end_index_after_closing_brace)."""
        j = self.i
        while j < len(self.src) and self.src[j] == " ":
            j += 1
        if j >= len(self.src) or self.src[j] != "{":
            # A single character argument, e.g. \text x (rare).
            if j < len(self.src):
                return self.src[j], j, j + 1
            raise self.err("Expected '{' after a command.", self.i, self.i)
        depth, k = 0, j
        while k < len(self.src):
            ch = self.src[k]
            if ch == "\\":
                k += 2
                continue
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    return self.src[j + 1:k], j + 1, k + 1
            k += 1
        raise self.err("Unbalanced braces: a '{' is never closed.", j, j + 1)

    def flush_run(self):
        if not self.run:
            return
        run, self.run = self.run, []
        text = "".join(ch for ch, *_ in run)
        whole = split_letters(text, self.user_functions)
        if len(text) > 1 and whole == [text]:
            # The whole run is one word, e.g. MathLive's o\operatorname{th}erwise.
            self.toks.append(self.word_token(text, run[0][1], run[-1][2]))
            return
        # Otherwise upright pieces (\operatorname{tg}) stay whole and plain
        # letters are split as usual.
        pos = 0
        while pos < len(run):
            upright = run[pos][3]
            end = pos
            while end < len(run) and run[end][3] == upright:
                end += 1
            seg = run[pos:end]
            seg_text = "".join(ch for ch, *_ in seg)
            if upright:
                self.toks.append(self.upright_token(seg_text, seg[0][1], seg[-1][2]))
            else:
                p = 0
                for w in split_letters(seg_text, self.user_functions):
                    self.toks.append(self.word_token(w, seg[p][1], seg[p + len(w) - 1][2]))
                    p += len(w)
            pos = end

    def upright_token(self, text: str, s: int, e: int) -> Token:
        if text in LATEX_ONLY_ALIASES:
            return Token("func", LATEX_ONLY_ALIASES[text], s, e)
        if len(text) == 1 or canonical_function(text) is not None or text in KEYWORDS \
                or text in CONSTANTS or text in GREEK or text in self.user_functions \
                or text in ("for", "when"):
            return self.word_token(text, s, e)
        raise self.err(f"Unknown function or word '{text}'.", s, e)

    def word_token(self, w: str, s: int, e: int) -> Token:
        if w in KEYWORDS or w in ("for", "when"):
            return Token("kw", w, s, e)
        if w in self.user_functions:
            return Token("name", w, s, e)
        if w in CONSTANTS:
            return Token("const", CONSTANTS[w], s, e)
        if w in LATEX_ONLY_ALIASES:
            return Token("func", LATEX_ONLY_ALIASES[w], s, e)
        if canonical_function(w) is not None:
            return Token("func", canonical_function(w), s, e)
        if w in GREEK or len(w) == 1:
            return Token("name", w, s, e)
        raise self.err(f"Unknown name '{w}'.", s, e)

    # --- main loop ---
    def tokenize(self) -> list[Token]:
        src, n = self.src, len(self.src)
        while self.i < n:
            c = src[self.i]
            start = self.i
            if c == "\n":
                # Lines of the visual editor are joined with newlines.
                self.add("sep", "\n", start, start + 1)
                self.i += 1
                continue
            if c in " \t\r~":
                self.flush_run()
                self.i += 1
                continue
            if c == "\\":
                self.command()
                continue
            if c in "0123456789" or (c == "." and self.i + 1 < n and src[self.i + 1] in "0123456789"):
                m = re.compile(r"[0-9]*(?:(?:\.|\{,\})[0-9]+)?\.?(?:e[+-]?[0-9]+)?").match(src, self.i)
                text = m.group(0).replace("{,}", ".").rstrip(".") or "0"
                self.add("num", text, start, m.end())
                self.i = m.end()
                continue
            if c.isascii() and c.isalpha():
                self.run.append((c, start, start + 1, False))
                self.i += 1
                continue
            self.i += 1
            if c in "+-*/":
                self.add("op", c, start, self.i)
            elif c == "^":
                self.add("op", "^", start, self.i)
            elif c == "!":
                if self.i < n and src[self.i] == "=":
                    self.i += 1
                    self.add("rel", "!=", start, self.i)
                else:
                    self.add("op", "!", start, self.i)
            elif c in "<>":
                if self.i < n and src[self.i] == "=":
                    self.i += 1
                    self.add("rel", c + "=", start, self.i)
                else:
                    self.add("rel", c, start, self.i)
            elif c == "=":
                self.add("rel", "=", start, self.i)
            elif c == ":":
                if self.i < n and src[self.i] == "=":
                    self.i += 1
                    self.add("rel", "=", start, self.i)
                else:
                    raise self.err("Unexpected ':'.", start, self.i)
            elif c in "()[],|_&{}":
                kind = {"&": "amp"}.get(c, c)
                self.add(kind, c, start, self.i)
            elif c == ";":
                self.add("sep", c, start, self.i)
            elif c == "'":
                self.add("op", "'", start, self.i)
            elif c == "%":
                raise self.err("Unexpected '%'.", start, self.i)
            elif c == "°":
                self.add("circ", c, start, self.i)
            elif c == "π":
                self.add("const", "pi", start, self.i)
            elif c == "∞":
                self.add("const", "inf", start, self.i)
            elif c in "−–":
                self.add("op", "-", start, self.i)
            elif c in "·×":
                self.add("op", "*", start, self.i)
            elif c == "≤":
                self.add("rel", "<=", start, self.i)
            elif c == "≥":
                self.add("rel", ">=", start, self.i)
            elif c == "≠":
                self.add("rel", "!=", start, self.i)
            else:
                raise self.err(f"Unexpected character '{c}'.", start, self.i)
        self.add("end", "", n, n)
        return self._postprocess(self.toks)

    def command(self):
        src, n = self.src, len(self.src)
        start = self.i
        j = self.i + 1
        if j >= n:
            raise self.err("A lone backslash at the end.", start, j)
        if not src[j].isalpha():
            ch = src[j]
            self.i = j + 1
            if ch in ",;:! >":
                self.flush_run()
                return
            if ch == "\\":
                self.add("rowsep", "\\\\", start, self.i)
            elif ch == "{":
                self.add("lbrace_d", "{", start, self.i)
            elif ch == "}":
                self.add("rbrace_d", "}", start, self.i)
            elif ch == "%":
                self.add("op", "%", start, self.i)
            elif ch == "|":
                raise self.err(UNSUPPORTED["Vert"], start, self.i)
            else:
                raise self.err(f"Unexpected '\\{ch}'.", start, self.i)
            return
        while j < n and src[j].isalpha():
            j += 1
        name = src[start + 1:j]
        if name == "operatorname" and j < n and src[j] == "*":
            j += 1
        self.i = j

        if name in SIZE_COMMANDS:
            self.delimiter(name, start)
            return
        if name in SKIP_COMMANDS:
            self.flush_run()
            return
        if name in ("hspace", "phantom", "hphantom", "vphantom", "color"):
            self.flush_run()
            self.read_group_skip()
            return
        if name == "textcolor":
            self.flush_run()
            self.read_group_skip()
            return  # the coloured content follows as a normal group
        if name in WORD_COMMANDS:
            self.word_command(name, start)
            return
        if name in FUNCTION_COMMANDS:
            if name in LATEX_ONLY_ALIASES:
                self.add("func", LATEX_ONLY_ALIASES[name], start, j)
            else:
                self.add("func", canonical_function(name), start, j)
            return
        if name in REL_COMMANDS:
            self.add("rel", REL_COMMANDS[name], start, j)
            return
        if name in OP_COMMANDS:
            self.add("op", OP_COMMANDS[name], start, j)
            return
        if name in ("doubleprime", "tripleprime"):
            for _ in range(2 if name == "doubleprime" else 3):
                self.add("op", "'", start, j)
            return
        if name in ("lim", "int", "sum", "prod"):
            self.add(name, name, start, j)
            return
        if name == "differentialD":
            # MathLive writes the d of dx as \differentialD: treat it as the letter d.
            self.run.append(("d", start, j, False))
            return
        if name == "in":
            rest = src[j:].lstrip()
            if rest[:1] == "f" and not rest[1:2].isalpha():
                raise self.err("'∈ f' looks like a mistyped ∞.", start, j + 1,
                               hint="In the visual editor, type 'oo' or 'infty' to get ∞.")
            self.add("kw", "in", start, j)
            return
        if name in ("land", "wedge"):
            self.add("kw", "and", start, j)
            return
        if name in ("lor", "vee"):
            if name == "lor" and self.run and self.run[-1][0] == "f" and self.run[-1][2] == start:
                # MathLive turns the "or" of a typed "for" into \lor: f\lor x\in[0,2\pi] means "for".
                f = self.run.pop()
                self.flush_run()
                self.toks.append(Token("kw", "for", f[1], j))
                return
            self.add("kw", "or", start, j)
            return
        if name == "pi":
            self.add("const", "pi", start, j)
            return
        if name in ("top", "intercal"):
            self.add("name", "T", start, j)  # A^{\top}, A^{\intercal}: the transpose, read as A^T
            return
        if name == "infty":
            self.add("const", "inf", start, j)
            return
        if name == "exponentialE":
            self.add("const", "e", start, j)
            return
        if name in GREEK or name in UPPER_GREEK:
            self.add("name", name, start, j)
            return
        if name in ("frac", "dfrac", "tfrac", "cfrac"):
            self.add("frac", "frac", start, j)
            return
        if name in ("binom", "dbinom", "tbinom"):
            self.add("binom", "binom", start, j)
            return
        if name == "sqrt":
            self.add("sqrt", "sqrt", start, j)
            return
        if name in ("circ", "degree"):
            self.add("circ", "°", start, j)
            return
        if name in ("lbrack",):
            self.add("[", "[", start, j)
            return
        if name in ("rbrack",):
            self.add("]", "]", start, j)
            return
        if name in ("vert", "lvert", "rvert", "mid"):
            self.add("|", "|", start, j)
            return
        if name in ("lbrace",):
            self.add("lbrace_d", "{", start, j)
            return
        if name in ("rbrace",):
            self.add("rbrace_d", "}", start, j)
            return
        if name in ("lfloor", "rfloor", "lceil", "rceil"):
            self.add(name, name, start, j)
            return
        if name == "placeholder":
            self.flush_run()
            # \placeholder[id]{content}
            if self.i < n and src[self.i] == "[":
                k = src.find("]", self.i)
                self.i = k + 1 if k >= 0 else n
            content, cs, end = self.read_group_raw()
            self.i = end
            if content.strip():
                # A filled-in placeholder: treat its content as a group.
                self.toks.append(Token("{", "{", cs - 1, cs))
                self.sub_tokenize(content, cs)
                self.toks.append(Token("}", "}", end - 1, end))
            else:
                self.add("placeholder", "", start, end)
            return
        if name in ("begin", "end"):
            content, cs, end = self.read_group_raw()
            self.i = end
            env = content.strip()
            self.add("begin" if name == "begin" else "endenv", env, start, end)
            if name == "begin" and env in ("array", "subarray", "alignat", "alignedat"):
                _, _, end2 = self.read_group_raw()
                self.i = end2
            return
        if name in ("to", "rightarrow", "longrightarrow"):
            self.add("to", "to", start, j)
            return
        if name in LATER:
            self.add("later", name, start, j)
            return
        if name in UNSUPPORTED:
            raise self.err(UNSUPPORTED[name], start, j)
        if name == "mathbb":
            content, cs, end = self.read_group_raw()
            self.i = end
            raise self.err(f"Number sets like ℤ/ℝ (\\mathbb{{{content}}}) aren't supported here.",
                           start, end)
        raise self.err(f"I don't know the LaTeX command '\\{name}'.", start, j)

    def read_group_skip(self):
        _, _, end = self.read_group_raw()
        self.i = end

    def delimiter(self, size_cmd: str, start: int):
        """Handle \\left( \\right] \\bigl| ... and emit a single bracket token."""
        src, n = self.src, len(self.src)
        j = self.i
        while j < n and src[j] == " ":
            j += 1
        if j >= n:
            raise self.err(f"\\{size_cmd} without a delimiter.", start, j)
        is_left = size_cmd.startswith("left") or size_cmd.endswith("l")
        is_right = size_cmd.startswith("right") or size_cmd.endswith("r")
        if src[j] == "\\":
            k = j + 1
            if k < n and not src[k].isalpha():
                d = src[j:k + 1]
                k += 1
            else:
                while k < n and src[k].isalpha():
                    k += 1
                d = src[j:k]
        else:
            d = src[j]
            k = j + 1
        self.i = k
        mapping = {
            "(": "(", ")": ")", "[": "[", "]": "]", "\\lbrack": "[", "\\rbrack": "]",
            "\\{": "lbrace_d", "\\}": "rbrace_d", "\\lbrace": "lbrace_d", "\\rbrace": "rbrace_d",
            ".": "nulldelim", "\\lfloor": "lfloor", "\\rfloor": "rfloor",
            "\\lceil": "lceil", "\\rceil": "rceil",
        }
        if d in ("|", "\\vert", "\\lvert", "\\rvert", "\\mid"):
            kind = "abs_open" if is_left else ("abs_close" if is_right else "|")
            self.add(kind, "|", start, k)
            return
        if d in mapping:
            kind = mapping[d]
            self.add(kind, kind if kind not in "()[]" else d[-1], start, k)
            return
        if d in ("\\Vert", "\\|"):
            raise self.err(UNSUPPORTED["Vert"], start, k)
        raise self.err(f"Unknown delimiter '{d}'.", start, k)

    def word_command(self, name: str, start: int):
        content, cs, end = self.read_group_raw()
        self.i = end
        inner = content
        # Unwrap nested style commands: \operatorname{\mathrm{tg}} -> tg
        m = re.fullmatch(r"\s*\\(?:mathrm|operatorname|mathit|text|textrm)\s*\{([^{}]*)\}\s*", inner)
        while m:
            inner = m.group(1)
            m = re.fullmatch(r"\s*\\(?:mathrm|operatorname|mathit|text|textrm)\s*\{([^{}]*)\}\s*", inner)
        if name in TEXT_COMMANDS:
            self.flush_run()
            m = re.match(r"\s*[,.:]?\s*([A-Za-z]+)(.*)$", inner, re.S)
            word = m.group(1) if m else ""
            if word not in KEYWORDS and word not in ("for", "when"):
                if not inner.strip(" ,.:"):
                    return
                raise self.err(f"I don't understand the text '{inner.strip()}'.", start, end,
                               hint="Text can only be 'if', 'otherwise', 'and', 'or'.")
            self.add("kw", word, start, end)
            rest = m.group(2)
            if rest.strip():
                # Math typed inside the text box after "if" (\text{ if x<0}): read it as math.
                self.sub_tokenize(rest, cs + m.start(2))
            return
        if re.fullmatch(r"[A-Za-z]+", inner):
            # Upright letters join the surrounding run so MathLive's
            # o\operatorname{th}erwise is still read as "otherwise".
            for k, ch in enumerate(inner):
                self.run.append((ch, start if k == 0 else end - 1, end, True))
            return
        if not inner.strip():
            self.flush_run()
            return
        # Anything else (e.g. \mathbf{x+1}): treat as a group.
        self.flush_run()
        self.toks.append(Token("{", "{", cs - 1, cs))
        self.sub_tokenize(inner if inner is content else content, cs)
        self.toks.append(Token("}", "}", end - 1, end))

    def sub_tokenize(self, content: str, offset: int):
        sub = LatexLexer(content, self.user_functions)
        toks = sub.tokenize()[:-1]  # drop end
        for t in toks:
            t.start += offset
            t.end += offset
        self.toks.extend(toks)

    def _postprocess(self, toks: list[Token]) -> list[Token]:
        """Drop alignment '&' inside aligned-style environments, and inside
        cases rows when the '&' sits right before a relation (x+y &= 3)."""
        out: list[Token] = []
        stack: list[str] = []
        for idx, t in enumerate(toks):
            if t.kind == "begin":
                stack.append(t.value)
            elif t.kind == "endenv" and stack:
                stack.pop()
            if t.kind == "amp" and stack:
                env = stack[-1]
                nxt = toks[idx + 1] if idx + 1 < len(toks) else None
                if env in ALIGN_ENVS or (env in CASES_ENVS and nxt is not None and nxt.kind == "rel"):
                    continue
            out.append(t)
        return out


class LatexParser(Parser):
    IMPLICIT_EXTRA = {"{", "frac", "sqrt", "binom", "abs_open", "lfloor", "lceil", "placeholder",
                      "lbrace_d", "sum", "prod"}

    def starts_implicit(self) -> bool:
        if self.peek().kind in self.IMPLICIT_EXTRA:
            return True
        if self.at("begin") and self.peek().value in MATRIX_ENVS:
            return True
        return super().starts_implicit()

    def parse_implicit(self, left, start):
        prev = self.prev()
        if self.at("frac") and isinstance(left, A.Num) and prev is not None and prev.kind == "num":
            frac = self.parse_power()
            if isinstance(frac, A.BinOp) and frac.op == "/" and _is_int(frac.left) and _is_int(frac.right) \
                    and "." not in left.text:
                # Mixed number: 2\frac{1}{2} means 2 + 1/2.
                return self.node(A.BinOp, "+", left, frac, start=start)
            return self.node(A.BinOp, "*", left, frac, implicit=True, start=start)
        return super().parse_implicit(left, start)

    # --- scripts: x^2, x^{10}, a_n, \log_2 ---
    def script(self, allow_empty=False):
        """Argument of ^ or _: a {group} or a single token (x^2, \\frac12)."""
        tok = self.peek()
        start = tok.start
        if tok.kind == "{":
            opener = self.next()
            if self.at("}"):
                self.next()
                if allow_empty:
                    return None
                raise self.error("Empty braces {}.", opener)
            if self.at("circ") and self.peek(1).kind == "}":
                self.next(); self.next()
                return A.Degrees(A.Num("0"), span=(start, self.last_end()))
            if self.at("placeholder") and self.peek(1).kind == "}" and allow_empty:
                self.next(); self.next()
                return None
            inner = self.parse_logic()
            self.expect("}", message="Expected '}'", opener=opener)
            return inner
        if tok.kind == "placeholder" and allow_empty:
            self.next()
            return None
        if tok.kind == "num":
            return self.single_digit()
        if tok.kind in ("name", "const"):
            self.next()
            return self.node(A.Name, tok.value, start=start)
        if tok.kind == "circ":
            self.next()
            return A.Degrees(A.Num("0"), span=(start, self.last_end()))
        if tok.kind in ("frac", "sqrt"):
            return self.parse_primary()
        if tok.kind == "op" and tok.value == "-":
            self.next()
            inner = self.script()
            return self.node(A.Neg, inner, start=start)
        raise self.error("Expected an exponent or subscript here.")

    def single_digit(self) -> A.Node:
        """Take one digit from a number token (LaTeX x^23 means x^2·3)."""
        tok = self.peek()
        if len(tok.value) > 1 and "." not in tok.value:
            first = Token("num", tok.value[0], tok.start, tok.start + 1)
            rest = Token("num", tok.value[1:], tok.start + 1, tok.end)
            self.toks[self.i:self.i + 1] = [first, rest]
        tok = self.next()
        return self.node(A.Num, tok.value, start=tok.start)

    def parse_exponent(self):
        return self.script()

    def parse_function_power(self):
        return self.script()

    def parse_subscript(self):
        return self.script(allow_empty=True)

    def parse_primes(self) -> int:
        primes = 0
        while True:
            if self.at("op", "'"):
                self.next()
                primes += 1
            elif self.at("op", "^") and self.at("{", k=1) and self.at("op", "'", k=2):
                k = 2
                while self.at("op", "'", k=k):
                    k += 1
                if not self.at("}", k=k):
                    break
                for _ in range(k + 1):
                    self.next()
                primes += k - 2
            elif self.at("op", "^") and self.at("op", "'", k=1):
                self.next(); self.next()
                primes += 1
            else:
                return primes

    def parse_function(self):
        tok = self.peek()
        try:
            return super().parse_function()
        except ParseError as e:
            # MathLive's log has a base slot; typing log(x) fills the base with (x).
            if tok.value == "log" and "needs an argument" in e.message:
                e.hint = ("The visual editor put what you typed into the base slot of log. "
                          "Type log, press → to leave the base empty (base 10), then type the argument.")
            raise

    # --- LaTeX-only primaries ---
    def parse_special(self, tok):
        k = tok.kind
        start = tok.start
        if k == "{":
            opener = self.next()
            if self.at("}"):
                raise self.error("Empty braces {}.", opener)
            inner = self.parse_logic()
            self.expect("}", message="Expected '}'", opener=opener)
            return inner
        if k == "frac":
            self.next()
            num = self.frac_arg("numerator")
            den = self.frac_arg("denominator")
            d = _derivative_fraction(num, den)
            if d is not None:
                var, order = d
                return self.derivative_of(var, order, start)
            return self.node(A.BinOp, "/", num, den, start=start)
        if k == "lim":
            return self.parse_limit()
        if k == "int":
            return self.parse_integral()
        if k in ("sum", "prod"):
            return self.parse_sum(product=k == "prod")
        if k == "binom":
            self.next()
            n = self.frac_arg("top")
            r = self.frac_arg("bottom")
            return self.node(A.Call, "binom", [n, r], start=start)
        if k == "sqrt":
            self.next()
            index = None
            if self.at("["):
                opener = self.next()
                if self.at("placeholder"):
                    self.next()
                else:
                    index = self.parse_additive()
                self.expect("]", message="Expected ']' after the root index", opener=opener)
            arg = self.frac_arg("root")
            return self.node(A.Root, arg, index, start=start)
        if k == "abs_open":
            opener = self.next()
            if self.at("abs_close"):
                raise self.error("Empty absolute value bars.", opener)
            saved = self.abs_depth
            self.abs_depth = 0
            inner = self.parse_additive()
            self.abs_depth = saved
            self.expect("abs_close", message="Expected a closing '|'", opener=opener)
            return self.node(A.Abs, inner, start=start)
        if k in ("lfloor", "lceil"):
            opener = self.next()
            inner = self.parse_additive()
            closer = "rfloor" if k == "lfloor" else "rceil"
            self.expect(closer, message=f"Expected '\\{closer}'", opener=opener)
            return self.node(A.Call, "floor" if k == "lfloor" else "ceil", [inner], start=start)
        if k == "lbrace_d":
            opener = self.next()
            if self.at("begin"):
                inner = self.parse_environment()
                if self.at("rbrace_d") or self.at("nulldelim"):
                    self.next()
                inner.span = (start, self.last_end())
                return inner
            saved = self.abs_depth
            self.abs_depth = 0
            inner = self.parse_logic()
            self.abs_depth = saved
            self.expect("rbrace_d", message="Expected a closing brace", opener=opener)
            return inner
        if k == "begin":
            return self.parse_environment()
        if k == "placeholder":
            raise self.error("There is an empty box in the input. Fill it in or delete it.", tok)
        if k == "circ":
            raise self.error("The degree sign needs a number before it.", tok)
        if k == "later":
            what = LATER[tok.value]
            raise self.error(f"{what} aren't supported yet.", tok)
        if k == "to":
            raise self.error("'→' can only be used in limits.", tok)
        if k == "abs_close":
            raise self.error("A closing '|' without an opening one.", tok)
        if k in ("rowsep", "amp"):
            raise self.error("Unexpected line break or '&' outside a cases/matrix block.", tok)
        return None

    # --- calculus ---
    def parse_limit(self) -> A.Node:
        r"""\lim_{x\to a} expr, \lim_{x\to a^{+}} expr, \lim_{x\to\infty} expr."""
        tok = self.next()
        start = tok.start
        if not self.at("_"):
            raise self.error("A limit needs x → a under it: type lim, then x, Tab, the point.", tok)
        self.next()
        opener = self.expect("{", message="Expected '{' after \\lim_")
        if self.at("placeholder"):
            raise self.error("The limit has an empty box under it: fill in the variable and the point.", tok)
        var_tok = self.expect("name", message="Expected the variable under lim, e.g. x → 0")
        self.expect("to", message="Expected '→' after the variable (type -> or use Tab in the lim template)")
        if self.at("placeholder"):
            raise self.error("The point of the limit is empty.", tok)
        direction = self.limit_direction()
        point = self.parse_additive()
        self.expect("}", message="Expected '}' to close the limit's subscript", opener=opener)
        if self.at("end") or self.at("sep") or self.at("rel") or self.at(","):
            raise self.error("Nothing after the limit sign: write the expression after it.", tok)
        expr = self.parse_multiplicative()
        return self.node(A.Limit, expr, var_tok.value, point, direction, start=start)

    def limit_direction(self) -> str | None:
        """0^{+} / 0^+ / 0^{-}: remove the sign written as a superscript and return it."""
        depth, k = 0, self.i
        while k < len(self.toks):
            tk = self.toks[k]
            if tk.kind == "{":
                depth += 1
            elif tk.kind == "}":
                if depth == 0:
                    break
                depth -= 1
            elif tk.kind == "end":
                return None
            k += 1
        t = self.toks
        # ... ^ { + } }   or   ... ^ + }
        if k >= 4 and t[k - 1].kind == "}" and t[k - 2].kind == "op" and t[k - 2].value in "+-" \
                and t[k - 3].kind == "{" and t[k - 4].kind == "op" and t[k - 4].value == "^":
            sign = t[k - 2].value
            del t[k - 4:k]
            return sign
        if k >= 2 and t[k - 1].kind == "op" and t[k - 1].value in "+-" and t[k - 2].kind == "op" \
                and t[k - 2].value == "^":
            sign = t[k - 1].value
            del t[k - 2:k]
            return sign
        return None

    def parse_integral(self) -> A.Node:
        r"""\int_a^b expr\,dx  and  \int expr\,dx (empty boxes for the bounds: indefinite)."""
        tok = self.next()
        start = tok.start
        lower = upper = None
        seen = set()
        for _ in range(2):
            if self.at("_") and "_" not in seen:
                self.next()
                seen.add("_")
                lower = self.script(allow_empty=True)
            elif self.at("op", "^") and "^" not in seen:
                self.next()
                seen.add("^")
                upper = self.script(allow_empty=True)
        if (lower is None) != (upper is None):
            raise self.error("The integral needs both bounds (or neither, for an indefinite integral).", tok)
        # Find the differential d<var> that ends the integrand, at this bracket depth.
        depth, k = 0, self.i
        found = None
        while k + 1 < len(self.toks):
            tk = self.toks[k]
            if tk.kind in ("(", "[", "{", "lbrace_d", "abs_open", "begin"):
                depth += 1
            elif tk.kind in (")", "]", "}", "rbrace_d", "abs_close", "endenv"):
                depth -= 1
                if depth < 0:
                    break
            elif tk.kind in ("end", "sep", "rel"):
                break
            elif depth == 0 and tk.kind == "name" and tk.value == "d" and self.toks[k + 1].kind == "name" \
                    and len(self.toks[k + 1].value) == 1:
                found = k
                break
            k += 1
        if found is None:
            raise self.error("An integral must end with dx (or dt, ...), e.g. \\int_0^1 x\\,dx.", tok,
                             hint="Type the integrand, then d and the variable.")
        var = self.toks[found + 1].value
        self.toks[found] = Token("dvar", var, self.toks[found].start, self.toks[found + 1].end)
        del self.toks[found + 1]
        if self.at("dvar"):
            raise self.error("The integral is empty: write the function before d" + var + ".", tok)
        expr = self.parse_additive()
        self.expect("dvar", message=f"Expected d{var} after the integrand")
        return self.node(A.Integral, expr, var, lower, upper, start=start)

    def parse_sum(self, product: bool = False) -> A.Node:
        r"""\sum_{n=a}^{b} expr. The summand is the product right after Σ, or the whole
        sum of terms when a later term uses the summation variable. The same for \prod."""
        sign, kind, verb = ("∏", "product", "multiply") if product else ("Σ", "sum", "add up")
        inf = "" if product else " (∞ is allowed)"  # infinite products aren't worked out
        tok = self.next()
        start = tok.start
        sub = upper = None
        seen = set()
        for _ in range(2):
            if self.at("_") and "_" not in seen:
                self.next()
                seen.add("_")
                sub = self.script(allow_empty=True)
            elif self.at("op", "^") and "^" not in seen:
                self.next()
                seen.add("^")
                upper = self.script(allow_empty=True)
        if not (isinstance(sub, A.Rel) and sub.ops == ["="] and isinstance(sub.items[0], A.Name)
                and sub.items[0].name not in ("pi", "e", "inf")):
            raise self.error(f"Write the start of the {kind} under {sign}, e.g. n=1.", tok,
                             hint=f"Type {'prod' if product else 'sum'}, then n=1, Tab, the upper limit{inf}, "
                                  "Tab, the expression.")
        if upper is None:
            raise self.error(f"The {kind} needs an upper limit above {sign}{inf}.", tok)
        if self.at("end") or self.at("sep") or self.at("rel") or self.at(",") or self.at("placeholder"):
            raise self.error(f"Nothing after the {kind} sign: write the expression to {verb} after it.", tok)
        var = sub.items[0].name
        lower = sub.items[1]
        expr = self.parse_additive() if self._later_term_uses(var) else self.parse_multiplicative()
        return self.node(A.Product if product else A.Sum, expr, var, lower, upper, start=start)

    def _later_term_uses(self, var: str) -> bool:
        """Does a term after the first top-level + or - (before the end of this
        expression) use `var`?"""
        depth, k, after = 0, self.i, False
        opens = ("(", "[", "{", "lbrace_d", "abs_open", "begin", "lfloor", "lceil")
        closes = (")", "]", "}", "rbrace_d", "abs_close", "endenv", "rfloor", "rceil")
        while k < len(self.toks):
            tk = self.toks[k]
            if tk.kind in opens:
                depth += 1
            elif tk.kind in closes:
                depth -= 1
                if depth < 0:
                    return False
            elif depth == 0 and tk.kind in ("end", "sep", "rel", ",", "amp", "rowsep", "kw", "to"):
                return False
            elif depth == 0 and tk.kind == "op" and tk.value in "+-" and k > self.i:
                prev = self.toks[k - 1]
                if not (prev.kind in ("op", "_") and prev.value not in ("!", "'")):
                    after = True
            if after and tk.kind == "name" and (tk.value == var or tk.value.endswith("_" + var)):
                return True
            k += 1
        return False

    def frac_arg(self, what: str) -> A.Node:
        tok = self.peek()
        if tok.kind == "{":
            opener = self.next()
            if self.at("}"):
                raise self.error(f"The {what} is empty.", opener)
            inner = self.parse_logic()
            self.expect("}", message="Expected '}'", opener=opener)
            return inner
        if tok.kind == "num":
            return self.single_digit()
        if tok.kind in ("name", "const"):
            self.next()
            return self.node(A.Name, tok.value, start=tok.start)
        if tok.kind == "placeholder":
            raise self.error(f"The {what} is an empty box.", tok)
        return self.parse_primary()

    def parse_environment(self) -> A.Node:
        begin = self.next()
        env = begin.value
        start = begin.start
        if env not in ALIGN_ENVS | CASES_ENVS | MATRIX_ENVS:
            raise self.error(f"The '{env}' block isn't supported.", begin)
        rows: list[list[A.Node | None]] = []
        while True:
            row: list[A.Node | None] = []
            while True:
                if self.at("amp") or self.at("rowsep") or self.at("endenv", env):
                    row.append(None)
                else:
                    row.append(self.parse_cell(env, len(row)))
                if self.at("amp"):
                    self.next()
                    continue
                break
            rows.append(row)
            if self.at("rowsep"):
                self.next()
                if self.at("endenv", env):
                    break
                continue
            if self.at("endenv", env):
                break
            raise self.error(f"Expected '&', a new row, or the end of the {env} block, "
                             f"but found {self.describe(self.peek())}.")
        self.next()  # \end{env}
        rows = [r for r in rows if any(c is not None for c in r)]
        if not rows:
            raise self.error(f"The {env} block is empty.", begin)

        if env in MATRIX_ENVS and not (env == "array" and _has_relation(rows)):
            width = max(len(r) for r in rows)
            for r_i, r in enumerate(rows):
                if len(r) != width or any(c is None for c in r):
                    raise self.error(f"Row {r_i + 1} of the matrix has an empty or missing entry.", begin)
            return self.node(A.Matrix, rows, det=(env == "vmatrix"), start=start)

        if env in CASES_ENVS and any(len(r) > 1 for r in rows):
            branches = []
            for r_i, r in enumerate(rows):
                if len(r) > 2:
                    raise self.error(f"Row {r_i + 1} of the cases block has too many '&'.", begin)
                value = r[0]
                if value is None:
                    raise self.error(f"Row {r_i + 1} of the cases block has no value.", begin)
                cond = r[1] if len(r) > 1 else None
                if len(r) > 1 and cond is None:
                    raise self.error(f"Row {r_i + 1} of the cases block has an empty condition "
                                     "(write 'otherwise' if it applies everywhere else).", begin)
                if isinstance(value, A.Conditional) and cond is None:
                    branches.append((value.value, value.cond))
                elif cond is None and len(r) == 1:
                    raise self.error(f"Row {r_i + 1} of the cases block has no condition "
                                     "(write 'otherwise' if it applies everywhere else).", begin)
                else:
                    branches.append((value, None if isinstance(cond, _Otherwise) else cond))
            return self.node(A.Cases, branches, start=start)

        items = []
        for r in rows:
            cells = [c for c in r if c is not None]
            if len(cells) != 1:
                raise self.error("Each line of a system must hold one equation or inequality.", begin)
            items.append(cells[0])
        if env in CASES_ENVS and all(isinstance(it, A.Conditional) for it in items):
            return self.node(A.Cases, [(it.value, it.cond) for it in items], start=start)
        return self.node(A.System, items, start=start)

    def parse_cell(self, env: str, column: int) -> A.Node | None:
        if self.at("placeholder") and self.peek(1).kind in ("amp", "rowsep", "endenv"):
            self.next()  # an unfilled box, e.g. a row added with "+row"
            return None
        if env in CASES_ENVS and column == 1:
            if self.at(","):
                self.next()
            if self.at_kw(CONDITION_WORDS):
                self.next()
            if self.at_kw(OTHERWISE_WORDS):
                tok = self.next()
                return _Otherwise(span=(tok.start, tok.end))
            return self.parse_logic()
        if env in MATRIX_ENVS:
            return self.parse_logic()
        return self.parse_statement()


class _Otherwise(A.Node):
    pass


def _is_int(node: A.Node) -> bool:
    return isinstance(node, A.Num) and "." not in node.text


def _derivative_fraction(num: A.Node, den: A.Node):
    """\frac{d}{dx} -> ("x", 1); \frac{d^2}{dx^2} -> ("x", 2); otherwise None."""
    order = 1
    if isinstance(num, A.BinOp) and num.op == "^" and _is_d(num.left) and _is_int(num.right):
        order = int(num.right.text)
    elif not _is_d(num):
        return None
    if not (isinstance(den, A.BinOp) and den.op == "*" and _is_d(den.left)):
        return None
    v = den.right
    if order == 1 and isinstance(v, A.Name) and len(v.name) == 1:
        return v.name, 1
    if isinstance(v, A.BinOp) and v.op == "^" and isinstance(v.left, A.Name) and _is_int(v.right) \
            and int(v.right.text) == order:
        return v.left.name, order
    return None


def _is_d(node: A.Node) -> bool:
    return isinstance(node, A.Name) and node.name == "d"


def _is_dvar(node: A.Node) -> bool:
    return (isinstance(node, A.BinOp) and node.op == "*" and _is_d(node.left)
            and isinstance(node.right, A.Name))


def _has_relation(rows) -> bool:
    return any(isinstance(c, (A.Rel, A.InSet, A.Logic)) for r in rows for c in r if c is not None)


_DEF_RE = re.compile(
    r"(?<![A-Za-z\\])([A-Za-z])\s*(?:\^\{?\\prime\}?|')*\s*(?:\\left)?\(\s*[A-Za-z](?:_\{?\w+\}?)?\s*"
    r"(?:,\s*[A-Za-z]\s*)*(?:\\right)?\)\s*(?:=|\\coloneq)")


def find_user_functions(src: str) -> set[str]:
    names = set()
    for m in _DEF_RE.finditer(src):
        name = m.group(1)
        if name in CONSTANTS:
            raise ParseError(f"'{name}' can't be a function name: it means the constant e ≈ 2.718.",
                             span=m.span(1), source=src, hint="Pick another letter, for example f, g or h.")
        if canonical_function(name) is None:
            names.add(name)
    return names


def parse(src: str) -> list[A.Node]:
    """Parse LaTeX (from the visual editor) into a list of statements."""
    user_functions = find_user_functions(src)
    tokens = LatexLexer(src, user_functions).tokenize()
    return LatexParser(tokens, src, user_functions).parse_program()
