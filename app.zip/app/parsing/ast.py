"""Shared syntax tree produced by both input front ends (plain text and LaTeX).

Every node carries the span of source text it came from, so errors and
"interpreted as" echoes can point back at what the user typed.
"""
from __future__ import annotations

from dataclasses import dataclass, field

Span = tuple[int, int]


@dataclass
class Node:
    span: Span = field(default=(0, 0), kw_only=True, compare=False, repr=False)


@dataclass
class Num(Node):
    text: str  # as typed: "12", "2.5"


@dataclass
class Name(Node):
    """A variable or constant. Subscripted names are stored as "a_1"."""
    name: str


@dataclass
class BinOp(Node):
    op: str  # one of + - * / ^
    left: Node
    right: Node
    implicit: bool = False  # True for implicit multiplication such as 2x


@dataclass
class Neg(Node):
    operand: Node


@dataclass
class Call(Node):
    """Function application. For log, args may be [argument, base]."""
    name: str
    args: list[Node]
    primes: int = 0  # f'(x) has primes=1


@dataclass
class Abs(Node):
    arg: Node


@dataclass
class Root(Node):
    arg: Node
    index: Node | None = None  # None means square root


@dataclass
class Factorial(Node):
    arg: Node


@dataclass
class Degrees(Node):
    arg: Node


@dataclass
class Subscript(Node):
    """a_{n-1}: a name indexed by a non-trivial expression."""
    base: str
    index: Node


@dataclass
class Rel(Node):
    """A (possibly chained) comparison: items[0] ops[0] items[1] ops[1] ..."""
    ops: list[str]  # = != < <= > >=
    items: list[Node]


@dataclass
class Logic(Node):
    op: str  # "and" | "or"
    items: list[Node]


@dataclass
class Interval(Node):
    lo: Node
    hi: Node
    left_closed: bool
    right_closed: bool


@dataclass
class InSet(Node):
    """x in [0, 1)"""
    item: Node
    set: Node


@dataclass
class Cases(Node):
    """Piecewise: list of (value, condition); condition None means 'otherwise'."""
    branches: list[tuple[Node, Node | None]]


@dataclass
class System(Node):
    """Several statements grouped together, e.g. \\begin{cases} without conditions."""
    items: list[Node]


@dataclass
class Matrix(Node):
    rows: list[list[Node]]
    det: bool = False  # written with vertical bars (vmatrix)


@dataclass
class Seq(Node):
    """A bracketed list [a, b, c] or a parenthesised tuple (a, b)."""
    items: list[Node]
    bracket: str = "["


@dataclass
class Conditional(Node):
    """A statement guarded by a condition: `value if cond` (cond None = otherwise)."""
    value: Node
    cond: Node | None


@dataclass
class Limit(Node):
    """lim_{var -> point} expr; direction "+" (from the right), "-" or None (two-sided)."""
    expr: Node
    var: str
    point: Node
    direction: str | None = None


@dataclass
class Derivative(Node):
    """d^order/dvar^order expr"""
    expr: Node
    var: str | None
    order: int = 1


@dataclass
class Integral(Node):
    """Integral of expr d(var), from lower to upper (both None: indefinite)."""
    expr: Node
    var: str | None
    lower: Node | None = None
    upper: Node | None = None


@dataclass
class Sum(Node):
    """Sum of expr for var = lower, lower + 1, ..., upper (upper may be ∞ or a letter)."""
    expr: Node
    var: str
    lower: Node
    upper: Node


@dataclass
class Product(Node):
    """Product of expr for var = lower, lower + 1, ..., upper (upper may be ∞ or a letter)."""
    expr: Node
    var: str
    lower: Node
    upper: Node


def transform(node: Node, fn) -> Node:
    """Rebuild the tree bottom-up. fn(node) returns a replacement, or None to keep the node."""
    import dataclasses
    changes = {}
    for f in dataclasses.fields(node):
        if f.name == "span":
            continue
        old = getattr(node, f.name)
        new = _transform_value(old, fn)
        if new is not old:
            changes[f.name] = new
    if changes:
        node = dataclasses.replace(node, **changes)
    out = fn(node)
    return node if out is None else out


def _transform_value(v, fn):
    if isinstance(v, Node):
        return transform(v, fn)
    if isinstance(v, (list, tuple)):
        out = [_transform_value(x, fn) for x in v]
        if all(a is b for a, b in zip(out, v)):
            return v
        return out if isinstance(v, list) else tuple(out)
    return v


def walk(node: Node):
    """Yield node and all its descendants (depth first)."""
    yield node
    for child in children(node):
        yield from walk(child)


def children(node: Node) -> list[Node]:
    if isinstance(node, BinOp):
        return [node.left, node.right]
    if isinstance(node, (Neg,)):
        return [node.operand]
    if isinstance(node, Call):
        return list(node.args)
    if isinstance(node, (Abs, Factorial, Degrees)):
        return [node.arg]
    if isinstance(node, Root):
        return [node.arg] + ([node.index] if node.index is not None else [])
    if isinstance(node, Subscript):
        return [node.index]
    if isinstance(node, (Rel, Logic, System, Seq)):
        return list(node.items)
    if isinstance(node, Interval):
        return [node.lo, node.hi]
    if isinstance(node, InSet):
        return [node.item, node.set]
    if isinstance(node, Cases):
        out = []
        for value, cond in node.branches:
            out.append(value)
            if cond is not None:
                out.append(cond)
        return out
    if isinstance(node, Matrix):
        return [cell for row in node.rows for cell in row]
    if isinstance(node, Conditional):
        return [node.value] + ([node.cond] if node.cond is not None else [])
    if isinstance(node, Limit):
        return [node.expr, node.point]
    if isinstance(node, Derivative):
        return [node.expr]
    if isinstance(node, Integral):
        return [node.expr] + [b for b in (node.lower, node.upper) if b is not None]
    if isinstance(node, (Sum, Product)):
        return [node.expr, node.lower, node.upper]
    return []
