"""Expression parser shared by the plain-text and LaTeX front ends.

Both tokenizers produce the same token kinds, and this recursive-descent
parser turns them into the AST in `ast.py`. The LaTeX front end subclasses it
to handle LaTeX-only constructs (groups, \\frac, environments, ...).

Precedence, lowest first:
    or < and < relations / `in` < + - < * / and implicit multiplication
    < unary minus < ^ (right associative) < postfix ! ° %
Implicit multiplication has the same precedence as explicit `*`, so `1/2x`
means (1/2)·x. The "interpreted as" echo shows this to the user.
"""
from __future__ import annotations

from dataclasses import dataclass

from . import ast as A
from .errors import ParseError
from .names import CALCULUS_OPERATORS, DEFAULT_FUNCTION_LETTERS, FUNCTIONS, INVERSE_TRIG


@dataclass
class Token:
    kind: str   # num name const func kw op rel sep , ( ) [ ] | _ end ... (LaTeX adds more)
    value: str
    start: int
    end: int
    base: str | None = None  # log2 / log10 words carry their base here

    def __repr__(self):
        return f"{self.kind}:{self.value!r}@{self.start}"


CONDITION_WORDS = {"if", "for", "when"}
OTHERWISE_WORDS = {"otherwise", "else"}

# Token kinds that can begin an implicitly multiplied factor (2x, x(x+1), 3sin x).
IMPLICIT_START = {"num", "name", "const", "func", "(", "sqrt_sym", "["}


class Parser:
    def __init__(self, tokens: list[Token], source: str, user_functions=frozenset()):
        self.toks = tokens
        self.src = source
        self.i = 0
        self.abs_depth = 0
        self.user_functions = set(user_functions)

    # ----- token helpers -------------------------------------------------
    def peek(self, k: int = 0) -> Token:
        j = self.i + k
        return self.toks[j] if j < len(self.toks) else self.toks[-1]

    def next(self) -> Token:
        tok = self.peek()
        if tok.kind != "end":
            self.i += 1
        return tok

    def at(self, kind: str, value: str | None = None, k: int = 0) -> bool:
        tok = self.peek(k)
        return tok.kind == kind and (value is None or tok.value == value)

    def at_kw(self, words) -> bool:
        tok = self.peek()
        return tok.kind == "kw" and tok.value in words

    def prev(self) -> Token | None:
        return self.toks[self.i - 1] if self.i > 0 else None

    def last_end(self) -> int:
        p = self.prev()
        return p.end if p else 0

    def error(self, message: str, tok: Token | None = None, hint: str | None = None) -> ParseError:
        tok = tok or self.peek()
        if tok.kind == "end":
            span = (len(self.src), len(self.src))
        else:
            span = (tok.start, tok.end)
        return ParseError(message, span=span, hint=hint, source=self.src)

    def expect(self, kind: str, value: str | None = None, message: str | None = None,
               opener: Token | None = None) -> Token:
        if self.at(kind, value):
            return self.next()
        tok = self.peek()
        what = message or f"Expected '{value or kind}'"
        if tok.kind == "end":
            msg = what + " but the input ended."
        else:
            msg = what + f" but found {self.describe(tok)}."
        hint = None
        if opener is not None:
            hint = f"The bracket opened at position {opener.start + 1} is never closed."
        raise self.error(msg, tok, hint)

    def describe(self, tok: Token) -> str:
        if tok.kind == "end":
            return "the end of the input"
        text = self.src[tok.start:tok.end] or tok.value
        return f"'{text}'"

    def node(self, cls, *args, start: int, **kw):
        n = cls(*args, **kw)
        n.span = (start, self.last_end())
        return n

    # ----- program / statements ------------------------------------------
    def parse_program(self) -> list[A.Node]:
        stmts: list[A.Node] = []
        while True:
            while self.at("sep"):
                self.next()
            if self.at("end"):
                break
            stmts.append(self.parse_statement())
            if self.at(","):
                self.next()
                continue
            if self.at("sep") or self.at("end"):
                continue
            raise self.error(f"I couldn't understand {self.describe(self.peek())} here.",
                             hint=self.hint_for(self.peek()))
        return stmts

    def hint_for(self, tok: Token) -> str | None:
        if tok.kind == ")":
            return "There is a closing bracket without a matching opening one."
        if tok.kind == "|":
            return "Check that every | has a matching |."
        if tok.kind == "kw":
            return f"'{tok.value}' can't be used here."
        if tok.kind == "to":
            return "Arrows are only used in limits, e.g. lim(sin(x)/x, x -> 0)."
        return None

    def parse_statement(self) -> A.Node:
        start = self.peek().start
        value = self.parse_logic()
        if self.at(",") and self.peek(1).kind == "kw" and self.peek(1).value in CONDITION_WORDS | OTHERWISE_WORDS:
            self.next()
        if self.at_kw(CONDITION_WORDS):
            self.next()
            cond = self.parse_logic()
            return self.node(A.Conditional, value, cond, start=start)
        if self.at_kw(OTHERWISE_WORDS):
            self.next()
            return self.node(A.Conditional, value, None, start=start)
        return value

    # ----- logic and relations -------------------------------------------
    def parse_logic(self) -> A.Node:
        start = self.peek().start
        items = [self.parse_and()]
        while self.at_kw({"or"}):
            self.next()
            items.append(self.parse_and())
        return items[0] if len(items) == 1 else self.node(A.Logic, "or", items, start=start)

    def parse_and(self) -> A.Node:
        start = self.peek().start
        items = [self.parse_relation()]
        while self.at_kw({"and"}):
            self.next()
            items.append(self.parse_relation())
        return items[0] if len(items) == 1 else self.node(A.Logic, "and", items, start=start)

    def parse_relation(self) -> A.Node:
        start = self.peek().start
        first = self.parse_additive()
        if self.at_kw({"in"}):
            self.next()
            s = self.parse_set()
            return self.node(A.InSet, first, s, start=start)
        if not self.at("rel"):
            return first
        ops, items = [], [first]
        while self.at("rel"):
            ops.append(self.next().value)
            if self.at("end") or self.at("sep"):
                raise self.error(f"Nothing after '{ops[-1]}'.")
            items.append(self.parse_additive())
        return self.node(A.Rel, ops, items, start=start)

    def parse_set(self) -> A.Node:
        start = self.peek().start
        if self.at("(") or self.at("["):
            opener = self.next()
            lo = self.parse_additive()
            self.expect(",", message="Expected ',' between the interval ends")
            hi = self.parse_additive()
            if not (self.at(")") or self.at("]")):
                self.expect(")", message="Expected ')' or ']' to close the interval", opener=opener)
            closer = self.next()
            return self.node(A.Interval, lo, hi, opener.kind == "[", closer.kind == "]", start=start)
        raise self.error("Expected an interval such as [0, 2pi] or (0, 1] after 'in'.")

    # ----- arithmetic ------------------------------------------------------
    def parse_additive(self) -> A.Node:
        start = self.peek().start
        left = self.parse_multiplicative()
        while self.at("op", "+") or self.at("op", "-"):
            op = self.next().value
            if self.at("end") or self.at("sep") or self.at(")"):
                raise self.error(f"Missing a term after '{op}'.")
            right = self.parse_multiplicative()
            left = self.node(A.BinOp, op, left, right, start=start)
        return left

    def parse_multiplicative(self) -> A.Node:
        start = self.peek().start
        left = self.parse_unary()
        while True:
            if self.at("op", "*") or self.at("op", "/"):
                op = self.next().value
                if self.at("end") or self.at("sep") or self.at(")"):
                    raise self.error(f"Missing something after '{op}'.")
                right = self.parse_unary()
                left = self.node(A.BinOp, op, left, right, start=start)
            elif self.starts_implicit():
                left = self.parse_implicit(left, start)
            else:
                break
        return left

    def starts_implicit(self) -> bool:
        tok = self.peek()
        if tok.kind == "|":
            return self.abs_depth == 0
        return tok.kind in IMPLICIT_START

    def parse_implicit(self, left: A.Node, start: int) -> A.Node:
        prev, tok = self.prev(), self.peek()
        if tok.kind == "num" and prev is not None and prev.kind == "num":
            raise self.error(
                f"Two numbers in a row: '{prev.value} {tok.value}'.",
                tok, hint=f"Write {prev.value}*{tok.value} to multiply, or remove the space.")
        right = self.parse_power()
        return self.node(A.BinOp, "*", left, right, implicit=True, start=start)

    def parse_unary(self) -> A.Node:
        start = self.peek().start
        if self.at("op", "-"):
            self.next()
            operand = self.parse_unary()
            return self.node(A.Neg, operand, start=start)
        if self.at("op", "+"):
            self.next()
            return self.parse_unary()
        return self.parse_power()

    def parse_power(self) -> A.Node:
        start = self.peek().start
        base = self.parse_postfix()
        if self.at("op", "^"):
            self.next()
            exp = self.parse_exponent()
            if isinstance(exp, A.Degrees):  # LaTeX x^{\circ}
                return self.node(A.Degrees, base, start=start)
            return self.node(A.BinOp, "^", base, exp, start=start)
        return base

    def parse_exponent(self) -> A.Node:
        # Plain text: right associative and allows a sign, as in 2^-x.
        if self.at("end") or self.at("sep"):
            raise self.error("Missing exponent after '^'.")
        return self.parse_unary()

    def parse_postfix(self) -> A.Node:
        start = self.peek().start
        node = self.parse_primary()
        while True:
            if self.at("op", "!"):
                self.next()
                node = self.node(A.Factorial, node, start=start)
            elif self.at("op", "°") or self.at("circ"):
                self.next()
                node = self.node(A.Degrees, node, start=start)
            elif self.at("op", "%"):
                tok = self.next()
                hundred = A.Num("100", span=(tok.start, tok.end))
                node = self.node(A.BinOp, "/", node, hundred, start=start)
            else:
                return node

    # ----- primaries -------------------------------------------------------
    def parse_primary(self) -> A.Node:
        tok = self.peek()
        start = tok.start
        k = tok.kind
        if k == "num":
            self.next()
            return self.node(A.Num, tok.value, start=start)
        if k == "const":
            self.next()
            return self.node(A.Name, tok.value, start=start)
        if k == "name":
            return self.parse_name()
        if k == "func":
            return self.parse_function()
        if k == "(":
            return self.parse_paren()
        if k == "[":
            return self.parse_bracket()
        if k == "|":
            return self.parse_abs()
        if k == "sqrt_sym":
            self.next()
            index = A.Num(tok.value, span=(tok.start, tok.end)) if tok.value != "2" else None
            arg = self.parse_power()
            return self.node(A.Root, arg, index, start=start)
        special = self.parse_special(tok)
        if special is not None:
            return special
        if k == "end":
            raise self.error("The input ended too early: something is missing at the end.")
        if k == "kw":
            raise self.error(f"'{tok.value}' can't be used here.", tok)
        if k in (")", "]"):
            raise self.error(f"Unexpected {self.describe(tok)}: there's no matching opening bracket, "
                             "or something is missing before it.", tok)
        if k == "rel":
            raise self.error(f"Missing something before {self.describe(tok)}.", tok)
        if k == "to":
            raise self.error("An arrow can only be used in a limit.", tok,
                             hint="Write limits as lim(sin(x)/x, x -> 0).")
        if k == "op":
            raise self.error(f"Missing something before {self.describe(tok)}.", tok)
        raise self.error(f"Unexpected {self.describe(tok)}.", tok)

    def parse_special(self, tok: Token) -> A.Node | None:
        """Hook for front-end specific primaries. Returns None if not handled."""
        return None

    def parse_name(self) -> A.Node:
        if self.peek().value == "d":
            d = self.derivative_operator()
            if d is not None:
                return d
        tok = self.next()
        start = tok.start
        name = tok.value
        if self.is_function_name(name):
            primes = self.parse_primes()
            if self.at("("):
                args = self.parse_call_args()
                return self.node(A.Call, name, args, primes=primes, start=start)
            if primes:
                raise self.error(f"Expected '(' after {name}{chr(39) * primes}.")
        if self.at("_"):
            self.next()
            sub = self.parse_subscript()
            if sub is None:
                return self.node(A.Name, name, start=start)
            if isinstance(sub, (A.Rel, A.Logic, A.InSet)):
                raise ParseError(
                    f"The subscript of {name} contains a comparison.", span=sub.span, source=self.src,
                    hint="In the visual editor, press → to leave the subscript before typing '='.")
            if isinstance(sub, A.Num) and "." not in sub.text:
                return self.node(A.Name, f"{name}_{sub.text}", start=start)
            if isinstance(sub, A.Name) and "_" not in sub.name:
                return self.node(A.Name, f"{name}_{sub.name}", start=start)
            return self.node(A.Subscript, name, sub, start=start)
        return self.node(A.Name, name, start=start)

    def is_function_name(self, name: str) -> bool:
        return name in self.user_functions or name in DEFAULT_FUNCTION_LETTERS

    def parse_primes(self) -> int:
        primes = 0
        while self.at("op", "'"):
            self.next()
            primes += 1
        return primes

    def parse_subscript(self) -> A.Node:
        # Plain text: a_1, a_n, a_(n-1)
        start = self.peek().start
        if self.at("("):
            opener = self.next()
            inner = self.parse_additive()
            self.expect(")", opener=opener)
            return inner
        if self.at("num") or self.at("name") or self.at("const"):
            tok = self.next()
            if tok.kind == "num":
                return self.node(A.Num, tok.value, start=start)
            return self.node(A.Name, tok.value, start=start)
        raise self.error("Expected a subscript after '_', such as a_1 or a_(n-1).")

    def parse_call_args(self) -> list[A.Node]:
        opener = self.expect("(")
        if self.at(")"):
            raise self.error("Empty parentheses: this function needs an argument.")
        args = [self.parse_logic()]
        while self.at(","):
            self.next()
            args.append(self.parse_logic())
        self.expect(")", message="Expected ')' to close the function call", opener=opener)
        return args

    def parse_function(self) -> A.Node:
        if self.peek().value in CALCULUS_OPERATORS:
            return self.parse_calculus_call()
        tok = self.next()
        start = tok.start
        name = tok.value
        base: A.Node | None = None
        if tok.base is not None:
            base = A.Num(tok.base, span=(tok.start, tok.end))
        power: A.Node | None = None
        for _ in range(2):
            if self.at("op", "^") and power is None:
                self.next()
                power = self.parse_function_power()
            elif self.at("_") and name == "log" and base is None:
                self.next()
                base = self.parse_subscript()
        if self.at("("):
            args = self.parse_call_args()
        else:
            if not (self.starts_implicit() or self.at("op", "-")):
                raise self.error(f"'{self.src[tok.start:tok.end]}' needs an argument.", tok)
            args = [self.parse_function_argument()]
        if name == "log":
            if base is not None:
                if len(args) != 1:
                    raise self.error("log has a base written twice.", tok)
                args = [args[0], base]
        lo, hi = FUNCTIONS[name]
        if not lo <= len(args) <= hi:
            want = str(lo) if lo == hi else f"{lo} to {hi}"
            raise self.error(f"{name} takes {want} argument(s) but got {len(args)}.", tok)
        if power is not None and _is_minus_one(power):
            if name in INVERSE_TRIG:
                return self.node(A.Call, INVERSE_TRIG[name], args, start=start)
            raise self.error(f"{name}^(-1) is ambiguous here; write 1/{name}(...) for the reciprocal.", tok)
        call = self.node(A.Call, name, args, start=start)
        if power is not None:
            return self.node(A.BinOp, "^", call, power, start=start)
        return call

    def parse_function_power(self) -> A.Node:
        return self.parse_exponent()

    def parse_function_argument(self) -> A.Node:
        """Argument of a function written without parentheses: sin 2x, ln x.

        Takes a product of factors (2x, x y) but stops at the next function
        name or any explicit operator, so `sin x cos x` is sin(x)·cos(x) and
        `ln x + 1` is ln(x) + 1.
        """
        start = self.peek().start
        if self.at("op", "-"):
            self.next()
            inner = self.parse_function_argument()
            return self.node(A.Neg, inner, start=start)
        left = self.parse_power()
        while self.starts_implicit() and not self.at("func"):
            left = self.parse_implicit(left, start)
        return left

    def parse_paren(self) -> A.Node:
        opener = self.next()
        start = opener.start
        if self.at(")"):
            raise self.error("Empty parentheses.", opener)
        saved_depth = self.abs_depth
        self.abs_depth = 0
        first = self.parse_logic()
        items = [first]
        while self.at(","):
            self.next()
            items.append(self.parse_logic())
        self.abs_depth = saved_depth
        self.expect(")", message="Expected ')'", opener=opener)
        if len(items) == 1:
            return first
        return self.node(A.Seq, items, "(", start=start)

    def parse_bracket(self) -> A.Node:
        opener = self.next()
        start = opener.start
        if self.at("]"):
            raise self.error("Empty brackets.", opener)
        saved_depth = self.abs_depth
        self.abs_depth = 0
        items = [self.bracket_item()]
        while self.at(","):
            self.next()
            items.append(self.bracket_item())
        self.abs_depth = saved_depth
        self.expect("]", message="Expected ']'", opener=opener)
        if len(items) == 1 and not isinstance(items[0], A.Seq):
            return items[0]
        if all(isinstance(it, A.Seq) and it.bracket == "[" for it in items):
            widths = {len(it.items) for it in items}
            if len(widths) != 1:
                raise self.error("Matrix rows have different lengths.", opener)
            return self.node(A.Matrix, [list(it.items) for it in items], start=start)
        return self.node(A.Seq, items, "[", start=start)

    def bracket_item(self) -> A.Node:
        """One item of a [...] list. An item that is a whole [x] of its own is a row
        with one entry, so [[1], [2]] is a column vector (not the list [1, 2])."""
        first = self.i
        item = self.parse_logic()
        if self.toks[first].kind == "[" and not isinstance(item, A.Seq) and self._closes_at(first, self.i - 1):
            return A.Seq([item], "[", span=item.span)
        return item

    def _closes_at(self, open_i: int, close_i: int) -> bool:
        depth = 0
        for k in range(open_i, close_i + 1):
            kind = self.toks[k].kind
            if kind == "[":
                depth += 1
            elif kind == "]":
                depth -= 1
                if depth == 0:
                    return k == close_i
        return False

    def parse_abs(self) -> A.Node:
        opener = self.next()
        start = opener.start
        self.abs_depth += 1
        inner = self.parse_additive()
        self.abs_depth -= 1
        self.expect("|", message="Expected a closing '|'", opener=opener)
        return self.node(A.Abs, inner, start=start)


    # ----- calculus ---------------------------------------------------------
    def derivative_operator(self) -> A.Node | None:
        """d/dx expr  or  d^2/dx^2 expr (plain text: the tokens d / d x)."""
        t = [self.peek(k) for k in range(8)]

        def is_(k, kind, value=None):
            return t[k].kind == kind and (value is None or t[k].value == value)
        start = t[0].start
        if is_(1, "op", "/") and is_(2, "name", "d") and is_(3, "name") and len(t[3].value) == 1:
            order, var, used = 1, t[3].value, 4
        elif is_(1, "op", "^") and is_(2, "num") and is_(3, "op", "/") and is_(4, "name", "d") \
                and is_(5, "name") and is_(6, "op", "^") and is_(7, "num") and t[2].value == t[7].value:
            order, var, used = int(t[2].value), t[5].value, 8
        else:
            return None
        for _ in range(used):
            self.next()
        return self.derivative_of(var, order, start)

    def derivative_of(self, var: str, order: int, start: int) -> A.Node:
        if self.at("end") or self.at("sep") or self.at(",") or self.at(")") or self.at("rel"):
            raise self.error("Nothing to differentiate after d/d" + var + ".",
                             hint="Write the function after it, e.g. d/dx (x^2 ln x).")
        if order < 1 or order > 20:
            raise self.error("The order of a derivative must be between 1 and 20.")
        operand = self.parse_multiplicative()
        return self.node(A.Derivative, operand, var, order, start=start)

    def parse_calculus_call(self) -> A.Node:
        """lim(expr, x -> a), lim(expr, x -> a+), diff(expr, x, n), int(expr, x, a, b)."""
        tok = self.next()
        name, start = tok.value, tok.start
        examples = {"lim": "lim(sin(x)/x, x -> 0)", "int": "int(x e^x, x, 0, 1)", "diff": "diff(x^2 ln(x), x)",
                    "sum": "sum(1/n^2, n, 1, inf)", "prod": "prod(1 + 1/k, k, 1, n)"}
        if not self.at("("):
            raise self.error(f"Write {name} with brackets, e.g. {examples[name]}.", tok)
        opener = self.next()
        expr = self.parse_logic()
        if name in ("sum", "prod"):
            return self.parse_sum_bounds(expr, opener, start, name)
        if name == "lim":
            self.expect(",", message="Expected ', x -> point' after the expression")
            var = self.expect("name", message="Expected the variable, e.g. x").value
            if self.at("to") or self.at(","):
                self.next()
            else:
                raise self.error("Expected '->' after the variable, e.g. lim(sin(x)/x, x -> 0).")
            direction = self.take_direction(")")
            point = self.parse_additive()
            self.expect(")", message="Expected ')' to close lim(...)", opener=opener)
            return self.node(A.Limit, expr, var, point, direction, start=start)
        extra = []
        while self.at(","):
            self.next()
            extra.append(self.parse_additive())
        self.expect(")", message=f"Expected ')' to close {name}(...)", opener=opener)
        if name == "diff":
            var, order = None, 1
            if extra:
                if not isinstance(extra[0], A.Name):
                    raise ParseError("The second argument of diff is the variable, e.g. diff(x^3, x).",
                                     span=extra[0].span, source=self.src)
                var = extra[0].name
            if len(extra) > 1:
                n = extra[1]
                if not (isinstance(n, A.Num) and n.text.isdigit()):
                    raise ParseError("The third argument of diff is the order: a whole number, "
                                     "e.g. diff(sin(x), x, 2).", span=n.span, source=self.src)
                order = int(n.text)
            if len(extra) > 2:
                raise self.error("diff takes at most 3 arguments: diff(expression, x, order).", tok)
            return self.node(A.Derivative, expr, var, order, start=start)
        # int
        var, lower, upper = None, None, None
        if len(extra) == 1 or len(extra) == 3:
            if not isinstance(extra[0], A.Name):
                raise ParseError("The second argument of int is the variable, e.g. int(x^2, x, 0, 1).",
                                 span=extra[0].span, source=self.src)
            var = extra[0].name
            extra = extra[1:]
        if len(extra) == 2:
            lower, upper = extra
        elif extra:
            raise self.error("Write int(expression, x) or int(expression, x, from, to).", tok)
        return self.node(A.Integral, expr, var, lower, upper, start=start)

    def parse_sum_bounds(self, expr: A.Node, opener: Token, start: int, name: str = "sum") -> A.Node:
        """The rest of sum(expr, n, a, b) or sum(expr, n = a, b); the same for prod."""
        usage = ("Write sum(expression, n, from, to), e.g. sum(1/n^2, n, 1, inf)." if name == "sum"
                 else "Write prod(expression, k, from, to), e.g. prod(1 + 1/k, k, 1, n).")
        what = "summation" if name == "sum" else "product's"
        self.expect(",", message="Expected ', n, from, to' after the expression")
        if not self.at("name"):
            raise self.error(f"Expected the {what} variable, e.g. n.", hint=usage)
        var = self.next().value
        if self.at("rel", "="):
            self.next()
        else:
            self.expect(",", message=f"Expected ',' after the {what} variable")
        lower = self.parse_additive()
        self.expect(",", message="Expected ', to' after the lower bound")
        upper = self.parse_additive()
        if self.at(","):
            raise self.error(f"{name} takes the expression, the variable and two bounds.", hint=usage)
        self.expect(")", message=f"Expected ')' to close {name}(...)", opener=opener)
        return self.node(A.Sum if name == "sum" else A.Product, expr, var, lower, upper, start=start)

    def take_direction(self, closer: str) -> str | None:
        """For a limit point written 0+ or 0- (one-sided): remove the trailing sign
        before `closer` and return it."""
        depth, k = 0, self.i
        while k < len(self.toks):
            tk = self.toks[k]
            if tk.kind in ("(", "[", "{", "lbrace_p"):
                depth += 1
            elif tk.kind in (")", "]", "}", "rbrace_p"):
                if depth == 0:
                    break
                depth -= 1
            elif tk.kind in ("end", "sep"):
                return None
            k += 1
        if k >= len(self.toks) or self.toks[k].kind != closer or k - 1 < self.i:
            return None
        prev = self.toks[k - 1]
        if prev.kind == "op" and prev.value in "+-" and k - 2 >= self.i \
                and self.toks[k - 2].kind not in ("op", "to", ","):
            del self.toks[k - 1]
            return prev.value
        return None


def _is_minus_one(node: A.Node) -> bool:
    return isinstance(node, A.Neg) and isinstance(node.operand, A.Num) and node.operand.text == "1"
