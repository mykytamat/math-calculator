"""Graph data sent to the browser.

Two kinds of curve:
  * "js": an ordinary expression (piecewise allowed) compiled to JavaScript.
    The browser samples it itself on every zoom/pan, splitting the line at
    the exact break points sent along (singularities, case boundaries,
    periodic families like pi/2 + k*pi).
  * "segments": a recursive function (or one using something JavaScript
    can't compute). The server samples it between its exact break points,
    and checks that the recursion takes the same path across each piece;
    the browser asks for new samples when the view changes ("refetch").

Dots at break points: closed where the function is defined (value computed
exactly), open at one-sided limits that differ from it or where the
function is undefined (holes).
"""
from __future__ import annotations

import math

import sympy as sp

from ..core.functions import Case, FunctionDef, FunctionTable
from ..core.recursion import Evaluator, exact
from ..parsing import MathError
from .breaks import Breaks, expression_breaks, function_breaks
from .jsprint import to_js
from .numeric import NumericFunctions

AppliedUndef = sp.core.function.AppliedUndef

DOT_TOL = 1e-7
MAX_DOTS = 400
MAX_DOT_POINTS = 150   # break points in view beyond which dots are skipped (zoom in to see them)


def _f(v) -> float | None:
    try:
        f = float(v)
    except (TypeError, ValueError, OverflowError):
        return None
    return f if math.isfinite(f) else None


def _clean(ys):
    return [y if (y is not None and math.isfinite(y)) else None for y in ys]


def label_for(fd: FunctionDef) -> str:
    return f"{fd.name}({', '.join(str(p) for p in fd.params)})"


# ---------------------------------------------------------------- dots ------
def _dots(points, value_at, limit_at, window) -> list[dict]:
    """Dots at break points.

    value_at(b) -> exact value or None (undefined);
    limit_at(b, side) -> float one-sided limit or None (none / infinite).
    Where the function is continuous no dot is drawn. Otherwise: a closed dot at
    the value (if defined) and an open dot at each one-sided limit that differs."""
    lo, hi = window

    def close(a, b):
        return abs(a - b) <= DOT_TOL * max(1.0, abs(b))

    out = []
    for b in sorted(points, key=float):
        bf = float(b)
        if not lo <= bf <= hi:
            continue
        v = value_at(b)
        vf = _f(v) if v is not None else None
        left, right = limit_at(b, "-"), limit_at(b, "+")
        if vf is not None and left is not None and right is not None and close(left, vf) and close(right, vf):
            continue  # continuous here
        if vf is not None:
            out.append({"x": bf, "y": vf, "open": False})
        drawn = []
        for L in (left, right):
            if L is None or (vf is not None and close(L, vf)) or any(close(L, d) for d in drawn):
                continue
            drawn.append(L)
            out.append({"x": bf, "y": L, "open": True})
        if len(out) > MAX_DOTS:
            break
    return out


# ------------------------------------------------------- expression trace ---
def expression_trace(expr, x: sp.Symbol, label: str, conditions=(), window=(-10, 10)) -> dict:
    """An ordinary one-variable expression."""
    expr = sp.sympify(expr)
    lo, hi = window
    br = expression_breaks(expr, x, conditions, sp.Interval(lo, hi))
    js = to_js(expr)
    trace = {"label": label, "kind": "js" if js else "segments", "js": js,
             "breaks": _break_list(br, window), "periodic": [[float(a), float(p)] for a, p in br.periodic],
             "dots": [], "refetch": js is None, "approximate": br.approximate}
    # Holes: points where the expression is undefined but has a finite limit, e.g. (x^2-1)/(x-1) at 1.
    def value_at(b):
        try:
            v = exact(expr.subs(x, b))
        except Exception:
            return None
        if v.has(sp.nan, sp.zoo, sp.oo, -sp.oo) or v.is_real is False:
            return None
        for c in conditions:
            try:
                if c.subs({x: b}).as_relational() is sp.false:
                    return None
            except Exception:
                pass
        return v

    fnum = sp.lambdify(x, expr, modules="math")

    def real_near(b, side) -> bool:
        """Is the expression real just beside b? (SymPy's limit works in complex
        numbers and would say sqrt(x-1) -> 0 from the left of 1.)"""
        bf = float(b)
        h = 1e-7 * max(1.0, abs(bf))
        try:
            v = fnum(bf - h if side == "-" else bf + h)
            return not isinstance(v, complex) and math.isfinite(float(v))
        except Exception:
            return False

    def limit_at(b, side):
        if not real_near(b, side) or sp.count_ops(expr) > 120:
            return None
        try:
            return _f(sp.limit(expr, x, b, side))
        except Exception:
            return None

    # Dots at singular points and domain edges: holes such as (x^2-1)/(x-1) at 1,
    # endpoints such as sqrt(x-1) at 1. Points where the expression is continuous get none.
    candidates = sorted(br.points, key=float)
    candidates = [b for b in candidates if lo <= float(b) <= hi][:40]
    trace["dots"] = _dots(candidates, value_at, limit_at, window)
    if js is None:
        trace["segments"] = _sample_simple(fnum, br, window)
    return trace


def _break_list(br: Breaks, window) -> list[float]:
    lo, hi = window
    pts = sorted({_f(p) for p in br.points if _f(p) is not None})
    return [p for p in pts if lo - 1e-9 <= p <= hi + 1e-9]


def _sample_simple(f, br: Breaks, window) -> list[dict]:
    lo, hi = window
    xs = _grid(lo, hi, 800)
    ys = []
    for v in xs:
        try:
            y = f(v)
            y = float(y.real) if isinstance(y, complex) and abs(y.imag) < 1e-12 else float(y)
        except Exception:
            y = None
        ys.append(y)
    return [{"x": xs, "y": _clean(ys)}]


def _grid(a: float, b: float, n: int) -> list[float]:
    if n <= 1 or b <= a:
        return [a]
    return [a + (b - a) * i / (n - 1) for i in range(n)]


# --------------------------------------------------------- function trace ---
def function_trace(table: FunctionTable, fd: FunctionDef, window=(-10, 10), depth_limit: int = 1000) -> dict:
    """A user function: compiled to JavaScript when it is an ordinary
    (possibly piecewise) formula, sampled on the server when recursive."""
    if fd.arity != 1:
        raise MathError(f"{fd.name} has {fd.arity} variables; only one-variable functions are graphed.")
    lo, hi = window
    uses_functions = bool(fd.calls() & set(table.functions))
    br = function_breaks(table, fd.name, sp.Interval(lo, hi))
    ev = Evaluator(table, depth_limit)

    def value_at(b):
        try:
            return ev.evaluate(sp.Function(fd.name)(b)).value
        except MathError:
            return None
        except Exception:
            return None

    body = None if uses_functions else fd.body()
    js = to_js(body) if body is not None else None
    trace = {"label": label_for(fd), "kind": "js" if js else "segments", "js": js,
             "breaks": _break_list(br, window), "periodic": [[float(a), float(p)] for a, p in br.periodic],
             "dots": [], "refetch": js is None, "approximate": br.approximate}
    num = NumericFunctions(table, depth_limit=min(depth_limit, 250))
    if js is None:
        segments, extra = _sample_function(num, fd.name, br, window)
        trace["segments"] = segments
        if extra:
            trace["approximate"] = True
            trace["breaks"] = sorted(set(trace["breaks"]) | set(extra))
    # Dots at case boundaries and recursion break points (not at plain singularities).
    boundary_points = br.points

    def limit_at(b, side):
        return _numeric_side_limit(num, fd, b, side, br, window, exact_body=body)

    in_view = [b for b in boundary_points if lo <= float(b) <= hi]
    if len(in_view) > MAX_DOT_POINTS or br.too_many:
        trace["note"] = (f"{label_for(fd)} has too many break points in this range to mark each one; "
                         "zoom in to see the endpoint dots.")
    else:
        trace["dots"] = _dots(in_view, value_at, limit_at, window)
    return trace


def _numeric_side_limit(num: NumericFunctions, fd: FunctionDef, b, side, br, window, exact_body=None):
    """One-sided limit at a break point. For a non-recursive piecewise function
    the neighbouring case's formula is evaluated exactly at b; otherwise the
    limit is extrapolated from two nearby values."""
    bf = float(b)
    pts = sorted(_f(p) for p in br.points if _f(p) is not None)
    gap = min([abs(p - bf) for p in pts if abs(p - bf) > 0] + [1.0])
    h = min(1e-6 * max(1.0, abs(bf)), gap / 1000)
    sign = -1 if side == "-" else 1
    v1, path = num.with_path(fd.name, bf + sign * h)
    v2 = num(fd.name, bf + 2 * sign * h)
    if not (math.isfinite(v1) and math.isfinite(v2)):
        return None
    if exact_body is not None and path:
        case: Case = fd.ordered()[path[0][1]]
        try:
            L = exact(sp.sympify(case.value).subs(fd.params[0], b))
            Lf = _f(L)
            if Lf is not None and L.is_real is not False:
                return Lf
        except Exception:
            pass
    L = 2 * v1 - v2
    span = abs(window[1] - window[0])
    if abs(L) > 1e6 * max(1.0, span) or abs(v1 - v2) > 1e-3 * max(1.0, abs(v1)):
        return None  # blowing up near an asymptote: no dot
    return L


def _sample_function(num: NumericFunctions, name: str, br: Breaks, window, total: int = 900):
    """Sample between consecutive break points. Inside each piece the recursion
    path must stay the same; where it changes, the switch point is found by
    bisection and treated as an (approximate) extra break."""
    lo, hi = window
    cuts = sorted({lo, hi} | {p for p in (_f(q) for q in br.points) if p is not None and lo < p < hi})
    segments = []
    extra_breaks = []
    width = hi - lo
    for a, b in zip(cuts, cuts[1:]):
        if b - a <= 0:
            continue
        many = len(cuts) > 120
        n = max(2 if many else 6, min(400, int(total * (b - a) / width) + 2))
        eps = (b - a) * 1e-7
        xs = [a + eps] + [a + (b - a) * (i + 0.5) / n for i in range(n)] + [b - eps]
        vals = [num.with_path(name, v) for v in xs]
        # Split where the path changes (a break point the exact search missed).
        cur_x, cur_y = [xs[0]], [vals[0][0]]
        for (x0, (y0, p0)), (x1, (y1, p1)) in zip(zip(xs, vals), zip(xs[1:], vals[1:])):
            if p0 != p1 and p0 and p1:
                s = _bisect_path(num, name, x0, x1, p0)
                extra_breaks.append(s)
                segments.append({"x": cur_x, "y": _clean(cur_y)})
                cur_x, cur_y = [], []
            cur_x.append(x1)
            cur_y.append(y1)
        segments.append({"x": cur_x, "y": _clean(cur_y)})
    return segments, extra_breaks


def _bisect_path(num, name, a, b, path_a) -> float:
    for _ in range(60):
        m = (a + b) / 2
        if m == a or m == b:
            break
        if num.with_path(name, m)[1] == path_a:
            a = m
        else:
            b = m
    return (a + b) / 2


# ------------------------------------------------------------- graph item ---
def graph_spec(traces: list[dict], window, notes=(), source: dict | None = None) -> dict:
    return {"x_range": [float(window[0]), float(window[1])], "traces": traces,
            "notes": list(notes), "source": source}
