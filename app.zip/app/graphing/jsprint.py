"""Compile SymPy expressions to JavaScript for in-browser plotting.

The browser re-samples functions itself on zoom and pan, so the server only
sends this code once. It is generated from SymPy objects (never from the raw
input text), and symbol names are restricted to letters, digits and `_`.

Real-number semantics match the rest of the app: fractional powers of
negative numbers are NaN (gaps in the graph), the real odd root of a negative
number is negative, logs of non-positive numbers are NaN.
"""
from __future__ import annotations

import re

import sympy as sp
from sympy.printing.jscode import JavascriptCodePrinter

_SAFE_NAME = re.compile(r"^[A-Za-z][A-Za-z0-9_]*$")


class Unsupported(Exception):
    pass


class _JS(JavascriptCodePrinter):
    def __init__(self):
        super().__init__({"strict": True})

    def _print_Pow(self, expr):
        b, e = expr.as_base_exp()
        if e.is_Rational and not e.is_Integer:
            # Math.cbrt would give the real cube root of a negative base; the app
            # treats x^(1/3) as defined for x >= 0 only, like Math.pow does.
            if e == sp.S.Half:
                return f"Math.sqrt({self._print(b)})"
            return f"Math.pow({self._print(b)}, {self._print(e.p)}/{self._print(e.q)})"
        if e.is_Integer and e < 0:
            return f"(1/{self._print(sp.Pow(b, -e, evaluate=False))})"
        if e.is_Integer and e == 2:
            s = self._print(b)
            return f"(({s})*({s}))"
        return f"Math.pow({self._print(b)}, {self._print(e)})"

    def _print_Piecewise(self, expr):
        out = "NaN"
        for value, cond in reversed(expr.args):
            if cond is sp.true:
                out = f"({self._print(value)})"
            else:
                out = f"(({self._print(cond)}) ? ({self._print(value)}) : {out})"
        return out

    def _print_Symbol(self, expr):
        if not _SAFE_NAME.match(expr.name):
            raise Unsupported(f"symbol name {expr.name!r}")
        return expr.name

    def _print_BooleanTrue(self, expr):
        return "true"

    def _print_BooleanFalse(self, expr):
        return "false"

    def _print_Not(self, expr):
        return f"!({self._print(expr.args[0])})"

    def _print_sec(self, expr):
        return f"(1/Math.cos({self._print(expr.args[0])}))"

    def _print_csc(self, expr):
        return f"(1/Math.sin({self._print(expr.args[0])}))"

    def _print_cot(self, expr):
        return f"(1/Math.tan({self._print(expr.args[0])}))"

    def _print_coth(self, expr):
        return f"(1/Math.tanh({self._print(expr.args[0])}))"

    def _print_ceiling(self, expr):
        return f"Math.ceil({self._print(expr.args[0])})"

    def _print_Infinity(self, expr):
        return "Infinity"

    def _print_NegativeInfinity(self, expr):
        return "-Infinity"

    def _print_NaN(self, expr):
        return "NaN"

    def _print_ComplexInfinity(self, expr):
        return "NaN"

    def emptyPrinter(self, expr):
        raise Unsupported(type(expr).__name__)


def to_js(expr) -> str | None:
    """JavaScript for `expr`, or None if it uses something the browser can't
    compute (then the server samples the function instead)."""
    try:
        code = _JS().doprint(sp.sympify(expr))
    except Exception:
        return None
    if "\n" in code or "//" in code:  # the printer emits comments for unsupported parts
        return None
    return code
