"""Fast floating-point evaluation of user functions, for sampling graphs.

Exact evaluation (core.recursion) is used for anything shown as an answer
and for the dots at break points. Graph lines need thousands of values, so
here every case is compiled once with lambdify into plain-Python math, and
recursion is followed numerically. Sample points are chosen strictly
between exactly computed break points, so the case chosen at each step does
not depend on rounding.
"""
from __future__ import annotations

import math

import sympy as sp

from ..core.functions import FunctionDef, FunctionTable

AppliedUndef = sp.core.function.AppliedUndef
NAN = float("nan")


class _CompiledCase:
    def __init__(self, fd: FunctionDef, case, names: set[str]):
        x = fd.params
        self.kind = case.kind
        self.point = tuple(float(p) for p in case.point) if case.kind == "point" else None
        cond = case.condition(fd.params)
        self.cond = None if case.kind != "cond" else sp.lambdify(x, cond, modules="math")
        # Replace calls (innermost first) by placeholders d0, d1, ...
        value = sp.sympify(case.value)
        self.calls: list[tuple[str, object]] = []   # (function name, compiled argument)
        dummies: list[sp.Symbol] = []
        while True:
            inner = [c for c in value.atoms(AppliedUndef)
                     if not any(a.has(AppliedUndef) for a in c.args)]
            if not inner:
                break
            for c in sorted(inner, key=sp.default_sort_key):
                d = sp.Symbol(f"_d{len(dummies)}")
                arg_fn = sp.lambdify(list(x) + dummies, c.args[0] if len(c.args) == 1 else sp.Tuple(*c.args),
                                     modules="math")
                self.calls.append((c.func.__name__, arg_fn))
                dummies.append(d)
                value = value.xreplace({c: d})
        self.value = sp.lambdify(list(x) + dummies, value, modules="math")

    def applies(self, args: tuple) -> bool:
        if self.kind == "point":
            return args == self.point
        if self.kind == "cond":
            try:
                return bool(self.cond(*args))
            except (ValueError, TypeError, ZeroDivisionError, OverflowError):
                return False
        return True


class NumericFunctions:
    def __init__(self, table: FunctionTable, depth_limit: int = 300):
        self.depth_limit = depth_limit
        self.cases: dict[str, list[_CompiledCase]] = {}
        for name, fd in table.functions.items():
            self.cases[name] = [_CompiledCase(fd, c, set(table.functions)) for c in fd.ordered()]

    def __call__(self, name: str, *args: float) -> float:
        try:
            return self._eval(name, tuple(float(a) for a in args), 0, None)
        except (RecursionError, OverflowError):
            return NAN

    def with_path(self, name: str, *args: float) -> tuple[float, tuple]:
        """Value plus the sequence of (function, case number) used; between two
        break points this path must not change."""
        path: list = []
        try:
            v = self._eval(name, tuple(float(a) for a in args), 0, path)
        except (RecursionError, OverflowError):
            v = NAN
        return v, tuple(path)

    def _eval(self, name: str, args: tuple, depth: int, path) -> float:
        if depth > self.depth_limit:
            return NAN
        if any(not math.isfinite(a) for a in args):
            return NAN
        cases = self.cases[name]
        chosen = next((c for c in cases if c.applies(args)), None)
        if path is not None:
            path.append((name, cases.index(chosen) if chosen is not None else -1))
        if chosen is None:
            return NAN
        vals = []
        try:
            for fname, arg_fn in chosen.calls:
                a = arg_fn(*args, *vals)
                a = tuple(a) if isinstance(a, (tuple, list)) else (a,)
                if any(isinstance(v, complex) for v in a):
                    return NAN
                v = self._eval(fname, tuple(float(t) for t in a), depth + 1, path)
                if math.isnan(v):
                    return NAN
                vals.append(v)
            out = chosen.value(*args, *vals)
        except (ValueError, TypeError, ZeroDivisionError, OverflowError):
            return NAN
        if isinstance(out, complex):
            return out.real if abs(out.imag) <= 1e-9 * abs(out.real) else NAN
        try:
            return float(out)
        except (TypeError, ValueError):
            return NAN
