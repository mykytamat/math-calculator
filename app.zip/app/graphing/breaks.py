"""Exact break points of functions: where a graph may jump, end, or blow up.

For an ordinary expression these are its singularities (finite points and
periodic families such as tan's pi/2 + k*pi) and the edges of its domain.

For a function defined by cases they also include the case boundaries, and
for a recursive function the points whose recursion reaches a boundary:
with f(x) = 1 + f(log2 x) and a boundary at 1, the points 2, 4, 16, 65536, ...
They are found as preimages (solve log2(x) = 1, then log2(x) = 2, ...) until
nothing new appears. Between two consecutive break points the recursion
always takes the same path, so the function is an ordinary expression there.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import sympy as sp

from ..core.functions import FunctionDef, FunctionTable

AppliedUndef = sp.core.function.AppliedUndef

MAX_POINTS = 1500
MAX_IN_WINDOW = 400   # more break points than this in view: stop and ask to zoom in
MAX_ROUNDS = 400
MAX_MAGNITUDE = 10**12


@dataclass
class Breaks:
    points: set = field(default_factory=set)            # exact real numbers
    periodic: list = field(default_factory=list)        # (start, period) as exact numbers
    approximate: bool = False                            # some could not be found exactly
    too_many: bool = False                               # stopped: too many in the window

    def add_set(self, s, window: sp.Interval | None = None) -> None:
        """Add the real points of a SymPy set (FiniteSet / Union / ImageSet)."""
        s = sp.sympify(s)
        if s == sp.S.EmptySet:
            return
        if isinstance(s, sp.FiniteSet):
            for p in s:
                if p.is_real and p.is_number and _reasonable(p):
                    self.points.add(sp.nsimplify(p) if p.is_Float else p)
                elif not p.is_real and p.is_real is not False:
                    self.approximate = True
            return
        if isinstance(s, sp.Union):
            for a in s.args:
                self.add_set(a, window)
            return
        if isinstance(s, sp.ImageSet):
            fam = _periodic_family(s)
            if fam is not None:
                self.periodic.append(fam)
                return
        if window is not None:
            try:
                inside = sp.Intersection(s, window)
                if isinstance(inside, sp.FiniteSet):
                    self.add_set(inside)
                    return
            except Exception:
                pass
        self.approximate = True


def _reasonable(p) -> bool:
    try:
        return abs(float(p)) <= MAX_MAGNITUDE
    except (TypeError, OverflowError):
        return False


def _periodic_family(s: sp.ImageSet):
    lam = s.lamda
    if len(lam.variables) != 1 or s.base_sets[0] != sp.S.Integers:
        return None
    n = lam.variables[0]
    expr = sp.expand(lam.expr)
    a, b = expr.coeff(n, 1), expr.coeff(n, 0)
    if sp.simplify(expr - (a * n + b)) != 0 or not (a.is_number and b.is_number) or a == 0:
        return None
    return (b, abs(a))


def _solve(eq, x, domain=sp.S.Reals):
    eq = sp.sympify(eq)
    # Fast path for linear equations (recursions like f(n - 1), f(x/2)).
    try:
        if eq.is_polynomial(x) and sp.degree(eq, x) == 1:
            a, b = eq.coeff(x, 1), eq.coeff(x, 0)
            if a.is_number and b.is_number and a != 0:
                root = -b / a
                if domain is sp.S.Reals:
                    return sp.FiniteSet(root)
                inside = domain.contains(root)
                if inside in (sp.true, sp.false):
                    return sp.FiniteSet(root) if inside is sp.true else sp.S.EmptySet
    except (sp.PolynomialError, TypeError, ValueError):
        pass
    try:
        return sp.solveset(eq, x, domain)
    except Exception:
        return None


def relation_boundaries(cond, x) -> list:
    """Equations whose solutions bound the region where `cond` holds."""
    out = []
    for rel in sp.sympify(cond).atoms(sp.core.relational.Relational):
        out.append(rel.lhs - rel.rhs)
    return out


def expression_breaks(expr, x, conditions=(), window: sp.Interval | None = None) -> Breaks:
    br = _expression_breaks(expr, x, conditions, window)
    br.periodic = list(dict.fromkeys(br.periodic))
    return br


def _expression_breaks(expr, x, conditions=(), window: sp.Interval | None = None) -> Breaks:
    """Singularities and domain edges of an ordinary expression."""
    br = Breaks()
    expr = sp.sympify(expr)
    if sp.count_ops(expr) <= 300:
        try:
            br.add_set(sp.singularities(expr, x, sp.S.Reals), window)
        except Exception:
            br.approximate = True
        for den in _denominators(expr):
            s = _solve(den, x)
            if s is None:
                br.approximate = True
            else:
                br.add_set(s, window)
    for c in conditions:
        e = sp.sympify(c.expr)
        if x not in e.free_symbols or e.has(AppliedUndef):
            continue
        s = _solve(e, x)
        if s is None:
            br.approximate = True
        else:
            br.add_set(s, window)
    return br


def _denominators(expr):
    out = []
    for p in sp.sympify(expr).atoms(sp.Pow):
        if p.exp.is_number and p.exp.is_negative:
            out.append(p.base)
    for f in sp.sympify(expr).atoms(sp.tan, sp.sec):
        out.append(sp.cos(f.args[0]))
    for f in sp.sympify(expr).atoms(sp.cot, sp.csc):
        out.append(sp.sin(f.args[0]))
    return out


def case_set(fd: FunctionDef, case) -> sp.Set:
    """Where a case applies (one-variable functions)."""
    if case.kind == "point":
        return sp.FiniteSet(*case.point)
    if case.kind == "cond":
        try:
            return sp.Intersection(case.cond.as_set(), sp.S.Reals)
        except Exception:
            return sp.S.Reals
    others = sp.S.EmptySet
    for c in fd.cases:
        if c is case or c.kind in ("otherwise", "always"):
            continue
        others = sp.Union(others, case_set(fd, c))
    return sp.Complement(sp.S.Reals, others)


def function_breaks(table: FunctionTable, name: str, window: sp.Interval) -> Breaks:
    """Break points of a user function (cases and recursion included)."""
    fds = {n: fd for n, fd in table.functions.items() if fd.arity == 1}
    per: dict[str, Breaks] = {n: Breaks() for n in fds}
    for n, fd in fds.items():
        x = fd.params[0]
        for c in fd.cases:
            if c.kind == "point":
                per[n].points.update(p for p in c.point if p.is_real)
            elif c.kind == "cond":
                for eq in relation_boundaries(c.cond, x):
                    s = _solve(eq, x)
                    if s is None:
                        per[n].approximate = True
                    else:
                        per[n].add_set(s, window)
            value = sp.sympify(c.value)
            if not value.has(AppliedUndef):
                inner = expression_breaks(value, x, c.conditions, window)
            else:
                inner = expression_breaks(value.replace(lambda e: isinstance(e, AppliedUndef), lambda e: sp.Integer(0)),
                                          x, [k for k in c.conditions if not sp.sympify(k.expr).has(AppliedUndef)],
                                          window)
            per[n].points |= inner.points
            per[n].periodic += inner.periodic
            per[n].approximate |= inner.approximate

    # Recursion: add preimages of break points under each call's argument map.
    calls = []  # (caller, callee, argument expression, set where the call happens)
    for n, fd in fds.items():
        x = fd.params[0]
        for c in fd.cases:
            if c.kind == "point":
                continue
            for call in sp.sympify(c.value).atoms(AppliedUndef):
                callee = call.func.__name__
                if callee not in fds or len(call.args) != 1:
                    continue
                arg = call.args[0]
                if arg.has(AppliedUndef):
                    per[n].approximate = True  # f(f(x)): break points can't be found by solving
                    continue
                if x in arg.free_symbols:
                    calls.append((n, callee, arg, case_set(fd, c), x))
    frontier = {n: set(b.points) for n, b in per.items()}
    for _ in range(MAX_ROUNDS):
        new: dict[str, set] = {n: set() for n in fds}
        for caller, callee, arg, where, x in calls:
            if per[callee].periodic:
                per[caller].approximate = True
            for b in frontier[callee]:
                s = _solve(arg - b, x, where)
                if s is None:
                    per[caller].approximate = True
                    continue
                tmp = Breaks()
                tmp.add_set(s, window)
                per[caller].approximate |= tmp.approximate
                for p in tmp.points:
                    # A preimage outside the window that moves further away from it
                    # can't lead back in (for the monotone maps of school problems);
                    # misses are caught later by checking the recursion path numerically.
                    if p not in per[caller].points and _distance(p, window) <= _distance(b, window):
                        new[caller].add(p)
        if not any(new.values()):
            break
        for n, pts in new.items():
            per[n].points |= pts
        frontier = new
        in_window = sum(1 for p in per[name].points if window.contains(p) is sp.true)
        if sum(len(b.points) for b in per.values()) > MAX_POINTS or in_window > MAX_IN_WINDOW:
            for b in per.values():
                b.approximate = True
            per[name].too_many = True
            break
    else:
        per[name].approximate = True
    result = per[name]
    result.periodic = list(dict.fromkeys(result.periodic))
    return result


def _distance(p, window: sp.Interval) -> float:
    v = float(p)
    lo, hi = float(window.start), float(window.end)
    return 0.0 if lo <= v <= hi else min(abs(v - lo), abs(v - hi))
