"""Graphs for the Equations tab and relations in the Graph tab.

Trace kinds (drawn by static/js/graph.js):
  * "js" / "segments": a curve y = f(x) (see traces.py), optionally dashed.
  * "implicit": the curve g(x, y) = 0, drawn as a zero contour in the browser.
    The denominators of g are sent too, so the contour is not drawn across a
    pole (where g jumps from +∞ to −∞).
  * "region": where a condition in x and y holds, shaded.
  * "points": marked points (solutions, corners); "periodic" repeats them.
  * "xbands": x-intervals shaded across the plot (one-variable inequalities).
Number lines are separate specs (static/js/numberline.js).
"""
from __future__ import annotations

import math
import re

import sympy as sp

from ..core.format import tex
from ..solving.periodic import PeriodicSet, pieces
from .breaks import _denominators
from .jsprint import to_js
from .traces import expression_trace, graph_spec

DEFAULT = (-10.0, 10.0)


def _f(v) -> float | None:
    try:
        f = float(sp.N(v, 20))
    except (TypeError, ValueError, OverflowError):
        return None
    return f if math.isfinite(f) else None


def plain_label(v) -> str:
    """Short plain-text form of a number for graph labels: π/6, √2, −3, 0.739."""
    v = sp.sympify(v)
    if v.has(sp.Float) or v.has(sp.CRootOf) or v.has(sp.LambertW):
        f = _f(v)
        return f"{f:.4g}" if f is not None else "?"
    s = sp.sstr(v)
    s = re.sub(r"sqrt\((\d+)\)", r"√\1", s)
    s = s.replace("sqrt", "√").replace("**", "^").replace("*", "·").replace("pi", "π")
    s = re.sub(r"(\d)·π", r"\1π", s)
    s = s.replace("log(", "ln(").replace("E", "e").replace("-", "−")
    if len(s) > 14:
        f = _f(v)
        return f"{f:.4g}" if f is not None else s
    return s


# -------------------------------------------------------------- windows -----
def fit_points(values, minimum: float = 3.0) -> tuple[float, float] | None:
    """A snug range around a few points (regions and systems in the plane)."""
    fs = [f for f in (_f(v) for v in values) if f is not None]
    if not fs:
        return None
    a, b = min(fs), max(fs)
    pad = max(2.0, 0.6 * (b - a))
    lo, hi = a - pad, b + pad
    if hi - lo < 2 * minimum:
        mid = (a + b) / 2
        lo, hi = mid - minimum, mid + minimum
    return lo, hi


def fit_window(values, default=DEFAULT, pad: float = 0.25) -> tuple[float, float]:
    """An x-range showing all the given numbers (and the default range if they fit in it)."""
    fs = [f for f in (_f(v) for v in values) if f is not None]
    lo, hi = default
    if not fs:
        return lo, hi
    a, b = min(fs), max(fs)
    if a >= lo * 0.8 and b <= hi * 0.8:
        return lo, hi
    span = max(b - a, 1.0)
    return min(a - pad * span, lo if abs(a) < 100 else a - pad * span), max(b + pad * span, hi if abs(b) < 100 else b + pad * span)


# ------------------------------------------------------- one variable -------
def side_traces(lhs, rhs, x, conditions, window, labels=None) -> list[dict]:
    """Curves y = left side and y = right side (just one if the other is a constant 0)."""
    traces = []
    conds = [c for c in conditions if sp.sympify(c.expr).free_symbols <= {x}]
    for i, (label, e) in enumerate((("left side", lhs), ("right side", rhs))):
        e = sp.sympify(e)
        if e == 0 and traces:
            continue
        if e == 0 and sp.sympify(rhs if label == "left side" else lhs) != 0:
            continue
        typed = labels[i] if labels else None
        name = f"y = {typed if typed and len(typed) <= 40 else _short(e)}"
        try:
            t = expression_trace(e, x, name, [c for c in conds if sp.sympify(c.expr).free_symbols <= e.free_symbols]
                                 if e.free_symbols else [], window)
        except Exception:
            continue
        traces.append(t)
    return traces


def _short(e) -> str:
    s = sp.sstr(e).replace("**", "^").replace("*", "·").replace("pi", "π").replace("sqrt", "√")
    return s if len(s) <= 40 else s[:37] + "…"


def points_trace(xs, ys_js: str | None, label: str, periodic=None, ys=None) -> dict:
    """Marked solutions. y is computed in the browser from ys_js (the left side) when given."""
    return {"kind": "points", "label": label, "x": [_f(v) for v in xs],
            "y": [_f(v) for v in ys] if ys is not None else None, "y_js": ys_js,
            "text": [plain_label(v) for v in xs], "periodic": periodic or []}


def periodic_points(ps: PeriodicSet) -> list[list[float]]:
    return [[_f(v), _f(ps.period)] for kind, v in pieces(ps.base) if kind == "pt"]


def bands_trace(solution, label: str = "solution set") -> dict:
    """Shaded x-intervals for a one-variable inequality."""
    intervals, period = [], None
    if isinstance(solution, PeriodicSet):
        period = _f(solution.period)
        s = solution.base
    else:
        s = solution
    for kind, v in pieces(s) if s != sp.S.EmptySet else []:
        if kind == "iv":
            intervals.append([_f(v.start) if v.start != -sp.oo else None, _f(v.end) if v.end != sp.oo else None])
    return {"kind": "xbands", "label": label, "intervals": intervals, "period": period}


def one_variable_graph(lhs, rhs, x, conditions, result, window, op: str, labels=None) -> dict | None:
    traces = side_traces(lhs, rhs, x, conditions, window, labels)
    if not traces:
        return None
    sol = result.solution
    ys_js = to_js(sp.sympify(lhs)) if sp.sympify(lhs).free_symbols <= {x} else None
    if op == "=":
        if isinstance(result.general, PeriodicSet) or isinstance(sol, PeriodicSet):
            fam = result.general if isinstance(result.general, PeriodicSet) else sol
            traces.append(points_trace([], ys_js, "solutions", periodic_points(fam)))
        elif isinstance(sol, sp.FiniteSet) and len(sol) <= 200:
            pts = list(sol)
            ys = None if ys_js else [sp.sympify(lhs).subs(x, p) for p in pts]
            traces.append(points_trace(pts, ys_js, "solutions", ys=ys))
    else:
        traces.append(bands_trace(sol))
    spec = graph_spec(traces, window, source=None)
    spec["var"] = str(x)
    return spec


def number_line(result, x) -> dict | None:
    """Intervals and points of a one-variable solution set, for the number line."""
    sol = result.solution
    if isinstance(sol, PeriodicSet):
        pts, ivs = sol.families()
        period = _f(sol.period)
        intervals = [_interval(lo, hi, lc, hc) for lo, hi, lc, hc in ivs]
        points = [{"x": _f(r), "label": plain_label(r)} for r, pm in pts]
        points += [{"x": -_f(r), "label": plain_label(-r)} for r, pm in pts if pm]
        values = [p["x"] for p in points] + [v for iv in intervals for v in (iv["lo"], iv["hi"]) if v is not None]
        span = max(abs(v) for v in values + [period]) if values else period
        return {"var": str(x), "intervals": intervals, "points": points, "period": period,
                "x_range": [-max(span, period) * 1.6, max(span, period) * 1.6]}
    if not isinstance(sol, sp.Set):
        return None
    try:
        parts = pieces(sol)
    except Exception:
        return None
    intervals, points = [], []
    for kind, v in parts:
        if kind == "pt":
            points.append({"x": _f(v), "label": plain_label(v)})
        else:
            intervals.append(_interval(v.start, v.end, not v.left_open, not v.right_open))
    finite = [p["x"] for p in points] + [e for iv in intervals for e in (iv["lo"], iv["hi"]) if e is not None]
    finite = [f for f in finite if f is not None]
    if finite:
        a, b = min(finite), max(finite)
        span = max(b - a, 2.0)
        rng = [a - 0.35 * span, b + 0.35 * span]
    else:
        rng = [-10, 10]
    return {"var": str(x), "intervals": intervals, "points": points, "period": None, "x_range": rng}


def _interval(lo, hi, lc, hc) -> dict:
    return {"lo": None if lo == -sp.oo else _f(lo), "hi": None if hi == sp.oo else _f(hi),
            "lo_closed": bool(lc) and lo != -sp.oo, "hi_closed": bool(hc) and hi != sp.oo,
            "lo_label": None if lo == -sp.oo else plain_label(lo),
            "hi_label": None if hi == sp.oo else plain_label(hi)}


# --------------------------------------------------------- two variables ----
def _poles(expr) -> list[str]:
    out = []
    for d in _denominators(expr):
        js = to_js(d)
        if js:
            out.append(js)
    return out


def explicit_in(expr, y):
    """If expr = a·y + b(x) with a a nonzero constant, return (a, b)."""
    e = sp.expand(sp.sympify(expr))
    if not e.has(y):
        return None
    try:
        if not e.is_polynomial(y) or sp.degree(e, y) != 1:
            return None
    except sp.PolynomialError:
        return None
    a, b = e.coeff(y, 1), e.coeff(y, 0)
    if not a.is_number or a == 0 or b.has(y):
        return None
    return a, b


def boundary_trace(lhs, rhs, op: str, xv, yv, label: str, window) -> dict | None:
    """The curve lhs = rhs: explicit y = f(x) when possible (sharper), else a contour."""
    g = sp.sympify(lhs - rhs)
    dash = op in ("<", ">", "!=")
    ex = explicit_in(g, yv)
    if ex is not None:
        a, b = ex
        f = sp.simplify(-b / a)
        if f.free_symbols <= {xv}:
            try:
                t = expression_trace(f, xv, label, [], window)
                t["dash"] = dash
                t["boundary"] = True
                return t
            except Exception:
                pass
    js = to_js(g)
    if js is None:
        return None
    return {"kind": "implicit", "label": label, "js": js, "vars": [str(xv), str(yv)], "dash": dash,
            "poles": _poles(g)}


def relation_js(leaves) -> str | None:
    parts = []
    for lf in leaves:
        js = to_js(lf.relation())
        if js is None:
            return None
        parts.append(f"({js})")
    return " && ".join(parts) if parts else None


def plane_graph(leaves, xv, yv, window, y_window=None, points=None, label_points="solutions",
                tree_js: str | None = None) -> dict | None:
    """Region shading for inequalities, curves for equations, and marked points."""
    traces = []
    ineqs = [lf for lf in leaves if lf.op != "="]
    eqs = [lf for lf in leaves if lf.op == "="]
    if ineqs and not eqs:
        js = tree_js or relation_js(ineqs)
        if js is not None:
            traces.append({"kind": "region", "label": "solution set", "js": js, "vars": [str(xv), str(yv)]})
    for lf in leaves:
        t = boundary_trace(lf.lhs, lf.rhs, lf.op, xv, yv, f"${tex(lf.relation())}$", window)
        if t is None:
            continue
        t["label"] = _short_rel(lf)
        if eqs and ineqs and lf.op != "=":
            t["dash"] = True
            t["faint"] = True
        traces.append(t)
    if eqs and ineqs:
        # Curves restricted by inequalities: only the part inside them is a solution.
        mask = relation_js(ineqs)
        for t in traces:
            if t["kind"] == "implicit" and not t.get("faint"):
                t["mask"] = mask
    if points:
        traces.append({"kind": "points", "label": label_points,
                       "x": [_f(p[xv]) for p in points], "y": [_f(p[yv]) for p in points],
                       "text": [f"({plain_label(p[xv])}, {plain_label(p[yv])})" for p in points],
                       "periodic": []})
    if not traces:
        return None
    spec = graph_spec(traces, window, source=None)
    spec["y_range"] = list(y_window) if y_window else list(window)
    spec["vars"] = [str(xv), str(yv)]
    return spec


def _short_rel(lf) -> str:
    sym = {"=": "=", "<": "<", "<=": "≤", ">": ">", ">=": "≥", "!=": "≠"}[lf.op]
    return f"{_short(lf.lhs)} {sym} {_short(lf.rhs)}"
