"""Russian text for app/i18n.py: English template -> Russian, {} = a value that varies.

A value matched by {} is translated in turn. {0}, {1} in the Russian pick values by position when
the word order differs. tests/test_i18n.py fails when a string in the code has no entry here.
"""
from __future__ import annotations

_T = "вкладке «{}»"
EVALUATE, PIECEWISE, EQUATIONS, CALCULUS, SEQUENCES, PARAMETERS, MATRICES = (
    "Вычисления", "Кусочные и рекурсивные", "Уравнения и неравенства", "Матанализ",
    "Последовательности и ряды", "Параметры", "Матрицы")

TEXT: dict[str, str] = {
    # ------------------------------------------------------------- core ---
    "The exact value has about {} digits, too many to show":
        "В точном значении около {} цифр, показать их все невозможно",
    "The exact form is too long to show": "Точная форма слишком длинная, чтобы её показать",
    "; this is its decimal approximation.": "; это её десятичное приближение.",
    "The exact value has about {} digits, too many to show; this is its decimal approximation.":
        "В точном значении около {} цифр, показать их все невозможно; это его десятичное приближение.",
    "The exact form is too long to show; this is its decimal approximation.":
        "Точная форма слишком длинная, чтобы её показать; это её десятичное приближение.",
    "Defined only where: {}": "Определено только при: {}",
    "Defined only where": "Определено только при",
    "(decided numerically: the value is zero to 45 digits but could not be proven exactly)":
        "(решено численно: значение равно нулю с точностью до 45 цифр, но точно это не доказано)",
    "${}\\left({}\\right)$ is undefined: ${}$ is outside every case of {} ({}).":
        "${}\\left({}\\right)$ не определено: ${}$ не попадает ни в один случай функции {} ({}).",
    "{} is defined with different numbers of variables.": "{} определена с разным числом переменных.",
    "{} is defined twice. Give each line a condition with 'if', or remove one of them.":
        "{} определена дважды. Задайте для каждой строки условие через 'if' или удалите одну из них.",
    "{} has more than one 'otherwise' case.": "У {} больше одного случая 'otherwise'.",
    "{} has cases with conditions and also a line without a condition. Write 'otherwise' on the line that covers the rest.":
        "У {} есть случаи с условиями и строка без условия. Напишите 'otherwise' в строке, которая охватывает остальное.",
    "The cases cover ${}$; {} is undefined elsewhere.": "Случаи охватывают ${}$; вне этого {} не определена.",
    "The arguments of {}(…) = … must be numbers or variables.": "Аргументами {}(…) = … должны быть числа или переменные.",
    "The cases cover ${}$.": "Случаи охватывают ${}$.",
    "Two cases overlap on ${}$; they are checked to agree whenever that part is evaluated.":
        "Два случая пересекаются на ${}$; при вычислении на этом участке проверяется, что они совпадают.",
    "Two cases of {} overlap on ${}$ and give different values there. Make the conditions exclusive, e.g. use < in one.":
        "Два случая функции {} пересекаются на ${}$ и дают там разные значения. Сделайте условия взаимоисключающими, например используйте < в одном из них.",
    "The right-hand side of the definition of {} must be an expression.": "Правая часть определения {} должна быть выражением.",
    "Each case of {} must be an expression.": "Каждый случай {} должен быть выражением.",
    "Only square matrices have a determinant; this one is {}.": "Определитель есть только у квадратных матриц; размер этой матрицы {}.",
    "Computed two ways (Bareiss elimination and the Berkowitz algorithm); they agree.":
        "Вычислено двумя способами (метод Барейсса и алгоритм Берковица); результаты совпадают.",
    "Checked: $A\\,A^{-1} = A^{-1}A = I$.": "Проверено: $A\\,A^{-1} = A^{-1}A = I$.",
    "Checked: it is in reduced row echelon form and has the same row space as the matrix (stacking the two has the same rank).":
        "Проверено: это приведённый ступенчатый вид с тем же пространством строк, что и у матрицы (объединение обеих матриц имеет тот же ранг).",
    "Warning: the reduced form failed its check.": "Внимание: приведённый вид не прошёл проверку.",
    "Equal to the number of pivots in the reduced row echelon form ({}).":
        "Равен числу ведущих элементов в приведённом ступенчатом виде ({}).",
    "Only square matrices have eigenvalues; this one is {}.": "Собственные значения есть только у квадратных матриц; размер этой матрицы {}.",
    "Some eigenvalues have no simple formula with radicals; they are shown as decimals (roots of the characteristic polynomial), with eigenvectors found numerically.":
        "Для некоторых собственных значений нет простой формулы в радикалах; они показаны десятичными дробями (корни характеристического многочлена), а собственные векторы найдены численно.",
    "Checked: $A\\,v = \\lambda v$ for every eigenvector shown, and every eigenvalue is a root of the characteristic polynomial.":
        "Проверено: $A\\,v = \\lambda v$ для каждого показанного собственного вектора, и каждое собственное значение является корнем характеристического многочлена.",
    "Complex eigenvalues are listed for completeness; their eigenvectors are not shown (this calculator works with real numbers).":
        "Комплексные собственные значения приведены для полноты; их собственные векторы не показаны (калькулятор работает с вещественными числами).",
    "The right-hand side must be a column vector; it is {}.": "Правая часть должна быть вектором-столбцом; её размер {}.",
    "A {} matrix needs a right-hand side with {} entries (it has {}).":
        "Для матрицы {} нужна правая часть из {} элементов (в ней {}).",
    "Warning: substituting the solution back does not give the right-hand side.":
        "Внимание: подстановка решения не даёт правую часть.",
    "Warning: two methods of computing the determinant disagree (${}$ and ${}$).":
        "Внимание: два способа вычисления определителя дали разные результаты (${}$ и ${}$).",
    "Warning: multiplying back does not give the identity matrix.": "Внимание: обратное умножение не даёт единичную матрицу.",
    "Warning: the rank and the number of pivots disagree.": "Внимание: ранг не совпадает с числом ведущих элементов.",
    "An eigenvalue failed its check (it is not a root of the characteristic polynomial).":
        "Собственное значение не прошло проверку (оно не является корнем характеристического многочлена).",
    "An eigenvector failed its check A·v = λ·v.": "Собственный вектор не прошёл проверку A·v = λ·v.",
    "Checked by substituting the solution back into the system": "Проверено подстановкой решения в систему",
    "Checked by substituting the solution back into the system (for every value of the parameters).":
        "Проверено подстановкой решения в систему (при всех значениях параметров).",
    "Checked by substituting the solution back into the system.": "Проверено подстановкой решения в систему.",
    "The reduced form has a row $0 = 1$ (all coefficients 0 but the right side not), so the system has no solution.":
        "В приведённом виде есть строка $0 = 1$ (все коэффициенты равны 0, а правая часть нет), поэтому система не имеет решений.",
    "${}$ is undefined. Following the calls ${}$: {}": "${}$ не определено. Цепочка вызовов ${}$: {}",
    "The cases cover ${}$. (Some conditions could not be decided here.)":
        "Случаи охватывают ${}$. (Некоторые условия здесь решить не удалось.)",
    "${}$ requires ${}$, but ${}$ is outside every case of {} ({}).":
        "Для ${}$ нужно ${}$, но ${}$ не попадает ни в один случай функции {} ({}).",
    "${}$ is undefined: ${}$ is outside every case of {} ({}).":
        "${}$ не определено: ${}$ не попадает ни в один случай функции {} ({}).",
    "(Some conditions could not be decided here.)": "(Некоторые условия здесь решить не удалось.)",
    "{} is not defined. Define it first, for example {}(x) = x^2.": "{} не определена. Сначала определите её, например {}(x) = x^2.",
    "{} takes {} argument(s) but was given {}.": "{} принимает аргументов: {}, а передано: {}.",
    "{} can only be evaluated at numbers here, not at ${}$.": "{} можно вычислять здесь только в числах, а не в ${}$.",
    "${}$ never finishes: it calls itself again (${}$), so the recursion loops forever.":
        "${}$ никогда не завершится: функция снова вызывает себя (${}$), и рекурсия не заканчивается.",
    "${}$ was stopped after {} nested calls (${}$). The recursion does not seem to reach a base case. You can raise the depth limit in the tab's options.":
        "${}$ остановлено после {} вложенных вызовов (${}$). Похоже, рекурсия не доходит до базового случая. Предел глубины можно увеличить в параметрах вкладки.",
    "Gave up after {} different calls.": "Вычисление прервано после {} разных вызовов.",
    "${}$ has no real value.": "${}$ не имеет вещественного значения.",
    "At ${}$ the condition ${}$ was decided numerically (the two sides agree to 45 digits).":
        "При ${}$ условие ${}$ решено численно (обе части совпадают с точностью до 45 цифр).",
    "${}$ fits more than one case ({}) and they give different formulas. Make the conditions exclusive.":
        "${}$ подходит более чем под один случай ({}), и они дают разные формулы. Сделайте условия взаимоисключающими.",

    # ---------------------------------------------------------- parsing ---
    "The input is empty.": "Ввод пуст.",
    "The input is nested too deeply to read.": "Слишком большая вложенность, разобрать ввод не удалось.",
    "Double integrals": "Двойные интегралы",
    "Contour integrals": "Контурные интегралы",
    "Partial derivatives": "Частные производные",
    "± isn't supported. Enter the two cases separately.": "Знак ± не поддерживается. Введите два случая отдельно.",
    "∓ isn't supported. Enter the two cases separately.": "Знак ∓ не поддерживается. Введите два случая отдельно.",
    "Complex numbers aren't supported: this calculator works with real numbers.":
        "Комплексные числа не поддерживаются: калькулятор работает с вещественными числами.",
    "≈ can't be used in input.": "Знак ≈ нельзя использовать во вводе.",
    "≡ can't be used in input.": "Знак ≡ нельзя использовать во вводе.",
    "'…' can't be used in input.": "Многоточие нельзя использовать во вводе.",
    "∅ can't be used in input.": "Знак ∅ нельзя использовать во вводе.",
    "Negated symbols aren't supported.": "Перечёркнутые символы не поддерживаются.",
    "∉ isn't supported.": "Знак ∉ не поддерживается.",
    "Norms ‖x‖ aren't supported.": "Нормы ‖x‖ не поддерживаются.",
    "Angle brackets aren't supported.": "Угловые скобки не поддерживаются.",
    "Unbalanced braces: a '{' is never closed.": "Скобки не сбалансированы: фигурная скобка '{' не закрыта.",
    "Unknown function or word '{}'.": "Неизвестная функция или слово '{}'.",
    "Unknown name '{}'.": "Неизвестное имя '{}'.",
    "I don't know the LaTeX command '\\{}'.": "Неизвестная команда LaTeX '\\{}'.",
    "Unknown delimiter '{}'.": "Неизвестный разделитель '{}'.",
    "Expected an exponent or subscript here.": "Здесь ожидался показатель степени или нижний индекс.",
    "Expected '{' after a command.": "После команды ожидалась скобка '{'.",
    "A lone backslash at the end.": "Лишняя обратная косая черта в конце.",
    "Number sets like ℤ/ℝ (\\mathbb{{}}) aren't supported here.": "Числовые множества вроде ℤ/ℝ (\\mathbb{{}}) здесь не поддерживаются.",
    "\\{} without a delimiter.": "\\{} без разделителя.",
    "There is an empty box in the input. Fill it in or delete it.": "Во вводе есть пустое поле. Заполните или удалите его.",
    "The degree sign needs a number before it.": "Перед знаком градуса должно стоять число.",
    "{} aren't supported yet.": "{}: пока не поддерживаются.",
    "'→' can only be used in limits.": "Стрелку '→' можно использовать только в пределах.",
    "A closing '|' without an opening one.": "Закрывающая '|' без открывающей.",
    "Unexpected line break or '&' outside a cases/matrix block.": "Неожиданный перенос строки или '&' вне блока случаев или матрицы.",
    "A limit needs x → a under it: type lim, then x, Tab, the point.": "Под знаком предела нужно x → a: введите lim, затем x, Tab и точку.",
    "Expected '{' after \\lim_": "После \\lim_ ожидалась скобка '{'",
    "The limit has an empty box under it: fill in the variable and the point.":
        "Под знаком предела пустое поле: заполните переменную и точку.",
    "Expected the variable under lim, e.g. x → 0": "Под lim ожидалась переменная, например x → 0",
    "Expected '→' after the variable (type -> or use Tab in the lim template)":
        "После переменной ожидалась '→' (введите -> или нажмите Tab в шаблоне lim)",
    "The point of the limit is empty.": "Не указана точка предела.",
    "Expected '}' to close the limit's subscript": "Ожидалась '}', закрывающая индекс предела",
    "Nothing after the limit sign: write the expression after it.": "После знака предела ничего нет: напишите выражение.",
    "The integral needs both bounds (or neither, for an indefinite integral).":
        "Для интеграла нужны оба предела (или ни одного, если интеграл неопределённый).",
    "An integral must end with dx (or dt, ...), e.g. \\int_0^1 x\\,dx.":
        "Интеграл должен заканчиваться на dx (или dt и т. п.), например \\int_0^1 x\\,dx.",
    "Expected d{} after the integrand": "После подынтегрального выражения ожидалось d{}",
    "Write the start of the sum under Σ, e.g. n=1.": "Напишите начало суммы под Σ, например n=1.",
    "Write the start of the product under ∏, e.g. n=1.": "Напишите начало произведения под ∏, например n=1.",
    "The sum needs an upper limit above Σ (∞ is allowed).": "Над Σ нужен верхний предел (можно ∞).",
    "The product needs an upper limit above ∏.": "Над ∏ нужен верхний предел.",
    "Nothing after the sum sign: write the expression to add up after it.": "После знака суммы ничего нет: напишите слагаемое.",
    "Nothing after the product sign: write the expression to multiply after it.": "После знака произведения ничего нет: напишите множитель.",
    "Type sum, then n=1, Tab, the upper limit (∞ is allowed), Tab, the expression.":
        "Введите sum, затем n=1, Tab, верхний предел (можно ∞), Tab и выражение.",
    "Type prod, then n=1, Tab, the upper limit, Tab, the expression.":
        "Введите prod, затем n=1, Tab, верхний предел, Tab и выражение.",
    "The {} is an empty box.": "{}: пустое поле.",
    "The '{}' block isn't supported.": "Блок '{}' не поддерживается.",
    "Expected '&', a new row, or the end of the {} block, but found {}.":
        "Ожидались '&', новая строка или конец блока {}, но найдено: {}.",
    "The {} block is empty.": "Блок {} пуст.",
    "'{}' can't be a function name: it means the constant e ≈ 2.718.": "'{}' не может быть именем функции: это константа e ≈ 2.718.",
    "'∈ f' looks like a mistyped ∞.": "'∈ f' похоже на опечатку вместо ∞.",
    "I don't understand the text '{}'.": "Непонятный текст '{}'.",
    "Empty braces {}.": "Пустые фигурные скобки {}.",
    "Expected '}'": "Ожидалась '}'",
    "The visual editor put what you typed into the base slot of log. Type log, press → to leave the base empty (base 10), then type the argument.":
        "Визуальный редактор поместил ввод в основание log. Введите log, нажмите →, чтобы оставить основание пустым (основание 10), затем введите аргумент.",
    "Empty absolute value bars.": "Пустой модуль.",
    "Expected a closing '|'": "Ожидалась закрывающая '|'",
    "Expected '\\{}'": "Ожидалось '\\{}'",
    "Expected a closing brace": "Ожидалась закрывающая скобка",
    "Type the integrand, then d and the variable.": "Введите подынтегральное выражение, затем d и переменную.",
    "The {} is empty.": "{}: пусто.",
    "Each line of a system must hold one equation or inequality.": "В каждой строке системы должно быть одно уравнение или неравенство.",
    "Pick another letter, for example f, g or h.": "Выберите другую букву, например f, g или h.",
    "In the visual editor, type 'oo' or 'infty' to get ∞.": "В визуальном редакторе введите 'oo' или 'infty', чтобы получить ∞.",
    "Text can only be 'if', 'otherwise', 'and', 'or'.": "Текстом могут быть только 'if', 'otherwise', 'and', 'or'.",
    "needs an argument": "нужен аргумент",
    "Expected ']' after the root index": "После показателя корня ожидалась ']'",
    "The integral is empty: write the function before d{}.": "Интеграл пуст: напишите функцию перед d{}.",
    "Row {} of the matrix has an empty or missing entry.": "В строке {} матрицы есть пустой или пропущенный элемент.",
    "Row {} of the cases block has too many '&'.": "В строке {} блока случаев слишком много '&'.",
    "Row {} of the cases block has no value.": "В строке {} блока случаев нет значения.",
    "Row {} of the cases block has an empty condition (write 'otherwise' if it applies everywhere else).":
        "В строке {} блока случаев пустое условие (напишите 'otherwise', если она действует во всех остальных случаях).",
    "Row {} of the cases block has no condition (write 'otherwise' if it applies everywhere else).":
        "В строке {} блока случаев нет условия (напишите 'otherwise', если она действует во всех остальных случаях).",
    "Unexpected '\\{}'.": "Неожиданное '\\{}'.",
    "Unexpected ':'.": "Неожиданный символ ':'.",
    "Unexpected '%'.": "Неожиданный символ '%'.",
    "Unexpected character '{}'.": "Неожиданный символ '{}'.",
    "Expected '{}'": "Ожидалось '{}'",
    "Expected '{}' but the input ended.": "Ожидалось '{}', но ввод закончился.",
    "Expected '{}' but found {}.": "Ожидалось '{}', но найдено: {}.",
    "The bracket opened at position {} is never closed.": "Скобка, открытая в позиции {}, не закрыта.",
    "the end of the input": "конец ввода",
    "There is a closing bracket without a matching opening one.": "Есть закрывающая скобка без открывающей.",
    "Check that every | has a matching |.": "Проверьте, что у каждой | есть парная |.",
    "'{}' can't be used here.": "'{}' здесь использовать нельзя.",
    "Arrows are only used in limits, e.g. lim(sin(x)/x, x -> 0).": "Стрелки используются только в пределах, например lim(sin(x)/x, x -> 0).",
    "Expected an interval such as [0, 2pi] or (0, 1] after 'in'.": "После 'in' ожидался интервал, например [0, 2pi] или (0, 1].",
    "Unexpected {}.": "Неожиданно: {}.",
    "Expected a subscript after '_', such as a_1 or a_(n-1).": "После '_' ожидался индекс, например a_1 или a_(n-1).",
    "Write sum(expression, n, from, to), e.g. sum(1/n^2, n, 1, inf).": "Напишите sum(выражение, n, от, до), например sum(1/n^2, n, 1, inf).",
    "Write prod(expression, k, from, to), e.g. prod(1 + 1/k, k, 1, n).": "Напишите prod(выражение, k, от, до), например prod(1 + 1/k, k, 1, n).",
    "I couldn't understand {} here.": "Здесь не удалось разобрать {}.",
    "Two numbers in a row: '{} {}'.": "Два числа подряд: '{} {}'.",
    "Missing exponent after '^'.": "После '^' нет показателя степени.",
    "The input ended too early: something is missing at the end.": "Ввод закончился слишком рано: в конце чего-то не хватает.",
    "Unexpected {}: there's no matching opening bracket, or something is missing before it.":
        "Неожиданно: {}. Нет парной открывающей скобки, или перед этим чего-то не хватает.",
    "Missing something before {}.": "Перед {} чего-то не хватает.",
    "An arrow can only be used in a limit.": "Стрелку можно использовать только в пределе.",
    "Empty parentheses: this function needs an argument.": "Пустые скобки: этой функции нужен аргумент.",
    "Expected ')' to close the function call": "Ожидалась ')', закрывающая вызов функции",
    "{} takes {} argument(s) but got {}.": "{} принимает аргументов: {}, а получено: {}.",
    "{}^(-1) is ambiguous here; write 1/{}(...) for the reciprocal.": "{}^(-1) здесь неоднозначно; для обратной величины напишите 1/{}(...).",
    "Empty parentheses.": "Пустые скобки.",
    "Expected ')'": "Ожидалась ')'",
    "Empty brackets.": "Пустые квадратные скобки.",
    "Expected ']'": "Ожидалась ']'",
    "The order of a derivative must be between 1 and 20.": "Порядок производной должен быть от 1 до 20.",
    "Write {} with brackets, e.g. {}.": "Напишите {} со скобками, например {}.",
    "Expected ')' to close {}(...)": "Ожидалась ')', закрывающая {}(...)",
    "Expected ', n, from, to' after the expression": "После выражения ожидалось ', n, от, до'",
    "Expected the summation variable, e.g. n.": "Ожидалась переменная суммирования, например n.",
    "Expected the product's variable, e.g. n.": "Ожидалась переменная произведения, например n.",
    "Expected ', to' after the lower bound": "После нижнего предела ожидалось ', до'",
    "{} takes the expression, the variable and two bounds.": "{} принимает выражение, переменную и два предела.",
    "Nothing after '{}'.": "После '{}' ничего нет.",
    "Expected ',' between the interval ends": "Между концами интервала ожидалась ','",
    "Missing a term after '{}'.": "После '{}' нет слагаемого.",
    "Write {}*{} to multiply, or remove the space.": "Для умножения напишите {}*{} или уберите пробел.",
    "Write limits as lim(sin(x)/x, x -> 0).": "Пределы пишутся так: lim(sin(x)/x, x -> 0).",
    "Expected '(' after {}{}.": "После {}{} ожидалась '('.",
    "The subscript of {} contains a comparison.": "В индексе {} есть сравнение.",
    "'{}' needs an argument.": "Для '{}' нужен аргумент.",
    "Matrix rows have different lengths.": "Строки матрицы разной длины.",
    "Write the function after it, e.g. d/dx (x^2 ln x).": "Напишите после него функцию, например d/dx (x^2 ln x).",
    "Expected ', x -> point' after the expression": "После выражения ожидалось ', x -> точка'",
    "Expected '->' after the variable, e.g. lim(sin(x)/x, x -> 0).": "После переменной ожидалось '->', например lim(sin(x)/x, x -> 0).",
    "Expected ')' to close lim(...)": "Ожидалась ')', закрывающая lim(...)",
    "diff takes at most 3 arguments: diff(expression, x, order).": "diff принимает не больше 3 аргументов: diff(выражение, x, порядок).",
    "The second argument of int is the variable, e.g. int(x^2, x, 0, 1).": "Второй аргумент int это переменная, например int(x^2, x, 0, 1).",
    "Write int(expression, x) or int(expression, x, from, to).": "Напишите int(выражение, x) или int(выражение, x, от, до).",
    "Expected ',' after the summation variable": "После переменной суммирования ожидалась ','",
    "Expected ',' after the product's variable": "После переменной произведения ожидалась ','",
    "Expected ')' or ']' to close the interval": "Ожидалась ')' или ']', закрывающая интервал",
    "Missing something after '{}'.": "После '{}' чего-то не хватает.",
    "In the visual editor, press → to leave the subscript before typing '='.":
        "В визуальном редакторе нажмите →, чтобы выйти из индекса, прежде чем вводить '='.",
    "log has a base written twice.": "У log основание указано дважды.",
    "Nothing to differentiate after d/d{}": "После d/d{} нечего дифференцировать",
    "Expected the variable, e.g. x": "Ожидалась переменная, например x",
    "The second argument of diff is the variable, e.g. diff(x^3, x).": "Второй аргумент diff это переменная, например diff(x^3, x).",
    "The third argument of diff is the order: a whole number, e.g. diff(sin(x), x, 2).":
        "Третий аргумент diff это порядок: целое число, например diff(sin(x), x, 2).",
    "an integral": "интеграл", "a sum": "сумма", "a product": "произведение",
    "a partial derivative": "частная производная",
    "Write int(f, x) or int(f, x, a, b), or use the ∫ button in the visual editor.":
        "Напишите int(f, x) или int(f, x, a, b) либо используйте кнопку ∫ в визуальном редакторе.",
    "Write sum(f, n, 1, inf), or use the Σ button in the visual editor.":
        "Напишите sum(f, n, 1, inf) либо используйте кнопку Σ в визуальном редакторе.",
    "Write prod(f, k, 1, n), or use the ∏ button in the visual editor.":
        "Напишите prod(f, k, 1, n) либо используйте кнопку ∏ в визуальном редакторе.",
    "Partial derivatives aren't supported; d/dx works for one variable.":
        "Частные производные не поддерживаются; d/dx работает для одной переменной.",
    "'{}' can't be a function name: it means the constant {}.": "'{}' не может быть именем функции: это константа {}.",
    "The symbol '{}' ({}) can't be typed in plain text.": "Символ '{}' ({}) нельзя вводить в текстовом режиме.",
    "Unknown letter '{}'. Variables must be Latin letters a-z.": "Неизвестная буква '{}'. Переменные должны быть латинскими буквами a-z.",
    "Empty braces.": "Пустые фигурные скобки.",
    "'{}{}' is ambiguous.": "'{}{}' неоднозначно.",
    "Did you mean '{}'?": "Возможно, вы имели в виду '{}'?",
    "Write Greek letters by name, e.g. alpha, theta, pi.": "Греческие буквы пишутся названиями, например alpha, theta, pi.",
    "Expected '}' but the input ended.": "Ожидалась '}', но ввод закончился.",
    "Expected ';', a new line or '}' but found {}.": "Ожидались ';', новая строка или '}', но найдено: {}.",
    "Write {}^{} for a power, {}_{} for a subscript, or {}*{} to multiply.":
        "Напишите {}^{} для степени, {}_{} для индекса или {}*{} для умножения.",
    "The brace opened at position {} is never closed.": "Фигурная скобка, открытая в позиции {}, не закрыта.",
    "Only square matrices have an inverse; this one is {}.": "Обратная матрица есть только у квадратных матриц; размер этой матрицы {}.",
    "The determinant is 0, so the matrix has no inverse (it is singular).": "Определитель равен 0, поэтому обратной матрицы нет (матрица вырожденная).",
    "Expected a condition such as 0 < x < 1.": "Ожидалось условие, например 0 < x < 1.",
    "Unknown operator {}": "Неизвестный оператор {}",
    "Say which variable to use for the {}: the expression has {}.": "Укажите переменную для операции ({}): в выражении есть {}.",
    "This number is too large to work with exactly: ${}$ would have about {} digits.":
        "Это число слишком велико для точных вычислений: в ${}$ было бы около {} цифр.",
    "${}!$ is too large to work with exactly: it has about {} digits (the limit is {}!).":
        "${}!$ слишком велико для точных вычислений: в нём около {} цифр (предел {}!).",
    "Can't use {} here.": "{}: здесь использовать нельзя.",
    "{}(…) gives a list of results, so it can only stand on its own line (in the Matrices tab).":
        "{}(…) даёт список результатов, поэтому должно стоять в отдельной строке (на вкладке «Матрицы»).",
    "Expected an expression here, but found {}.": "Здесь ожидалось выражение, но найдено: {}.",
    "A number can't be raised to a matrix power. The power of a matrix is A^n with a whole number n (A^T is the transpose).":
        "Число нельзя возводить в матричную степень. Степень матрицы это A^n с целым n (A^T означает транспонирование).",
    "Only square matrices have powers; this one is {}.": "Возводить в степень можно только квадратные матрицы; размер этой матрицы {}.",
    "A matrix can only be raised to a whole-number power (A^T is its transpose).":
        "Матрицу можно возводить только в целую степень (A^T означает транспонирование).",
    "{} needs a square matrix; this one is {}.": "Для {} нужна квадратная матрица; размер этой матрицы {}.",
    "Write the derivative of {} as d/dx {}(x).": "Производную {} пишите как d/dx {}(x).",
    "The root index must be a whole number 2 or more.": "Показатель корня должен быть целым числом не меньше 2.",
    "Only a single variable can be restricted to an interval (x in [a, b]).": "Ограничить интервалом можно только одну переменную (x in [a, b]).",
    "The point of a limit must be a number (or ∞).": "Точка предела должна быть числом (или ∞).",
    "The bounds of an integral must be numbers (∞ is allowed).": "Пределы интеграла должны быть числами (можно ∞).",
    "A sum must start at a whole number; only the upper bound can be ∞.": "Сумма должна начинаться с целого числа; только верхний предел может быть ∞.",
    "A product must start at a whole number; only the upper bound can be ∞.": "Произведение должно начинаться с целого числа; только верхний предел может быть ∞.",
    "A matrix and a number can't be added or subtracted.": "Матрицу и число нельзя складывать или вычитать.",
    "Only matrices of the same size can be added: these are {} and {}.": "Складывать можно только матрицы одного размера: здесь {} и {}.",
    "A {} matrix can't be multiplied by a {} matrix: the first needs as many columns as the second has rows.":
        "Матрицу {} нельзя умножить на матрицу {}: в первой должно быть столько столбцов, сколько строк во второй.",
    "Dividing by a matrix isn't defined; multiply by its inverse, A^(-1).": "Деление на матрицу не определено; умножьте на обратную, A^(-1).",
    "A determinant needs a square matrix.": "Для определителя нужна квадратная матрица.",
    "The summation variable {} can't appear in its own bounds.": "Переменная суммирования {} не может входить в свои пределы.",
    "The product's variable {} can't appear in its own bounds.": "Переменная произведения {} не может входить в свои пределы.",
    "The lower bound of a sum must be a whole number (∞ is allowed at the top).": "Нижний предел суммы должен быть целым числом (∞ можно только сверху).",
    "The upper bound of a sum must be a whole number (∞ is allowed at the top).": "Верхний предел суммы должен быть целым числом (можно ∞).",
    "The lower bound of a product must be a whole number (∞ is allowed at the top).": "Нижний предел произведения должен быть целым числом.",
    "The upper bound of a product must be a whole number (∞ is allowed at the top).": "Верхний предел произведения должен быть целым числом.",
    "an interval": "интервал", "a cases block": "блок случаев",
    "f'(...) works for functions of one variable.": "f'(...) работает для функций одной переменной.",
    "For a real odd root of a negative number, write $\\sqrt[{}]{\\ }$ or root(x, {})":
        "Для вещественного корня нечётной степени из отрицательного числа напишите $\\sqrt[{}]{\\ }$ или root(x, {})",

    # ---------------------------------------------------- solving (shared) ---
    "Found by counting the roots numerically for {} values of a in [{}, {}] (x searched in [{}, {}]), then locating where the count changes. Outside that range of a the count is assumed not to change.":
        "Найдено численным подсчётом корней для {} значений a из [{}, {}] (поиск x в [{}, {}]) с уточнением мест, где их число меняется. Предполагается, что вне этого диапазона a число корней не меняется.",
    "The exact method didn't work here ({}), so this was found numerically.": "Точный метод здесь не сработал ({}), поэтому результат найден численно.",
    "Found numerically for {} values of a in [{}, {}], with x sampled in [{}, {}]; the ends of the intervals are estimates (whether they are included was not decided).":
        "Найдено численно для {} значений a из [{}, {}] при x из [{}, {}]; концы интервалов приближённые (входят ли они, не определялось).",
    "can't isolate the parameter": "не удаётся выразить параметр",
    "a direct check disagreed with it": "прямая проверка с ним не согласуется",
    "too many pieces": "слишком много участков",
    "too many periods": "слишком много периодов",
    "periodic with an unbounded restriction": "периодичность при неограниченном условии",
    "derivative undefined on an interval": "производная не определена на интервале",
    "branch check": "проверка ветвей",
    "the domain depends on the parameter": "область определения зависит от параметра",
    "not linear in the parameter": "зависимость от параметра нелинейна",
    "the coefficient of the parameter": "коэффициент при параметре",
    "no parameter": "нет параметра",
    "branches meet": "ветви сходятся",
    "${}$ is a solution (both the coefficient of a and the rest vanish there).":
        "${}$ является решением (там обращаются в ноль и коэффициент при a, и остальная часть).",
    "The critical values {} were recognised from their decimals, and solving exactly just below and just above each gave the counts on either side; that nothing else happens in between isn't proven.":
        "Критические значения {} распознаны по десятичной записи, а точное решение чуть ниже и чуть выше каждого дало число корней с обеих сторон; что между ними ничего не меняется, не доказано.",
    "At $x = {}$ the parameter drops out and the inequality is false there, whatever a is.":
        "При $x = {}$ параметр исчезает, и неравенство там ложно при любом a.",
    "For every a, {}": "При любом a: {}",
    "Checked by solving the equation directly at {}": "Проверено прямым решением уравнения при {}",
    "Checked by solving the inequality directly at {}": "Проверено прямым решением неравенства при {}",
    "not a finite union of intervals: {}": "не конечное объединение интервалов: {}",
    "can't compare {} and {}": "нельзя сравнить {} и {}",
    "periods don't fit": "периоды не согласуются",
    "the periods have no common multiple": "у периодов нет общего кратного",
    "too many": "слишком много",
    "The periodic and non-periodic parts were combined by listing the solutions in ${} \\le x \\le {}$.":
        "Периодическая и непериодическая части объединены перечислением решений при ${} \\le x \\le {}$.",
    "${}$ is not real there.": "${}$ там не является вещественным числом.",
    "It doesn't satisfy ${}$: the left side is ${}$ and the right side is ${}$.":
        "Не удовлетворяет ${}$: левая часть равна ${}$, а правая ${}$.",
    "No exact method worked; the solutions were searched for numerically with every unknown between {} and {}.":
        "Точные методы не сработали; решения искались численно при всех неизвестных от {} до {}.",
    "It doesn't satisfy ${}$.": "Не удовлетворяет ${}$.",
    "The interval is too long to list every solution in it.": "Интервал слишком длинный, чтобы перечислить все решения в нём.",
    "The other conditions restrict the parameter further.": "Остальные условия дополнительно ограничивают параметр.",
    "The two sides are not real numbers there.": "Обе части там не являются вещественными числами.",
    "Substituting gives ${}$ on the left but ${}$ on the right.": "При подстановке слева получается ${}$, а справа ${}$.",
    "The expression is not a real number there.": "Выражение там не является вещественным числом.",
    "The equation holds for every value where both sides are defined.": "Равенство верно при всех значениях, где определены обе части.",
    "too many critical points": "слишком много критических точек",
    "Part of the sign chart was found numerically (a root or edge the exact solver missed).":
        "Часть таблицы знаков найдена численно (корень или граница, пропущенные точным решателем).",
    "The roots were searched for numerically in {}.": "Корни искались численно на {}.",
    "The roots were searched for numerically in {}; beyond that the sign is assumed not to change.":
        "Корни искались численно на {}; предполагается, что дальше знак не меняется.",
    "${} = {}$ was checked numerically (to 45 digits), not proven exactly.":
        "${} = {}$ проверено численно (до 45 цифр), а не доказано точно.",
    "${} = {}$ was missed by the exact solver; it was found numerically and then proven by substitution.":
        "${} = {}$ пропущено точным решателем; найдено численно и затем доказано подстановкой.",

    # ---------------------------------------------------------- calculus ---
    "Analysis": "Исследование функции", "Result": "Результат", "neither even nor odd": "ни чётная, ни нечётная",
    "; periodic with period ${}$": "; периодическая с периодом ${}$", "Symmetry": "Симметрия", "Zeros": "Нули",
    "Critical points": "Критические точки", "Increasing on": "Возрастает на", "Decreasing on": "Убывает на",
    "Concave up on": "Выпукла вниз на", "Concave down on": "Выпукла вверх на",
    "even (the graph is symmetric about the y-axis)": "чётная (график симметричен относительно оси y)",
    "odd (the graph is symmetric about the origin)": "нечётная (график симметричен относительно начала координат)",
    "none (0 is not in the domain)": "нет (0 не входит в область определения)",
    "The zeros were found numerically in ${} \\le {} \\le {}$.": "Нули найдены численно при ${} \\le {} \\le {}$.",
    "Local maximum": "Локальный максимум", "Local minimum": "Локальный минимум",
    "Values shown with ≈ were found numerically: they are numerical estimates.": "Значения со знаком ≈ найдены численно: это численные оценки.",
    "Vertical asymptotes": "Вертикальные асимптоты", "Horizontal / oblique asymptotes": "Горизонтальные и наклонные асимптоты",
    "Horizontal asymptote": "Горизонтальная асимптота", "Oblique asymptote": "Наклонная асимптота",
    "Domain": "Область определения", "The domain could not be worked out exactly.": "Область определения не удалось найти точно.",
    "Only the first {} local maxima are listed.": "Показаны только первые {} локальных максимумов.",
    "Only the first {} local minima are listed.": "Показаны только первые {} локальных минимумов.",
    "Inflection points": "Точки перегиба",
    "Critical points where the derivative does not exist: {}": "Критические точки, где производная не существует: {}",
    "The function is not defined at ${} = {}$.": "Функция не определена при ${} = {}$.",
    "The derivative is not defined near ${} = {}$.": "Производная не определена вблизи ${} = {}$.",
    "The difference quotient has no limit there (the derivative does not exist).": "Разностное отношение там не имеет предела (производная не существует).",
    "The tangent at ${} = {}$ is vertical (the derivative is infinite), so the function is not differentiable there.":
        "Касательная при ${} = {}$ вертикальна (производная бесконечна), поэтому функция там не дифференцируема.",
    "The function is not differentiable at ${} = {}$: the derivative from the left is ${}$ and from the right ${}$ (a corner).":
        "Функция не дифференцируема при ${} = {}$: производная слева равна ${}$, а справа ${}$ (излом).",
    "${}$ is not in the domain of the function: {}": "${}$ не входит в область определения функции: {}",
    "This is the one-sided derivative from the left (the function is only defined on that side).": "Это односторонняя производная слева (функция определена только с этой стороны).",
    "This is the one-sided derivative from the right (the function is only defined on that side).": "Это односторонняя производная справа (функция определена только с этой стороны).",
    "${}$ is not continuous at ${} = {}$, so it has no derivative there.": "${}$ разрывна при ${} = {}$, поэтому там нет производной.",
    "${}$ does not appear in the equation, so $dy/dx$ is not defined by it.": "${}$ не входит в уравнение, поэтому оно не задаёт $dy/dx$.",
    "The point $\\left({}, {}\\right)$ is not on the curve.": "Точка $\\left({}, {}\\right)$ не лежит на кривой.",
    "At this point $\\partial F/\\partial {} = 0$: the tangent is vertical, ${} = {}$.": "В этой точке $\\partial F/\\partial {} = 0$: касательная вертикальна, ${} = {}$.",
    "No antiderivative in terms of elementary functions was found.": "Первообразная в элементарных функциях не найдена.",
    "Warning: differentiating the answer did not give the integrand back at every test point; check it.":
        "Внимание: дифференцирование ответа дало подынтегральную функцию не во всех контрольных точках; проверьте результат.",
    "The bounds are in reverse order, so the result is minus the integral from the smaller to the larger bound.":
        "Пределы идут в обратном порядке, поэтому результат равен интегралу от меньшего предела к большему со знаком минус.",
    "the integrand is unbounded at ${} = {}$, inside the interval": "подынтегральная функция не ограничена при ${} = {}$, внутри интервала",
    "the integrand is unbounded at ${} = {}$": "подынтегральная функция не ограничена при ${} = {}$",
    "The integrand is not defined for ${} \\in {}$, which is part of the interval, so this integral doesn't exist (in the real numbers).":
        "Подынтегральная функция не определена при ${} \\in {}$, а это часть интервала, поэтому интеграл не существует (в вещественных числах).",
    "the upper bound is infinite": "верхний предел бесконечен", "the lower bound is infinite": "нижний предел бесконечен",
    "Computed numerically (no exact antiderivative was found)": "Вычислено численно (точная первообразная не найдена)",
    "Warning: numerical integration gives ≈ {}; the exact result may be wrong.": "Внимание: численное интегрирование даёт ≈ {}; точный результат может быть неверным.",
    "This integral could not be computed exactly, and the numerical integration did not settle (it may diverge).":
        "Этот интеграл не удалось вычислить точно, а численное интегрирование не сошлось (возможно, он расходится).",
    "A Cauchy principal value may exist, but the integral itself diverges.": "Главное значение по Коши может существовать, но сам интеграл расходится.",
    "; it looks like ${}$, but that isn't proven.": "; похоже на ${}$, но это не доказано.",
    "Computed numerically (no exact antiderivative was found); it looks like ${}$, but that isn't proven.":
        "Вычислено численно (точная первообразная не найдена); похоже на ${}$, но это не доказано.",
    "Found numerically (no exact method worked).": "Найдено численно (точные методы не сработали).",
    "Warning: a numerical check gives about {}; the exact result may be wrong.": "Внимание: численная проверка даёт примерно {}; точный результат может быть неверным.",
    "The limit could not be found, exactly or numerically.": "Предел не удалось найти ни точно, ни численно.",
    "Found numerically; it looks like ${}$, but that isn't proven.": "Найдено численно; похоже на ${}$, но это не доказано.",
    "The function is not defined (as a real number) near ${}$, so the limit doesn't exist.":
        "Функция не определена (как вещественная) вблизи ${}$, поэтому предел не существует.",
    "The function is only defined to the left of ${} = {}$, so this is the one-sided limit from the left.":
        "Функция определена только слева от ${} = {}$, поэтому это односторонний предел слева.",
    "The function is only defined to the right of ${} = {}$, so this is the one-sided limit from the right.":
        "Функция определена только справа от ${} = {}$, поэтому это односторонний предел справа.",
    "The function is not defined (as a real number) just to the left of ${}$, so this one-sided limit doesn't exist.":
        "Функция не определена (как вещественная) сразу слева от ${}$, поэтому этот односторонний предел не существует.",
    "The function is not defined (as a real number) just to the right of ${}$, so this one-sided limit doesn't exist.":
        "Функция не определена (как вещественная) сразу справа от ${}$, поэтому этот односторонний предел не существует.",
    "; it also matches the first {} computed terms.": "; она также совпадает с первыми {} вычисленными членами.",
    "Checked by substitution: it satisfies the recurrence and the initial values, which proves it by induction":
        "Проверено подстановкой: формула удовлетворяет рекуррентному соотношению и начальным значениям, что доказывает её по индукции",
    "Checked: it matches the initial values, and it satisfies the recurrence numerically to 40 digits at 30 values of n (not proven symbolically)":
        "Проверено: формула совпадает с начальными значениями и численно удовлетворяет соотношению с точностью до 40 цифр при 30 значениях n (символьно не доказано)",
    "it satisfies the recurrence": "она удовлетворяет соотношению",
    "Found by spotting a pattern in the first terms. {}": "Найдено по закономерности в первых членах. {}",
    "Found by spotting a pattern in the first terms.": "Найдено по закономерности в первых членах.",
    "Estimated by computing the terms (numerical, not proven).": "Оценено вычислением членов (численно, не доказано).",
    "${}$ isn't defined here. Define it first, e.g. {}_n = …": "${}$ здесь не определено. Сначала определите, например {}_n = …",
    "{} must have a single index.": "У {} должен быть один индекс.",
    "${}_{{}}$ is not an earlier term ${}_{{}-1}, {}_{{}-2}, …$. Recursions like that are handled in the Piecewise & recursive tab.":
        "${}_{{}}$ не является предыдущим членом ${}_{{}-1}, {}_{{}-2}, …$. Такая рекурсия считается на вкладке «Кусочные и рекурсивные».",
    "The right side uses ${}_{{}}$; it may only use earlier terms such as ${}_{{}-1}$.":
        "В правой части есть ${}_{{}}$; можно использовать только предыдущие члены, например ${}_{{}-1}$.",
    "Recurrences of order more than 20 aren't supported.": "Рекуррентные соотношения порядка больше 20 не поддерживаются.",
    "No closed form is shown: it would need the roots of a cubic (or higher) equation, which have no readable formula.":
        "Явная формула не показана: для неё нужны корни кубического (или более высокого) уравнения, у которых нет читаемой записи.",
    "Estimated from the terms near n = 10⁸ (numerical; not proven).": "Оценено по членам вблизи n = 10⁸ (численно, не доказано).",
    "The terms could not be computed far enough to judge the limit.": "Не удалось вычислить достаточно далёкие члены, чтобы судить о пределе.",
    "The terms grow without bound while changing sign, so there is no limit (numerical, not proven).":
        "Члены неограниченно растут, меняя знак, поэтому предела нет (численно, не доказано).",
    "The terms get too large to judge the limit numerically.": "Члены становятся слишком большими, чтобы численно судить о пределе.",
    "The terms don't settle down in the first {} terms (they move between about {} and {}).":
        "В первых {} членах значения не стабилизируются (колеблются примерно от {} до {}).",
    "${}$ is not a real number.": "${}$ не является вещественным числом.",
    "the even and the odd terms both tend to it": "к нему стремятся и чётные, и нечётные члены",
    "the subsequences n = {}m, {}m + 1, …, {}m + {} all tend to it": "к нему стремятся все подпоследовательности n = {}m, {}m + 1, …, {}m + {}",
    "Far-out terms keep jumping between about {} and {} (checked numerically).": "Далёкие члены продолжают скакать примерно между {} и {} (проверено численно).",
    "The terms keep growing: the sequence appears to diverge to ∞ (numerical, not proven).":
        "Члены продолжают расти: похоже, последовательность расходится к ∞ (численно, не доказано).",
    "The terms keep decreasing: the sequence appears to diverge to −∞ (numerical, not proven).":
        "Члены продолжают убывать: похоже, последовательность расходится к −∞ (численно, не доказано).",
    "${}$ is not given and there is no rule for it.": "${}$ не задано, и правила для него нет.",
    "The recurrence needs {} to start.": "Для начала соотношению нужно {}.",
    "The terms approach ${}$ numerically, and $L = {}$ solves $L = {}$ exactly. That the terms converge was seen numerically, not proven.":
        "Члены численно приближаются к ${}$, а $L = {}$ точно решает $L = {}$. Сходимость замечена численно, но не доказана.",
    "${}$ is undefined (it is not a real number).": "${}$ не определено (это не вещественное число).",
    "${}$ is undefined, or too large to compute.": "${}$ не определено или слишком велико для вычисления.",
    "Found by splitting the terms: {}.": "Найдено разбиением членов: {}.",
    "${}$ is undefined: {}": "${}$ не определено: {}",
    "No exact formula was found; the {} terms were added as decimals.": "Точная формула не найдена; {} слагаемых сложены как десятичные дроби.",
    "From the formula ${}$ for the product up to $N$ ({})": "По формуле ${}$ для произведения до $N$ ({})",
    "SymPy found its sum": "SymPy нашёл его сумму",
    "the integral test gives the bounds {} ≤ S ≤ {}; the terms were checked to be decreasing and convex numerically":
        "интегральный признак даёт оценки {} ≤ S ≤ {}; убывание и выпуклость членов проверены численно",
    "the terms alternate in sign and shrink, so the sum lies between the partial sums $S_{{}}$ and $S_{{}}$: {} ≤ S ≤ {}":
        "знаки членов чередуются, а модули убывают, поэтому сумма лежит между частичными суммами $S_{{}}$ и $S_{{}}$: {} ≤ S ≤ {}",
    "only the digits on which all of mpmath's methods ({}) agree are shown; this is not a guaranteed bound":
        "показаны только цифры, на которых сходятся все методы mpmath ({}); это не гарантированная оценка",
    "The upper bound is below the lower one, so the sum is empty: it equals 0.": "Верхний предел меньше нижнего, поэтому сумма пуста и равна 0.",
    "Added term by term ({} terms).": "Сложено почленно (слагаемых: {}).",
    "From the formula ${}$ for the sum up to $N$ ({})": "По формуле ${}$ для суммы до $N$ ({})",
    "This sum has {} terms and no formula for it was found, so it can't be added up here.":
        "В этой сумме {} слагаемых, и формула для неё не найдена, поэтому сложить её здесь нельзя.",
    "Proved by induction: the formula gives the first term, and adding the next term gives the formula for n + 1.":
        "Доказано по индукции: формула даёт первый член, а прибавление следующего члена даёт формулу для n + 1.",
    "Checked against the sums added term by term for the first 8 values of n{}; the general identity was not proven symbolically.":
        "Сверено с почленными суммами для первых 8 значений n{}; в общем виде тождество символьно не доказано.",
    "The upper bound is below the lower one, so the product is empty: it equals 1.": "Верхний предел меньше нижнего, поэтому произведение пусто и равно 1.",
    "Multiplied factor by factor ({} factors).": "Перемножено по одному множителю (множителей: {}).",
    "This product has {} factors and no formula for it was found, so it can't be multiplied out here (up to {} factors are multiplied directly).":
        "В этом произведении {} множителей, и формула для него не найдена, поэтому вычислить его здесь нельзя (напрямую перемножается до {} множителей).",
    "From the formula ${}$ for the product up to $N$ ({}), evaluated at $N = {}$ with decimals: the exact value has about {} digits.":
        "По формуле ${}$ для произведения до $N$ ({}), вычислено при $N = {}$ в десятичных дробях: в точном значении около {} цифр.",
    "Proved by induction: the formula gives the first factor, and multiplying by the next factor gives the formula for n + 1.":
        "Доказано по индукции: формула даёт первый множитель, а умножение на следующий множитель даёт формулу для n + 1.",
    "Checked against the products multiplied out for the first 8 values of n{}; the general identity was not proven symbolically.":
        "Сверено с перемноженными произведениями для первых 8 значений n{}; в общем виде тождество символьно не доказано.",
    "its partial sums grow to ${}$": "его частичные суммы растут до ${}$",
    "SymPy's convergence tests show it converges": "признаки сходимости SymPy показывают, что он сходится",
    "It isn't even known whether its terms tend to 0.": "Неизвестно даже, стремятся ли его члены к 0.",
    "No formula was found for this series with the parameter {}. Give the parameter a value to test convergence.":
        "Для этого ряда с параметром {} формула не найдена. Задайте значение параметра, чтобы проверить сходимость.",
    "This holds for the values of {} where the series converges.": "Это верно при тех значениях {}, где ряд сходится.",
    "Undefined: the term for ${}$ has no value (it is not a real number).": "Не определено: член при ${}$ не имеет значения (это не вещественное число).",
    "This product has {} factors; its value is too large to work out here.": "В этом произведении {} множителей; его значение слишком велико для вычисления здесь.",
    "its terms shrink faster than any power of ${}$": "его члены убывают быстрее любой степени ${}$",
    "its terms are about $1/{}^{p}$ in size with $p = {} > 1$": "его члены имеют порядок $1/{}^{p}$ при $p = {} > 1$",
    "its terms grow without bound, so they don't tend to 0": "его члены неограниченно растут, поэтому не стремятся к 0",
    "its terms don't tend to 0 ({} tend to {})": "его члены не стремятся к 0 ({} стремятся к {})",
    "its terms tend to ${}$": "его члены стремятся к ${}$",
    "its terms tend to ${} \\ne 0$": "его члены стремятся к ${} \\ne 0$",
    "SymPy's convergence tests show it diverges": "признаки сходимости SymPy показывают, что он расходится",
    "{}. These don't show whether it converges.": "{}. По этим данным нельзя сказать, сходится ли он.",
    "No formula was found for this series with the parameter {}.": "Для этого ряда с параметром {} формула не найдена.",
    "Undefined: the term for ${}$ has no value. {}": "Не определено: член при ${}$ не имеет значения. {}",
    "From the formula ${}$ for the sum up to $N$, evaluated at $N = {}$ with 30-digit decimals (the exact value is a fraction far too long to show).":
        "По формуле ${}$ для суммы до $N$, вычислено при $N = {}$ с 30 десятичными цифрами (точное значение это слишком длинная дробь).",
    "The factor for ${}$ is 0, so the product is 0.": "Множитель при ${}$ равен 0, поэтому произведение равно 0.",
    "its terms all have the same sign and are about $1/{}^{p}$ in size with $p = {} < 1$, which is too large (like the harmonic series)":
        "все его члены одного знака и имеют порядок $1/{}^{p}$ при $p = {} < 1$, а это слишком много (как в гармоническом ряду)",
    "the even and the odd terms": "чётные и нечётные члены",
    "the terms with $k = {}m, …, {}m + {}$": "члены с $k = {}m, …, {}m + {}$",
    "its terms don't tend to 0 (they keep oscillating)": "его члены не стремятся к 0 (продолжают колебаться)",
    "its terms don't tend to 0 (they have no limit)": "его члены не стремятся к 0 (предела нет)",
    "Checked numerically: {}.": "Проверено численно: {}.",
    "No exact value was found. Numerically: {}.": "Точное значение не найдено. Численно: {}.",
    "It converges, but its value could not be estimated reliably.": "Ряд сходится, но надёжно оценить его значение не удалось.",
    "Partial sums (numerical): {}": "Частичные суммы (численно): {}",
    "For other values of {} the convergence was not decided here.": "При других значениях {} сходимость здесь не определена.",
    "Checked numerically at {}.": "Проверено численно при {}.",
    "Warning: a numerical check at a sample value disagrees; the formula may be wrong.":
        "Внимание: численная проверка при пробном значении не сходится; формула может быть неверной.",
    "Warning: a numerical check gives about {} ({}); the exact value may be wrong.":
        "Внимание: численная проверка даёт примерно {} ({}); точное значение может быть неверным.",
    "The exact value could not be checked numerically.": "Точное значение не удалось проверить численно.",
    "It looks like ${}$, but that isn't proven.": "Похоже на ${}$, но это не доказано.",
    "after ${} = {}$ the ratio of consecutive terms stays below {}, which bounds the rest: {} ≤ S ≤ {}":
        "после ${} = {}$ отношение соседних членов остаётся меньше {}, что ограничивает остаток: {} ≤ S ≤ {}",

    # -------------------------------------------------- graphing and tabs ---
    "solution set": "множество решений", "left side": "левая часть", "right side": "правая часть",
    "{} has too many break points in this range to mark each one; zoom in to see the endpoint dots.":
        "У {} слишком много точек разрыва в этом диапазоне; приблизьте график, чтобы увидеть точки на концах.",
    "{} has {} variables; only one-variable functions are graphed.": "У {} переменных: {}; графики строятся только для функций одной переменной.",
    "Found by differentiating both sides with respect to ${}$, treating ${}$ as a function of ${}$.":
        "Найдено дифференцированием обеих частей по ${}$, где ${}$ считается функцией от ${}$.",
    "The graph range must go from a smaller to a larger number.": "Диапазон графика должен идти от меньшего числа к большему.",
    "A condition ('if ...') only makes sense in a function definition, for example f(x) = 0 if x < 0, or after an equation in x and y: x^2 + y^2 = 25 for x = 3.":
        "Условие ('if ...') имеет смысл только в определении функции, например f(x) = 0 if x < 0, или после уравнения с x и y: x^2 + y^2 = 25 for x = 3.",
    "Equations and inequalities are solved in the Equations & inequalities tab. Here, an equation in x and y such as x^2 + y^2 = 25 gives dy/dx.":
        "Уравнения и неравенства решаются на вкладке «Уравнения и неравенства». Здесь уравнение с x и y, например x^2 + y^2 = 25, даёт dy/dx.",
    "Write a limit, a derivative, an integral, or a function to analyse.": "Напишите предел, производную, интеграл или функцию для исследования.",
    "Write one equation, e.g. x^2 + y^2 = 25.": "Напишите одно уравнение, например x^2 + y^2 = 25.",
    "graph range": "диапазон графика",
    "The values keep oscillating between ${}$ and ${}$.": "Значения продолжают колебаться между ${}$ и ${}$.",
    "The one-sided limits differ, so the (two-sided) limit does not exist.": "Односторонние пределы различны, поэтому (двусторонний) предел не существует.",
    "Derivative": "Производная",
    "The derivative can only exist there.": "Производная может существовать только там.",
    "The derivative does not exist there.": "Производная там не существует.",
    "No antiderivative in terms of elementary functions was found for ${}$. A definite integral (with bounds) can still be computed.":
        "Для ${}$ первообразная в элементарных функциях не найдена. Определённый интеграл (с пределами) всё же можно вычислить.",
    "Checked: differentiating the answer gives the integrand back.": "Проверено: дифференцирование ответа даёт подынтегральную функцию.",
    "The constant C may be different on each interval where the function is defined.": "Постоянная C может быть своей на каждом интервале, где функция определена.",
    "Checked by numerical integration.": "Проверено численным интегрированием.",
    "Improper integral ({}): it diverges{}.": "Несобственный интеграл ({}): расходится{}.",
    "Improper integral ({}): it converges.": "Несобственный интеграл ({}): сходится.",
    "vertical asymptote": "вертикальная асимптота",
    "'otherwise' only makes sense in a function definition by cases.": "'otherwise' имеет смысл только в определении функции по случаям.",
    "That's an equation in one variable: solve it in the Equations & inequalities tab. Here, an equation in two variables (x and y) gives dy/dx.":
        "Это уравнение с одной переменной: решите его на вкладке «Уравнения и неравенства». Здесь уравнение с двумя переменными (x и y) даёт dy/dx.",
    "Implicit differentiation works with two variables (x and y).": "Неявное дифференцирование работает с двумя переменными (x и y).",
    "Give the point as 'for {} = 3 and {} = 4' (or just 'for {} = 3').": "Укажите точку как 'for {} = 3 and {} = 4' (или просто 'for {} = 3').",
    "Second derivative": "Вторая производная",
    "There is no variable here, so this is just its value.": "Здесь нет переменной, поэтому это просто значение.",
    "A function to analyse must have one variable (here: {}": "Функция для исследования должна иметь одну переменную (здесь: {}",
    "Limit": "Предел",
    "The function becomes infinite with different signs on the two sides.": "Функция обращается в бесконечность разных знаков с двух сторон.",
    "Simplified": "Упрощено", "Tangent line": "Касательная", "Antiderivative": "Первообразная",
    "(there is no formula with elementary functions).": "(формулы в элементарных функциях нет).",
    "Integral": "Интеграл",
    "The answer uses the special function {}": "В ответе есть специальная функция {}",
    "Still working: the rest of the analysis was not finished.": "Вычисление ещё идёт: остальное исследование не завершено.",
    "No point of the curve has ${} = {}$.": "На кривой нет точек с ${} = {}$.",
    "Slope": "Угловой коэффициент", "${}$ does not exist.": "${}$ не существует.",
    "From the left": "Слева", "From the right": "Справа", "Tangent at ({}, {})": "Касательная в точке ({}, {})",
    "local max": "локальный максимум", "local min": "локальный минимум",
    "the interval": "интервал",
    "{} {} treated as {}. How the solutions depend on it (when they are real, how many there are) is the job of the Parameters tab (milestone 6). To solve for another letter, fill in 'solve for'.":
        "{} {} считается как {}. Как решения зависят от этого (когда они вещественны, сколько их), показывает вкладка «Параметры». Чтобы решить относительно другой буквы, заполните 'solve for'.",
    "This line is not an equation or inequality. Use the Evaluate tab to compute a value, or write an equation such as x^2 = 4.":
        "Эта строка не уравнение и не неравенство. Для вычисления значения используйте вкладку «Вычисления» или напишите уравнение, например x^2 = 4.",
    "Solutions in {}": "Решения на {}", "In {}": "На {}", "Solution set": "Множество решений",
    "These lines were solved together as one system, because they share unknowns. To solve them one at a time, calculate them separately.":
        "Эти строки решены вместе как одна система, потому что у них общие неизвестные. Чтобы решить их по отдельности, вычислите их отдельно.",
    "A condition can't be used here.": "Условие здесь использовать нельзя.",
    "'or' between equations works only with one unknown; between inequalities in x and y it gives a region.":
        "'or' между уравнениями работает только с одной неизвестной; между неравенствами с x и y оно даёт область.",
    "This can't be decided (a side is not a real number).": "Это нельзя определить (одна из частей не является вещественным числом).",
    "Decided numerically: the two sides agree to 45 digits.": "Определено численно: обе части совпадают с точностью до 45 цифр.",
    "Rejected ${}$ (extraneous): {}": "Отброшено ${}$ (посторонний корень): {}",
    "Rejected ${} = {}$ (extraneous): {}": "Отброшено ${} = {}$ (посторонний корень): {}",
    "Domain: ${} \\in {}$.": "Область определения: ${} \\in {}$.",
    "Each solution was checked by substituting it back into the equation.": "Каждое решение проверено подстановкой в уравнение.",
    "Values shown only with ≈ were found numerically: they are numerical estimates.": "Значения только со знаком ≈ найдены численно: это численные оценки.",
    "No exact method found every solution, so ${} \\le {} \\le {}$ was searched numerically; there may be more solutions outside this range (change it with the x range options).":
        "Точные методы не нашли всех решений, поэтому ${} \\le {} \\le {}$ просмотрено численно; вне этого диапазона могут быть другие решения (его можно изменить в настройках диапазона x).",
    "In complex numbers the solutions would be ${}$.": "В комплексных числах решениями были бы ${}$.",
    "This has the parameter(s) {}. Inequalities and systems with parameters belong to the Parameters tab (milestone 6).":
        "Здесь есть параметры: {}. Неравенства и системы с параметрами решаются на вкладке «Параметры».",
    "The solution set is the shaded region in the graph. A solid boundary is included, a dashed one is not.":
        "Множество решений это закрашенная область на графике. Сплошная граница входит в него, пунктирная нет.",
    "Each solution was checked by substituting it back into every equation.": "Каждое решение проверено подстановкой во все уравнения.",
    "Expected an equation or inequality.": "Ожидалось уравнение или неравенство.",
    "The option 'solve for' names {}, which doesn't appear here.": "В настройке 'solve for' указано {}, но здесь этого нет.",
    "The condition after 'for' must be about the unknown, e.g. x in [0, 2pi] or x > 0.": "Условие после 'for' должно относиться к неизвестной, например x in [0, 2pi] или x > 0.",
    "Systems of inequalities can be solved for two unknowns (a region in the plane), not more.": "Системы неравенств решаются для двух неизвестных (область на плоскости), не больше.",
    "Curve": "Кривая", "Every point of the curve in the graph is a solution (infinitely many).": "Каждая точка кривой на графике является решением (их бесконечно много).",
    "The two sides are never equal for real x and y in the range searched (a grid check, not a proof).":
        "Обе части нигде не равны при вещественных x и y в проверенном диапазоне (проверка по сетке, а не доказательство).",
    "Provisional: the exact solver was still working.": "Предварительно: точный решатель ещё работал.",
    "A cases block can only stand in a function definition such as f(x) = {cases}.": "Блок случаев может стоять только в определении функции, например f(x) = {cases}.",
    "General solution": "Общее решение", "Corner points": "Угловые точки", "Infinitely many solutions": "Бесконечно много решений",
    "Solutions": "Решения", "Solution": "Решение",
    "Type an equation or inequality, e.g. x^2 - 5x + 6 = 0.": "Введите уравнение или неравенство, например x^2 - 5x + 6 = 0.",
    "Interval form": "В виде интервалов", "As inequalities": "В виде неравенств",
    "This can't be solved here ({}).": "Здесь это решить нельзя ({}).", "Solved for y": "Выражено через y",
    "Limits and integrals are worked out in the Calculus tab (with checks and a graph).": "Пределы и интегралы считаются на вкладке «Матанализ» (с проверками и графиком).",
    "A condition ('if ...') only makes sense in a function definition, for example f(x) = 0 if x < 0.":
        "Условие ('if ...') имеет смысл только в определении функции, например f(x) = 0 if x < 0.",
    "Equations, inequalities and systems are solved in the Equations & inequalities tab.": "Уравнения, неравенства и системы решаются на вкладке «Уравнения и неравенства».",
    "Give the cases a name to use them, for example f(x) = {cases}.": "Чтобы использовать случаи, дайте им имя, например f(x) = {cases}.",
    "Conditions can't be evaluated on their own here.": "Условия здесь нельзя вычислять сами по себе.",
    "{} is recursive. The Piecewise & recursive tab shows the call chain and a graph.": "{} рекурсивна. Вкладка «Кусочные и рекурсивные» показывает цепочку вызовов и график.",
    "Undefined (the expression has no value here).": "Не определено (здесь выражение не имеет значения).",
    "The result could not be evaluated.": "Результат не удалось вычислить.",
    "Expanded": "Раскрыто", "Factored": "Разложено на множители",
    "This is an equation or inequality with a variable: solve it in the Equations & inequalities tab.": "Это уравнение или неравенство с переменной: решите его на вкладке «Уравнения и неравенства».",
    "Derivatives of recursive functions aren't supported.": "Производные рекурсивных функций не поддерживаются.",
    "Stored": "Сохранено",
    "The result is not a real number (it would be ${}$ in complex numbers).": "Результат не является вещественным числом (в комплексных числах это ${}$).",
    "This comparison can't be decided (a side is not a real number).": "Это сравнение нельзя решить (одна из частей не является вещественным числом).",
    "Lists can only contain expressions here.": "Списки здесь могут содержать только выражения.",
    "Defined": "Определено",
    "{} is recursive, so it can only be evaluated at numbers here.": "{} рекурсивна, поэтому здесь её можно вычислять только в числах.",
    "Undefined. {}": "Не определено. {}", "Undefined.": "Не определено.",
    "Infinite products aren't supported yet. A product up to a whole number or a letter works.":
        "Бесконечные произведения пока не поддерживаются. Работают произведения до целого числа или буквы.",
    "Products up to a letter are worked out in the Sequences & series tab.": "Произведения до буквы считаются на вкладке «Последовательности и ряды».",
    "${}$ is too large to work out exactly here; try the Sequences & series tab.": "${}$ слишком велико для точного вычисления здесь; попробуйте вкладку «Последовательности и ряды».",
    "Infinite sums and sums up to a letter are worked out in the Sequences & series tab.": "Бесконечные суммы и суммы до буквы считаются на вкладке «Последовательности и ряды».",
    "${}$ has too many terms to add up exactly here; try the Sequences & series tab.": "В ${}$ слишком много слагаемых для точного сложения здесь; попробуйте вкладку «Последовательности и ряды».",
    "Move the slider{} to change {}; a line such as a = 2 sets the start value, and a in [0, 10] the range.":
        "Двигайте ползунки, чтобы менять {1}; строка вида a = 2 задаёт начальное значение, а a in [0, 10] диапазон.",
    "The x range must go from a smaller to a larger number.": "Диапазон x должен идти от меньшего числа к большему.",
    "The {} must be numbers, for example -10 and 10 (pi and 2pi work too).": "{}: нужны числа, например -10 и 10 (pi и 2pi тоже подходят).",
    "A number in this line is too large to draw.": "Число в этой строке слишком велико для графика.",
    "A surface is written z = f(x, y), for example z = x^2 - y^2.": "Поверхность задаётся как z = f(x, y), например z = x^2 - y^2.",
    "This surface can't be drawn (it uses something the browser can't compute).": "Эту поверхность нельзя построить (в ней есть то, что браузер не может вычислить).",
    "z is the height of the surface (z = f(x, y)), so it can't be used in the formula itself.": "z это высота поверхности (z = f(x, y)), поэтому её нельзя использовать в самой формуле.",
    "'or' between equations can't be drawn; put each on its own line.": "'or' между уравнениями нельзя построить; напишите каждое в своей строке.",
    "This relation can't be drawn.": "Это соотношение нельзя построить.",
    "This function can't be drawn with sliders (it uses something the browser can't compute).": "Эту функцию нельзя построить с ползунками (в ней есть то, что браузер не может вычислить).",
    "Write y = … or f(x) = …, or a relation in x and y such as x^2 + y^2 = 4.": "Напишите y = … или f(x) = … либо соотношение с x и y, например x^2 + y^2 = 4.",
    "Only expressions can be graphed here.": "Здесь можно строить только выражения.",
    "Change the x, y and z ranges above the graph (or zoom out) to see more. 'True proportions' draws x, y and z to the same scale; 'cut off spikes' hides the tallest values near poles.":
        "Чтобы увидеть больше, измените диапазоны x, y и z над графиком или отдалите его. «Истинные пропорции» рисуют x, y и z в одном масштабе; «срезать пики» скрывает самые большие значения около полюсов.",
    "Write each part as an equation or inequality, e.g. y > x^2 and y < 4.": "Запишите каждую часть как уравнение или неравенство, например y > x^2 and y < 4.",
    "Use x as the variable; the other letters then become sliders.": "Используйте x как переменную; остальные буквы станут ползунками.",
    "Functions defined on other lines can't be combined with slider parameters yet.": "Функции из других строк пока нельзя сочетать с ползунками.",
    "{} has {} variables; only functions of one or two variables are graphed.": "У {} переменных: {}; графики строятся только для функций одной или двух переменных.",
    "{} is recursive; it can't be used inside a curve or region.": "{} рекурсивна; её нельзя использовать в кривой или области.",
    "Some break points of {} were located numerically.": "Некоторые точки разрыва {} найдены численно.",
    "{} is recursive; it can't be drawn as a surface.": "{} рекурсивна; её нельзя построить как поверхность.",
    "{} is recursive, so it can't have a slider parameter.": "{} рекурсивна, поэтому у неё не может быть ползунка.",
    "Write a matrix, an operation on matrices, or a linear system.": "Напишите матрицу, операцию над матрицами или линейную систему.",
    "Only a matrix or a number can be stored.": "Сохранить можно только матрицу или число.",
    "Eigenvectors (a basis of each eigenspace)": "Собственные векторы (базис каждого собственного подпространства)",
    "Unknown operation {}.": "Неизвестная операция {}.",
    "{}(…) gives several results, so it can't be stored.": "{}(…) даёт несколько результатов, поэтому сохранить нельзя.",
    "Reduced form: {}": "Приведённый вид: {}",
    "The entries contain {}: the rank, inverse, reduced form and eigenvectors are for general values of {}; for special values{} they can be different.":
        "В элементах есть {}: ранг, обратная матрица, приведённый вид и собственные векторы даны для общих значений {}; при особых значениях{} они могут отличаться.",
    "(for example where the determinant ${}$ is 0)": "(например, где определитель ${}$ равен 0)",
    "eigenvalue": "собственное значение", "eigenvectors": "собственные векторы",
    "algebraic multiplicity": "алгебраическая кратность", "geometric multiplicity": "геометрическая кратность",
    "{} needs a matrix, e.g. {}([[1, 2], [3, 4]]).": "Для {} нужна матрица, например {}([[1, 2], [3, 4]]).",
    "There are no unknowns in this system.": "В этой системе нет неизвестных.",
    "Infinitely many solutions: {} can be any real number{} (free unknowns).": "Бесконечно много решений: {} может быть любым вещественным числом{} (свободные неизвестные).",
    "Matrix ({})": "Матрица ({})", "Determinant: {}": "Определитель: {}", "Rank": "Ранг", "Transpose": "Транспонированная",
    "Reduced row echelon form": "Приведённый ступенчатый вид", "Characteristic polynomial": "Характеристический многочлен",
    "Eigenvalues": "Собственные значения",
    "Checked: multiplying it by ${}$ gives the identity matrix.": "Проверено: умножение на ${}$ даёт единичную матрицу.",
    "There are no pivots (the matrix is 0).": "Ведущих элементов нет (матрица нулевая).",
    "The right-hand side must be a vector, e.g. solve(A, [1, 2]).": "Правая часть должна быть вектором, например solve(A, [1, 2]).",
    "Only equations can be solved here (inequalities are in the Equations & inequalities tab).": "Здесь можно решать только уравнения (неравенства на вкладке «Уравнения и неравенства»).",
    "A matrix equation A = B compares matrices; to solve A·x = b use solve(A, b).": "Матричное равенство A = B сравнивает матрицы; чтобы решить A·x = b, используйте solve(A, b).",
    "This system is not linear; the Equations & inequalities tab solves it.": "Эта система нелинейна; её решает вкладка «Уравнения и неравенства».",
    "Augmented matrix": "Расширенная матрица", "Reduced form": "Приведённый вид", "Determinant": "Определитель", "Trace": "След",
    "none: the determinant is 0": "нет: определитель равен 0", "Inverse: {}": "Обратная: {}",
    "Diagonalizable (over ℝ)": "Диагонализуема (над ℝ)", "Inverse": "Обратная матрица", "Result ({})": "Результат ({})",
    "Stored ({})": "Сохранено ({})", "Pivot columns: {}": "Ведущие столбцы: {}",
    "no solutions": "нет решений", "not determined": "не определено", "holds for every x": "верно при всех x",
    "holds for some x, not all": "верно при некоторых x, но не всех", "infinitely many solutions": "бесконечно много решений",
    "The option 'solutions wanted' must be a number of solutions such as 2, 0, >= 1 or inf.": "Настройка «нужно решений» должна быть числом решений, например 2, 0, >= 1 или inf.",
    "every x in the interval": "каждый x из интервала",
    "Give both ends of a range, or neither.": "Укажите оба конца диапазона или ни одного.",
    "A range must go from a smaller to a larger number.": "Диапазон должен идти от меньшего числа к большему.",
    "at least {}": "не меньше {}", "at most {}": "не больше {}", "more than {}": "больше {}", "fewer than {}": "меньше {}",
    "({} per period)": "({} на период)",
    "Write one equation or inequality in x with a parameter, e.g. x^2 - 2x + a = 0.": "Напишите одно уравнение или неравенство с x и параметром, например x^2 - 2x + a = 0.",
    "Write one equation or inequality.": "Напишите одно уравнение или неравенство.",
    "≠ isn't supported here; write an equation or an inequality.": "Знак ≠ здесь не поддерживается; напишите уравнение или неравенство.",
    "Use x as the unknown (and another letter, such as a, as the parameter).": "Используйте x как неизвестную (а другую букву, например a, как параметр).",
    "There is no parameter here. Equations without one are solved in the Equations & inequalities tab.": "Здесь нет параметра. Уравнения без параметра решаются на вкладке «Уравнения и неравенства».",
    "The restriction may only use x, e.g. for x > 0.": "В ограничении может быть только x, например for x > 0.",
    "The restriction must be a single interval, e.g. for x in [0, 2pi] or for x > 0.": "Ограничение должно быть одним интервалом, например for x in [0, 2pi] или for x > 0.",
    "The equation is periodic (period ${}$), so a solution comes back in every period. Add 'for x in [0, 2pi]' to count the solutions in an interval.":
        "Уравнение периодично (период ${}$), поэтому решение повторяется в каждом периоде. Добавьте 'for x in [0, 2pi]', чтобы посчитать решения на интервале.",
    "Number of solutions for each a": "Число решений при каждом a",
    "Number of solutions for each a (✓ = checked by solving directly)": "Число решений при каждом a (✓ = проверено прямым решением)",
    "At some critical values the number of solutions wasn't determined, so they are left out of the answer.": "При некоторых критических значениях число решений не определено, поэтому они не вошли в ответ.",
    "For {}": "При {}", "line {} = const": "прямая {} = const",
    "The option 'solutions wanted' is for equations; for an inequality both questions are answered above.": "Настройка «нужно решений» работает для уравнений; для неравенства выше есть ответ на оба вопроса.",
    "'otherwise' doesn't make sense here.": "'otherwise' здесь не имеет смысла.",
    "Only one parameter at a time: this has {}. Give the others values.": "Только один параметр за раз: здесь {}. Задайте значения остальным.",
    "The restriction must be on x, e.g. for x in [0, 2pi].": "Ограничение должно быть на x, например for x in [0, 2pi].",
    "Number of solutions": "Число решений", "solutions": "решения", "Holds for {}": "Верно при {}", "Has a solution": "Есть решение",
    "where it holds": "где верно", "solution for every a": "решение при каждом a",
    "Steps, in the order they were finished": "Шаги в порядке завершения", "({} rows not shown)": "(не показано строк: {})",
    "Steps, in the order they were finished ({} rows not shown)": "Шаги в порядке завершения (не показано строк: {})",
    "Call": "Вызов", "Case used": "Случай", "Value": "Значение", "Does not terminate": "Не завершается",
    "{} different calls were evaluated (depth {}).": "Вычислено разных вызовов: {} (глубина {}).",
    "{} has no value for most of this range: either no case applies or its recursion does not end there.":
        "{} не имеет значения на большей части диапазона: либо не подходит ни один случай, либо рекурсия там не заканчивается.",
    "Call chain": "Цепочка вызовов",
    "No function is defined yet. Define one by cases, for example f(x) = 0 if 0 < x < 1 and f(x) = 1 + f(log(x, 2)) if x >= 1, then evaluate f(16).":
        "Функция ещё не определена. Задайте её по случаям, например f(x) = 0 if 0 < x < 1 и f(x) = 1 + f(log(x, 2)) if x >= 1, затем вычислите f(16).",
    "Sum": "Сумма", "Product": "Произведение",
    "The index of an initial value must be a whole number, e.g. {}_0 = 1.": "Индекс начального значения должен быть целым числом, например {}_0 = 1.",
    "An initial value must be a number: ${}_{{}} = …$ with a number on the right.": "Начальное значение должно быть числом: ${}_{{}} = …$ с числом справа.",
    "${}_{{}}$ must be a real number.": "${}_{{}}$ должно быть вещественным числом.",
    "${}_{{}}$ is given twice.": "${}_{{}}$ задано дважды.",
    "The index on the left must be like n or n + 1 (here it is ${}$). Recursions such as f(2n) = … belong in the Piecewise & recursive tab.":
        "Индекс слева должен быть вроде n или n + 1 (здесь ${}$). Рекурсия вроде f(2n) = … считается на вкладке «Кусочные и рекурсивные».",
    "The formula uses {} besides the index {}. Use numbers instead (or {} as the index).": "Кроме индекса {1}, в формуле есть {0}. Подставьте числа (или используйте {2} как индекс).",
    "Terms for {} = {} to {}": "Члены при {} от {} до {}",
    "The exact value got too large to keep, so this was computed with 30-digit decimals.": "Точное значение стало слишком большим, поэтому вычислено с 30 десятичными цифрами.",
    "The upper bound must be a whole number, a letter, or ∞.": "Верхний предел должен быть целым числом, буквой или ∞.",
    "Equations and inequalities are solved in the Equations & inequalities tab. Here, define a sequence (a_n = …) or write a sum, e.g. sum(1/n^2, n, 1, inf).":
        "Уравнения и неравенства решаются на вкладке «Уравнения и неравенства». Здесь задайте последовательность (a_n = …) или напишите сумму, например sum(1/n^2, n, 1, inf).",
    "Write a sequence (a_n = … or a formula in n) or a sum.": "Напишите последовательность (a_n = … или формулу от n) или сумму.",
    "Read as the sequence ${} = {}$ for ${} \\ge {}$ (change the first index in the options).": "Понято как последовательность ${} = {}$ при ${} \\ge {}$ (первый индекс можно изменить в настройках).",
    "That term is too far out to compute by stepping through the recurrence (more than {} steps), and no closed form was found.":
        "Этот член слишком далёк для пошагового вычисления (больше {} шагов), а явная формула не найдена.",
    "Start the sum at a whole number, e.g. sum(1/k^2, k, 1, inf).": "Начните сумму с целого числа, например sum(1/k^2, k, 1, inf).",
    "Write sums and products on separate lines.": "Пишите суммы и произведения в отдельных строках.",
    "It diverges{}: {}.": "Расходится{}: {}.", "partial sums S_N": "частичные суммы S_N",
    "The option '{}' must be a whole number.": "Настройка '{}' должна быть целым числом.",
    "A sequence has a single index: write {}_n = ….": "У последовательности один индекс: напишите {}_n = ….",
    "Sums and products inside a sequence's definition aren't supported; write the sum or product on its own line.":
        "Суммы и произведения внутри определения последовательности не поддерживаются; напишите их в отдельной строке.",
    "Only initial values of {} are given. Add the rule, e.g. {}_n = 2{}_(n-1) + 1.": "Для {} заданы только начальные значения. Добавьте правило, например {}_n = 2{}_(n-1) + 1.",
    "No value is given for {}, so the solution has constants ($C_0, C_1, …$). Give {} to fix them.": "Значение {} не задано, поэтому в решении есть постоянные ($C_0, C_1, …$). Задайте {}, чтобы их определить.",
    "Checked by substitution: it satisfies the recurrence for any constants.": "Проверено подстановкой: формула удовлетворяет соотношению при любых постоянных.",
    "The limit could not be determined.": "Предел определить не удалось.",
    "the terms with $n = {}m, {}m+1, …, {}m+{}$": "члены с $n = {}m, {}m+1, …, {}m+{}$",
    "It does not exist: {} tend to {}.": "Не существует: {} стремятся к {}.",
    "The sequence diverges to ${}$.": "Последовательность расходится к ${}$.",
    "{} is not defined. Define it first, e.g. {}_n = ….": "{} не определена. Сначала задайте её, например {}_n = ….",
    "Ask for one term with a number as the index, e.g. {}_10.": "Запросите один член с числовым индексом, например {}_10.",
    "The index must be a whole number ≥ {} (the first index of {}).": "Индекс должен быть целым числом ≥ {} (первый индекс {}).",
    "${}_{{}}$ is undefined (not a real number).": "${}_{{}}$ не определено (не вещественное число).",
    "That term could not be computed.": "Этот член вычислить не удалось.",
    "No formula was found for ${}$. With a number as the upper bound it can be added up.": "Для ${}$ формула не найдена. С числом в верхнем пределе сумму можно вычислить.",
    "For ${} \\ge {}$ (a whole number).": "При ${} \\ge {}$ (целое число).",
    "{} is not defined here.": "{} здесь не определена.",
    "${}$ has no closed form, so it can only be summed with numbers as bounds.": "У ${}$ нет явной формулы, поэтому суммировать можно только с числовыми пределами.",
    "Products of products aren't supported.": "Произведения произведений не поддерживаются.",
    "Products of a defined sequence's terms aren't supported; write the formula instead.": "Произведения членов заданной последовательности не поддерживаются; напишите формулу.",
    "Start the product at a whole number, e.g. prod(1 + 1/k, k, 1, n).": "Начните произведение с целого числа, например prod(1 + 1/k, k, 1, n).",
    "It converges: {}.": "Сходится: {}.",
    "{} is defined by two formulas. Keep one, and give initial values such as {}_0 = … on their own.": "{} задана двумя формулами. Оставьте одну, а начальные значения вроде {}_0 = … укажите отдельно.",
    "There is no index here, so this is just its value.": "Здесь нет индекса, поэтому это просто значение.",
    "A formula for a sequence must use one letter as the index (here: {}": "В формуле последовательности индексом должна быть одна буква (здесь: {}",
    "It does not exist: the terms keep oscillating.": "Не существует: члены продолжают колебаться.",
    "${}_{{}}$ is undefined: {}": "${}_{{}}$ не определено: {}",
    "Added up from the computed terms.": "Сложено из вычисленных членов.",
    "The sum uses terms before the first one, ${}_{{}}$.": "В сумме есть члены до первого, ${}_{{}}$.",
    "${}$ is not a term of {} (its first index is {}).": "${}$ не является членом {} (первый индекс {}).",
    "The terms got too large to add up exactly.": "Члены стали слишком большими для точного сложения.",
    "Start each sum at a whole number.": "Начинайте каждую сумму с целого числа.",
    "${}$ is too large to work out exactly; write it on its own line.": "${}$ слишком велико для точного вычисления; напишите его в отдельной строке.",
    "The upper bound of a product must be a whole number or a letter.": "Верхний предел произведения должен быть целым числом или буквой.",
    "When": "Когда", "Convergence": "Сходимость",
    "The series of absolute values diverges, so the convergence is conditional.": "Ряд из модулей расходится, поэтому сходимость условная.",
    "The formula holds for ${} \\ge {}$ (the given initial values before that don't follow it).": "Формула верна при ${} \\ge {}$ (заданные раньше начальные значения ей не следуют).",
    "First {} terms": "Первые члены ({})", "First term": "Первый член", "Type": "Тип", "Partial sums": "Частичные суммы",
    "No formula was found for ${}$. With a number as the upper bound it can be multiplied out.": "Для ${}$ формула не найдена. С числом в верхнем пределе произведение можно вычислить.",
    "Still working: the rest was not finished.": "Вычисление ещё идёт: остальное не завершено.",
    "Whether it also converges absolutely was not decided.": "Сходится ли он абсолютно, не определено.",
    "Closed form": "Явная формула", "No closed form was found; the terms are computed from the recurrence.": "Явная формула не найдена; члены вычисляются по рекуррентному соотношению.",
    "Partial sums: {}": "Частичные суммы: {}", "${}$ could not be computed.": "${}$ вычислить не удалось.",
    "${}$ has no exact value here; write it on its own line to see why.": "У ${}$ здесь нет точного значения; напишите его в отдельной строке, чтобы узнать почему.",
    "Write a sum up to a letter on its own line.": "Напишите сумму до буквы в отдельной строке.",
    "${}$ has no exact value.": "У ${}$ нет точного значения.",

    # ------------------------------------------------- words inside \text{} ---
    "none": "нет", "otherwise": "иначе", "true": "верно", "false": "неверно", "nowhere": "нигде", "if": "если", "or": "или",
    "and": "и", "diverges": "расходится", "converges": "сходится", "no real solutions": "нет вещественных решений",
    "yes": "да", "no": "нет", "undefined": "не определено", "the limit does not exist": "предел не существует",
    "not decided": "не определено", "no value of": "ни при каком", "no solution": "нет решений",
    "no solutions in this interval": "нет решений на этом интервале",
    "no solution found in terms of the parameters": "решение через параметры не найдено",
    "no real points in the shown range": "нет вещественных точек в показанном диапазоне", "geometric,": "геометрическая,",
    "for no": "ни при каком", "for every": "при любом", "error": "ошибка", "does not exist": "не существует",
    "converges conditionally": "сходится условно", "converges absolutely": "сходится абсолютно", "constant": "постоянная",
    "arithmetic,": "арифметическая,", "all": "все", "(formula)": "(формула)", "to": "до", "per period": "на период",

    # -------------------------------------------------- server and worker ---
    "Internal error: {}: {}": "Внутренняя ошибка: {}: {}",
    "The exact solver ran out of time after {} s. The answers below come from the fast numerical pass: they are numerical estimates.":
        "Точному решателю не хватило времени ({} с). Ответы ниже получены быстрым численным проходом: это численные оценки.",
    "Timed out after {} s, so the computation was stopped.": "Время истекло ({} с), вычисление остановлено.",
    "Try a simpler form of the problem, or raise the time limit in Settings.": "Попробуйте упростить задачу или увеличьте лимит времени в настройках.",
    "Stopped. The answers below come from the fast numerical pass: they are numerical estimates.":
        "Остановлено. Ответы ниже получены быстрым численным проходом: это численные оценки.",
    "Stopped.": "Остановлено.", "Re-drawing timed out.": "Время перерисовки истекло.",
    "The computation engine stopped unexpectedly (possibly out of memory).": "Вычислительное ядро неожиданно остановилось (возможно, не хватило памяти).",
    "The computation engine stopped unexpectedly.": "Вычислительное ядро неожиданно остановилось.",
    "The computation engine did not start.": "Вычислительное ядро не запустилось.",

    # ------------------------------------------- labels and assembled phrases ---
    "area": "площадь", "y-intercept": "пересечение с осью y", "y-intercept ({}, {})": "пересечение с осью y ({}, {})",
    "zero": "нуль", "zero ({}, {})": "нуль ({}, {})", "limit": "предел", "limit {}": "предел {}", "tangent": "касательная",
    "point": "точка", "inflection": "перегиб", "inflection ({}, {})": "перегиб ({}, {})", "corners": "угловые точки",
    "f (integrand)": "f (подынтегральная функция)", "x allowed": "допустимые x", "max": "максимум", "min": "минимум",
    "local max ({}, {})": "локальный максимум ({}, {})", "local min ({}, {})": "локальный минимум ({}, {})",
    "asymptote y = {}": "асимптота y = {}", "1 solution": "1 решение", "{} solutions": "решений: {}", "exactly {}": "ровно {}",
    "every x": "всех x", "{} ({} per period)": "{} ({} на период)",
    "${}$: {}, {}": "${}$: {}, {}", "${}$: {}": "${}$: {}",
    "Checked by substitution: it satisfies the recurrence and the initial values, which proves it by induction; it also matches the first {} computed terms.":
        "Проверено подстановкой: формула удовлетворяет рекуррентному соотношению и начальным значениям, что доказывает её по индукции; она также совпадает с первыми {} вычисленными членами.",
    "Defined only where {}.": "Определено только при {}.",
    "Defined only where {}. The derivative can only exist there.": "Определено только при {}. Производная может существовать только там.",
    "${}$ ({}); {}": "${}$ ({}); {}", "${}$ ({})": "${}$ ({})",
    "Move the slider to change {}; a line such as a = 2 sets the start value, and a in [0, 10] the range.":
        "Двигайте ползунок, чтобы менять {}; строка вида a = 2 задаёт начальное значение, а a in [0, 10] диапазон.",
    "{} is treated as a parameter. How the solutions depend on it (when they are real, how many there are) is the job of the Parameters tab (milestone 6). To solve for another letter, fill in 'solve for'.":
        "{} считается параметром. Как решения зависят от него (когда они вещественны, сколько их), показывает вкладка «Параметры». Чтобы решить относительно другой буквы, заполните 'solve for'.",
    "{} are treated as parameters. How the solutions depend on them (when they are real, how many there are) is the job of the Parameters tab (milestone 6). To solve for another letter, fill in 'solve for'.":
        "{} считаются параметрами. Как решения зависят от них (когда они вещественны, сколько их), показывает вкладка «Параметры». Чтобы решить относительно другой буквы, заполните 'solve for'.",
    "the base of a fractional power (for a real odd root of a negative number, write $\\sqrt[{}]{\\ }$ or root(x, {}))":
        "основание дробной степени (для вещественного корня нечётной степени из отрицательного числа напишите $\\sqrt[{}]{\\ }$ или root(x, {}))",
    "The answer uses the special function {} (there is no formula with elementary functions).": "В ответе есть специальная функция {} (формулы в элементарных функциях нет).",
    "{}; periodic with period": "{}; периодическая с периодом",
    "{}; it looks like ${}$, but that isn't proven.": "{}; похоже на ${}$, но это не доказано.",
}

# The explanations of undefined results: "<what> <requirement>, but here it equals <value>".
_WHAT = {
    "the denominator": "знаменатель", "the base of a fractional power": "основание дробной степени",
    "the argument of the factorial": "аргумент факториала",
    "the base of a power with a variable exponent": "основание степени с переменным показателем",
    "the argument of $\\ln$": "аргумент $\\ln$", "the argument of $\\lg$": "аргумент $\\lg$",
    "the argument of $\\log_{{}}$": "аргумент $\\log_{{}}$", "the expression under the square root": "выражение под квадратным корнем",
    "the cosine of the argument of $\\{}$": "косинус аргумента $\\{}$", "the sine of the argument of $\\{}$": "синус аргумента $\\{}$",
    "the argument of $\\arc{}$": "аргумент $\\arc{}$", "the argument of arcosh": "аргумент arcosh",
    "the argument of artanh": "аргумент artanh", "the argument of coth": "аргумент coth",
    "the expression under an even root": "выражение под корнем чётной степени", "the base of a negative power": "основание отрицательной степени",
    "the base of the logarithm": "основание логарифма",
}
_NEEDS = {
    "must be positive": "значение должно быть положительным", "must not be negative": "значение не может быть отрицательным",
    "must not be zero": "значение не может быть равно нулю", "must not be 1": "значение не может быть равно 1",
    "must be between −1 and 1": "значение должно быть от −1 до 1", "must be at least 1": "значение должно быть не меньше 1",
    "must be strictly between −1 and 1": "значение должно быть строго между −1 и 1",
    "must be a whole number ≥ 0": "значение должно быть целым числом ≥ 0", "must fall into one of the cases": "значение должно попадать в один из случаев",
}
_NUMERIC = " (decided numerically: the value is zero to 45 digits but could not be proven exactly)"
_NUMERIC_RU = " (решено численно: значение равно нулю с точностью до 45 цифр, но точно это не доказано)"
TEXT.update(_WHAT)
TEXT.update(_NEEDS)
for _need, _ru in _NEEDS.items():
    TEXT[f"{{}} {_need}, but here it equals ${{}}$."] = f"{{}}: {_ru}, а здесь оно равно ${{}}$."
    TEXT[f"{{}} {_need}, but here it equals ${{}}$ (${{}}$)."] = f"{{}}: {_ru}, а здесь оно равно ${{}}$ (${{}}$)."
    TEXT[f"{{}} {_need}, but here it equals ${{}}${_NUMERIC}."] = f"{{}}: {_ru}, а здесь оно равно ${{}}${_NUMERIC_RU}."
    TEXT[f"{{}} {_need}, but here it equals ${{}}$ (${{}}$){_NUMERIC}."] = (
        f"{{}}: {_ru}, а здесь оно равно ${{}}$ (${{}}$){_NUMERIC_RU}.")
