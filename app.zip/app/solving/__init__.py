"""Solving equations, inequalities and systems (Equations tab)."""
