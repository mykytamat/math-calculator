"""Problems with a parameter: for which a does the equation have exactly two
roots, does the inequality hold for every x, ...

Symbolic method. When the equation is linear in a, A(x)·a + B(x) = 0, it says
a = g(x) with g = −B/A (where A ≠ 0), so the number of roots for a given a is
the number of x with g(x) = a: the horizontal line at height a meets the graph
of g that many times. g is cut into pieces where it is continuous and strictly
monotone (from the sign chart of g′). On a piece from x = p to x = q, g runs
from L = lim g(p⁺) to R = lim g(q⁻) and takes every value between them once;
the cut points themselves add one root each at the level g(c). Adding these up
for every a gives the count, and the critical values of a are the L, R and
g(c). Points where A = B = 0 solve the equation for every a. Each row of the
answer is then checked by solving the equation directly at a sample a.

For inequalities linear in a, A(x)·a + B(x) > 0 is a > g(x) where A > 0 and
a < g(x) where A < 0, so "for every x" and "for some x" come from the supremum
and infimum of g on those parts (and whether they are attained).

Numerical method (the fallback): scan a, count the roots for each value, and
locate the values of a where the count changes by bisection. Its answer is
labelled a numerical estimate; exact-looking critical values are recognised
but not claimed as proven.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np
import sympy as sp

from ..calculus.limits import compute_limit
from ..core.decide import compare
from ..core.domain import first_violation, substitute
from ..core.format import tex
from ..parsing.to_sympy import Condition
from . import numeric
from .periodic import NotRepresentable, PeriodicSet
from .univariate import OneVariable, as_float, is_real_number, pick_between, safe, sort_exact

INF = "inf"          # infinitely many solutions
MAX_PERIODS = 60


class Unsolved(Exception):
    """The symbolic method doesn't apply or couldn't finish."""


# ------------------------------------------------------------ results -----
@dataclass
class Row:
    lo: object                 # a interval from lo to hi, or a single value lo when hi is None
    hi: object
    count: object              # int or INF
    per_period: int | None = None   # periodic problems: roots in each period
    checked: bool = False      # confirmed by solving directly at a sample a
    lo_closed: bool = False    # the interval includes lo / hi (a critical value merged into it)
    hi_closed: bool = False

    @property
    def point(self) -> bool:
        return self.hi is None

    def as_set(self) -> sp.Set:
        if self.point:
            return sp.FiniteSet(self.lo)
        return sp.Interval(self.lo, self.hi, not self.lo_closed, not self.hi_closed)


@dataclass
class CountResult:
    rows: list[Row]
    exact: bool
    method: str                        # "symbolic" | "numerical"
    notes: list[str] = field(default_factory=list)
    branches: list = field(default_factory=list)    # a = g(x) curves
    all_a: list = field(default_factory=list)       # x that solve it for every a
    xs: list = field(default_factory=list)          # x positions worth showing
    period: object = None

    @property
    def critical(self) -> list:
        """Every value of a where the count changes (or is special)."""
        vals = []
        for r in self.rows:
            for v in ([r.lo] if r.point else [r.lo, r.hi]):
                if _finite(v) and not any(v == w for w in vals):
                    vals.append(v)
        return vals


@dataclass
class IneqResult:
    holds_all: sp.Set                  # the a for which every x (in the domain) is a solution
    some: sp.Set                       # the a for which there is at least one solution
    exact: bool
    method: str
    notes: list[str] = field(default_factory=list)
    critical: list = field(default_factory=list)
    xs: list = field(default_factory=list)


# ------------------------------------------------------------ helpers -----
def less(u, v) -> bool:
    t = compare("<", u, v)
    if t.value is None:
        raise Unsolved("comparison")
    return t.value


def equal(u, v) -> bool:
    if (u in (sp.oo, -sp.oo)) or (v in (sp.oo, -sp.oo)):
        return u == v
    t = compare("=", u, v)
    if t.value is None:
        raise Unsolved("comparison")
    return t.value


def _finite(v) -> bool:
    return v not in (sp.oo, -sp.oo) and v is not None


def isolate(F, x, a):
    """(branches g_i, A, all-a points): F = 0 ⇔ a = g_i(x) (where A ≠ 0)."""
    num, _den = safe(lambda: sp.fraction(sp.together(F))) or (F, 1)
    num = sp.expand(num)
    if num.is_polynomial(a) and sp.degree(num, a) == 1:
        A, B = num.coeff(a, 1), num.coeff(a, 0)
        if not A.has(a) and not B.has(a):
            g = sp.simplify(-B / A)
            all_a = []
            if A.free_symbols:
                for c in safe(sp.solve, A, x) or []:
                    if is_real_number(c) and safe(sp.simplify, B.subs(x, c)) == 0:
                        all_a.append(c)
            return [g], A, all_a
    sols = safe(sp.solve, F, a) or []
    sols = [s for s in sols if not isinstance(s, dict) and not s.has(a) and s.free_symbols <= {x}]
    if not sols:
        raise Unsolved("can't isolate the parameter")
    return sols, None, []


# ------------------------------------------------------------ pieces ------
@dataclass
class Piece:
    lo: object
    hi: object
    L: object       # lim g at lo+
    R: object       # lim g at hi-
    flat: bool = False


class _DomainChart(OneVariable):
    """Sign chart of g′ that treats points outside g's domain as undefined, also
    in its numerical samples (g′ alone is often defined more widely: 1/x vs ln x)."""

    def __init__(self, *args, **kw):
        super().__init__(*args, **kw)
        self._inside = []
        for c in self.conds:
            if c.rel == "case":
                continue
            try:
                test = sp.Or(sp.Not(sp.sympify(c.guard)), c.as_relational())
                self._inside.append(sp.lambdify(self.x, test, modules="math"))
            except Exception:
                pass

    def _value(self, f, v):
        for test in self._inside:
            try:
                if not test(v):
                    return math.nan
            except (ValueError, TypeError, ZeroDivisionError, OverflowError):
                return math.nan
        return super()._value(f, v)


def monotone_pieces(g, x, conds, restriction=None, search=(-100.0, 100.0)):
    """g cut into open pieces where it is continuous and strictly monotone (or
    constant), plus the cut points where g is defined: (pieces, points, period, exact)."""
    dg = sp.diff(g, x)
    dg = safe(sp.simplify, dg) if sp.count_ops(dg) < 200 else dg
    if dg is None:
        raise Unsolved("derivative")
    problem = _DomainChart(dg, ">", sp.Integer(0), x, conds, None, search)
    try:
        chart = problem.sign_chart()
    except NotRepresentable:
        raise Unsolved("too many pieces")
    exact = not chart["numeric"]
    P = problem.period
    segs = [(p, q, s) for p, q, s in chart["segments"]]
    if P is not None and restriction is not None and restriction.inf != -sp.oo and restriction.sup != sp.oo:
        lo_k = math.floor(as_float(restriction.inf) / as_float(P)) - 1
        hi_k = math.ceil(as_float(restriction.sup) / as_float(P)) + 1
        if hi_k - lo_k > MAX_PERIODS:
            raise Unsolved("too many periods")
        segs = [(p + k * P, q + k * P, s) for k in range(lo_k, hi_k) for p, q, s in segs]
        P = None
    elif P is not None and restriction is not None:
        raise Unsolved("periodic with an unbounded restriction")

    def defined(c) -> bool:
        if restriction is not None and restriction.contains(c) != sp.true:
            return False
        if first_violation(substitute(conds, {x: c})) is not None:
            return False
        return is_real_number(safe(lambda: g.subs(x, c)))

    pieces, ends = [], []
    for p, q, s in segs:
        if restriction is not None:
            if restriction.inf != -sp.oo and (p == -sp.oo or less(p, restriction.inf)):
                p = restriction.inf
            if restriction.sup != sp.oo and (q == sp.oo or less(restriction.sup, q)):
                q = restriction.sup
            if p != -sp.oo and q != sp.oo and not less(p, q):
                continue
        ends += [e for e in (p, q) if _finite(e)]
        mid = pick_between(p, q)
        if not defined(mid):
            continue  # outside the domain of g
        if s is None:
            raise Unsolved("derivative undefined on an interval")
        if s == 0:
            v = sp.simplify(g.subs(x, mid))
            pieces.append(Piece(p, q, v, v, flat=True))
            continue
        L = _side_limit(g, x, p, "+")
        R = _side_limit(g, x, q, "-")
        if L is None or R is None:
            raise Unsolved("limit")
        if L.has(sp.Float) or R.has(sp.Float):
            exact = False
        pieces.append(Piece(p, q, L, R))
    points = []
    for c in sort_exact(ends):
        if P is not None and equal(c, P):
            continue
        if defined(c):
            v = safe(sp.simplify, g.subs(x, c))
            if v is None or not is_real_number(v):
                continue
            points.append((c, v))
    return pieces, points, P, exact


def _side_limit(g, x, point, side):
    if point == -sp.oo:
        side = "+"
    elif point == sp.oo:
        side = "-"
    try:
        r = compute_limit(g, x, point, side)
    except (ValueError, TypeError):
        return None
    if not r.exists or r.value is None or isinstance(r.value, sp.AccumBounds):
        return None
    if not r.exact:
        return sp.Float(float(sp.N(r.value)), 15) if _finite(r.value) else r.value
    return r.value


# ------------------------------------------------------------ equations ---
class Equation:
    def __init__(self, lhs, rhs, x, a, conds, restriction=None, search=None):
        self.lhs, self.rhs = sp.sympify(lhs), sp.sympify(rhs)
        self.F = sp.sympify(self.lhs - self.rhs)
        self.x, self.a = x, a
        self.conds = conds
        self.restriction = restriction
        self.search = search or (-100.0, 100.0)

    # ---- symbolic ----
    def symbolic(self) -> CountResult:
        x, a = self.x, self.a
        branches, A, all_a = isolate(self.F, x, a)
        analysed = []
        exact = True
        period = None
        xs = list(all_a)
        branch_conds = []
        for g in branches:
            conds = [c.subs({a: g}) for c in self.conds]
            if A is not None and A.free_symbols:
                conds.append(Condition("!=0", A, "the coefficient of the parameter", tex(A)))
            # A branch from solving for a can hold extraneous x (√(x − a) = x gives a = x − x²,
            # which is wrong for x < 0): keep only the x where it satisfies the equation.
            regions = [("interval", self.restriction)] if A is not None else self._valid_regions(g, conds)
            pieces, points = [], []
            for kind, R in regions:
                if kind == "point":
                    v = safe(sp.simplify, g.subs(x, R))
                    if v is not None and is_real_number(v) and first_violation(substitute(conds, {x: R})) is None:
                        points.append((R, v))
                    continue
                pc, pt, P, ex = monotone_pieces(g, x, conds, R, self.search)
                pieces += pc
                points += pt
                exact = exact and ex
                if P is not None:
                    period = P
            analysed.append((g, pieces, points))
            branch_conds.append(conds)
            xs += [c for c, _ in points]
        self.meets = self._meets(branches, branch_conds) if len(branches) > 1 else []
        all_a = [c for c in all_a if self._valid_for_all(c)]
        values = list(self.meets)
        for _, pieces, points in analysed:
            for pc in pieces:
                values += [v for v in (pc.L, pc.R) if _finite(v)]
            values += [v for _, v in points]
        crit = _unique_sorted(values)
        rows = []
        edges = [-sp.oo] + crit + [sp.oo]
        for lo, hi in zip(edges, edges[1:]):
            rows.append(Row(lo, hi, self._count(analysed, pick_between(lo, hi), len(all_a))))
            if hi != sp.oo:
                rows.append(Row(hi, None, self._count(analysed, hi, len(all_a))))
        rows = merge_rows(rows)
        if period is not None:
            for r in rows:
                if r.count not in (0, INF):
                    r.per_period, r.count = r.count, INF
        res = CountResult(rows, exact, "symbolic", branches=branches, all_a=all_a, xs=xs, period=period)
        if all_a:
            res.notes.append("For every a, " + ", ".join(f"$x = {tex(c)}$" for c in all_a) +
                             " is a solution (both the coefficient of a and the rest vanish there).")
        return res

    def _valid_regions(self, g, conds) -> list:
        """Where a = g(x) really solves F(x, a) = 0: [("interval", I or None), ("point", p), ...]."""
        x = self.x
        r = safe(sp.simplify, self.F.subs(self.a, g))
        if r is None:
            raise Unsolved("branch check")
        if r == 0:
            return [("interval", self.restriction)]
        res = safe(OneVariable(r, "=", sp.Integer(0), x, conds, self.restriction, self.search).solve)
        if res is None or not res.exact or not res.complete or not isinstance(res.solution, sp.Set):
            raise Unsolved("branch check")
        out = []
        for part in (res.solution.args if isinstance(res.solution, sp.Union) else [res.solution]):
            if isinstance(part, sp.Interval):
                out.append(("interval", part))
            elif isinstance(part, sp.FiniteSet):
                out += [("point", p) for p in part]
            elif part == sp.S.Reals:
                out.append(("interval", self.restriction))
            elif part != sp.S.EmptySet:
                raise Unsolved("branch check")
        return out

    def _valid_for_all(self, c) -> bool:
        conds = [k.subs({self.x: c}) for k in self.conds]
        return all(not k.expr.free_symbols for k in conds) and first_violation(conds) is None

    def _meets(self, branches, branch_conds) -> list:
        """Levels a where two branches give the same root x (it must be counted once)."""
        x = self.x
        out = []
        for i in range(len(branches)):
            for j in range(i + 1, len(branches)):
                d = safe(sp.solve, branches[i] - branches[j], x)
                if d is None or isinstance(d, dict):
                    raise Unsolved("branches meet")
                for c in d:
                    if not is_real_number(c):
                        continue
                    if self.restriction is not None and self.restriction.contains(c) != sp.true:
                        continue
                    if any(first_violation(substitute(cs, {x: c})) is not None
                           for cs in (branch_conds[i], branch_conds[j])):
                        continue
                    out.append(sp.simplify(branches[i].subs(x, c)))
        return out

    def _count(self, analysed, v, extra: int):
        total = extra - sum(1 for m in getattr(self, "meets", []) if equal(m, v))
        for _, pieces, points in analysed:
            for pc in pieces:
                if pc.flat:
                    if equal(pc.L, v):
                        return INF
                    continue
                lo, hi = (pc.L, pc.R) if less(pc.L, pc.R) or pc.L == -sp.oo else (pc.R, pc.L)
                if less(lo, v) and less(v, hi):
                    total += 1
            total += sum(1 for _, pv in points if equal(pv, v))
        return total

    # ---- direct check at one value of a ----
    def direct_count(self, a0):
        """(count, exact) from solving at a = a0, or None if the solver can't say."""
        x, a = self.x, self.a
        conds = [c.subs({a: a0}) for c in self.conds]
        prob = OneVariable(self.lhs.subs(a, a0), "=", self.rhs.subs(a, a0), x, conds,
                           self.restriction, self.search)
        res = safe(prob.solve)
        if res is None:
            return None
        sol = res.solution
        if isinstance(sol, PeriodicSet):
            return (INF if not sol.is_empty else 0), res.exact
        if isinstance(sol, sp.FiniteSet):
            return len(sol), res.exact and res.complete
        if sol == sp.S.EmptySet:
            return 0, res.exact and res.complete
        if isinstance(sol, (sp.Interval, sp.Union)):
            return INF, res.exact
        return None

    def verify(self, res: CountResult) -> bool:
        """Solve directly at a sample a of every row. False if any disagrees."""
        checked = []
        for r in res.rows:
            samples = [r.lo] if r.point else (
                [pick_between(r.lo, r.hi)] + ([r.lo] if r.lo_closed else []) + ([r.hi] if r.hi_closed else []))
            all_ok = True
            for a0 in samples:
                got = self.direct_count(a0)
                if got is None:
                    all_ok = False
                    continue
                n, ok = got
                want = INF if r.per_period else r.count
                if n != want:
                    if ok:
                        return False
                    all_ok = False
                    continue
                if ok:
                    checked.append((a0, n))
                all_ok = all_ok and ok
            r.checked = all_ok
        if checked:
            parts = ", ".join(f"$a = {tex(a0)}$: {_count_words(n)}" for a0, n in checked[:6])
            res.notes.append("Checked by solving the equation directly at " + parts + ".")
        return True

    # ---- numerical ----
    def numerical(self, a_range=None, x_range=None, samples: int = 400) -> CountResult:
        x, a = self.x, self.a
        xl, xh = x_range or self.search
        if self.restriction is not None:
            if self.restriction.inf != -sp.oo:
                xl = max(xl, as_float(self.restriction.inf))
            if self.restriction.sup != sp.oo:
                xh = min(xh, as_float(self.restriction.sup))
        al, ah = a_range or (-10.0, 10.0)
        counter = _RootCounter(self.F, x, a, self.conds, xl, xh)
        grid = np.linspace(al, ah, samples)
        counts = [counter(v) for v in grid]
        crit = []
        for (u, cu), (w, cw) in zip(zip(grid, counts), zip(grid[1:], counts[1:])):
            if cu == cw:
                continue
            lo_, hi_ = float(u), float(w)
            for _ in range(50):
                m = (lo_ + hi_) / 2
                if counter(m) == cu:
                    lo_ = m
                else:
                    hi_ = m
            crit.append(((lo_ + hi_) / 2, cu, cw))
        rows, notes = [], []
        prev = -sp.oo
        named_all = []
        for c, before, after in crit:
            val = self._exact_critical(c, before, after)
            if val is None:
                val = sp.Float(c, 10)
            else:
                named_all.append(val)
            rows.append(Row(prev, val, before))
            at = self.direct_count(val) if not val.has(sp.Float) else None
            rows.append(Row(val, None, at[0] if at else None))
            prev = val
        rows.append(Row(prev, sp.oo, counts[-1]))
        notes.append(f"Found by counting the roots numerically for {samples} values of a in "
                     f"[{al:g}, {ah:g}] (x searched in [{xl:g}, {xh:g}]), then locating where the count "
                     "changes. Outside that range of a the count is assumed not to change.")
        if named_all:
            notes.append("The critical values " + ", ".join(f"${tex(v)}$" for v in named_all) +
                         " were recognised from their decimals, and solving exactly just below and just above "
                         "each gave the counts on either side; that nothing else happens in between isn't proven.")
        return CountResult(merge_rows(rows), False, "numerical", notes=notes)

    def _exact_critical(self, c: float, before, after):
        """A simple exact number near c where the count really changes from `before` to `after`."""
        cands = list(numeric.recognize(sp.Float(c, 12)))
        for extra in ([], [sp.pi], [sp.E]):
            v = safe(sp.nsimplify, sp.Float(c, 12), extra, tolerance=1e-4 * max(1.0, abs(c)))
            if v is not None:
                cands.append(v)
        for v in cands:
            if not is_real_number(v) or abs(float(sp.N(v)) - c) > 1e-3 * max(1.0, abs(c)) or sp.count_ops(v) > 12:
                continue
            delta = sp.Rational(1, 10**4) * max(1, abs(sp.nsimplify(round(c))))
            lo_, hi_ = self.direct_count(v - delta), self.direct_count(v + delta)
            if lo_ and hi_ and lo_[0] == before and hi_[0] == after and lo_[1] and hi_[1]:
                return v
        return None

    def solve(self, a_range=None, x_range=None) -> CountResult:
        try:
            res = self.symbolic()
        except (Unsolved, NotRepresentable) as e:
            res = None
            reason = str(e)
        if res is not None:
            if self.verify(res):
                return res
            reason = "a direct check disagreed with it"
        out = self.numerical(a_range, x_range)
        out.notes.insert(0, f"The exact method didn't work here ({reason}), so this was found numerically.")
        return out


def merge_rows(rows: list[Row]) -> list[Row]:
    """Join interval–point–interval runs with the same count (the point isn't critical), and a
    critical point into a neighbouring interval with the same count (0 ≤ a < 1/4)."""
    out: list[Row] = []
    i = 0
    rows = list(rows)
    while i < len(rows):
        r = rows[i]
        if (out and not out[-1].point and r.point and i + 1 < len(rows) and not rows[i + 1].point
                and out[-1].count == r.count == rows[i + 1].count and r.count is not None):
            prev, nxt = out[-1], rows[i + 1]
            out[-1] = Row(prev.lo, nxt.hi, r.count, lo_closed=prev.lo_closed, hi_closed=nxt.hi_closed)
            i += 2
            continue
        out.append(r)
        i += 1
    joined: list[Row] = []
    i = 0
    while i < len(out):
        r = out[i]
        if r.point and r.count is not None:
            if i + 1 < len(out) and not out[i + 1].point and out[i + 1].count == r.count \
                    and not (joined and not joined[-1].point and joined[-1].count == r.count):
                nxt = out[i + 1]
                joined.append(Row(r.lo, nxt.hi, r.count, nxt.per_period, r.checked and nxt.checked,
                                  lo_closed=True, hi_closed=nxt.hi_closed))
                i += 2
                continue
            if joined and not joined[-1].point and joined[-1].count == r.count:
                prev = joined[-1]
                joined[-1] = Row(prev.lo, r.lo, r.count, prev.per_period, prev.checked and r.checked,
                                 lo_closed=prev.lo_closed, hi_closed=True)
                i += 1
                continue
        joined.append(r)
        i += 1
    return joined


def _unique_sorted(values):
    vals = [v for v in values if is_real_number(v)]
    try:
        return sort_exact(vals)
    except NotRepresentable:
        raise Unsolved("comparison")


def _count_words(n) -> str:
    if n == INF:
        return "infinitely many solutions"
    if n == 0:
        return "no solutions"
    return "1 solution" if n == 1 else f"{n} solutions"


class _RootCounter:
    """Number of roots of F(x, a0) in [lo, hi], numerically: sign changes on a
    grid (not across poles) plus touching zeros."""

    def __init__(self, F, x, a, conds, lo, hi, n: int = 6001):
        self.f = sp.lambdify((x, a), F, modules="numpy")
        self.cond_fns = []
        for c in conds:
            try:
                self.cond_fns.append((c.rel, sp.lambdify((x, a), sp.sympify(c.expr), modules="numpy")))
            except Exception:
                pass
        self.xs = np.linspace(lo, hi, n)

    def values(self, a0):
        with np.errstate(all="ignore"):
            try:
                ys = np.asarray(self.f(self.xs, a0), dtype=complex) * np.ones_like(self.xs)
            except Exception:
                return np.full_like(self.xs, np.nan)
            ok = np.abs(ys.imag) < 1e-9
            ys = np.where(ok, ys.real, np.nan)
            for rel, fn in self.cond_fns:
                try:
                    v = np.asarray(fn(self.xs, a0), dtype=complex) * np.ones_like(self.xs)
                except Exception:
                    continue
                v = np.where(np.abs(v.imag) < 1e-9, v.real, np.nan)
                bad = {">0": v <= 0, ">=0": v < 0, "!=0": v == 0}.get(rel)
                if bad is not None:
                    ys = np.where(bad | np.isnan(v), np.nan, ys)
        return ys

    def __call__(self, a0) -> int:
        ys = self.values(a0)
        fin = np.isfinite(ys)
        scale = np.nanmax(np.abs(ys)) if fin.any() else 1.0
        count = 0
        for i in range(len(ys) - 1):
            y0, y1 = ys[i], ys[i + 1]
            if not (fin[i] and fin[i + 1]):
                continue
            if y0 == 0:
                count += 1
                continue
            if y0 * y1 < 0:
                # A real crossing stays small in between; across a pole it blows up.
                ym = self.values_at((self.xs[i] + self.xs[i + 1]) / 2, a0)
                if ym is not None and abs(ym) <= max(abs(y0), abs(y1)):
                    count += 1
        if fin[-1] and ys[-1] == 0:
            count += 1
        # Touching zeros (double roots): a local minimum of |y| that is practically 0.
        ay = np.abs(ys)
        for i in range(1, len(ys) - 1):
            if fin[i - 1] and fin[i] and fin[i + 1] and ys[i] != 0 and ys[i - 1] * ys[i + 1] > 0 \
                    and ay[i] < ay[i - 1] and ay[i] <= ay[i + 1] and ay[i] < 1e-9 * max(scale, 1):
                count += 1
        return count

    def values_at(self, xv, a0):
        with np.errstate(all="ignore"):
            try:
                v = complex(self.f(xv, a0))
            except Exception:
                return None
        return v.real if abs(v.imag) < 1e-9 and math.isfinite(v.real) else None


# ------------------------------------------------------------ inequalities -
class Inequality:
    """F(x, a) op 0 with op in < <= > >=."""

    def __init__(self, lhs, op, rhs, x, a, conds, restriction=None, search=None):
        self.lhs, self.rhs, self.op = sp.sympify(lhs), sp.sympify(rhs), op
        self.x, self.a = x, a
        self.conds = conds
        self.restriction = restriction
        self.search = search or (-100.0, 100.0)

    def symbolic(self) -> IneqResult:
        x, a = self.x, self.a
        F = sp.expand(self.lhs - self.rhs)
        op = self.op
        if op in ("<", "<="):
            F, op = -F, {"<": ">", "<=": ">="}[op]
        if any(sp.sympify(c.expr).has(a) for c in self.conds):
            raise Unsolved("the domain depends on the parameter")
        if not (F.is_polynomial(a) and sp.degree(F, a) == 1):
            raise Unsolved("not linear in the parameter")
        A, B = F.coeff(a, 1), F.coeff(a, 0)
        strict = op == ">"
        notes = []
        xs = []
        # Where A > 0: a op g(x); where A < 0: a op' g(x); where A = 0: B op 0.
        g = sp.simplify(-B / A)
        parts = []
        if A.free_symbols:
            pos = Condition(">0", A, "the coefficient of the parameter", tex(A))
            neg = Condition(">0", -A, "the coefficient of the parameter", tex(A))
            for cond, sign in ((pos, 1), (neg, -1)):
                pieces, points, P, ex = monotone_pieces(g, x, self.conds + [cond], self.restriction, self.search)
                parts.append((sign, pieces, points, ex))
                xs += [c for c, _ in points]
            zeros = [c for c in (safe(sp.solve, A, x) or []) if is_real_number(c)]
        else:
            if A == 0:
                raise Unsolved("no parameter")
            pieces, points, P, ex = monotone_pieces(g, x, self.conds, self.restriction, self.search)
            parts.append((1 if A > 0 else -1, pieces, points, ex))
            xs += [c for c, _ in points]
            zeros = []
        exact = all(ex for *_, ex in parts)
        everywhere, somewhere = sp.S.Reals, sp.S.EmptySet
        for sign, pieces, points, _ in parts:
            hi_v, hi_att = _extreme(pieces, points, top=True)
            lo_v, lo_att = _extreme(pieces, points, top=False)
            if hi_v is None:  # this part of the line is empty
                continue
            if sign > 0:   # a > g(x) (or ≥) on this part
                if hi_v == sp.oo:
                    everywhere = sp.S.EmptySet
                else:
                    open_ = strict and hi_att
                    everywhere = everywhere & sp.Interval(hi_v, sp.oo, open_, True)
                if lo_v == -sp.oo:
                    somewhere = sp.S.Reals
                else:
                    somewhere = somewhere | sp.Interval(lo_v, sp.oo, strict or not lo_att, True)
            else:          # a < g(x) (or ≤) on this part
                if lo_v == -sp.oo:
                    everywhere = sp.S.EmptySet
                else:
                    open_ = strict and lo_att
                    everywhere = everywhere & sp.Interval(-sp.oo, lo_v, True, open_)
                if hi_v == sp.oo:
                    somewhere = sp.S.Reals
                else:
                    somewhere = somewhere | sp.Interval(-sp.oo, hi_v, True, strict or not hi_att)
        for c in zeros:
            if first_violation(substitute(self.conds, {x: c})) is not None:
                continue
            if self.restriction is not None and self.restriction.contains(c) != sp.true:
                continue
            xs.append(c)
            val = sp.simplify(B.subs(x, c))
            t = compare(op, val, 0)
            if t.value is None:
                raise Unsolved("comparison")
            if t.value:
                somewhere = sp.S.Reals
            else:
                everywhere = sp.S.EmptySet
                notes.append(f"At $x = {tex(c)}$ the parameter drops out and the inequality is false there, "
                             "whatever a is.")
        crit = []
        for s in (everywhere, somewhere):
            if s != sp.S.EmptySet:
                crit += [e for e in (s.inf, s.sup) if _finite(e)]
        return IneqResult(everywhere, somewhere, exact, "symbolic", notes, _unique_sorted(crit), xs)

    def direct(self, a0):
        """(holds for all x, has a solution, exact) at a = a0, or None."""
        x, a = self.x, self.a
        conds = [c.subs({a: a0}) for c in self.conds]
        L, R = self.lhs.subs(a, a0), self.rhs.subs(a, a0)
        neg = {"<": ">=", "<=": ">", ">": "<=", ">=": "<"}[self.op]
        yes = safe(OneVariable(L, self.op, R, x, conds, self.restriction, self.search).solve)
        no = safe(OneVariable(L, neg, R, x, conds, self.restriction, self.search).solve)
        if yes is None or no is None:
            return None
        return _empty(no.solution) is True, _empty(yes.solution) is False, yes.exact and no.exact

    def verify(self, res: IneqResult) -> bool:
        edges = [-sp.oo] + res.critical + [sp.oo]
        samples = [pick_between(u, v) for u, v in zip(edges, edges[1:])] + list(res.critical)
        for extra in (-3, -1, 0, 1, 3):  # also where nothing seems to happen
            if not any(equal(extra, s) for s in samples):
                samples.append(sp.Integer(extra))
        checked = []
        for a0 in samples[:16]:
            got = self.direct(a0)
            if got is None:
                continue
            all_, some, ok = got
            want = (res.holds_all.contains(a0) == sp.true, res.some.contains(a0) == sp.true)
            if (all_, some) != want:
                if ok:
                    return False
                continue
            if ok:
                checked.append(a0)
        if checked:
            res.notes.append("Checked by solving the inequality directly at " +
                             ", ".join(f"$a = {tex(v)}$" for v in checked[:8]) + ".")
        return True

    def numerical(self, a_range=None, x_range=None, samples: int = 400) -> IneqResult:
        x, a = self.x, self.a
        xl, xh = x_range or (-20.0, 20.0)
        if self.restriction is not None:
            if self.restriction.inf != -sp.oo:
                xl = max(xl, as_float(self.restriction.inf))
            if self.restriction.sup != sp.oo:
                xh = min(xh, as_float(self.restriction.sup))
        al, ah = a_range or (-10.0, 10.0)
        counter = _RootCounter(self.lhs - self.rhs, x, a, self.conds, xl, xh, n=4001)
        test = {"<": np.less, "<=": np.less_equal, ">": np.greater, ">=": np.greater_equal}[self.op]

        def state(a0):
            ys = counter.values(a0)
            fin = np.isfinite(ys)
            if not fin.any():
                return (False, False)
            ok = test(ys[fin], 0)
            return (bool(ok.all()), bool(ok.any()))

        grid = [float(v) for v in np.linspace(al, ah, samples)]
        states = [state(v) for v in grid]
        sets = []
        for idx in (0, 1):
            out = sp.S.EmptySet
            start = -sp.oo if states[0][idx] else None   # true at the left end: assumed to go on
            for (u, su), (w, sw) in zip(zip(grid, states), zip(grid[1:], states[1:])):
                if su[idx] == sw[idx]:
                    continue
                lo_, hi_ = u, w
                for _ in range(50):
                    m = (lo_ + hi_) / 2
                    if state(m)[idx] == su[idx]:
                        lo_ = m
                    else:
                        hi_ = m
                c = _nice((lo_ + hi_) / 2)
                if sw[idx]:
                    start = c
                else:
                    out = out | sp.Interval(start, c, True, True)
                    start = None
            if start is not None:
                out = out | sp.Interval(start, sp.oo, True, True)
            sets.append(out)
        res = IneqResult(sets[0], sets[1], False, "numerical")
        res.notes.append(f"Found numerically for {samples} values of a in [{al:g}, {ah:g}], with x sampled in "
                         f"[{xl:g}, {xh:g}]; the ends of the intervals are estimates (whether they are "
                         "included was not decided).")
        return res

    def solve(self, a_range=None, x_range=None) -> IneqResult:
        try:
            res = self.symbolic()
        except (Unsolved, NotRepresentable) as e:
            res, reason = None, str(e)
        if res is not None:
            if self.verify(res):
                return res
            reason = "a direct check disagreed with it"
        out = self.numerical(a_range, x_range)
        out.notes.insert(0, f"The exact method didn't work here ({reason}), so this was found numerically.")
        return out


def _nice(v: float):
    named = numeric.recognize(sp.Float(v, 12))
    if named and abs(float(sp.N(named[0])) - v) < 1e-7 * max(1, abs(v)):
        return named[0]
    return sp.Float(v, 8)


def _empty(sol):
    if isinstance(sol, PeriodicSet):
        return sol.is_empty
    if isinstance(sol, sp.Set):
        return sol == sp.S.EmptySet or sol.is_empty
    return None


def _extreme(pieces, points, top: bool):
    """(sup or inf of g over the pieces and points, attained?) — (None, None) if empty."""
    cands = []   # (value, attained)
    for pc in pieces:
        if pc.flat:
            cands.append((pc.L, True))
        else:
            cands += [(pc.L, False), (pc.R, False)]
    cands += [(v, True) for _, v in points]
    if not cands:
        return None, None
    best = None
    for v, att in cands:
        if best is None:
            best = (v, att)
            continue
        if equal(v, best[0]):
            best = (best[0], best[1] or att)
        elif (top and less(best[0], v)) or (not top and less(v, best[0])):
            best = (v, att)
    return best
