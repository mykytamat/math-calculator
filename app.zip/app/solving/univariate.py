"""Equations and inequalities in one variable.

SymPy's solvers are used, but not trusted on their own (solveset returns a
single period for sin x > 1/2 and drops roots of 2sin²x − sin x − 1 = 0 on
[0, 2π)). So:

* Equations: candidates come from several sources (solveset over the window,
  solveset over ℝ, solve() without checking, the numerator of the combined
  fraction). Every candidate is substituted back: values outside the domain
  or that don't satisfy the equation are rejected with the reason. Then a
  numerical scan looks for roots the exact solvers missed.
* Inequalities: the sign-chart method. The critical points (roots, domain
  edges, poles, case boundaries) cut the line into pieces; the sign is
  decided exactly at one test point per piece, and a few numerical samples
  check that it doesn't change inside.
* Periodic problems are solved on one period [0, P) and returned as a
  PeriodicSet.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

import sympy as sp

from ..core.decide import compare, sign_of
from ..core.domain import explain, first_violation, substitute
from ..core.format import tex
from ..graphing.breaks import Breaks, _solve, expression_breaks, relation_boundaries
from ..parsing.to_sympy import Condition
from . import numeric
from .periodic import NotRepresentable, PeriodicSet, cmp, residue

DEFAULT_SEARCH = (-100.0, 100.0)
MAX_CRITICAL = 400
MAX_RECOGNIZE = 12
ZERO = sp.Float("1e-25")

STRICT = {"<": "<", ">": ">"}
OPS = {"<": sp.Lt, "<=": sp.Le, ">": sp.Gt, ">=": sp.Ge, "=": sp.Eq, "!=": sp.Ne}


@dataclass
class Rejected:
    value: object          # an exact number, or a PeriodicSet of rejected values
    reason: str            # text with $math$


@dataclass
class Result:
    op: str
    var: sp.Symbol
    solution: object                      # sp.Set or PeriodicSet
    general: PeriodicSet | None = None    # before a restriction cut it down
    restriction: sp.Set | None = None
    rejected: list[Rejected] = field(default_factory=list)
    domain: object = None                 # sp.Set or PeriodicSet, None if unknown
    exact: bool = True
    complete: bool = True                 # False: found by a numerical search only
    searched: tuple | None = None
    notes: list[str] = field(default_factory=list)
    complex_roots: list = field(default_factory=list)
    numeric_check: bool = False           # the numerical scan agreed with the exact answer

    @property
    def periodic(self) -> bool:
        return isinstance(self.solution, PeriodicSet)


# ------------------------------------------------------------ small helpers --
def safe(fn, *args, **kw):
    try:
        return fn(*args, **kw)
    except (NotImplementedError, ValueError, TypeError, AttributeError, sp.PolynomialError,
            RecursionError, ZeroDivisionError, KeyError, IndexError):
        return None
    except Exception:
        return None


def is_real_number(v) -> bool:
    v = sp.sympify(v)
    if not v.is_number or v.has(sp.nan, sp.zoo, sp.oo, -sp.oo):
        return False
    if v.is_real:
        return True
    if v.is_real is False:
        return False
    n = safe(sp.N, v, 30)
    if n is None:
        return False
    re, im = n.as_real_imag()
    return abs(im) < 1e-25 * max(1, abs(re))


def real_part(v):
    v = sp.sympify(v)
    if v.is_real:
        return v
    s = safe(sp.simplify, v)
    if s is not None and s.is_real:
        return s
    re = safe(sp.re, v)
    return sp.simplify(re) if re is not None else v


def as_float(v) -> float:
    return float(sp.N(v, 20))


def periodicity(exprs, x):
    """Common period of all expressions that contain x (None if any isn't periodic)."""
    from .periodic import lcm_period
    period = None
    for e in exprs:
        e = sp.sympify(e)
        if x not in e.free_symbols:
            continue
        p = safe(sp.periodicity, e, x)
        if p is None or p == 0 or not p.is_number:
            return None
        period = p if period is None else lcm_period(period, p)
        if period is None:
            return None
    if period is None:
        return None
    # Check: g(t + P) = g(t) at a few points.
    for e in exprs:
        e = sp.sympify(e)
        if x not in e.free_symbols:
            continue
        f = numeric.scalar(e, x)
        for t in (0.3711, 1.2345, -2.718):
            a, b = f(t), f(t + float(period))
            if math.isnan(a) != math.isnan(b) or (not math.isnan(a) and abs(a - b) > 1e-7 * max(1, abs(a))):
                return None
    return period


def condition_exprs(conds: list[Condition]):
    out = []
    for c in conds:
        rel = c.as_relational()
        for r in sp.sympify(rel).atoms(sp.core.relational.Relational):
            out.append(r.lhs - r.rhs)
        g = sp.sympify(c.guard)
        for r in g.atoms(sp.core.relational.Relational):
            out.append(r.lhs - r.rhs)
    return out


def bool_set(b, x, W):
    """The set where a condition on x holds, within W (None if SymPy can't tell)."""
    b = sp.sympify(b)
    if b is sp.true:
        return W
    if b is sp.false:
        return sp.S.EmptySet
    if isinstance(b, sp.And):
        parts = [bool_set(a, x, W) for a in b.args]
        return None if any(p is None for p in parts) else sp.Intersection(*parts)
    if isinstance(b, sp.Or):
        parts = [bool_set(a, x, W) for a in b.args]
        return None if any(p is None for p in parts) else sp.Union(*parts)
    if isinstance(b, sp.Not):
        inner = bool_set(b.args[0], x, W)
        return None if inner is None else sp.Complement(W, inner)
    if isinstance(b, sp.core.relational.Relational):
        if x not in b.free_symbols:
            return W if b == sp.true else None
        s = safe(sp.solveset, b, x, W)
        if s is None or s.has(sp.ConditionSet) or isinstance(s, sp.ConditionSet):
            return None
        return s
    return None


def domain_set(conds: list[Condition], x, W):
    D = W
    for c in conds:
        rel = c.as_relational()
        g = sp.sympify(c.guard)
        if g is not sp.true:
            rel = sp.Or(sp.Not(g), rel)
        s = bool_set(rel, x, W)
        if s is None:
            return None
        D = sp.Intersection(D, s)
    return D


def finite_points(s):
    """Points of a FiniteSet / Union of FiniteSets, else None."""
    if s is None:
        return None
    if s == sp.S.EmptySet:
        return []
    if isinstance(s, sp.FiniteSet):
        return list(s)
    return None


def split_set(s):
    """(points, interval part, ok) for a finite union of points and intervals."""
    if s == sp.S.EmptySet:
        return [], sp.S.EmptySet, True
    if isinstance(s, sp.FiniteSet):
        return list(s), sp.S.EmptySet, True
    if isinstance(s, sp.Interval):
        return [], s, True
    if isinstance(s, sp.Union):
        pts, ivs = [], []
        for a in s.args:
            p, i, ok = split_set(a)
            if not ok:
                return [], sp.S.EmptySet, False
            pts += p
            ivs.append(i)
        return pts, sp.Union(*ivs), True
    if isinstance(s, sp.Complement) and isinstance(s.args[1], sp.FiniteSet):
        p, i, ok = split_set(s.args[0])
        if ok and not p:
            return [], s, True
    return [], sp.S.EmptySet, False


def nice_root_forms(poly: sp.Poly):
    """Radical forms of the real roots where they exist without complex numbers."""
    forms = []
    r = safe(sp.roots, poly)
    if r:
        for e in r:
            if not e.has(sp.I) and is_real_number(e):
                forms.append(e)
    return forms


def pick_between(a, b):
    """A simple rational strictly between a and b (either may be ±∞)."""
    if a == -sp.oo and b == sp.oo:
        return sp.Integer(0)
    if a == -sp.oo:
        return sp.Integer(math.floor(as_float(b))) - 1
    if b == sp.oo:
        return sp.Integer(math.ceil(as_float(a))) + 1
    af, bf = as_float(a), as_float(b)
    if af < 0 < bf:
        return sp.Integer(0)
    q = 1
    for _ in range(40):
        p = math.floor(af * q) + 1
        t = sp.Rational(p, q)
        if p / q < bf and cmp(t, a) > 0 and cmp(t, b) < 0:
            return t
        q *= 2
    return (sp.nsimplify(a) + sp.nsimplify(b)) / 2


def holds(op: str, s: int) -> bool:
    return {"<": s < 0, "<=": s <= 0, ">": s > 0, ">=": s >= 0, "=": s == 0, "!=": s != 0}[op]


def sort_exact(points):
    pts = sorted(points, key=as_float)
    out = []
    for p in pts:
        if out and cmp(p, out[-1]) == 0:
            continue
        out.append(p)
    return out


# ------------------------------------------------------------ the problem ---
class OneVariable:
    def __init__(self, lhs, op: str, rhs, x: sp.Symbol, conditions: list[Condition],
                 restriction: sp.Set | None = None, search: tuple | None = None):
        self.lhs, self.rhs = sp.sympify(lhs), sp.sympify(rhs)
        self.op = op
        self.x = x
        self.g = sp.sympify(self.lhs - self.rhs)
        self.conds = [c for c in conditions if x in sp.sympify(c.expr).free_symbols
                      or x in sp.sympify(c.guard).free_symbols
                      or (c.custom is not None and x in sp.sympify(c.custom).free_symbols)]
        self.restriction = restriction
        self.period = periodicity([self.g] + condition_exprs(self.conds), x)
        if self.period is not None and x not in self.g.free_symbols:
            self.period = None
        self.W = sp.Interval.Ropen(0, self.period) if self.period is not None else sp.S.Reals
        lo, hi = search or DEFAULT_SEARCH
        if restriction is not None and self.period is None:
            r = restriction
            lo = max(lo, as_float(r.inf)) if r.inf != -sp.oo else lo
            hi = min(hi, as_float(r.sup)) if r.sup != sp.oo else hi
            if r.inf != -sp.oo and r.sup != sp.oo:
                lo, hi = as_float(r.inf), as_float(r.sup)
        self.search = (lo, hi)
        self.notes: list[str] = []
        self._precise = None

    # ---- checking a value ----
    def check(self, p) -> tuple[bool, str | None, bool]:
        """(is a solution, reason if not, decided exactly)."""
        v = first_violation(substitute(self.conds, {self.x: p}))
        if v is not None:
            c, exact = v
            return False, explain(c, exact), exact
        L, R = self.lhs.subs(self.x, p), self.rhs.subs(self.x, p)
        t = compare("=", L, R)
        if t.value is True:
            return True, None, t.exact
        if t.value is False:
            Ls, Rs = safe(sp.simplify, L) or L, safe(sp.simplify, R) or R
            return False, (f"Substituting gives ${tex(Ls)}$ on the left but ${tex(Rs)}$ "
                           "on the right."), True
        return False, "The two sides are not real numbers there.", True

    def defined_at(self, p) -> tuple[bool, str | None]:
        v = first_violation(substitute(self.conds, {self.x: p}))
        if v is not None:
            return False, explain(*v)
        val = self.g.subs(self.x, p)
        if not is_real_number(val):
            return False, "The expression is not a real number there."
        return True, None

    def domain(self):
        D = domain_set(self.conds, self.x, self.W)
        if D is None:
            return None
        if self.period is not None:
            try:
                return PeriodicSet(self.period, D).reduced()
            except NotRepresentable:
                return None
        return D

    # ---- candidates ----
    def _in_window(self, p) -> bool:
        if self.period is None:
            return True
        return cmp(p, 0) >= 0 and cmp(p, self.period) < 0

    def _norm(self, p):
        p = real_part(p)
        if self.period is not None:
            p = residue(p, self.period)
        return p

    def candidates(self):
        """(points, interval part, complete): all values worth checking."""
        g, x, W = self.g, self.x, self.W
        pts: list = []
        intervals = sp.S.EmptySet
        complete = False
        num, den = safe(lambda: sp.fraction(sp.together(g))) or (g, sp.Integer(1))
        polynomial = (num.is_polynomial(x) and den.is_polynomial(x)
                      and num.free_symbols <= {x} and den.free_symbols <= {x})
        if polynomial and num != 0:
            P = sp.Poly(num, x)
            roots = safe(P.real_roots) or []
            forms = nice_root_forms(P) if any(r.has(sp.CRootOf) for r in roots) else []
            for r in roots:
                if r.has(sp.CRootOf):
                    match = [f for f in forms if abs(sp.N(f - r, 30)) < 1e-25]
                    r = match[0] if match else r
                pts.append(r)
            return pts, intervals, True
        if polynomial and num == 0:
            return [], W, True
        S = safe(sp.solveset, g, x, W)
        p_, iv, ok = split_set(S) if S is not None else ([], sp.S.EmptySet, False)
        if ok:
            pts += p_
            intervals = iv
            complete = True
        if self.period is not None:
            SR = safe(sp.solveset, g, x, sp.S.Reals)
            fam = PeriodicSet.from_sympy(SR) if SR is not None else None
            if fam is not None:
                pts += [p for k, p in _pts(fam.tiled(self.period) if _divides(fam.period, self.period) else sp.S.EmptySet)]
                complete = True
            elif isinstance(SR, sp.FiniteSet):
                pts += list(SR)
            elif SR == sp.S.EmptySet:
                complete = True
        for c in (safe(sp.solve, g, x, check=False) or []):
            if not isinstance(c, dict):
                pts.append(c)
                complete = True
        if den.has(x):
            Sn = safe(sp.solveset, num, x, W)
            pn, _, okn = split_set(Sn) if Sn is not None else ([], None, False)
            if okn:
                pts += pn
        if g.has(sp.log) and not pts:
            t = safe(lambda: sp.logcombine(sp.expand_log(g, force=True), force=True))
            for c in (safe(sp.solve, t, x, check=False) or []) if t is not None else []:
                if not isinstance(c, dict):
                    pts.append(c)
        out = []
        for p in pts:
            if not is_real_number(p):
                continue
            p = self._norm(p)
            if self._in_window(p) and not any(cmp(p, q) == 0 for q in out):
                out.append(p)
        return out, intervals, complete

    # ---- equations ----
    def solve_equation(self, numeric_only: bool = False) -> Result:
        x = self.x
        domain = None if numeric_only else safe(self.domain)
        if self.g == 0 or (not self.g.free_symbols and not numeric_only and sign_of(self.g).sign == 0):
            # True for every x where both sides are defined.
            sol = domain if domain is not None else self.W
            res = Result("=", x, sol if not isinstance(sol, sp.Set) or self.period is None
                         else PeriodicSet(self.period, sol), domain=domain)
            res.notes.append("The equation holds for every value where both sides are defined.")
            return self._restrict(res)
        if not self.g.has(x):
            return self._restrict(Result("=", x, sp.S.EmptySet, domain=domain))
        valid, rejected, intervals = [], [], sp.S.EmptySet
        exact = True
        complete = False
        if not numeric_only:
            cands, intervals, complete = self.candidates()
            for p in sort_exact(cands):
                ok, reason, ex = self.check(p)
                if ok:
                    valid.append(p)
                    exact = exact and True
                    if not ex:
                        self.notes.append(f"${tex(x)} = {tex(p)}$ was checked numerically (to 45 digits), "
                                          "not proven exactly.")
                else:
                    rejected.append((p, reason))
            if intervals != sp.S.EmptySet and domain is not None:
                intervals = sp.Intersection(intervals, domain if isinstance(domain, sp.Set) else self.W)
        # Numerical scan: a fallback, and a check of the exact answer.
        lo, hi = (0.0, as_float(self.period)) if self.period is not None else self.search
        numeric_roots = []
        scan_ok = intervals == sp.S.EmptySet
        if scan_ok:
            found = safe(numeric.scan_roots, self.g, x, lo, hi) or []
            known = valid + [p for p, _ in rejected]
            recognized = 0
            for r in found:
                if self.period is not None and abs(float(r) - hi) < 1e-9:
                    r = sp.Float(0, 30)
                if any(abs(as_float(k) - float(r)) <= 1e-9 * max(1, abs(float(r))) for k in known):
                    continue
                ok, _ = self.defined_at(r)
                if not ok:
                    continue
                promoted = None
                if not numeric_only and recognized < MAX_RECOGNIZE:
                    recognized += 1
                    for c in numeric.recognize(r):
                        good, _, ex = self.check(c)
                        if good and ex:
                            promoted = c
                            break
                if promoted is not None:
                    valid.append(self._norm(promoted))
                    if complete and not numeric_only:
                        self.notes.append(f"${tex(x)} = {tex(promoted)}$ was missed by the exact solver; "
                                          "it was found numerically and then proven by substitution.")
                    known.append(promoted)
                else:
                    numeric_roots.append(r)
                    known.append(r)
            if numeric_roots:
                exact = False
        pts = valid + numeric_roots
        sol = sp.Union(sp.FiniteSet(*pts), intervals) if pts else intervals
        res = Result("=", x, sol, domain=domain, exact=exact, complete=complete or self.period is not None,
                     notes=self.notes)
        res.numeric_check = scan_ok and not numeric_only
        if not complete and self.period is None:
            res.searched = (lo, hi)
        if self.period is not None:
            res.solution = PeriodicSet(self.period, sp.Intersection(sol, self.W)).reduced()
            grouped: dict[str, list] = {}
            for p, reason in rejected:
                grouped.setdefault(reason, []).append(p)
            res.rejected = [Rejected(PeriodicSet.from_residues(ps, self.period), reason)
                            for reason, ps in grouped.items()]
        else:
            res.rejected = [Rejected(p, reason) for p, reason in rejected]
        if not pts and intervals == sp.S.EmptySet and self.g.is_polynomial(x) and self.g.free_symbols == {x}:
            roots = safe(sp.Poly(self.g, x).all_roots) or []
            res.complex_roots = [r for r in roots if not is_real_number(r)][:6]
        return self._restrict(res)

    # ---- inequalities ----
    def critical_points(self, roots) -> list:
        x = self.x
        lo, hi = (0, self.period) if self.period is not None else self.search
        window = sp.Interval(lo, hi)
        br = Breaks()
        e_br = safe(expression_breaks, self.g, x, (), window)
        if e_br is not None:
            br.points |= e_br.points
            br.periodic += e_br.periodic
        for c in self.conds:
            exprs = condition_exprs([c])
            for e in exprs:
                if x not in sp.sympify(e).free_symbols:
                    continue
                s = _solve(e, x)
                if s is not None:
                    br.add_set(s, window)
                else:
                    br.approximate = True
        for fn in self.g.atoms(sp.floor, sp.ceiling, sp.frac):
            u = fn.args[0]
            if u.is_polynomial(x) and sp.degree(u, x) == 1 and u.free_symbols == {x}:
                a_, b_ = u.coeff(x, 1), u.coeff(x, 0)
                ends = sorted([as_float(a_ * lo + b_), as_float(a_ * hi + b_)])
                if ends[1] - ends[0] <= MAX_CRITICAL:
                    for n in range(math.floor(ends[0]), math.ceil(ends[1]) + 1):
                        br.points.add((n - b_) / a_)
        for fn in self.g.atoms(sp.sign):
            s = _solve(fn.args[0], x)
            if s is not None:
                br.add_set(s, window)
        for pw in self.g.atoms(sp.Piecewise):
            for _, cond in pw.args:
                for e in relation_boundaries(cond, x):
                    s = _solve(e, x)
                    if s is not None:
                        br.add_set(s, window)
        pts = list(roots) + list(br.points)
        for start, per in br.periodic:
            try:
                k0 = math.floor((as_float(window.start) - as_float(start)) / as_float(per)) - 1
                k1 = math.ceil((as_float(window.end) - as_float(start)) / as_float(per)) + 1
            except (TypeError, ValueError):
                continue
            if k1 - k0 > MAX_CRITICAL:
                continue
            pts += [start + k * per for k in range(k0, k1 + 1)]
        out = []
        for p in pts:
            if not is_real_number(p):
                continue
            p = self._norm(p)
            if self.period is None and not (self.search[0] - 1e-9 <= as_float(p) <= self.search[1] + 1e-9) \
                    and br.periodic:
                continue
            if self._in_window(p):
                out.append(p)
        return sort_exact(out)

    def sign_at(self, t) -> int | None:
        """Sign of g at an exact point, None where undefined."""
        ok, _ = self.defined_at(t)
        if not ok:
            return None
        v = self.g.subs(self.x, t)
        n = safe(sp.N, v, 30)
        if n is not None and n.is_real and abs(n) > ZERO:
            return 1 if n > 0 else -1
        s = sign_of(v)
        return s.sign

    def _step_roots(self, numeric_only: bool) -> Result:
        """Roots of g = 0 when g has floor/sign steps: candidates are checked, and
        numerical "roots" that are really stretches where g is 0 are dropped
        (the sign chart finds those stretches)."""
        x = self.x
        valid = []
        if not numeric_only:
            cands, _, _ = self.candidates()
            valid = [p for p in sort_exact(cands) if self.check(p)[0]]
        lo, hi = (0.0, as_float(self.period)) if self.period is not None else self.search
        f = numeric.scalar(self.g, x)
        found = []
        for r in safe(numeric.scan_roots, self.g, x, lo, hi) or []:
            rf = float(r)
            if f(rf - 1e-4) == 0 or f(rf + 1e-4) == 0:
                continue
            if any(abs(as_float(v) - rf) < 1e-9 * max(1, abs(rf)) for v in valid):
                continue
            named = next((c for c in numeric.recognize(r) if self.check(c)[0]), None) \
                if not numeric_only and len(found) < MAX_RECOGNIZE else None
            if named is not None:
                valid.append(named)
            else:
                found.append(r)
        return Result("=", x, sp.FiniteSet(*(valid + found)), exact=not found, complete=True,
                      searched=None if self.period is not None else (lo, hi))

    def sign_chart(self, numeric_only: bool = False) -> dict:
        """The sign of g = lhs - rhs on every piece of the line (or of one period).

        Returns {"segments": [(a, b, sign or None)], "points": [(c, sign, exact)],
        "roots": Result of g = 0, "numeric": bool}."""
        x = self.x
        if self.g.has(sp.floor, sp.ceiling, sp.frac, sp.sign):
            roots_res = self._step_roots(numeric_only)
        else:
            eq = OneVariable(self.lhs, "=", self.rhs, x, self.conds, None, self.search)
            roots_res = eq.solve_equation(numeric_only=numeric_only)
        if isinstance(roots_res.solution, PeriodicSet):
            roots_set = roots_res.solution.tiled(self.period) if _divides(roots_res.solution.period, self.period) \
                else sp.S.EmptySet
        else:
            roots_set = roots_res.solution
        roots, ident, ok = split_set(roots_set) if isinstance(roots_set, sp.Set) else ([], sp.S.EmptySet, False)
        extra = []
        for kind, iv in (_pts(ident) if ident != sp.S.EmptySet else []):
            extra += [e for e in (iv.start, iv.end) if e.is_finite]
        crit = self.critical_points(list(roots) + extra)
        if len(crit) > MAX_CRITICAL:
            raise NotRepresentable("too many critical points")
        if self.period is not None:
            edges = [sp.Integer(0)] + [c for c in crit if cmp(c, 0) > 0] + [self.period]
        else:
            edges = [-sp.oo] + crit + [sp.oo]
        f = numeric.scalar(self.g, x)
        segments = []
        numeric_used = False
        for a, b in zip(edges, edges[1:]):
            if a != -sp.oo and b != sp.oo and cmp(a, b) >= 0:
                continue
            t = pick_between(a, b)
            sgn = self.sign_at(t)
            if self._samples_agree(f, a, b, sgn):
                segments.append((a, b, sgn))
                continue
            # The sign changes inside: a root or a domain edge was missed. Split numerically.
            numeric_used = True
            for (u, v), su in self._numeric_split(f, a, b):
                segments.append((u, v, su))
        points = []
        cands = list(crit)
        if self.period is not None and not any(cmp(c, 0) == 0 for c in cands):
            cands.append(sp.Integer(0))  # the edge of the window [0, P) is not a real break
        for c in cands:
            if self.period is not None and cmp(c, self.period) >= 0:
                continue
            ok_c, _ = self.defined_at(c)
            if not ok_c:
                continue
            sg = sign_of(self.lhs.subs(x, c) - self.rhs.subs(x, c))
            if sg.sign is None:
                continue
            points.append((c, sg.sign, sg.exact or c.is_Float))
        return {"segments": segments, "points": points, "roots": roots_res, "numeric": numeric_used}

    def solve_inequality(self, numeric_only: bool = False, chart: dict | None = None,
                         op: str | None = None) -> Result:
        x, op = self.x, op or self.op
        chart = chart or self.sign_chart(numeric_only)
        roots_res = chart["roots"]
        exact = roots_res.exact
        pieces = [sp.Interval.open(a, b) for a, b, sg in chart["segments"] if sg is not None and holds(op, sg)]
        for c, sg, ex in chart["points"]:
            if holds(op, sg):
                pieces.append(sp.FiniteSet(c))
                exact = exact and ex
        numeric_used = chart["numeric"]
        sol = sp.Union(*pieces) if pieces else sp.S.EmptySet
        if numeric_used or sol.has(sp.Float):
            exact = False
        res = Result(op, x, sol, domain=safe(self.domain) if not numeric_only else None, exact=exact,
                     complete=roots_res.complete, searched=roots_res.searched, notes=list(roots_res.notes))
        if numeric_used:
            res.notes.append("Part of the sign chart was found numerically (a root or edge the exact "
                             "solver missed).")
        if self.period is not None:
            res.solution = PeriodicSet(self.period, sp.Intersection(sol, self.W)).reduced()
        elif roots_res.searched is not None:
            lo_, hi_ = roots_res.searched
            span = f"${_num(lo_)} \\le {tex(x)} \\le {_num(hi_)}$"
            r = self.restriction
            if r is not None and r.inf != -sp.oo and r.sup != sp.oo:
                res.notes.append(f"The roots were searched for numerically in {span}.")
            else:
                res.notes.append(f"The roots were searched for numerically in {span}; beyond that the sign "
                                 "is assumed not to change.")
        return self._restrict(res)

    def signs(self, numeric_only: bool = False) -> tuple[Result, Result, Result]:
        """(where g > 0, where g < 0, where g = 0) from a single sign chart."""
        chart = self.sign_chart(numeric_only)
        return (self.solve_inequality(numeric_only, chart, ">"), self.solve_inequality(numeric_only, chart, "<"),
                chart["roots"])

    def _samples_agree(self, f, a, b, s) -> bool:
        if a == -sp.oo and b == sp.oo:
            xs = [sg * 2 ** j for j in range(-3, 25) for sg in (-1, 1)]
        elif a == -sp.oo or b == sp.oo:
            base = as_float(b) if a == -sp.oo else as_float(a)
            direction = -1 if a == -sp.oo else 1
            xs = [base + direction * 2 ** j for j in range(-3, 25)]
        else:
            af, bf = as_float(a), as_float(b)
            xs = [af + (bf - af) * (i + 0.5) / 24 for i in range(24)]
        vals = [self._value(f, v) for v in xs]
        fin = [v for v in vals if not math.isnan(v)]
        if s is None:
            # Undefined at the test point: fine if (almost) all samples are undefined too.
            return len(fin) <= 1
        if len(fin) < len(vals) - 1:
            return False
        scale = max([abs(v) for v in fin] + [1e-300])
        if scale < 1e-10:
            return True
        for v in fin:
            if abs(v) < 1e-9 * scale:
                continue
            if (v > 0) != (s > 0) and s != 0:
                return False
        return True

    def _value(self, f, v) -> float:
        """g(v) as a float; where floats overflow, the sign comes from mpmath."""
        y = f(v)
        if not math.isnan(y):
            return y
        if self._precise is None:
            self._precise = numeric.precise(self.g, self.x)
        p = self._precise(v)
        if p is None:
            return math.nan
        return math.copysign(1e300, float(p)) if p != 0 else 0.0

    def _numeric_split(self, f, a, b):
        """Split (a, b) at numerically found roots and domain edges; the sign of each piece."""
        lo = as_float(a) if a != -sp.oo else min(self.search[0], as_float(b) - 1e6)
        hi = as_float(b) if b != sp.oo else max(self.search[1], as_float(a) + 1e6)
        roots = numeric.scan_roots(self.g, self.x, lo, hi, n=8001)
        xs = [lo + (hi - lo) * i / 8000 for i in range(8001)]
        edges = []
        prev = None
        for v in xs:
            d = not math.isnan(self._value(f, v))
            if prev is not None and d != prev[1]:
                u, w = prev[0], v
                for _ in range(60):
                    m = (u + w) / 2
                    if (not math.isnan(self._value(f, m))) == prev[1]:
                        u = m
                    else:
                        w = m
                edges.append(sp.Float((u + w) / 2, 15))
            prev = (v, d)
        # Jumps (floor, sign, ...) change the sign without a root: cut there too.
        jumps = []
        ys = [self._value(f, v) for v in xs]
        for (u, yu), (w, yw) in zip(zip(xs, ys), zip(xs[1:], ys[1:])):
            if math.isnan(yu) or math.isnan(yw) or (yu > 0) == (yw > 0) or yu == 0 or yw == 0:
                continue
            if any(u <= float(r) <= w for r in roots):
                continue
            for _ in range(60):
                m = (u + w) / 2
                ym = self._value(f, m)
                if math.isnan(ym):
                    break
                if (ym > 0) == (yu > 0):
                    u = m
                else:
                    w = m
            jumps.append((u + w) / 2)
        cuts = sorted(set([float(r) for r in roots] + [float(e) for e in edges] + jumps))
        pts = [a] + [sp.Float(c, 30) for c in cuts if lo < c < hi] + [b]
        out = []
        for u, v in zip(pts, pts[1:]):
            uf = as_float(u) if u != -sp.oo else lo - 1
            vf = as_float(v) if v != sp.oo else hi + 1
            mid = (uf + vf) / 2
            y = self._value(f, mid)
            out.append(((u, v), None if math.isnan(y) else (0 if y == 0 else (1 if y > 0 else -1))))
        return out

    # ---- restriction ----
    def _restrict(self, res: Result) -> Result:
        if isinstance(res.solution, PeriodicSet) and res.solution.is_empty:
            res.solution = sp.S.EmptySet
        r = self.restriction
        if r is None:
            return res
        res.restriction = r
        if isinstance(res.solution, PeriodicSet):
            res.general = res.solution
            try:
                res.solution = res.solution.intersect(r)
            except NotRepresentable:
                res.notes.append("The interval is too long to list every solution in it.")
        else:
            res.solution = sp.Intersection(res.solution, r)
            res.rejected = [j for j in res.rejected if not isinstance(j.value, sp.Basic)
                            or r.contains(j.value) == sp.true]
        return res

    def solve(self, numeric_only: bool = False) -> Result:
        if self.op == "=" and self.g.has(sp.floor, sp.ceiling, sp.frac, sp.sign):
            return self.solve_inequality(numeric_only)  # g can be 0 on whole intervals
        if self.op == "=":
            return self.solve_equation(numeric_only)
        if self.op == "!=":
            eq = self.solve_equation(numeric_only)
            return _not_equal(self, eq)
        return self.solve_inequality(numeric_only)


def _not_equal(problem: OneVariable, eq: Result) -> Result:
    """x ≠ ...: the domain minus the solutions of the equation."""
    D = eq.domain if eq.domain is not None else problem.W
    if isinstance(eq.solution, PeriodicSet) or isinstance(D, PeriodicSet):
        P = problem.period
        Dp = D if isinstance(D, PeriodicSet) else PeriodicSet(P, sp.Intersection(D, problem.W))
        Sp = eq.solution if isinstance(eq.solution, PeriodicSet) else PeriodicSet(P, eq.solution)
        sol = Sp.complement_within(Dp)
    else:
        sol = sp.Complement(D, eq.solution)
    out = Result("!=", eq.var, sol, domain=eq.domain, exact=eq.exact, complete=eq.complete,
                 searched=eq.searched, notes=eq.notes)
    return out


def _divides(small, big) -> bool:
    from .periodic import ratio
    r = ratio(big, small)
    return r is not None and r.is_Integer


def _pts(s):
    from .periodic import pieces
    return pieces(s)


def _num(v: float) -> str:
    return f"{v:g}"
