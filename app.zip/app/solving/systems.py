"""Systems: several relations joined by "and" (and, for one unknown, "or").

* One unknown: each relation is solved on its own (univariate) and the
  solution sets are intersected (and) or joined (or).
* Equations in several unknowns: linear systems with linsolve (parametric
  answers when there are infinitely many solutions), others with solve();
  every candidate is substituted back (domain and each relation) and the
  failures are listed with the reason. When SymPy finds nothing, a
  multi-start numerical search is used.
* Inequalities in two unknowns: the answer is a region (drawn in the graph),
  plus its corner points.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import sympy as sp

from ..core.decide import compare, truth_of
from ..core.domain import explain, first_violation, substitute
from ..core.format import tex
from ..parsing.to_sympy import Condition
from . import numeric
from .periodic import NotRepresentable, PeriodicSet
from .univariate import DEFAULT_SEARCH, OneVariable, Result, safe

PREFERRED = ["x", "y", "z", "t", "u", "v", "w"]


@dataclass
class Leaf:
    lhs: sp.Expr
    op: str
    rhs: sp.Expr

    @property
    def expr(self):
        return sp.sympify(self.lhs - self.rhs)

    def relation(self):
        return {"=": sp.Eq, "!=": sp.Ne, "<": sp.Lt, "<=": sp.Le, ">": sp.Gt, ">=": sp.Ge}[self.op](
            self.lhs, self.rhs, evaluate=False)

    def free(self):
        return sp.sympify(self.lhs).free_symbols | sp.sympify(self.rhs).free_symbols


@dataclass
class Tree:
    op: str            # "and" | "or" | "leaf"
    items: list = field(default_factory=list)
    leaf: Leaf | None = None

    def leaves(self) -> list[Leaf]:
        if self.op == "leaf":
            return [self.leaf]
        return [lf for t in self.items for lf in t.leaves()]

    def is_conjunction(self) -> bool:
        return self.op == "leaf" or (self.op == "and" and all(t.is_conjunction() for t in self.items))

    def free(self):
        out = set()
        for lf in self.leaves():
            out |= lf.free()
        return out


def order_symbols(symbols) -> list[sp.Symbol]:
    def key(s):
        n = s.name
        return (PREFERRED.index(n) if n in PREFERRED else len(PREFERRED), n)
    return sorted(symbols, key=key)


# -------------------------------------------------------- one unknown -------
def set_and(a, b, note: list):
    if isinstance(a, PeriodicSet) and isinstance(b, PeriodicSet):
        try:
            return a.intersect(b)
        except NotRepresentable:
            pass
    if isinstance(a, PeriodicSet) or isinstance(b, PeriodicSet):
        p, s = (a, b) if isinstance(a, PeriodicSet) else (b, a)
        if isinstance(s, PeriodicSet):
            s = s.enumerate_in(sp.Interval(*DEFAULT_SEARCH))
            note.append(_window_note())
        try:
            return p.intersect(s)
        except NotRepresentable:
            note.append(_window_note())
            return sp.Intersection(p.enumerate_in(sp.Interval(*DEFAULT_SEARCH)), s)
    return sp.Intersection(a, b)


def set_or(a, b, note: list):
    if isinstance(a, PeriodicSet) and isinstance(b, PeriodicSet):
        try:
            return a.union(b)
        except NotRepresentable:
            pass
    if isinstance(a, PeriodicSet) or isinstance(b, PeriodicSet):
        note.append(_window_note())
        a = a.enumerate_in(sp.Interval(*DEFAULT_SEARCH)) if isinstance(a, PeriodicSet) else a
        b = b.enumerate_in(sp.Interval(*DEFAULT_SEARCH)) if isinstance(b, PeriodicSet) else b
    return sp.Union(a, b)


def _window_note() -> str:
    lo, hi = DEFAULT_SEARCH
    return (f"The periodic and non-periodic parts were combined by listing the solutions in "
            f"${lo:g} \\le x \\le {hi:g}$.")


def solve_one_variable_tree(tree: Tree, x, conditions: list[Condition], restriction=None,
                            search=None, numeric_only=False) -> Result:
    """Solve a combination of relations in one unknown."""
    notes: list[str] = []
    parts: list[Result] = []

    def go(t: Tree):
        if t.op == "leaf":
            lf = t.leaf
            r = OneVariable(lf.lhs, lf.op, lf.rhs, x, conditions, None, search).solve(numeric_only)
            parts.append(r)
            return r.solution
        sets = [go(it) for it in t.items]
        out = sets[0]
        for s in sets[1:]:
            out = set_and(out, s, notes) if t.op == "and" else set_or(out, s, notes)
        return out

    sol = go(tree)
    if isinstance(sol, PeriodicSet):
        sol = sol.reduced()
        if sol.is_empty:
            sol = sp.S.EmptySet
    res = Result("system", x, sol, exact=all(p.exact for p in parts),
                 complete=all(p.complete for p in parts))
    res.notes = list(dict.fromkeys(notes + [n for p in parts for n in p.notes]))
    for p in parts:
        res.rejected += p.rejected
    searched = [p.searched for p in parts if p.searched]
    res.searched = searched[0] if searched else None
    if restriction is not None:
        res.restriction = restriction
        if isinstance(sol, PeriodicSet):
            res.general = sol
            try:
                res.solution = sol.intersect(restriction)
            except NotRepresentable:
                res.notes.append("The interval is too long to list every solution in it.")
        else:
            res.solution = sp.Intersection(sol, restriction)
    return res


# ---------------------------------------------------- several unknowns ------
@dataclass
class SystemResult:
    variables: list[sp.Symbol]
    kind: str                          # "points" | "parametric" | "region" | "curve"
    solutions: list[dict] = field(default_factory=list)
    parametric: tuple | None = None    # (values tuple, parameter symbols)
    rejected: list[tuple[dict, str]] = field(default_factory=list)
    exact: bool = True
    complete: bool = True
    notes: list[str] = field(default_factory=list)
    corners: list[dict] = field(default_factory=list)
    parameters: list[sp.Symbol] = field(default_factory=list)


def _real_point(sol: dict) -> bool:
    for v in sol.values():
        v = sp.sympify(v)
        if v.is_real is False:
            return False
        if not v.is_real and v.is_number:
            n = safe(sp.N, v, 30)
            if n is None or abs(sp.im(n)) > 1e-25:
                return False
    return True


def check_point(sol: dict, leaves: list[Leaf], conditions: list[Condition]):
    """(ok, reason, exact) for a candidate solution of a system."""
    v = first_violation(substitute(conditions, sol))
    if v is not None:
        return False, explain(*v), v[1]
    exact = True
    approximate = any(sp.sympify(v).has(sp.Float) for v in sol.values())
    for lf in leaves:
        L = sp.sympify(lf.lhs).subs(sol)
        R = sp.sympify(lf.rhs).subs(sol)
        if L.free_symbols or R.free_symbols:
            return True, None, True  # parameters left: can't decide
        if approximate:
            # A numerical solution: compare with a tolerance instead of exactly.
            Ln, Rn = safe(sp.N, L, 30), safe(sp.N, R, 30)
            if Ln is None or Rn is None or not (Ln.is_real and Rn.is_real):
                return False, f"${tex(lf.relation())}$ is not real there.", False
            tol = sp.Float("1e-20") * max(1, abs(Ln), abs(Rn))
            d = Ln - Rn
            good = {"=": abs(d) <= tol, "!=": abs(d) > tol, "<": d < tol, "<=": d <= tol,
                    ">": d > -tol, ">=": d >= -tol}[lf.op]
            if not good:
                return False, f"It doesn't satisfy ${tex(lf.relation())}$.", False
            exact = False
            continue
        t = compare(lf.op, L, R)
        if t.value is None:
            return False, f"${tex(lf.relation())}$ is not real there.", True
        if not t.value:
            Ls, Rs = safe(sp.simplify, L) or L, safe(sp.simplify, R) or R
            return False, (f"It doesn't satisfy ${tex(lf.relation())}$: the left side is ${tex(Ls)}$ "
                           f"and the right side is ${tex(Rs)}$."), True
        exact = exact and t.exact
    return True, None, exact


def _simplest(sol: dict, leaves, conditions) -> dict:
    """Replace complicated exact values (LambertW, nested radicals) by simple
    numbers when those are proven to be a solution too and are equal numerically."""
    out = dict(sol)
    changed = False
    for k, v in sol.items():
        v = sp.sympify(v)
        if v.free_symbols or (numeric.simple(v) and not v.has(sp.LambertW, sp.CRootOf)):
            continue
        n = safe(sp.N, v, 30)
        if n is None or not n.is_real:
            continue
        for c in numeric.recognize(n):
            if sp.count_ops(c) < sp.count_ops(v):
                out[k] = c
                changed = True
                break
    if changed and check_point(out, leaves, conditions)[0]:
        return out
    return sol


def _dedupe(points: list[dict], variables) -> list[dict]:
    out = []
    for p in points:
        if any(all(compare("=", p[v], q[v]).value for v in variables) for q in out):
            continue
        out.append(p)
    return out


def solve_system(leaves: list[Leaf], variables: list[sp.Symbol], conditions: list[Condition],
                 numeric_only: bool = False, box=(-10.0, 10.0)) -> SystemResult:
    eqs = [lf for lf in leaves if lf.op == "="]
    ineqs = [lf for lf in leaves if lf.op != "="]
    res = SystemResult(list(variables), "points")
    if not eqs:
        res.kind = "region"
        res.exact = True
        if len(variables) == 2 and not numeric_only:
            res.corners = corner_points(ineqs, variables, conditions)
        return res
    exprs = [lf.expr for lf in eqs]
    candidates: list[dict] = []
    found_exactly = False
    if not numeric_only:
        linear = all(safe(lambda e=e: sp.Poly(e, *variables).total_degree() <= 1) for e in exprs)
        if linear:
            S = safe(sp.linsolve, exprs, variables)
            if S is not None:
                found_exactly = True
                if S == sp.S.EmptySet:
                    candidates = []
                else:
                    tup = next(iter(S))
                    free = [v for v in variables if any(v in sp.sympify(t).free_symbols for t in tup)]
                    if free:
                        names = ["t", "s", "r", "q"]
                        params = [sp.Symbol(n, real=True) for n in names[:len(free)]]
                        mapping = dict(zip(free, params))
                        res.kind = "parametric"
                        res.parametric = (tuple(sp.sympify(t).xreplace(mapping) for t in tup), params)
                        if ineqs:
                            res.notes.append("The other conditions restrict the parameter further.")
                        return res
                    candidates = [dict(zip(variables, tup))]
        if not found_exactly:
            sols = safe(sp.solve, exprs, variables, dict=True, check=False)
            if sols is not None:
                found_exactly = True
                for s in sols:
                    if set(s) >= set(variables):
                        candidates.append({v: s[v] for v in variables})
                    elif s:
                        # Underdetermined: some unknowns stay free.
                        res.kind = "parametric"
                        free = [v for v in variables if v not in s]
                        params = [sp.Symbol(n, real=True) for n in ["t", "s", "r"][:len(free)]]
                        mapping = dict(zip(free, params))
                        vals = tuple(sp.sympify(s.get(v, v)).xreplace(mapping) for v in variables)
                        res.parametric = (vals, params)
                        return res
    valid, rejected = [], []
    for c in candidates:
        if not _real_point(c):
            continue
        c = {k: (sp.re(v) if not sp.sympify(v).is_real and sp.sympify(v).is_number else v) for k, v in c.items()}
        c = {k: (safe(sp.simplify, v) or v) if sp.count_ops(v) > 3 else v for k, v in c.items()}
        ok, reason, exact = check_point(c, leaves, conditions)
        if ok:
            valid.append(_simplest(c, leaves, conditions))
            res.exact = res.exact and exact
        else:
            # Only report rejected values that solve the equations (true extraneous solutions),
            # or that fail the domain; values failing an inequality are simply filtered out.
            eq_ok = all(compare("=", sp.sympify(lf.lhs).subs(c), sp.sympify(lf.rhs).subs(c)).value
                        for lf in eqs)
            dom = first_violation(substitute(conditions, c))
            if dom is not None or not eq_ok or not ineqs:
                rejected.append((c, reason))
    # Numerical search: fallback, and a check for solutions solve() missed.
    if len(exprs) == len(variables) and len(variables) <= 3:
        num = safe(numeric.multistart, exprs, variables, box) or []
        for p in num:
            sol = dict(zip(variables, p))
            if any(all(abs(float(sp.N(q[v])) - float(sol[v])) < 1e-9 * max(1, abs(float(sol[v])))
                       for v in variables) for q in valid + [r for r, _ in rejected]):
                continue
            ok, _, _ = check_point(sol, leaves, conditions)
            if not ok:
                continue
            named = {v: (numeric.recognize(sol[v]) or [None])[0] for v in variables}
            if all(n is not None for n in named.values()):
                good, _, ex = check_point(named, leaves, conditions)
                if good and ex:
                    valid.append(named)
                    continue
            valid.append(sol)
            res.exact = False
        if not found_exactly:
            res.complete = False
            res.notes.append(f"No exact method worked; the solutions were searched for numerically with "
                             f"every unknown between {box[0]:g} and {box[1]:g}.")
    elif not found_exactly:
        res.complete = False
    res.solutions = _dedupe(valid, variables)
    res.solutions.sort(key=lambda s: tuple(float(sp.N(s[v])) for v in variables))
    res.rejected = rejected
    return res


def corner_points(ineqs: list[Leaf], variables, conditions) -> list[dict]:
    """Intersections of pairs of boundary curves that lie in the closed region."""
    if len(ineqs) > 8:
        return []
    closed = [Leaf(lf.lhs, {"<": "<=", ">": ">="}.get(lf.op, lf.op), lf.rhs) for lf in ineqs]
    out = []
    for i in range(len(ineqs)):
        for j in range(i + 1, len(ineqs)):
            a, b = ineqs[i].expr, ineqs[j].expr
            if not all(safe(lambda e=e: sp.Poly(e, *variables).total_degree() <= 2) for e in (a, b)):
                continue
            sols = safe(sp.solve, [a, b], variables, dict=True) or []
            for s in sols:
                if set(s) != set(variables) or not _real_point(s):
                    continue
                ok, _, _ = check_point(s, closed, conditions)
                if ok:
                    out.append(s)
    out = _dedupe(out, variables)
    out.sort(key=lambda s: tuple(float(sp.N(s[v])) for v in variables))
    return out


def region_truth(leaves: list[Leaf], point: dict) -> bool | None:
    rel = sp.And(*[lf.relation().subs(point) for lf in leaves])
    return truth_of(rel).value
