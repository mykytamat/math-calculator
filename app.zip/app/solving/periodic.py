"""Periodic solution sets: {r + P·k : k ∈ ℤ} and unions of such intervals.

A `PeriodicSet` is a period P together with a `base` set inside [0, P); the
whole set is base + P·ℤ. Equations give a finite base (residues), inequalities
a union of intervals. For display the period is reduced to the smallest one,
each family gets a representative in (−P/2, P/2], families r and −r are
merged (±r + Pk), and intervals that wrap around the window edge are joined:
cos x > 1/2 is (−π/3 + 2πk, π/3 + 2πk), not [0, π/3) ∪ (5π/3, 2π).
"""
from __future__ import annotations

from functools import lru_cache

import sympy as sp

from ..core.decide import sign_of
from ..core.format import tex

MAX_TILES = 64        # most copies of a base set when changing to a common period
MAX_ENUMERATED = 2000  # most members listed for a bounded interval


class NotRepresentable(Exception):
    pass


# ------------------------------------------------------------ exact helpers --
def cmp(a, b) -> int:
    """Exact comparison of two real numbers: -1, 0 or 1."""
    d = sp.sympify(a) - sp.sympify(b)
    if d.is_zero:
        return 0
    if d.is_positive:
        return 1
    if d.is_negative:
        return -1
    s = sign_of(d)
    if s.sign is None:
        raise NotRepresentable(f"can't compare {a} and {b}")
    return s.sign


def floor_div(a, p) -> sp.Integer:
    """floor(a / p), exact."""
    q = sp.simplify(sp.sympify(a) / p)
    f = sp.floor(q)
    if not f.is_Integer:
        f = sp.Integer(int(sp.floor(sp.N(q, 50))))
    # Guard against rounding at exact multiples.
    if cmp(f * p, a) > 0:
        f -= 1
    elif cmp((f + 1) * p, a) <= 0:
        f += 1
    return f


def ceil_div(a, p) -> sp.Integer:
    f = floor_div(a, p)
    return f if cmp(f * p, a) == 0 else f + 1


def residue(a, p):
    """a mod p in [0, p)."""
    r = sp.sympify(a) - floor_div(a, p) * p
    return sp.nsimplify(r) if r.is_Float else r


def pieces(s: sp.Set):
    """The points and intervals of a finite union, in no particular order."""
    s = sp.sympify(s)
    if s == sp.S.EmptySet:
        return []
    if isinstance(s, sp.FiniteSet):
        return [("pt", p) for p in s]
    if isinstance(s, sp.Interval):
        return [("iv", s)]
    if isinstance(s, sp.Union):
        out = []
        for a in s.args:
            out += pieces(a)
        return out
    raise NotRepresentable(f"not a finite union of intervals: {s}")


@lru_cache(maxsize=4096)
def translate(s: sp.Set, d) -> sp.Set:
    parts = []
    for kind, v in pieces(s):
        if kind == "pt":
            parts.append(sp.FiniteSet(v + d))
        else:
            parts.append(sp.Interval(v.start + d, v.end + d, v.left_open, v.right_open))
    return sp.Union(*parts) if parts else sp.S.EmptySet


@lru_cache(maxsize=4096)
def to_window(s: sp.Set, p) -> sp.Set:
    """Reduce a bounded set modulo p into [0, p)."""
    parts = []
    for kind, v in pieces(s):
        if kind == "pt":
            parts.append(sp.FiniteSet(residue(v, p)))
            continue
        if cmp(v.end - v.start, p) >= 0:
            return sp.Interval.Ropen(0, p)
        k = floor_div(v.start, p)
        lo, hi = v.start - k * p, v.end - k * p
        if cmp(hi, p) <= 0:
            if cmp(hi, p) == 0 and not v.right_open:
                parts.append(sp.Interval(lo, p, v.left_open, True))
                parts.append(sp.FiniteSet(0))
            else:
                parts.append(sp.Interval(lo, hi, v.left_open, v.right_open))
        else:
            parts.append(sp.Interval(lo, p, v.left_open, True))
            parts.append(sp.Interval(0, hi - p, False, v.right_open))
    return sp.Union(*parts) if parts else sp.S.EmptySet


@lru_cache(maxsize=4096)  # pure, slow (SymPy set algebra) and asked about the same sets repeatedly
def same_set(a: sp.Set, b: sp.Set) -> bool:
    if a == b:
        return True
    return sp.Complement(a, b) == sp.S.EmptySet and sp.Complement(b, a) == sp.S.EmptySet


def ratio(p, q) -> sp.Rational | None:
    r = sp.nsimplify(sp.simplify(sp.sympify(p) / q))
    return r if r.is_Rational and r > 0 else None


def lcm_period(p, q):
    r = ratio(p, q)
    if r is None:
        return None
    return q * r.p  # p/q = a/b in lowest terms -> lcm = a·q = b·p


# ------------------------------------------------------------------ the set --
class PeriodicSet:
    def __init__(self, period, base: sp.Set):
        self.period = sp.sympify(period)
        self.base = sp.sympify(base)

    def __repr__(self):
        return f"PeriodicSet({self.period}, {self.base})"

    # ---- construction ----
    @classmethod
    def from_residues(cls, points, period) -> "PeriodicSet":
        base = sp.FiniteSet(*[residue(p, period) for p in points])
        return cls(period, base).reduced()

    @classmethod
    def from_set(cls, s: sp.Set, period) -> "PeriodicSet":
        """s is any bounded set; it is reduced modulo the period."""
        return cls(period, to_window(s, period)).reduced()

    @classmethod
    def from_sympy(cls, s) -> "PeriodicSet | None":
        """A union of ImageSets {a·n + b : n ∈ ℤ} (as returned by solveset)."""
        fams = []
        for part in (s.args if isinstance(s, sp.Union) else [s]):
            if not isinstance(part, sp.ImageSet) or len(part.lamda.variables) != 1 \
                    or part.base_sets[0] != sp.S.Integers:
                return None
            n = part.lamda.variables[0]
            e = sp.expand(part.lamda.expr)
            a, b = e.coeff(n, 1), e.coeff(n, 0)
            if not (a.is_number and b.is_number) or a == 0 or sp.simplify(e - a * n - b) != 0:
                return None
            fams.append((b, abs(a)))
        if not fams:
            return None
        period = fams[0][1]
        for _, a in fams[1:]:
            period = lcm_period(period, a)
            if period is None:
                return None
        pts = []
        for b, a in fams:
            r = ratio(period, a)
            if r is None or r > MAX_TILES:
                return None
            pts += [b + j * a for j in range(int(r))]
        return cls.from_residues(pts, period)

    # ---- basic properties ----
    @property
    def is_empty(self) -> bool:
        return self.base == sp.S.EmptySet

    @property
    def points_only(self) -> bool:
        return isinstance(self.base, sp.FiniteSet) or self.base == sp.S.EmptySet

    @property
    def is_everything(self) -> bool:
        return same_set(self.base, sp.Interval.Ropen(0, self.period))

    def contains(self, value) -> bool:
        return bool(self.base.contains(residue(value, self.period)) == sp.true)

    def reduced(self) -> "PeriodicSet":
        """The same set with the smallest period that is a whole fraction of this one."""
        if self.is_empty:
            return self
        if self.is_everything:
            return PeriodicSet(self.period, sp.Interval.Ropen(0, self.period))
        n = len(pieces(self.base))
        # The window edge can split one piece in two, so the count need not divide evenly.
        candidates = range(n, 1, -1) if self.points_only else range(min(2 * n, 24), 1, -1)
        for m in candidates:
            if self.points_only and n % m:
                continue
            step = self.period / m
            if same_set(to_window(translate(self.base, step), self.period), self.base):
                p = self.period / m
                return PeriodicSet(p, sp.Intersection(self.base, sp.Interval.Ropen(0, p)))
        return self

    def tiled(self, period) -> sp.Set:
        """The base expanded to the window [0, period) of a multiple of the period."""
        r = ratio(period, self.period)
        if r is None or not r.is_Integer or r > MAX_TILES:
            raise NotRepresentable("periods don't fit")
        return sp.Union(*[translate(self.base, j * self.period) for j in range(int(r))])

    # ---- set operations ----
    def _common(self, other: "PeriodicSet"):
        L = lcm_period(self.period, other.period)
        if L is None:
            raise NotRepresentable("the periods have no common multiple")
        return L, self.tiled(L), other.tiled(L)

    def intersect(self, other):
        if isinstance(other, PeriodicSet):
            L, a, b = self._common(other)
            return PeriodicSet(L, sp.Intersection(a, b)).reduced()
        other = sp.sympify(other)
        if other == sp.S.Reals:
            return self
        lo, hi = other.inf, other.sup
        if lo == -sp.oo or hi == sp.oo:
            raise NotRepresentable("unbounded")
        return sp.Intersection(self.enumerate_in(sp.Interval(lo, hi)), other)

    def union(self, other: "PeriodicSet") -> "PeriodicSet":
        L, a, b = self._common(other)
        return PeriodicSet(L, sp.Union(a, b)).reduced()

    def complement_within(self, other: "PeriodicSet") -> "PeriodicSet":
        """other \\ self."""
        L, a, b = self._common(other)
        return PeriodicSet(L, sp.Complement(b, a)).reduced()

    def enumerate_in(self, interval: sp.Interval) -> sp.Set:
        """All members inside a bounded interval, as an ordinary set."""
        a, b = interval.start, interval.end
        P = self.period
        out = []
        count = 0
        for kind, v in pieces(self.base):
            lo = v if kind == "pt" else v.start
            hi = v if kind == "pt" else v.end
            k0 = floor_div(a - hi, P)
            k1 = ceil_div(b - lo, P)
            if k1 - k0 > MAX_ENUMERATED:
                raise NotRepresentable("too many")
            for k in range(int(k0), int(k1) + 1):
                if kind == "pt":
                    out.append(sp.FiniteSet(v + k * P))
                else:
                    out.append(sp.Interval(v.start + k * P, v.end + k * P, v.left_open, v.right_open))
                count += 1
        return sp.Intersection(sp.Union(*out), interval) if out else sp.S.EmptySet

    # ---- display ----
    def families(self):
        """(points, intervals) for display: points are (rep, pm) with pm=True for ±rep;
        intervals are (lo, hi, lo_closed, hi_closed), each shifted near zero."""
        P = self.period
        half = P / 2
        pts, ivs = [], []
        parts = pieces(self.base)
        raw_iv = sorted([v for k, v in parts if k == "iv"], key=lambda iv: float(iv.start))
        raw_pt = [v for k, v in parts if k == "pt"]
        # Join an interval that starts at 0 with one that ends at P (wrap-around).
        if len(raw_iv) >= 2 and raw_iv[0].start == 0 and not raw_iv[0].left_open \
                and cmp(raw_iv[-1].end, P) == 0:
            first, last = raw_iv[0], raw_iv[-1]
            raw_iv = raw_iv[1:-1] + [sp.Interval(last.start - P, first.end, last.left_open, first.right_open)]
        elif len(raw_iv) == 1 and raw_iv[0].start == 0 and not raw_iv[0].left_open \
                and cmp(raw_iv[0].end, P) == 0:
            pass  # the whole line except possibly points: shown as is
        for iv in raw_iv:
            mid = (iv.start + iv.end) / 2
            shift = 0
            if cmp(mid, half) > 0:
                shift = -P
            elif cmp(mid, -half) <= 0:
                shift = P
            ivs.append((iv.start + shift, iv.end + shift, not iv.left_open, not iv.right_open))
        reps = []
        for r in raw_pt:
            rep = r - P if cmp(r, half) > 0 else r
            reps.append(sp.nsimplify(rep) if rep.is_Float else rep)
        used = set()
        for rep in sorted(reps, key=lambda v: (abs(float(v)), float(v))):
            if rep in used:
                continue
            neg = -rep
            if rep != 0 and cmp(rep, half) != 0 and any(cmp(neg, o) == 0 for o in reps if o not in used and o != rep):
                other = next(o for o in reps if o != rep and cmp(neg, o) == 0)
                used |= {rep, other}
                pts.append((abs(rep), True))
            else:
                used.add(rep)
                pts.append((rep, False))
        pts.sort(key=lambda t: float(t[0]))
        ivs.sort(key=lambda t: float(t[0]))
        return pts, ivs

    def term(self, rep, k: sp.Symbol, pm: bool = False) -> str:
        step = tex(self.period * k)
        if rep == 0:
            return step
        r = (r"\pm " if pm else "") + tex(rep)
        return f"{r} + {step}"

    def latex_equation(self, var: str, k: sp.Symbol) -> str:
        """x = π/6 + 2πk or x = 5π/6 + 2πk,  k ∈ ℤ"""
        pts, ivs = self.families()
        parts = [f"{var} = " + self.term(rep, k, pm) for rep, pm in pts]
        parts += [self._interval_relation(iv, var, k) for iv in ivs]
        return r" \;\text{or}\; ".join(parts) + r",\quad " + tex(k) + r" \in \mathbb{Z}"

    def latex_set(self, var: str, k: sp.Symbol) -> str:
        """x ∈ (π/6 + 2πk, 5π/6 + 2πk), k ∈ ℤ   (intervals and points)"""
        pts, ivs = self.families()
        parts = []
        for lo, hi, lc, hc in ivs:
            lb = r"\left[" if lc else r"\left("
            rb = r"\right]" if hc else r"\right)"
            parts.append(f"{lb}{self.term(lo, k)}, {self.term(hi, k)}{rb}")
        for rep, pm in pts:
            parts.append(r"\left\{" + self.term(rep, k, pm) + r"\right\}")
        return f"{var} \\in " + r" \cup ".join(parts) + r",\quad " + tex(k) + r" \in \mathbb{Z}"

    def _interval_relation(self, iv, var, k) -> str:
        lo, hi, lc, hc = iv
        op1 = r"\le" if lc else "<"
        op2 = r"\le" if hc else "<"
        return f"{self.term(lo, k)} {op1} {var} {op2} {self.term(hi, k)}"

    def latex_inequality(self, var: str, k: sp.Symbol) -> str:
        """π/6 + 2πk < x < 5π/6 + 2πk,  k ∈ ℤ"""
        return self.latex_equation(var, k)


def k_symbol(used_names: set[str]) -> sp.Symbol:
    for name in ("k", "n", "m", "j"):
        if name not in used_names:
            return sp.Symbol(name, integer=True)
    return sp.Symbol("k_1", integer=True)
