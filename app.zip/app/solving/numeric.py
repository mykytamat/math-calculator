"""Numerical root finding, used as a fallback and as an independent check.

* `scan_roots` samples a function on a fine grid, brackets every sign change,
  looks for touching roots (local minima of |g| that reach zero), and refines
  each root to 30 digits with mpmath. Poles are rejected: a sign change where
  |g| blows up is not a root.
* `recognize` tries to name a decimal exactly (0.5235987… → π/6). The caller
  must still prove the guess by substitution before calling it exact.
* `multistart` solves systems from a grid of starting points.
"""
from __future__ import annotations

import itertools
import math
import warnings

import mpmath
import numpy as np
import sympy as sp

DIGITS = 30
GRID = 20001
MAX_ROOTS = 400


# ------------------------------------------------------------ evaluation ----
def vectorized(expr, x):
    """f(array) -> float array, NaN where the expression is undefined or not real."""
    expr = sp.sympify(expr)
    try:
        f = sp.lambdify(x, expr, modules="numpy")
    except Exception:
        f = None

    def call(xs):
        xs = np.asarray(xs, dtype=float)
        if f is not None:
            try:
                with np.errstate(all="ignore"), warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    ys = f(xs)
                ys = np.broadcast_to(np.asarray(ys), xs.shape)
                if np.iscomplexobj(ys):
                    # Real only if the imaginary part is negligible relative to the value itself.
                    ys = np.where(np.abs(ys.imag) <= 1e-9 * np.abs(ys.real), ys.real, np.nan)
                ys = ys.astype(float)
                return np.where(np.isfinite(ys), ys, np.nan)
            except Exception:
                pass
        g = scalar(expr, x)
        return np.array([g(v) for v in xs], dtype=float)
    return call


def scalar(expr, x):
    """f(float) -> float (NaN where undefined), via plain math, else mpmath."""
    expr = sp.sympify(expr)
    try:
        f = sp.lambdify(x, expr, modules="math")
    except Exception:
        f = None
    m = precise(expr, x)

    def call(v):
        if f is not None:
            try:
                y = f(v)
                if isinstance(y, complex):
                    return y.real if abs(y.imag) <= 1e-9 * abs(y.real) else math.nan
                y = float(y)
                return y if math.isfinite(y) else math.nan
            except (ValueError, ZeroDivisionError, OverflowError, TypeError):
                return math.nan
            except Exception:
                pass
        y = m(v)
        return float(y) if y is not None else math.nan
    return call


def precise(expr, x):
    """f(mpf) -> mpf or None (undefined / not real), at DIGITS digits."""
    expr = sp.sympify(expr)
    try:
        f = sp.lambdify(x, expr, modules="mpmath")
    except Exception:
        f = None

    def call(v):
        with mpmath.workdps(DIGITS + 10):
            try:
                if f is not None:
                    y = f(mpmath.mpf(v))
                elif expr.has(sp.Derivative, sp.Integral):
                    return None
                else:
                    y = sp.N(expr.subs(x, sp.Float(str(v), DIGITS)), DIGITS)
                    y = mpmath.mpmathify(complex(y)) if not y.is_real else mpmath.mpf(str(y))
            except (ValueError, ZeroDivisionError, OverflowError, TypeError, ArithmeticError):
                return None
            except Exception:
                return None
            if isinstance(y, mpmath.mpc):
                if abs(y.imag) > mpmath.mpf(10) ** (-DIGITS) * abs(y.real):
                    return None
                y = y.real
            try:
                y = mpmath.mpf(y)
            except (TypeError, ValueError):
                return None
            if not mpmath.isfinite(y):
                return None
            return y
    return call


# ------------------------------------------------------------ root finding --
def _bisect(fm, a, b, fa_sign) -> mpmath.mpf | None:
    with mpmath.workdps(DIGITS + 10):
        a, b = mpmath.mpf(a), mpmath.mpf(b)
        for _ in range(120):
            m = (a + b) / 2
            fm_ = fm(m)
            if fm_ is None:
                return None
            if fm_ == 0:
                return m
            if (fm_ > 0) == (fa_sign > 0):
                a = m
            else:
                b = m
            if abs(b - a) < mpmath.mpf(10) ** (-DIGITS - 2) * max(1, abs(a)):
                break
        return (a + b) / 2


def scan_roots(expr, x, lo: float, hi: float, n: int = GRID) -> list[sp.Float]:
    """Real roots of expr in [lo, hi], each to about 30 digits."""
    expr = sp.sympify(expr)
    if x not in expr.free_symbols:
        return []
    f = vectorized(expr, x)
    fm = precise(expr, x)
    xs = np.linspace(lo, hi, n)
    ys = f(xs)
    fin = np.isfinite(ys)
    if not fin.any():
        return []
    roots: list = []

    def accept(r, scale) -> bool:
        if r is None:
            return False
        v = fm(r)
        if v is None:
            return False
        return abs(v) <= mpmath.mpf(10) ** (-DIGITS + 8) * max(1, scale)

    # Exact zeros on the grid and sign changes.
    zero = fin & (ys == 0)
    # A run of exact zeros is a stretch where g vanishes (floor(x) = 2), not a root.
    isolated = zero.copy()
    isolated[1:] &= ~zero[:-1]
    isolated[:-1] &= ~zero[1:]
    for i in np.nonzero(isolated)[0][:MAX_ROOTS]:
        r = mpmath.mpf(float(xs[i]))
        try:
            with mpmath.workdps(DIGITS + 10):
                r = mpmath.findroot(lambda t: fm(t) if fm(t) is not None else mpmath.mpf(1), r, tol=mpmath.mpf(10) ** (-2 * DIGITS))
        except Exception:
            pass
        if accept(r, 1.0):
            roots.append(r)
    both = fin[:-1] & fin[1:]
    sc = np.nonzero(both & (np.sign(ys[:-1]) * np.sign(ys[1:]) < 0))[0]
    for i in sc[:MAX_ROOTS]:
        a, b = float(xs[i]), float(xs[i + 1])
        r = _bisect(fm, a, b, ys[i])
        scale = max(abs(ys[i]), abs(ys[i + 1]))
        # A pole flips the sign too: there |g| grows instead of reaching zero.
        if r is not None and accept(r, min(scale, 1.0)):
            roots.append(r)
    # Touching roots: local minima of |g| that come close to zero without a sign change.
    a_ = np.abs(ys)
    mins = np.nonzero(fin[1:-1] & fin[:-2] & fin[2:] & (a_[1:-1] <= a_[:-2]) & (a_[1:-1] <= a_[2:])
                      & (np.sign(ys[:-2]) == np.sign(ys[2:])))[0] + 1
    dexpr = sp.diff(expr, x)
    if len(mins) and not dexpr.has(sp.Derivative):
        local = np.array([np.nanmax(a_[max(0, i - 6):i + 7]) for i in mins])
        mins = mins[(a_[mins] < 0.2 * local) & (a_[mins] > 0)]
        dm = precise(dexpr, x)
        for i in mins[:MAX_ROOTS]:
            r = None
            try:
                with mpmath.workdps(DIGITS + 10):
                    r = mpmath.findroot(lambda t: dm(t) if dm(t) is not None else mpmath.mpf(1),
                                        mpmath.mpf(float(xs[i])), tol=mpmath.mpf(10) ** (-2 * DIGITS))
                if abs(r - float(xs[i])) > 4 * (hi - lo) / n:
                    r = None
            except Exception:
                r = None
            if accept(r, 1.0):
                roots.append(r)
    roots = [_polish(fm, r) for r in roots]
    roots = [r for r in roots if r is not None]
    roots.sort()
    out: list = []
    for r in roots:
        if out and abs(r - out[-1]) <= mpmath.mpf(10) ** (-12) * max(1, abs(r)):
            continue
        out.append(r)
    return [sp.Float(mpmath.nstr(r, DIGITS), DIGITS) for r in out if lo - 1e-12 <= r <= hi + 1e-12]


def _polish(fm, r):
    """Refine a root to full precision. At a multiple root g and g' both vanish,
    so Newton's method on g alone stalls; the root of g' is used there."""
    with mpmath.workdps(DIGITS + 10):
        h = mpmath.mpf(10) ** (-DIGITS // 2)

        def g(t):
            v = fm(t)
            return v if v is not None else mpmath.mpf(1)
        try:
            d = (g(r + h) - g(r - h)) / (2 * h)
        except Exception:
            return r
        scale = max(abs(g(r + 1e-3)), abs(g(r - 1e-3)), mpmath.mpf(10) ** -30)
        try:
            if abs(d) * 1e-3 > 1e-6 * scale:
                new = mpmath.findroot(g, r, tol=mpmath.mpf(10) ** (-DIGITS - 5), verify=False)
            else:
                def dg(t):
                    return (g(t + h) - g(t - h)) / (2 * h)
                new = mpmath.findroot(dg, r, tol=mpmath.mpf(10) ** (-DIGITS - 5), verify=False)
        except Exception:
            return r
        new = mpmath.mpf(new.real if isinstance(new, mpmath.mpc) else new)
        if abs(new - r) > 1e-6 * max(1, abs(r)):
            return r
        v_new, v_old = fm(new), fm(r)
        if v_new is None:
            return r
        if v_old is None or abs(v_new) <= abs(v_old) * 10:
            return new
        return r


# -------------------------------------------------------------- recognize ---
_CONSTANTS = [[], [sp.pi], [sp.E], [sp.sqrt(2)], [sp.sqrt(3)], [sp.sqrt(5)], [sp.log(2)], [sp.log(3)],
              [sp.log(5)], [sp.log(10)]]


def simple(e) -> bool:
    e = sp.sympify(e)
    if e.has(sp.Float) or sp.count_ops(e) > 14:
        return False
    for r in e.atoms(sp.Rational):
        if abs(r.p) > 10000 or r.q > 10000:
            return False
    return True


def recognize(value) -> list[sp.Expr]:
    """Simple exact numbers that `value` (a 30-digit Float) might be."""
    v = sp.Float(value, DIGITS)
    out = []
    near = sp.Integer(round(float(v)))
    if abs(v - near) < sp.Float(10) ** -20 * max(1, abs(v)):
        out.append(near)
    for consts in _CONSTANTS:
        try:
            c = sp.nsimplify(v, consts, tolerance=sp.Float(10) ** -20 * max(1, abs(float(v))))
        except Exception:
            continue
        if c not in out and simple(c) and abs(sp.N(c, DIGITS) - v) < sp.Float(10) ** -18 * max(1, abs(v)):
            out.append(c)
    return out


# ---------------------------------------------------------------- systems ---
def multistart(exprs, variables, box=(-10.0, 10.0), per_axis: int | None = None) -> list[tuple]:
    """Real solutions of exprs = 0 (as many equations as unknowns), found by
    damped Newton steps in floating point from a grid of starting points, then
    polished to 30 digits with mpmath."""
    n = len(variables)
    if len(exprs) != n or n == 0:
        return []
    per_axis = per_axis or {1: 25, 2: 9, 3: 5}.get(n, 3)
    fs = [scalar_multi(e, variables) for e in exprs]

    def F(v):
        return [f(*v) for f in fs]

    lo, hi = box
    axis = [lo + (hi - lo) * (i + 0.5) / per_axis for i in range(per_axis)]
    found: list = []
    for start in itertools.product(axis, repeat=n):
        v = list(start)
        ok = False
        for _ in range(60):
            r = F(v)
            if any(math.isnan(t) for t in r):
                break
            norm = max(abs(t) for t in r)
            if norm < 1e-13:
                ok = True
                break
            J = []
            for j in range(n):
                h = 1e-7 * max(1.0, abs(v[j]))
                w = list(v)
                w[j] += h
                rj = F(w)
                if any(math.isnan(t) for t in rj):
                    w[j] -= 2 * h
                    rj = F(w)
                    h = -h
                if any(math.isnan(t) for t in rj):
                    J = None
                    break
                J.append([(a - b) / h for a, b in zip(rj, r)])
            if J is None:
                break
            try:
                step = np.linalg.solve(np.array(J).T, -np.array(r))
            except np.linalg.LinAlgError:
                break
            lam = 1.0
            step = [float(t) for t in step]
            while lam > 1e-4:
                w = [a + lam * b for a, b in zip(v, step)]
                rw = F(w)
                if not any(math.isnan(t) for t in rw) and max(abs(t) for t in rw) < norm:
                    break
                lam /= 2
            else:
                break
            v = w
            if max(abs(t) for t in v) > 1e8:
                break
        if not ok:
            continue
        if any(max(abs(a - b) for a, b in zip(v, f)) < 1e-8 * max(1.0, max(abs(t) for t in v)) for f in found):
            continue
        found.append(v)
    return [_polish_point(exprs, variables, v) for v in found]


def scalar_multi(expr, variables):
    try:
        f = sp.lambdify(variables, expr, modules="math")
    except Exception:
        return lambda *v: math.nan

    def call(*v):
        try:
            y = f(*v)
            if isinstance(y, complex):
                return y.real if abs(y.imag) <= 1e-9 * abs(y.real) else math.nan
            y = float(y)
            return y if math.isfinite(y) else math.nan
        except (ValueError, ZeroDivisionError, OverflowError, TypeError):
            return math.nan
    return call


def _polish_point(exprs, variables, v) -> tuple:
    try:
        F = sp.lambdify(variables, list(exprs), modules="mpmath")
        with mpmath.workdps(DIGITS + 10):
            sol = mpmath.findroot(lambda *a: F(*a), [mpmath.mpf(t) for t in v],
                                  tol=mpmath.mpf(10) ** (-2 * DIGITS), maxsteps=20, verify=False)
            vals = [sol] if len(variables) == 1 else [sol[i] for i in range(len(variables))]
            vals = [mpmath.mpf(t.real if isinstance(t, mpmath.mpc) else t) for t in vals]
            if max(abs(a - b) for a, b in zip(vals, v)) > 1e-6 * max(1, max(abs(t) for t in v)):
                raise ValueError
    except Exception:
        vals = [mpmath.mpf(t) for t in v]
    return tuple(sp.Float(mpmath.nstr(t, DIGITS), DIGITS) for t in vals)
