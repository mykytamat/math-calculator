"""Deciding comparisons between exact numbers.

SymPy leaves things like Eq(log(16)/log(2), 4) unevaluated. `compare` first
tries to prove the answer exactly (simplification, SymPy's assumptions), then
falls back to high-precision evaluation. A sign found numerically is still
reliable when the difference is far from zero; only when the difference is
indistinguishable from zero without a proof is the result flagged as not
exact.
"""
from __future__ import annotations

from dataclasses import dataclass

import sympy as sp

# |difference| below this, at 60 digits of working precision, is treated as zero.
ZERO_TOL = sp.Float("1e-45")


@dataclass
class Sign:
    sign: int | None   # -1, 0, 1, or None if undecidable (e.g. not real)
    exact: bool        # True if proven; False if zero was assumed numerically


def sign_of(value) -> Sign:
    v = sp.sympify(value)
    if v.is_zero:
        return Sign(0, True)
    if v.is_positive:
        return Sign(1, True)
    if v.is_negative:
        return Sign(-1, True)
    if v.free_symbols:
        return Sign(None, True)
    s = sp.simplify(v)
    if s.is_zero:
        return Sign(0, True)
    if s.is_positive:
        return Sign(1, True)
    if s.is_negative:
        return Sign(-1, True)
    try:
        n = sp.N(s, 60)
    except Exception:
        return Sign(None, True)
    if n.has(sp.nan, sp.zoo) or not n.is_number:
        return Sign(None, True)
    re, im = n.as_real_imag()
    if abs(im) > ZERO_TOL:
        return Sign(None, True)  # not a real number
    if abs(re) > ZERO_TOL:
        return Sign(1 if re > 0 else -1, True)
    # Looks like zero but could not be proven: try a structural simplification once more.
    for f in (sp.nsimplify, sp.radsimp, sp.sqrtdenest, sp.logcombine):
        try:
            t = sp.simplify(f(s))
        except Exception:
            continue
        if t.is_zero:
            return Sign(0, True)
    return Sign(0, False)


@dataclass
class Truth:
    value: bool | None
    exact: bool


def compare(op: str, a, b) -> Truth:
    """Decide `a op b` for numbers a, b. op is one of = != < <= > >=."""
    a, b = sp.sympify(a), sp.sympify(b)
    if a.has(sp.oo, -sp.oo) or b.has(sp.oo, -sp.oo):
        r = {"=": sp.Eq, "!=": sp.Ne, "<": sp.Lt, "<=": sp.Le, ">": sp.Gt, ">=": sp.Ge}[op](a, b)
        if r in (sp.true, sp.false):
            return Truth(bool(r), True)
    s = sign_of(a - b)
    if s.sign is None:
        return Truth(None, s.exact)
    v = {"=": s.sign == 0, "!=": s.sign != 0, "<": s.sign < 0, "<=": s.sign <= 0,
         ">": s.sign > 0, ">=": s.sign >= 0}[op]
    return Truth(v, s.exact)


def truth_of(cond) -> Truth:
    """Decide a SymPy boolean (relations combined with And/Or) without free symbols."""
    cond = sp.sympify(cond)
    if cond is sp.true:
        return Truth(True, True)
    if cond is sp.false:
        return Truth(False, True)
    if isinstance(cond, sp.And):
        exact = True
        for c in cond.args:
            t = truth_of(c)
            exact = exact and t.exact
            if t.value is False:
                return Truth(False, t.exact)
            if t.value is None:
                return Truth(None, exact)
        return Truth(True, exact)
    if isinstance(cond, sp.Or):
        exact = True
        unknown = False
        for c in cond.args:
            t = truth_of(c)
            exact = exact and t.exact
            if t.value is True:
                return Truth(True, t.exact)
            if t.value is None:
                unknown = True
        return Truth(None if unknown else False, exact)
    if isinstance(cond, sp.Not):
        t = truth_of(cond.args[0])
        return Truth(None if t.value is None else not t.value, t.exact)
    if isinstance(cond, sp.core.relational.Relational):
        op = {sp.Eq: "=", sp.Ne: "!=", sp.StrictLessThan: "<", sp.LessThan: "<=",
              sp.StrictGreaterThan: ">", sp.GreaterThan: ">="}.get(type(cond))
        if op is None:
            return Truth(None, True)
        return compare(op, cond.lhs, cond.rhs)
    return Truth(None, True)
