"""User-defined functions: collecting their cases from the input.

A function can be written
  * in one line:                 f(x) = x^2 + 1
  * one case per line:           f(x) = 0 if 0 < x < 1      (and `otherwise`)
  * as a cases block (visual):   f(x) = {0 if 0<x<1; 1 + f(log2 x) if x >= 1}
  * with point values:           f(0) = 1   together with   f(n) = n f(n-1)
All definition lines of one function are merged, wherever they appear in the
input. Point values are checked first, then the cases with conditions, then
`otherwise` (an unconditional line next to point values counts as otherwise).
"""
from __future__ import annotations

from dataclasses import dataclass, field

import sympy as sp

from ..parsing import A, MathError
from ..parsing.names import FUNCTIONS
from ..parsing.to_sympy import CasesObj, Condition, Converter, symbol
from .format import tex


@dataclass
class Definition:
    """One definition line as parsed, before conversion."""
    name: str
    params: list[str] | None      # None for a point value such as f(0) = 1
    point_args: list[A.Node] | None
    rhs: A.Node
    guarded: bool                 # written with `if ...` or `otherwise`
    cond: A.Node | None           # the condition (None for `otherwise` or unguarded)
    node: A.Node = None


def definition_head(node: A.Node) -> Definition | None:
    """If node is `f(x, y) = ...` / `f(0) = ...` (optionally with `if`/`otherwise`), describe it."""
    stmt = node
    cond = None
    guarded = False
    if isinstance(node, A.Conditional):
        cond = node.cond
        guarded = True
        node = node.value
    if not (isinstance(node, A.Rel) and node.ops == ["="] and len(node.items) == 2):
        return None
    lhs, rhs = node.items
    if not (isinstance(lhs, A.Call) and lhs.name not in FUNCTIONS and lhs.primes == 0):
        return None
    if all(isinstance(a, A.Name) and a.name not in ("pi", "e", "inf") for a in lhs.args):
        names = [a.name for a in lhs.args]
        if len(set(names)) != len(names):
            return None
        return Definition(lhs.name, names, None, rhs, guarded, cond, stmt)
    if all(_is_closed(a) for a in lhs.args) and not guarded:
        return Definition(lhs.name, None, list(lhs.args), rhs, False, None, stmt)
    return None


def _is_closed(node: A.Node) -> bool:
    """No variables inside (numbers and constants only)."""
    return not any(isinstance(n, A.Name) and n.name not in ("pi", "e", "inf")
                   or isinstance(n, A.Call) for n in A.walk(node))


@dataclass
class Case:
    value: sp.Expr                  # may contain calls of user functions
    kind: str                       # "point" | "cond" | "otherwise" | "always"
    cond: sp.Basic | None = None    # for "cond" (and "point" once params are known)
    point: tuple | None = None      # argument values of a point case
    conditions: list[Condition] = field(default_factory=list)  # domain conditions of value

    def condition(self, params) -> sp.Basic:
        if self.kind == "point":
            return sp.And(*[sp.Eq(p, v) for p, v in zip(params, self.point)])
        if self.kind == "cond":
            return self.cond
        return sp.true


ORDER = {"point": 0, "cond": 1, "otherwise": 2, "always": 2}


@dataclass
class FunctionDef:
    name: str
    params: list[sp.Symbol] | None
    cases: list[Case] = field(default_factory=list)
    nodes: list[A.Node] = field(default_factory=list)

    @property
    def arity(self) -> int:
        if self.params is not None:
            return len(self.params)
        return len(self.cases[0].point)

    def ordered(self) -> list[Case]:
        return sorted(self.cases, key=lambda c: ORDER[c.kind])

    @property
    def piecewise(self) -> bool:
        return not (len(self.cases) == 1 and self.cases[0].kind == "always")

    def body(self) -> sp.Expr:
        """The definition as one SymPy expression (Piecewise when there are cases)."""
        cases = self.ordered()
        if not self.piecewise:
            return cases[0].value
        return sp.Piecewise(*[(c.value, c.condition(self.params)) for c in cases])

    def guarded_conditions(self) -> list[Condition]:
        """Every case's domain conditions, each applying only where its case is used."""
        out = []
        ordered = self.ordered()
        for i, c in enumerate(ordered):
            if c.kind in ("otherwise", "always"):
                earlier = [o.condition(self.params) for o in ordered[:i]]
                guard = sp.And(*[sp.Not(e) for e in earlier]) if earlier else sp.true
            else:
                guard = c.condition(self.params)
            for k in c.conditions:
                out.append(Condition(k.rel, k.expr, k.what, k.latex, guard, k.custom))
        return out

    def calls(self) -> set[str]:
        out = set()
        for c in self.cases:
            for f in sp.sympify(c.value).atoms(sp.core.function.AppliedUndef):
                out.add(f.func.__name__)
        return out

    def coverage(self) -> sp.Set | None:
        """The set of arguments some case applies to (one-variable functions only)."""
        if self.arity != 1:
            return None
        if any(c.kind in ("otherwise", "always") for c in self.cases):
            return sp.S.Reals
        x = self.params[0]
        s = sp.S.EmptySet
        try:
            for c in self.cases:
                s = s.union(sp.Intersection(c.condition(self.params).as_set(), sp.S.Reals)
                            if c.kind == "cond" else sp.FiniteSet(*c.point))
        except Exception:
            return None
        return s.subs(x, x)

    def head_latex(self) -> str:
        args = ", ".join(tex(p) for p in self.params)
        return f"{_name_tex(self.name)}\\left({args}\\right)"

    def latex(self) -> str:
        """The definition as written (SymPy's Piecewise would turn a last
        `x > 0` into `otherwise`, so the cases are printed directly)."""
        cases = self.ordered()
        if not self.piecewise:
            return f"{self.head_latex()} = {tex(cases[0].value)}"
        rows = []
        for c in cases:
            cond = r"\text{otherwise}" if c.kind in ("otherwise", "always") \
                else r"\text{if } " + tex(c.condition(self.params))
            rows.append(f"{tex(c.value)} & {cond}")
        return f"{self.head_latex()} = " + r"\begin{cases}" + r" \\ ".join(rows) + r"\end{cases}"


def _name_tex(name: str) -> str:
    return name if len(name) == 1 else r"\operatorname{" + name + "}"


class FunctionTable:
    """All functions defined in one input."""

    def __init__(self, log_base: int = 10):
        self.log_base = log_base
        self.functions: dict[str, FunctionDef] = {}
        self.notes: dict[str, list[str]] = {}

    def converter(self, names: set[str]) -> Converter:
        return Converter(self.log_base, set(names))

    def add(self, d: Definition, names: set[str]) -> FunctionDef:
        conv = self.converter(names | {d.name})
        params = [symbol(p) for p in d.params] if d.params is not None else None
        new_cases: list[Case] = []
        if d.point_args is not None:
            point = tuple(sp.simplify(conv.expr(a)) for a in d.point_args)
            if any(p.free_symbols for p in point):
                raise MathError(f"The arguments of {d.name}(…) = … must be numbers or variables.")
            value_conv = self.converter(names | {d.name})
            value = value_conv.expr(d.rhs)
            new_cases.append(Case(value, "point", point=point, conditions=list(value_conv.conditions)))
        elif d.guarded:
            # The condition is converted separately: its own requirements (e.g. log in
            # "if log(x) > 0") only decide whether the case applies.
            cond = None if d.cond is None else conv.condition(d.cond)
            value_conv = self.converter(names | {d.name})
            value = value_conv.expr(d.rhs)
            new_cases.append(Case(value, "otherwise" if cond is None else "cond", cond=cond,
                                  conditions=list(value_conv.conditions)))
        else:
            rhs = conv.convert(d.rhs)
            if isinstance(rhs, CasesObj):
                for (value, cond), conds in zip(rhs.branches, rhs.branch_conditions):
                    if not isinstance(value, sp.Expr):
                        raise MathError(f"Each case of {d.name} must be an expression.")
                    new_cases.append(Case(value, "otherwise" if cond is None else "cond", cond=cond,
                                          conditions=list(conds)))
            else:
                if not isinstance(rhs, sp.Expr):
                    raise MathError(f"The right-hand side of the definition of {d.name} must be an expression.")
                new_cases.append(Case(rhs, "always", conditions=list(conv.conditions)))

        fd = self.functions.get(d.name)
        if fd is None:
            fd = self.functions[d.name] = FunctionDef(d.name, params)
        elif params is not None:
            if fd.params is None:
                fd.params = params
            elif fd.params != params:
                if len(fd.params) != len(params):
                    raise MathError(f"{d.name} is defined with different numbers of variables.")
                mapping = dict(zip(params, fd.params))
                new_cases = [_rename(c, mapping) for c in new_cases]
        if fd.cases and fd.arity != (len(params) if params is not None else len(new_cases[0].point)):
            raise MathError(f"{d.name} is defined with different numbers of variables.")
        fd.cases.extend(new_cases)
        fd.nodes.append(d.node)
        self._check_shape(fd)
        return fd

    def _check_shape(self, fd: FunctionDef):
        kinds = [c.kind for c in fd.cases]
        if kinds.count("always") > 1:
            raise MathError(f"{fd.name} is defined twice. Give each line a condition with 'if', "
                            "or remove one of them.")
        if kinds.count("always") + kinds.count("otherwise") > 1:
            raise MathError(f"{fd.name} has more than one 'otherwise' case.")
        if "always" in kinds and "cond" in kinds:
            raise MathError(f"{fd.name} has cases with conditions and also a line without a condition. "
                            "Write 'otherwise' on the line that covers the rest.")

    def finalize(self) -> dict[str, Exception]:
        """Fill in missing parameter names and collect notes about each definition.
        Returns {function name: error} for definitions that are contradictory."""
        errors = {}
        for fd in list(self.functions.values()):
            if fd.params is None:  # only point values, e.g. f(0) = 1
                fd.params = [symbol("x")] if fd.arity == 1 else [symbol(f"x_{i + 1}") for i in range(fd.arity)]
            for c in fd.cases:
                if c.kind == "always" and len(fd.cases) > 1:
                    c.kind = "otherwise"  # f(0) = 1 next to f(n) = n f(n-1)
            try:
                self.notes[fd.name] = self._notes(fd)
            except MathError as e:
                errors[fd.name] = e
                del self.functions[fd.name]
        return errors

    def _notes(self, fd: FunctionDef) -> list[str]:
        notes = []
        cov = fd.coverage()
        if cov is not None and cov != sp.S.Reals and not fd.calls() & {fd.name}:
            notes.append(f"The cases cover ${_set_tex(cov)}$; {fd.name} is undefined elsewhere.")
        elif cov is not None and cov != sp.S.Reals:
            notes.append(f"The cases cover ${_set_tex(cov)}$.")
        notes.extend(self._overlaps(fd))
        return notes

    def _overlaps(self, fd: FunctionDef) -> list[str]:
        """Cases whose conditions overlap must agree there."""
        if fd.arity != 1:
            return []
        out = []
        conds = [(i, c) for i, c in enumerate(fd.cases) if c.kind in ("cond", "point")]
        for a in range(len(conds)):
            for b in range(a + 1, len(conds)):
                ca, cb = conds[a][1], conds[b][1]
                try:
                    sa = ca.condition(fd.params).as_set() if ca.kind == "cond" else sp.FiniteSet(*ca.point)
                    sb = cb.condition(fd.params).as_set() if cb.kind == "cond" else sp.FiniteSet(*cb.point)
                    both = sp.Intersection(sa, sb)
                except Exception:
                    continue
                if both is sp.S.EmptySet or both == sp.S.EmptySet:
                    continue
                if fd.name in fd.calls():
                    out.append(f"Two cases overlap on ${_set_tex(both)}$; they are checked to agree "
                               "whenever that part is evaluated.")
                    continue
                if not _agree(ca.value, cb.value, fd.params[0], both):
                    raise MathError(f"Two cases of {fd.name} overlap on ${_set_tex(both)}$ and give "
                                    "different values there. Make the conditions exclusive, e.g. use < in one.")
        return out

    def recursive_names(self) -> set[str]:
        """Functions that (directly or through others) call themselves."""
        graph = {n: fd.calls() & set(self.functions) for n, fd in self.functions.items()}
        out = set()
        for start in graph:
            seen, stack = set(), list(graph[start])
            while stack:
                n = stack.pop()
                if n == start:
                    out.add(start)
                    break
                if n not in seen:
                    seen.add(n)
                    stack.extend(graph.get(n, ()))
        return out


def _rename(c: Case, mapping) -> Case:
    return Case(c.value.subs(mapping, simultaneous=True), c.kind,
                None if c.cond is None else c.cond.subs(mapping, simultaneous=True), c.point,
                [k.subs(mapping) for k in c.conditions])


def _agree(v1, v2, x, where: sp.Set) -> bool:
    if isinstance(where, sp.FiniteSet):
        return all(sp.simplify(v1.subs(x, p) - v2.subs(x, p)) == 0 for p in where)
    return sp.simplify(v1 - v2) == 0


def _set_tex(s: sp.Set) -> str:
    from .format import set_latex
    return set_latex(s)


def collect_definitions(stmts: list[A.Node], log_base: int = 10, skip: set[int] = frozenset()):
    """First pass over an input: build the function table.

    Returns (table, where, errors): `where` maps the index of each definition
    line to its function, `errors` maps a line index to the error it caused.
    Lines in `skip` are not definitions (the Equations tab: `f(x) = 3` after f
    is defined is an equation)."""
    from ..parsing import ParseError
    heads = [(i, None if i in skip else definition_head(s)) for i, s in enumerate(stmts)]
    names = {d.name for _, d in heads if d is not None}
    table = FunctionTable(log_base)
    where: dict[int, FunctionDef] = {}
    errors: dict[int, Exception] = {}
    for i, d in heads:
        if d is None:
            continue
        try:
            where[i] = table.add(d, names)
        except (MathError, ParseError) as e:
            errors[i] = e
    for name, e in table.finalize().items():
        first = min(i for i, fd in where.items() if fd.name == name)
        errors.setdefault(first, e)
        for i in [i for i, fd in where.items() if fd.name == name]:
            del where[i]
    return table, where, errors
