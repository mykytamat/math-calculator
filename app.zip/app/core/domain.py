"""Domain conditions: checking them at a point and explaining violations."""
from __future__ import annotations

import sympy as sp

from ..parsing.to_sympy import Condition
from .decide import truth_of
from .format import tex


def substitute(conditions: list[Condition], subs: dict) -> list[Condition]:
    return [c.subs(subs) for c in conditions]


def first_violation(conditions: list[Condition]) -> tuple[Condition, bool] | None:
    """Return the first condition that is definitely false (and whether that was
    decided exactly). Conditions that still contain variables are skipped."""
    for c in conditions:
        if c.expr.free_symbols:
            continue
        g = sp.sympify(c.guard)
        if g.free_symbols:
            continue
        if g is not sp.true:
            tg = truth_of(g)
            if tg.value is not True:
                continue  # this branch is not the active one
        t = truth_of(c.as_relational())
        if t.value is False:
            return c, t.exact
    return None


def explain(c: Condition, exact: bool = True) -> str:
    """Human explanation with $...$ math, e.g.
    "the argument of $\\log_{2}$ must be positive, but here it equals $-2$"."""
    if c.rel == "case":
        args = ", ".join(tex(sp.simplify(a)) for a in c.expr)
        return (f"${c.what}\\left({args}\\right)$ is undefined: ${args}$ is outside every case "
                f"of {c.what} ({c.latex}).")
    value = sp.simplify(c.expr)
    msg = f"{c.what} {c.requirement_text()}, but here it equals ${tex(value)}$"
    if c.latex and c.latex.strip() != tex(value) and not _is_plain_number(c.latex):
        msg += f" (${c.latex}$)"
    if not exact:
        msg += " (decided numerically: the value is zero to 45 digits but could not be proven exactly)"
    return msg[0].upper() + msg[1:] + "."


def _is_plain_number(latex: str) -> bool:
    s = latex.replace("-", "", 1).replace(".", "", 1)
    return s.isdigit()


def requirements_note(conditions: list[Condition]) -> str | None:
    """List the domain requirements of a symbolic expression, e.g.
    "Defined only where: $x-1>0$ (argument of log₂), $x\\ne0$ (denominator)"."""
    parts = []
    seen = set()
    for c in conditions:
        if not c.expr.free_symbols:
            continue
        rel = c.as_relational()
        try:
            rel_tex = tex(rel)
        except Exception:
            continue
        if rel_tex in seen:
            continue
        seen.add(rel_tex)
        parts.append(f"${rel_tex}$ ({c.what})")
    if not parts:
        return None
    return "Defined only where " + "; ".join(parts) + "."
