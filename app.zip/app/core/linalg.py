"""Exact linear algebra, each result checked independently of how it was found.

Entries are exact (typed decimals are already fractions). Checks:
  * determinant: computed by two different algorithms (Bareiss elimination and
    Berkowitz), which must agree;
  * inverse: A·A⁻¹ = I and A⁻¹·A = I;
  * rank: equals the number of pivots of the RREF;
  * RREF: has the reduced row echelon shape and the same row space as A;
  * eigenvectors: A·v = λ·v, and the eigenvalues are roots of the
    characteristic polynomial;
  * linear systems: the solution is substituted back into A·x = b.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import sympy as sp

from ..parsing import MathError
from ..parsing.to_sympy import inverse


def _is_zero_matrix(m) -> bool:
    return all(sp.simplify(e) == 0 for e in m)


def shape_text(m) -> str:
    return f"{m.rows}×{m.cols}"


@dataclass
class Checked:
    value: object
    notes: list[str] = field(default_factory=list)
    exact: bool = True


def determinant(m) -> Checked:
    if m.rows != m.cols:
        raise MathError(f"Only square matrices have a determinant; this one is {shape_text(m)}.")
    d1 = sp.simplify(m.det(method="bareiss"))
    d2 = sp.simplify(m.det(method="berkowitz"))
    if sp.simplify(d1 - d2) != 0:
        return Checked(d1, ["Warning: two methods of computing the determinant disagree "
                            f"(${sp.latex(d1)}$ and ${sp.latex(d2)}$)."], exact=False)
    return Checked(d1, ["Computed two ways (Bareiss elimination and the Berkowitz algorithm); they agree."])


def inverse_checked(m) -> Checked:
    inv = inverse(m)
    n = m.rows
    if not (_is_zero_matrix(m * inv - sp.eye(n)) and _is_zero_matrix(inv * m - sp.eye(n))):
        return Checked(inv, ["Warning: multiplying back does not give the identity matrix."], exact=False)
    return Checked(inv, ["Checked: $A\\,A^{-1} = A^{-1}A = I$."])


def rref_checked(m) -> Checked:
    """(R, pivots) with checks."""
    R, piv = m.rref(simplify=True)
    R = sp.ImmutableMatrix(R)
    ok = _is_rref(R, piv)
    r = m.rank(simplify=True)
    same_space = len(piv) == r and sp.Matrix.vstack(m, R).rank(simplify=True) == r
    notes = []
    if ok and same_space:
        notes.append("Checked: it is in reduced row echelon form and has the same row space as the matrix "
                     "(stacking the two has the same rank).")
        return Checked((R, list(piv)), notes)
    return Checked((R, list(piv)), ["Warning: the reduced form failed its check."], exact=False)


def _is_rref(R, piv) -> bool:
    rows = R.rows
    for i, j in enumerate(piv):
        if sp.simplify(R[i, j] - 1) != 0:
            return False
        if any(sp.simplify(R[k, j]) != 0 for k in range(rows) if k != i):
            return False
        if any(sp.simplify(R[i, c]) != 0 for c in range(j)):
            return False
    for i in range(len(piv), rows):
        if any(sp.simplify(e) != 0 for e in R.row(i)):
            return False
    return list(piv) == sorted(piv)


def rank_checked(m) -> Checked:
    r = m.rank(simplify=True)
    rr = rref_checked(m)
    R, piv = rr.value
    if r != len(piv):
        return Checked(sp.Integer(r), ["Warning: the rank and the number of pivots disagree."], exact=False)
    return Checked(sp.Integer(r), [f"Equal to the number of pivots in the reduced row echelon form ({len(piv)})."])


@dataclass
class Eigen:
    value: object             # exact eigenvalue (may be complex, or a CRootOf)
    multiplicity: int
    vectors: list             # a basis of the eigenspace (only for real eigenvalues)
    real: bool
    radical: bool             # written with radicals (not a CRootOf)


@dataclass
class EigenResult:
    charpoly: sp.Expr
    lam: sp.Symbol
    items: list[Eigen]
    notes: list[str] = field(default_factory=list)
    exact: bool = True

    @property
    def diagonalizable(self) -> bool | None:
        if not all(e.real for e in self.items):
            return False
        if all(e.multiplicity == 1 for e in self.items):
            return True  # distinct real eigenvalues
        if not all(e.radical for e in self.items):
            return None
        return sum(len(e.vectors) for e in self.items) == sum(e.multiplicity for e in self.items)


def eigen(m) -> EigenResult:
    if m.rows != m.cols:
        raise MathError(f"Only square matrices have eigenvalues; this one is {shape_text(m)}.")
    n = m.rows
    lam = sp.Symbol("lambda")
    P = sp.Poly(m.charpoly(lam).as_expr(), lam)
    p = sp.factor(P.as_expr())
    items: list[Eigen] = []
    notes: list[str] = []
    exact = True
    # Roots from linear and quadratic factors are written with radicals; cubic and
    # higher factors give unreadable (Cardano) formulas, so those roots are kept as
    # exact root objects and shown as decimals.
    found = {}
    for factor, mult in sp.factor_list(P)[1]:
        if factor.degree() <= 2:
            for r, k in sp.roots(factor).items():
                found[r] = found.get(r, 0) + k * mult
        else:
            for r in factor.all_roots():
                found[r] = found.get(r, 0) + mult
    if any(r.has(sp.CRootOf) for r in found):
        notes.append("Some eigenvalues have no simple formula with radicals; they are shown as decimals "
                     "(roots of the characteristic polynomial), with eigenvectors found numerically.")
        exact = False
    checked = 0
    for v, mult in sorted(found.items(), key=lambda kv: _order(kv[0])):
        radical = not v.has(sp.CRootOf)
        real = v.is_real
        if real is None:
            try:
                real = abs(complex(sp.N(v, 30)).imag) < 1e-25
            except TypeError:  # entries with letters: assume real (letters are real numbers here)
                real = not v.has(sp.I)
        if radical and sp.expand(P.as_expr().subs(lam, v)) != 0 and sp.simplify(P.as_expr().subs(lam, v)) != 0:
            raise MathError("An eigenvalue failed its check (it is not a root of the characteristic polynomial).")
        vectors = []
        if real and radical:
            for vec in (m - v * sp.eye(n)).nullspace(simplify=True):
                vec = _nice_vector(vec)
                if not _is_zero_matrix(m * vec - v * vec):
                    raise MathError("An eigenvector failed its check A·v = λ·v.")
                vectors.append(sp.ImmutableMatrix(vec))
                checked += 1
        elif real:
            vec = _numeric_eigenvector(m, v)
            if vec is not None:
                vectors.append(vec)
        items.append(Eigen(v, mult, vectors, real, radical))
    if checked:
        notes.append("Checked: $A\\,v = \\lambda v$ for every eigenvector shown, and every eigenvalue is a root "
                     "of the characteristic polynomial.")
    if any(not e.real for e in items):
        notes.append("Complex eigenvalues are listed for completeness; their eigenvectors are not shown "
                     "(this calculator works with real numbers).")
    return EigenResult(p, lam, items, notes, exact)


def _numeric_eigenvector(m, v, digits: int = 6):
    """An eigenvector for an eigenvalue known only as a root object: the null
    vector of A − λI in floating point (largest entry scaled to 1), if A·v ≈ λ·v."""
    import numpy as np
    lam = float(sp.N(v, 30))
    M = np.array(m.evalf(30).tolist(), dtype=float) - lam * np.eye(m.rows)
    try:
        _, _, vt = np.linalg.svd(M)
    except np.linalg.LinAlgError:
        return None
    vec = vt[-1]
    vec = vec / vec[np.argmax(np.abs(vec))]
    A = np.array(m.evalf(30).tolist(), dtype=float)
    if np.max(np.abs(A @ vec - lam * vec)) > 1e-8 * max(1.0, np.max(np.abs(A))):
        return None
    return sp.ImmutableMatrix([sp.Float(float(c), digits) for c in vec])


def _order(v):
    try:
        z = complex(sp.N(v, 20))
    except TypeError:  # contains letters: keep a stable, readable order
        return (0.0, 0.0, str(v))
    return (z.real, z.imag, "")


def _nice_vector(vec):
    """Scale an eigenvector so its entries have no fractions (and radicals sit in numerators)."""
    entries = [sp.radsimp(sp.simplify(e)) for e in vec]
    dens = [sp.fraction(sp.together(e))[1] for e in entries]
    if all(d.is_Integer for d in dens):
        entries = [sp.expand(e * sp.ilcm(1, *[int(d) for d in dens])) for e in entries]
        if all(e.is_Integer for e in entries):
            g = sp.igcd(0, *[int(e) for e in entries])
            if g > 1:
                entries = [e / g for e in entries]
    return sp.Matrix(entries)


@dataclass
class LinearSolution:
    kind: str                   # "unique" | "none" | "infinite"
    solution: object = None     # column vector (may contain the parameters t_1, ...)
    params: list = field(default_factory=list)
    rref: object = None         # RREF of the augmented matrix
    pivots: list = field(default_factory=list)
    notes: list[str] = field(default_factory=list)


def solve_linear(A, b) -> LinearSolution:
    if b.cols != 1:
        raise MathError(f"The right-hand side must be a column vector; it is {shape_text(b)}.")
    if A.rows != b.rows:
        raise MathError(f"A {shape_text(A)} matrix needs a right-hand side with {A.rows} entries "
                        f"(it has {b.rows}).")
    aug = A.row_join(b)
    R, piv = aug.rref(simplify=True)
    if A.cols in piv:
        return LinearSolution("none", rref=sp.ImmutableMatrix(R), pivots=list(piv), notes=[
            "The reduced form has a row $0 = 1$ (all coefficients 0 but the right side not), so the system "
            "has no solution."])
    sol, taus = A.gauss_jordan_solve(b)
    params = [sp.Symbol(f"t_{i + 1}") for i in range(len(taus))]
    sol = sp.ImmutableMatrix(sol.xreplace(dict(zip(list(taus), params))))
    notes = []
    if _is_zero_matrix(A * sol - b):
        notes.append("Checked by substituting the solution back into the system" +
                     (" (for every value of the parameters)." if params else "."))
    else:
        notes.append("Warning: substituting the solution back does not give the right-hand side.")
    kind = "infinite" if params else "unique"
    return LinearSolution(kind, sol, params, sp.ImmutableMatrix(R), list(piv), notes)
