"""Evaluating (possibly recursive) user functions at exact arguments.

The evaluator is iterative: an explicit stack of frames instead of Python
recursion, so a chain of 1000 calls can't overflow the interpreter's stack.
Results are memoised on exact arguments, which makes tree recursion such as
Fibonacci fast.

At every call the arguments are kept exact (log2(16) is 4, not 3.9999...),
and the case is chosen with core.decide, which proves comparisons exactly
when it can and otherwise flags the decision as numerical.

It reports:
  * the value,
  * the call chain (the deepest path of calls: 16 -> 4 -> 2 -> 1 -> 0),
  * the steps in the order they were finished (f(0)=0, f(1)=1, ...),
  * why a result is undefined (no case applies, or a case's own domain fails),
  * non-termination: an exact argument repeating on the chain (a proof), or
    the depth limit being reached.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from fractions import Fraction

import sympy as sp

from ..parsing import MathError
from ..parsing.to_sympy import Condition
from .decide import sign_of, truth_of
from .domain import explain, first_violation
from .format import decimal_latex, set_latex, tex
from .functions import Case, FunctionDef, FunctionTable

AppliedUndef = sp.core.function.AppliedUndef

MAX_FRAMES = 200_000   # distinct calls evaluated in one request


def exact(e) -> sp.Expr:
    """Canonical exact form of an argument or value."""
    e = sp.sympify(e)
    if e.is_Rational or e.is_Atom:
        return e
    s = sp.simplify(e)
    if s.is_Rational or not s.is_number:
        return s
    # A number that may still be a rational in disguise, e.g. log(8)/log(4) = 3/2.
    r = _nearby_rational(s)
    if r is not None:
        sign = sign_of(s - r)
        if sign.sign == 0 and sign.exact:
            return r
    return s


def _nearby_rational(v) -> sp.Rational | None:
    """A rational with a small denominator within 1e-45 of v, if there is one."""
    try:
        n = sp.N(v, 60)
        if not n.is_real:
            return None
        cand = sp.Rational(str(n)).limit_denominator(10**6)
    except (TypeError, ValueError):
        return None
    return cand if abs(sp.N(v - cand, 60)) < sp.Float("1e-45") else None


Key = tuple  # (name, args)


@dataclass
class Step:
    name: str
    args: tuple
    case: Case
    case_index: int
    value: sp.Expr


@dataclass
class Result:
    value: sp.Expr
    chain: list[Key]          # deepest call path, top call first
    steps: list[Step]         # finished calls, in finishing order
    calls: int                # distinct calls evaluated
    numeric_decisions: list[str] = field(default_factory=list)


class Undefined(MathError):
    def __init__(self, message: str, chain: list[Key]):
        super().__init__(message)
        self.chain = chain


class NonTermination(MathError):
    def __init__(self, message: str, chain: list[Key], kind: str):
        super().__init__(message)
        self.chain = chain
        self.kind = kind  # "cycle" | "depth" | "work"


@dataclass
class _Frame:
    key: Key
    fd: FunctionDef
    case: Case | None = None
    case_index: int = -1
    exprs: list | None = None     # [value, *condition exprs] still containing calls


def short_tex(v, limit: int = 40) -> str:
    """LaTeX of a value, or its decimal approximation when the exact form is long."""
    t = tex(v)
    if len(t) <= limit:
        return t
    d = decimal_latex(v, 4)
    return r"{\approx}\," + d[0] if d else r"\ldots"


def call_tex(key: Key) -> str:
    name, args = key
    n = name if len(name) == 1 else r"\operatorname{" + name + "}"
    return n + r"\left(" + ", ".join(short_tex(a) for a in args) + r"\right)"


def args_tex(key: Key) -> str:
    return ", ".join(short_tex(a) for a in key[1])


def chain_tex(chain: list[Key], head: int = 10, tail: int = 10) -> str:
    """16 → 4 → 2 → 1 → 0 (with the function name shown when it changes).
    Long chains show only their first `head` and last `tail` calls."""
    names = {k[0] for k in chain}
    if len(chain) > head + tail + 1:
        chain_parts = chain[:head] + [None] + chain[-tail:]
    else:
        chain_parts = chain
    parts = [r"\ldots" if k is None else (call_tex(k) if len(names) > 1 else args_tex(k)) for k in chain_parts]
    return r" \to ".join(parts)


class Evaluator:
    def __init__(self, table: FunctionTable, depth_limit: int = 1000):
        self.table = table
        self.depth_limit = depth_limit
        self.memo: dict[Key, sp.Expr] = {}
        self.steps: list[Step] = []
        self.numeric: list[str] = []
        self.deepest: list[Key] = []

    # ------------------------------------------------------------------
    def key_of(self, call) -> Key:
        return (call.func.__name__, tuple(exact(a) for a in call.args))

    def evaluate(self, expr) -> Result:
        """Evaluate an expression whose calls have numeric arguments."""
        expr = sp.sympify(expr)
        self.steps, self.deepest = [], []
        for _ in range(10_000):
            calls = _innermost_calls(expr)
            if not calls:
                break
            for c in calls:
                k = self.key_of(c)
                self._run(k)
                expr = expr.xreplace({c: self.memo[k]})
        return Result(exact(expr), list(self.deepest), list(self.steps), len(self.memo),
                      list(dict.fromkeys(self.numeric)))

    # ------------------------------------------------------------------
    def _run(self, top: Key):
        if top in self.memo:
            return
        fd = self._function(top)
        stack = [_Frame(top, fd)]
        on_stack = {top: 0}
        while stack:
            fr = stack[-1]
            if len(stack) > len(self.deepest) or (stack and self.deepest[:1] != [top]):
                if len(stack) > len(self.deepest):
                    self.deepest = [f.key for f in stack]
            if fr.case is None:
                self._choose_case(fr, stack)
            pending = None
            replacements = {}
            for e in fr.exprs:
                for c in _innermost_calls(e):
                    k = self.key_of(c)
                    if k in self.memo:
                        replacements[c] = self.memo[k]
                    elif pending is None:
                        pending = k
            if replacements:
                fr.exprs = [e.xreplace(replacements) for e in fr.exprs]
                continue
            if pending is not None:
                chain = [f.key for f in stack]
                if pending in on_stack:
                    i = on_stack[pending]
                    loop = chain[i:] + [pending]
                    raise NonTermination(
                        f"${call_tex(pending)}$ never finishes: it calls itself again "
                        f"(${chain_tex(loop, 6, 3)}$), so the recursion loops forever.",
                        chain + [pending], "cycle")
                if len(stack) >= self.depth_limit:
                    raise NonTermination(
                        f"${call_tex(top)}$ was stopped after {self.depth_limit} nested calls "
                        f"(${chain_tex(chain, 6, 3)}$). The recursion does not seem to reach a base case. "
                        "You can raise the depth limit in the tab's options.",
                        chain, "depth")
                if len(self.memo) + len(stack) > MAX_FRAMES:
                    raise NonTermination(f"Gave up after {MAX_FRAMES} different calls.", chain, "work")
                stack.append(_Frame(pending, self._function(pending)))
                on_stack[pending] = len(stack) - 1
                continue
            # All calls resolved: check the case's own domain, then finish.
            value, *cond_exprs = fr.exprs
            self._check_domain(fr, cond_exprs, stack)
            value = exact(value)
            if value.has(sp.nan, sp.zoo) or (value.is_number and value.is_real is False):
                raise Undefined(self._prefix(stack) + f"${call_tex(fr.key)}$ has no real value.",
                                [f.key for f in stack])
            self.memo[fr.key] = value
            self.steps.append(Step(fr.key[0], fr.key[1], fr.case, fr.case_index, value))
            stack.pop()
            del on_stack[fr.key]

    def _function(self, key: Key) -> FunctionDef:
        name, args = key
        fd = self.table.functions.get(name)
        if fd is None:
            raise MathError(f"{name} is not defined. Define it first, for example {name}(x) = x^2.")
        if len(args) != fd.arity:
            raise MathError(f"{name} takes {fd.arity} argument(s) but was given {len(args)}.")
        for a in args:
            if a.free_symbols:
                raise MathError(f"{name} can only be evaluated at numbers here, not at ${tex(a)}$.")
        return fd

    def _choose_case(self, fr: _Frame, stack):
        fd = fr.fd
        mapping = dict(zip(fd.params, fr.key[1]))
        matches: list[tuple[int, Case]] = []
        fallback = None
        undecided = []
        rational_args = all(a.is_Rational for a in fr.key[1])
        env = {p: Fraction(int(a.p), int(a.q)) for p, a in zip(fd.params, fr.key[1])} if rational_args else None
        for i, c in enumerate(fd.ordered()):
            if c.kind in ("otherwise", "always"):
                fallback = (i, c)
                continue
            fast = _decide_fast(c.condition(fd.params), env) if rational_args else None
            if fast is not None:
                if fast:
                    matches.append((i, c))
                continue
            cond = c.condition(fd.params).subs(mapping, simultaneous=True)
            try:
                t = truth_of(cond)
            except (TypeError, ValueError):
                t = None
            if t is None or t.value is None:
                undecided.append(cond)
                continue
            if t.value:
                matches.append((i, c))
                if not t.exact:
                    self.numeric.append(f"At ${call_tex(fr.key)}$ the condition ${tex(c.condition(fd.params))}$ "
                                        "was decided numerically (the two sides agree to 45 digits).")
        if matches:
            points = [m for m in matches if m[1].kind == "point"]
            if points:
                matches = points[:1]  # a point value such as f(0) = 1 takes priority
            if len(matches) > 1:
                values = {sp.srepr(exact(m[1].value.subs(mapping, simultaneous=True))) for m in matches}
                if len(values) > 1:
                    conds = "; ".join(f"${tex(m[1].condition(fd.params))}$" for m in matches)
                    raise Undefined(self._prefix(stack) +
                                    f"${call_tex(fr.key)}$ fits more than one case ({conds}) and they give "
                                    "different formulas. Make the conditions exclusive.",
                                    [f.key for f in stack])
            chosen = matches[0]
        elif fallback is not None:
            chosen = fallback
        else:
            raise Undefined(self._no_case_message(fr, stack, undecided), [f.key for f in stack])
        fr.case_index, fr.case = chosen
        fr.exprs = [chosen[1].value.subs(mapping, simultaneous=True)] + \
                   [k.expr.subs(mapping, simultaneous=True) for k in chosen[1].conditions]

    def _check_domain(self, fr: _Frame, cond_exprs, stack):
        conds = [Condition(k.rel, e, k.what, k.latex, sp.true, k.custom)
                 for k, e in zip(fr.case.conditions, cond_exprs)]
        v = first_violation(conds)
        if v is not None:
            c, ex = v
            raise Undefined(self._prefix(stack) + f"${call_tex(fr.key)}$ is undefined: " +
                            explain(c, ex)[0].lower() + explain(c, ex)[1:], [f.key for f in stack])

    def _prefix(self, stack) -> str:
        if len(stack) <= 1:
            return ""
        chain = [f.key for f in stack]
        return (f"${call_tex(chain[0])}$ is undefined. Following the calls ${chain_tex(chain, 6, 3)}$: ")

    def _no_case_message(self, fr: _Frame, stack, undecided) -> str:
        fd = fr.fd
        cases = "; ".join(f"${tex(c.condition(fd.params))}$" for c in fd.ordered())
        args = args_tex(fr.key)
        cov = fd.coverage()
        cover = f" The cases cover ${set_latex(cov)}$." if cov is not None and cov != sp.S.Reals else ""
        if len(stack) > 1:
            parent = stack[-2].key
            core = (f"${call_tex(parent)}$ requires ${call_tex(fr.key)}$, but ${args}$ is outside "
                    f"every case of {fd.name} ({cases}).")
        else:
            core = f"${call_tex(fr.key)}$ is undefined: ${args}$ is outside every case of {fd.name} ({cases})."
        if undecided:
            core += " (Some conditions could not be decided here.)"
        return self._prefix(stack) + core + cover


# ---------------------------------------------------------------------------
# Exact fast path: conditions built only from + - * /, integer powers and
# comparisons can be decided with Python fractions, much faster than SymPy
# when the arguments are rational (factorial, Fibonacci, f(n-1), ...).
class _NotRational(Exception):
    pass


def _frac(e, env):
    if e.is_Rational:
        return Fraction(int(e.p), int(e.q))
    if e.is_Symbol:
        if e in env:
            return env[e]
        raise _NotRational
    if e.is_Add:
        return sum((_frac(a, env) for a in e.args), Fraction(0))
    if e.is_Mul:
        out = Fraction(1)
        for a in e.args:
            out *= _frac(a, env)
        return out
    if e.is_Pow and e.exp.is_Integer:
        base = _frac(e.base, env)
        if base == 0 and e.exp < 0:
            raise _NotRational
        return base ** int(e.exp)
    raise _NotRational


_REL = {sp.Eq: lambda a, b: a == b, sp.Ne: lambda a, b: a != b, sp.StrictLessThan: lambda a, b: a < b,
        sp.LessThan: lambda a, b: a <= b, sp.StrictGreaterThan: lambda a, b: a > b,
        sp.GreaterThan: lambda a, b: a >= b}


def _decide_fast(cond, env) -> bool | None:
    """Decide a condition exactly with fractions, or None if it isn't purely rational."""
    try:
        return _truth(cond, env)
    except (_NotRational, ZeroDivisionError):
        return None


def _truth(c, env) -> bool:
    if c is sp.true:
        return True
    if c is sp.false:
        return False
    if isinstance(c, sp.And):
        return all(_truth(a, env) for a in c.args)
    if isinstance(c, sp.Or):
        return any(_truth(a, env) for a in c.args)
    if isinstance(c, sp.Not):
        return not _truth(c.args[0], env)
    op = _REL.get(type(c))
    if op is None:
        raise _NotRational
    return op(_frac(c.lhs, env), _frac(c.rhs, env))


def _innermost_calls(expr) -> list:
    """Calls of user functions whose arguments contain no further calls."""
    out = []
    for f in sp.sympify(expr).atoms(AppliedUndef):
        if not any(a.has(AppliedUndef) for a in f.args):
            out.append(f)
    # Larger arguments first, so f(n-1) + f(n-2) explores n-1, n-2, ... (the natural chain).
    def order(f):
        try:
            return (0, -float(f.args[0]))
        except (TypeError, ValueError, IndexError):
            return (1, 0.0)
    out.sort(key=lambda f: (order(f), sp.default_sort_key(f)))
    return out
