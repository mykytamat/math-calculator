"""Formatting of results: exact LaTeX, decimals, and "exact ≈ decimal" lines."""
from __future__ import annotations

from decimal import MAX_EMAX, MIN_EMIN, ROUND_HALF_UP, Context, Decimal, InvalidOperation, localcontext

import sympy as sp
from sympy.printing.latex import LatexPrinter


class LogBase(sp.Function):
    """Display-only log with an explicit base: log(a)/log(b) prints as log_b(a)."""
    nargs = 2

    @classmethod
    def eval(cls, a, b):
        return None

    def _latex(self, printer):
        a, b = self.args
        base = printer._print(b)
        arg = printer._print(a)
        if a.is_Symbol or (a.is_Integer and a > 0):
            return rf"\log_{{{base}}} {arg}"
        return rf"\log_{{{base}}}\left({arg}\right)"


class RealRoot(sp.Function):
    """Display-only real n-th root: |u|^(1/n)·sign(u) prints as the n-th root of u."""
    nargs = 2

    @classmethod
    def eval(cls, u, n):
        return None

    def _latex(self, printer):
        u, n = self.args
        return rf"\sqrt[{printer._print(n)}]{{{printer._print(u)}}}"


_REL_TEX = {"<": "<", "<=": r"\le", ">": ">", ">=": r"\ge"}
_FLIP = {"<": ">", "<=": ">=", ">": "<", ">=": "<="}


def _as_lower_upper(rel):
    """For x > a / a < x style relations return (var, op, bound) normalised to
    `bound op var` with op in {<, <=}, or `var op bound` with op in {<, <=}."""
    if not isinstance(rel, (sp.StrictLessThan, sp.LessThan, sp.StrictGreaterThan, sp.GreaterThan)):
        return None
    op = {sp.StrictLessThan: "<", sp.LessThan: "<=", sp.StrictGreaterThan: ">", sp.GreaterThan: ">="}[type(rel)]
    return rel.lhs, op, rel.rhs


class _Printer(LatexPrinter):
    def __init__(self, settings=None):
        s = {"ln_notation": True, "inv_trig_style": "full", "mat_delim": "("}
        s.update(settings or {})
        super().__init__(s)

    def _print_And(self, expr):
        args = list(expr.args)
        # Merge  a < x  and  x < b  into the chain  a < x < b.
        if len(args) == 2:
            p, q = _as_lower_upper(args[0]), _as_lower_upper(args[1])
            if p and q:
                chain = _chain(p, q)
                if chain:
                    lo, op1, var, op2, hi = chain
                    return (f"{self._print(lo)} {_REL_TEX[op1]} {self._print(var)} "
                            f"{_REL_TEX[op2]} {self._print(hi)}")
        return r"\text{ and }".join(self._print_bool_arg(a) for a in args)

    def _print_Or(self, expr):
        return r"\text{ or }".join(self._print_bool_arg(a) for a in expr.args)

    def _print_bool_arg(self, a):
        s = self._print(a)
        return r"\left(" + s + r"\right)" if isinstance(a, (sp.And, sp.Or)) else s

    def _print_Piecewise(self, expr):
        rows = []
        for value, cond in expr.args:
            c = r"\text{otherwise}" if cond is sp.true else r"\text{if } " + self._print(cond)
            rows.append(self._print(value) + " & " + c)
        return r"\begin{cases}" + r" \\ ".join(rows) + r"\end{cases}"


def _chain(p, q):
    """Combine two one-sided bounds on the same variable into lo op1 var op2 hi."""
    def lower(rel):  # returns (bound, op, var) meaning bound op var with op in < <=
        a, op, b = rel
        if op in ("<", "<="):
            return (a, op, b)
        return (b, _FLIP[op], a)
    p1, q1 = lower(p), lower(q)
    # p1 = (a, op, b) means a op b. Find the shared variable.
    for first, second in ((p1, q1), (q1, p1)):
        lo, op1, var = first
        var2, op2, hi = second
        if var == var2 and not var.is_number and lo.is_number and hi.is_number:
            return lo, op1, var, op2, hi
    return None


def _prettify(expr):
    if not isinstance(expr, sp.Basic) or expr.is_Atom or isinstance(expr, sp.MatrixBase):
        return expr
    args = [_prettify(a) for a in expr.args]
    if isinstance(expr, sp.Mul):
        args = _rewrite_mul_factors(args)
        return sp.Mul(*args, evaluate=False) if len(args) > 1 else args[0]
    if isinstance(expr, sp.Add):
        return sp.Add(*args, evaluate=False)
    if isinstance(expr, sp.Pow):
        return sp.Pow(*args, evaluate=False)
    if isinstance(expr, sp.core.relational.Relational):
        # Rebuilding Eq(x^2 + y^2, -1) would evaluate it to False.
        return expr.func(*args, evaluate=False)
    try:
        return expr.func(*args)
    except Exception:
        return expr


def _rewrite_mul_factors(factors: list) -> list:
    factors = list(factors)
    # log(a) * log(b)^-1  ->  LogBase(a, b)
    inv_logs = [f for f in factors if isinstance(f, sp.Pow) and f.exp == -1 and isinstance(f.base, sp.log)
                and f.base.args[0].is_number and f.base.args[0].is_positive and f.base.args[0] != sp.E]
    if len(inv_logs) == 1:
        logs = [f for f in factors if isinstance(f, sp.log)]
        if len(logs) >= 1:
            inv, lg = inv_logs[0], logs[0]
            factors.remove(inv)
            factors.remove(lg)
            factors.append(LogBase(lg.args[0], inv.base.args[0]))
    # |u|^(1/n) * sign(u)  ->  RealRoot(u, n)
    signs = [f for f in factors if isinstance(f, sp.sign)]
    for sg in signs:
        u = sg.args[0]
        for f in factors:
            if isinstance(f, sp.Pow) and isinstance(f.base, sp.Abs) and f.base.args[0] == u \
                    and f.exp.is_Rational and f.exp.p == 1 and f.exp.q > 1:
                factors.remove(sg)
                factors.remove(f)
                factors.append(RealRoot(u, sp.Integer(f.exp.q)))
                break
    return factors


MAX_EXACT_DIGITS = 1000


def huge_number_digits(expr) -> int:
    """Number of digits of the largest integer/rational part of expr (0 if small)."""
    expr = sp.sympify(expr)
    worst = 0
    for a in expr.atoms(sp.Rational):
        for part in (a.p, a.q):
            bits = abs(int(part)).bit_length()
            if bits > MAX_EXACT_DIGITS * 3.32:
                worst = max(worst, int(bits * 0.30103) + 1)
    return worst


def tex(expr) -> str:
    """LaTeX for a SymPy object, with readable logs and real roots."""
    try:
        return _tex(expr)
    except ValueError:
        # Integers beyond Python's 4300-digit str limit: show an approximation.
        return _tex(sp.N(expr, 15))


def _tex(expr) -> str:
    if isinstance(expr, bool):
        return r"\text{true}" if expr else r"\text{false}"
    if expr is sp.true:
        return r"\text{true}"
    if expr is sp.false:
        return r"\text{false}"
    if isinstance(expr, sp.MatrixBase):
        return _Printer().doprint(expr.applyfunc(_prettify))
    return _Printer().doprint(_prettify(sp.sympify(expr)))


# ------------------------------------------------------------- decimals ----
# Decimal arithmetic with an exponent range wide enough for 10^(10^6). 32-bit builds (the
# WebAssembly version) allow exponents up to about 4*10^8 only.
_CTX = Context(prec=60, Emax=min(10**15, MAX_EMAX), Emin=max(-10**15, MIN_EMIN), rounding=ROUND_HALF_UP)


def _to_decimal(value: sp.Expr, digits: int = 50) -> Decimal | None:
    v = sp.N(value, digits)
    if not v.is_real or v in (sp.oo, -sp.oo, sp.zoo, sp.nan):
        return None
    try:
        return _CTX.create_decimal(str(v))
    except InvalidOperation:
        return None


def _sci(d: Decimal, sig: int) -> str:
    """Scientific notation in LaTeX with `sig` significant digits."""
    if d == 0:
        return "0"
    with localcontext(_CTX):
        exp = d.adjusted()
        mant = d.scaleb(-exp).quantize(Decimal(1).scaleb(-(sig - 1)))
        if abs(mant) >= 10:  # rounding overflow, e.g. 9.99995 -> 10.0000
            mant = (mant / 10).quantize(Decimal(1).scaleb(-(sig - 1)))
            exp += 1
    return f"{mant}" + r" \times 10^{" + str(exp) + "}"


def is_terminating(r: sp.Rational) -> bool:
    q = int(r.q)
    for p in (2, 5):
        while q % p == 0:
            q //= p
    return q == 1


def decimal_latex(value: sp.Expr, places: int = 4) -> tuple[str, bool] | None:
    """Decimal form of a real number.

    Returns (latex, exact) where exact means the decimal equals the value
    exactly (so it is joined with "=" rather than "≈"). None if not real.
    """
    value = sp.sympify(value)
    if value.is_Rational and not huge_number_digits(value) and is_terminating(value):
        with localcontext(_CTX):
            d = Decimal(int(value.p)) / Decimal(int(value.q))
            text = format(d.normalize(), "f")
        if "." not in text or len(text.split(".")[1]) <= max(places, 6):
            if abs(d) < Decimal("1e12"):
                return text, True
    d = _to_decimal(value)
    if d is None:
        return None
    with localcontext(_CTX):
        if d != 0 and (abs(d) < Decimal(10) ** (-places) or abs(d) >= Decimal("1e12")):
            return _sci(d, places + 1), False
        q = d.quantize(Decimal(1).scaleb(-places))
    text = format(q, "f")
    if text.startswith("-") and q == 0:
        text = text[1:]
    return text, False


MAX_TEX_CHARS = 3000


def exact_and_decimal(value: sp.Expr, places: int = 4) -> dict:
    """{"latex": "\\sqrt{7} \\approx 2.6458", "exact": "\\sqrt{7}", "decimal": "2.6458"}.

    When the exact form is too large to show (a number with thousands of
    digits), only the approximation is returned, with "too_long" explaining why.
    """
    digits = huge_number_digits(value)
    exact = None if digits else tex(value)
    if exact is not None and len(exact) > MAX_TEX_CHARS:
        exact = None
    dec = decimal_latex(value, places)
    if exact is None:
        approx = dec[0] if dec else tex(sp.N(value, places + 1))
        why = (f"The exact value has about {digits} digits, too many to show"
               if value.is_Rational else "The exact form is too long to show")
        return {"exact": None, "decimal": approx, "latex": r"\approx " + approx,
                "too_long": why + "; this is its decimal approximation."}
    out = {"exact": exact, "decimal": None, "latex": exact}
    if dec is None:
        return out
    dtext, is_exact = dec
    out["decimal"] = dtext
    if (value.is_Integer and abs(value) < 10**12) or dtext == exact:
        return out
    out["latex"] = exact + (" = " if is_exact else r" \approx ") + dtext
    return out


# ------------------------------------------------------------ sets ----------
def _interval_latex(iv: sp.Interval) -> str:
    lo, hi = iv.start, iv.end
    lb = r"\left(" if iv.left_open or lo == -sp.oo else r"\left["
    rb = r"\right)" if iv.right_open or hi == sp.oo else r"\right]"
    return f"{lb}{tex(lo)}, {tex(hi)}{rb}"


def _set_key(s):
    try:
        return float(s.inf)
    except Exception:
        return 0.0


def set_latex(s) -> str:
    """Interval notation: (-∞, 1) ∪ (3, ∞), {1, 2}, ℝ, ∅."""
    s = sp.sympify(s)
    if s == sp.S.Reals:
        return r"\mathbb{R}"
    if s == sp.S.EmptySet:
        return r"\varnothing"
    if isinstance(s, sp.Complement) and s.args[0] == sp.S.Reals and isinstance(s.args[1], sp.FiniteSet) \
            and all(p.is_real for p in s.args[1]):
        pts = sorted(s.args[1], key=float)
        parts = [sp.Interval.open(-sp.oo, pts[0])]
        parts += [sp.Interval.open(a, b) for a, b in zip(pts, pts[1:])]
        parts.append(sp.Interval.open(pts[-1], sp.oo))
        return r" \cup ".join(_interval_latex(p) for p in parts)
    if isinstance(s, sp.Interval):
        return _interval_latex(s)
    if isinstance(s, sp.FiniteSet):
        items = list(s)
        try:
            items.sort(key=float)
        except TypeError:
            pass
        return r"\left\{" + ", ".join(tex(i) for i in items) + r"\right\}"
    if isinstance(s, sp.Union):
        return r" \cup ".join(set_latex(a) for a in sorted(s.args, key=_set_key))
    return tex(s)
